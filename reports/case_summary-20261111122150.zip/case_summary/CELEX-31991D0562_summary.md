# 'IV/32.737', 'Eirpage'

**CELEX ID:** CELEX-31991D0562  
**Industry:** | industry                                    |
|:--------------------------------------------|
| Paging Services                             |
| Telecommunications                          |
| Paging Equipment Manufacturing/Distribution |  
**Cartel Period:** 1988-02-23 : 2001-07-31  

## Summary

### Celex Case Id
CELEX-31991D0562

### Case Title
Eirpage

### Overview
The European Commission investigated a joint venture between Bord Telecom Eireann, Motorola Ireland Limited, and Eirpage Limited in the telecommunications sector in Ireland. The venture involved the provision of paging services and the distribution of paging equipment. The Commission granted an exemption under Article 85(3) of the EC Treaty, with attached reporting obligations.

### Industry
Paging Services, Telecommunications, Paging Equipment Manufacturing/Distribution

### Oecd Nace
OECD: communication; NACE: 26.30 (Manufacture of communication equipment)

### Companies Undertakings
| Bord Telecom Eireann | IE |
| Motorola Ireland Limited | IE |
| Eirpage Limited | IE |

### Market
Republic of Ireland

### Cartel Period
1988-02-23 : 2001-07-31

### Key Timeline
| Event | Date |
| --- | --- |
| Joint venture agreement entered into | 1988-02-23 |
| Parties made proposals to meet Commission's objections | 1988-05-17 |
| Application for negative clearance or exemption submitted | 1988-05-17 |
| Exemption took effect after submitting required amendments and undertaking | 1990-03-26 |
| Exemption from Article 85(1) declared applicable | 1990-03-26 |
| Commission Decision issued | 1991-10-18 |
| Decision adopted | 1991-10-18 |
| Exemption period ended | 2001-07-31 |

### Legal Framework
Article 85 (operative), Article 85 (all relevant); canonical concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
medium

### Exemption
Exemption sought and granted under Article 85(3) of the EC Treaty for the joint venture.

### Leniency
NA

### Fines
NA

### Remedies
No specific decision remedies such as cease and desist orders or divestitures were ordered by the Commission to terminate an infringement. The Commission granted exemption under Article 85(3) with attached reporting obligations, but did not impose structural or behavioral remedies for an existing infringement.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) of the EC Treaty for the joint venture, with attached reporting obligations. No structural or behavioral remedies were imposed.


*(reported: 2026-10-16 20:31:45)*

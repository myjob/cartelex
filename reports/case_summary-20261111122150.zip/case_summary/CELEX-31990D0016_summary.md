# '90/16/EEC', 'concerning the provision in the Netherlands of express delivery services'

**CELEX ID:** CELEX-31990D0016  
**Industry:** | industry                |
|:------------------------|
| postal service          |
| express courier service |
| courier services        |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
NA

### Case Title
90/16/EEC, concerning the provision in the Netherlands of express delivery services

### Overview
This case concerns the Netherlands' provision of express delivery services, focusing on PTT Post BV's dominant position in the postal and courier market. The Commission found that the Netherlands had infringed Community law by allowing PTT Post BV to maintain exclusive rights to collect, transport, and distribute mail weighing up to 500 grammes within the Netherlands, which constituted an abuse of dominance.

### Industry
postal service, express courier service, courier services

### Oecd Nace
OECD sector: transport, NACE group code: 53.2: Other postal and courier activities, NACE class code: 53.20: Other postal and courier activities

### Companies Undertakings
| companies                  |
|:---------------------------|
| PTT Post BV                |
| Kingdom of the Netherlands |

### Market
Netherlands, market outside EU: False

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1954-10-26 | PTT Post BV | was granted exclusive rights to collect, transport and distribute all mail weighing up to 500 grammes within the Netherlands |
| 1988-10-26 | Dutch authorities | entered into force of the Law of 26 October 1988, regulating postal services and introducing competition |
| 1988-11-07 | Commission | expressed reservations concerning Article 12 (1) and (2) of the draft postal law |
| 1988-12-19 | Commission | sent a telex requesting further information and inviting comments on possible incompatibility with Community Law |
| 1988-12-19 | Netherlands authorities | sent the definitive version of the Law together with the minutes of the parliamentary debates |
| 1988-12-19 | PTT Post BV | reserved express collection, transport and distribution of postal items |
| 1988-12-19 | PTT Post BV | extended dominant position to express delivery market by reserving section for itself |
| 1988-12-19 | Government of the Netherlands | adopted decree fixing minimum tariffs for courier services |
| 1989-01-16 | Netherlands authorities | replied to the substance of the questions put by the Commission |
| 1989-03-01 | Netherlands | introduced measure requiring annual rate registration for private express couriers |
| 1989-05-12 | Netherlands | adopted decree defining conditions of registration for courier services |
| 1989-12-20 | Kingdom of the Netherlands | adopted this decision |

### Legal Framework
Law articles: Article 86, Article 90; Canonical concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance, member_states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Netherlands shall inform the Commission, within two months from the date of notification of this Decision, of the measures it has taken to comply therewith.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the Netherlands had infringed Community law by allowing PTT Post BV to maintain exclusive rights in the express delivery market, constituting an abuse of dominance. The remedy required the Netherlands to inform the Commission of compliance measures within two months.


*(reported: 2026-11-10 18:50:29)*

# 'IV/27.095', 'Franco-Japanese ballbearings agreement'

**CELEX ID:** CELEX-31974D0634  
**Industry:** NA  
**Cartel Period:** 1972-02 : 1972-06  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31974D0634 | IV/27095  |

### Case Title
Franco-Japanese ballbearings agreement

### Overview
This case involves a cartel agreement between French and Japanese manufacturers of ballbearings, where French companies colluded with their Japanese counterparts to fix prices and reduce imports. The infringement occurred from February to June 1972, and the European Commission took action under Article 3 of Regulation No 17, leading to a decision in November 1974.

### Industry
ballbearings, needle bearings, roller bearings, special-type bearings

### Oecd Nace
manufacturing (OECD_sector), 28.1:Manufacture of general — purpose machinery (NACE_group_code), 28.15: Manufacture of bearings, gears, gearing and driving elements (NACE_class_code)

### Companies Undertakings
| companies                                                      | location        |
|:---------------------------------------------------------------|:----------------|
| SKF                                                            | Clamart, France |
| SNR                                                            | Annecy, France  |
| Chambre syndicale nationale de la mécanique de haute précision | Paris, France   |
| Nippon Seiko Kaisha                                            | Tokyo, Japan    |
| Koyo Seiko Co. Ltd                                             | Osaka, Japan    |
| Fujikoshi Ltd                                                  | Toyama, Japan   |
| NTN Toyo Bearing Co. Ltd                                       | Osaka, Japan    |
| Japan Bearing Industrial Association                           | Tokyo, Japan    |

### Market
France, oligopoly market, no turbulence, no outside EU market

### Cartel Period
1972-02 : 1972-06

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-02-16 | French ballbearing manufacturers and their trade association | requested Japanese competitors to enter into a written agreement to increase prices of Japanese ballbearings imported into France |
| 1972-02-16 | Chambre syndicale | hosted meeting with Japanese bearing manufacturers |
| 1972-02-16 | redacted | discussed reducing imports and increasing prices with Japanese manufacturers |
| 1972-02-16 | Japanese producers | made aware of trade routing practices |
| 1972-03-10 | Japan Bearing Industrial Association | sent letter concerning ballbearing price increase |
| 1972-03-10 | Japan Association | confirmed agreement in principle to increase prices and proposed price reduction between French and Japanese bearings |
| 1972-03-10 | Japanese manufacturers | committed to raising prices of bearing exports |
| 1972-04-01 | Japanese bearing manufacturers | began implementing price increases in French market |
| 1972-04-01 | Japanese manufacturers | implemented price adjustments |
| 1972-07-26 | Chambre syndicale | met with Japanese manufacturers in Paris |
| 1973-11-14 | Commission | commenced proceedings under Article 3 of Regulation No 17 |
| 1974-11-29 | Commission | issued Decision on Franco-Japanese ballbearings agreement |

### Legal Framework
Article 85 (operative), Article 85 (all relevant), anticompetitive_agreement (canonical concept)

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Not specified in the text

### Company Recidivism
| companies | recidivism |
| --- | --- |
| SKF, Compagnie d'applications mécaniques, SA | NA |
| SNR, Société nouvelle de roulements | NA |
| Nippon Seiko Kaisha | NA |
| NTN Toyo Bearing Co. Ltd | NA |
| Koyo Seiko Co. Ltd | NA |
| Fujikoshi Ltd | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found the agreement to be in breach of Article 85, leading to a formal decision issued in November 1974.


*(reported: 2026-11-11 10:07:04)*

# 'IV/36.456/F3 — Inntrepreneur and IV/36.492/F3 — Spring', 'relating to a proceeding pursuant to Article 81 of the EC Treaty'

**CELEX ID:** CELEX-32000D0484  
**Industry:** | industry    |
|:------------|
| Brewing     |
| Wholesaling |
| Retailing   |  
**Cartel Period:** 1997-01-01 : 1998-03-28  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0484 | IV/36456  |

### Case Title
Inntrepreneur and IV/36.492/F3 — Spring

### Overview
This case involves an investigation by the European Commission into anticompetitive agreements in the UK brewing and retailing sector, specifically focusing on vertical restraints related to exclusive dealing and market foreclosure.

### Industry
Brewing, Wholesaling, Retailing

### Oecd Nace
trade (wholesaling and retailing) and hotels

NACE_group_code: 11.0:Manufacture of beverages

NACE_class_code: 11.06: Manufacture of malt

### Companies Undertakings
| company                                       |
|:----------------------------------------------|
| The Grand Pub Company Ltd                     |
| Inntrepreneur Pub Company Limited             |
| The Inntrepreneur Beer Supply Company Limited |
| Spring Inns Limited                           |

### Market
United Kingdom

market_outside_eu: True

market_oligopoly: True

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1997-03-27 | Inntrepreneur Pub Company Limited and The Inntrepreneur Beer Supply Company Limited | notified standard form tenancy agreements under Article 4 of Regulation No 17 |
| 1997-04-29 | Spring Inns Limited | notified Leases used for letting licensed premises under Article 4 of Regulation No 17 |
| 1997-09-21 | GPC | entered into agreement to acquire IPCL and Spring |
| 1998-02-09 | GPC | notified upstream beer supply agreements to the Commission |
| 1998-03-11 | Commission | issued negative clearance comfort letter to GPC |
| 1998-03-27 | GPC | exercised option to acquire share capital of IPCL and Spring |
| 1998-03-28 | GPC | introduced standard variable term lease and variable term agreement |
| 1998-03-28 | GPC | notified upstream beer supply agreements for use after date |
| 1998-03-29 | GPC | sold 310 pubs to Scottish and Newcastle plc |
| 1998-03-29 | the notifying parties | implemented multi-sourcing and periodic tendering for beer supply |
| 1999-06-29 | GPC | confirmed that it did not enforce the advertising clause |
| 2000-06-29 | Commission of the European Communities | issued Commission Decision |

### Legal Framework
Article 81

law_article_all_relevant:
| law_article   |
|:--------------|
| Article 81    |
| Article 85    |

infringement_concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
low

### Exemption
| company                                   |
|:------------------------------------------|
| Inntrepreneur Pub Company Limited         |
| In Inntrepreneur Beer Supply Company Limited |
| Spring Inns Limited                       |

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                                  | country        | jurisdiction    |
|:---------------------------------------|:---------------|:----------------|
| High Court of Justice                  | United Kingdom | England & Wales |
| Court of Justice of the European Union | European Union | European Union  |

### Book Reference
NA

### Outcome
No action was taken by the Commission, and the case is not marked as a landmark in any book.


*(reported: 2026-10-16 22:36:59)*

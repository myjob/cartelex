# 'IV/400', 'Agreements between manufacturers of glass containers'

**CELEX ID:** CELEX-31974D0292  
**Industry:** NA  
**Cartel Period:** 1960 : 1971  

## Summary

### Celex Case Id
CELEX-31974D0292

### Case Title
Agreements between manufacturers of glass containers

### Overview
This case involves a cartel among manufacturers of glass containers in the European Economic Community, where companies engaged in anticompetitive agreements including exchange of information on prices and sales. The infringement period spanned from 1960 to 1971, with significant activities documented by IFTRA representatives and signatories. The European Commission took action under Article 85 of the EEC Treaty, issuing cease and desist orders to end the infringements.

### Industry
- bottles
- jars
- flasks
- containers in hollow glass
- beverages
- food products
- chemical products
- cleaning materials
- toilet preparations
- preserved products
- pharmaceutical products
- cosmetic products

### Oecd Nace
manufacturing
23.1:Manufacture of glass and glass products
23.13: Manufacture of hollow glass

### Companies Undertakings
| Gerresheimer Glas Aktiengesellschaft | NA |
| Glashitte Achern GmbH | NA |
| Amberger Flaschenhütten GmbH | NA |
| Glashitte Budenheim GmbH | NA |
| Oldenburgische Glashütte GmbH | NA |
| Glashitte Heilbronn | NA |
| Veba-Glas AG | NA |
| Ruhrglas | NA |
| H. Heye Glasfabrik 'Schauenstein' | NA |
| Himly, Holscher & Co KG | NA |
| Bayerische Flaschen-Glashüttenwerke Wiegand & Söhne GmbH | NA |
| Carl. Aug. Heinz Glashittenwerke | NA |
| Liner Glashüttenwerke GmbH | NA |
| Glashittenwerke Ernst W. Müller GmbH | NA |
| Noelle & von Campe Glashütte GmbH | NA |
| Oberland-Glas GmbH | NA |
| Spessarter Hohlglaswerke GmbH | NA |
| Tettauer Glashüttenwerke AG | NA |
| Weck Glaswerk GmbH | NA |
| Verlica-Momignies S.A. | NA |
| Bouteilleries Belges Réunies S.A. | NA |
| N.V. Vereenigde Glasfabrieken | NA |
| Boussois-Souchon-Neuvesel (BSN) S.A. | NA |
| Saint-Gobain Emballage S.A. | NA |
| Verreries de Blanc-Misseron S.A. | NA |
| Verrerie Ouvrière d'Albi S.A. | NA |
| Verreries du Puy-de-Dome S.A. | NA |
| Bordoni Miva Vetrerie Riunite SpA | NA |
| Aziende Vetrarie Italiane Ricciardi AVIR SpA | NA |
| Vetreria Italiana VETR.I. SpA | NA

### Market
| country        |
|:---------------|
| France         |
| United Kingdom |
| Denmark        |
| Germany        |
| Belgium        |
| Netherlands    |
| Italy          |

market_oligopoly: True
market_outside_eu: false

### Cartel Period
1960 : 1971

### Key Timeline
| 1959-01-27 | IFTRA representatives | discussed fixing export prices based on domestic prices |
| 1960-01-29 | representatives of the IFTRA signatories | began holding regular meetings |
| 1960-04-28 | five French manufacturers | signed IFTRA rules for bottles |
| 1961-01-18 | IFTRA representatives | discussed fixing export prices |
| 1961-01-19 | IFTRA representatives | discussed fixing export prices |
| 1961-10-12 | IFTRA signatories | discussed exchanging price lists, discounts, and sales terms |
| 1962-01-12 | IFTRA signatories | considered communication of price information between producers |
| 1962-02-06 | Council | adopted Regulation No 17/62 |
| 1962-05-04 | IFTRA signatories | addressed exchange of information on price changes and sales terms |
| 1962-10-30 | Dr A. E. Rüdell | submitted notification concerning IFTRA rules |
| 1970-02-04 | IFTRA | decided to exchange information directly between producers |
| 1974-05-15 | Commission of the European Communities | issued Commission Decision relating to proceedings under Article 85 of the EEC Treaty

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frangois-Xavier ORTOLI

### Courts
| Court of Arbitration | Liechtenstein | International Fair Trade Practice Rules |
| European Commission | European Union | European Economic Community

### Book Reference
IV/400

### Outcome
Cease and desist orders were issued to all undertakings involved, requiring them to bring the infringements established to an immediate end. Each undertaking was ordered to take necessary steps to immediately end the infringements.


*(reported: 2026-11-11 10:05:32)*

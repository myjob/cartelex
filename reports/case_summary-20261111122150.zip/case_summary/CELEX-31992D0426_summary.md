# 'IV/32.725', 'Viho/Parker Pen'

**CELEX ID:** CELEX-31992D0426  
**Industry:** | industry         |
|:-----------------|
| writing utensils |
| office equipment |
| office supplies  |
| import-export    |  
**Cartel Period:** 1987-03-01 : 1989-09-26  

## Summary

### Celex Case Id
CELEX-31992D0426

### Case Title
IV/32.725 – Viho/Parker Pen

### Overview
This case involved anticompetitive agreements in the writing utensils industry. Companies Parker Pen Ltd, Herlitz AG, API SpA, Viho Europe BV, and Parker Pen Limited were investigated for violating Article 85 of the EEC Treaty by engaging in vertical restraints such as territorial exclusivity and parallel trade bans. The Commission found that these agreements restricted competition and imposed fines on the companies involved.

### Industry
writing utensils, office equipment, office supplies, import-export

### Oecd Nace
manufacturing, 25.7:Manufacture of cutlery, tools and general hardware, 25.73: Manufacture of tools

### Companies Undertakings
| companies          | country   |
|:-------------------|:----------|
| Parker Pen Ltd     | GB        |
| Herlitz AG         | DE        |
| API SpA            | IT        |
| Viho Europe BV     | NL        |
| Parker Pen Limited | GB        |

### Market
| country        |
|:---------------|
| United Kingdom |
| France         |
| Germany        |
| Spain          |
| Netherlands    |
| Belgium        |
| Portugal       |
| Italy          |
| Greece         |
| Denmark        |

market_outside_eu: True

### Cartel Period
1987-03-01 : 1989-09-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-08-18 | Parker and Herlitz | concluded distribution agreement with export ban |
| 1987-03-01 | Herlitz | agreement entered into force |
| 1988-05-19 | Viho Europe BV | lodged complaint against Parker Pen Limited under Article 3 (1) of Regulation No 17 |
| 1989-09-19 | Commission officials | found distribution agreement during investigation |
| 1989-09-19 | Commission | conducted investigation on premises of Herlitz |
| 1989-09-26 | Parker | sent letter to Herlitz ending illegal agreement |
| 1989-09-28 | Parker | revoked clause prohibiting exports in distribution agreement |
| 1989-10-01 | Parker | initiated new distribution agreement with retroactive effect |
| 1991-01-21 | Commission | initiated proceedings under Regulation No 17 |
| 1991-05-14 | Parker | informed exclusive distributors they were free to supply customers outside their territory |
| 1992-07-15 | Commission of the European Communities | adopted decision imposing fines on Parker Pen Ltd and Herlitz AG for Treaty infringement |
| 1992-07-15 | Commission | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Parker Pen Ltd | ECU 700 000 |
| Herlitz AG | ECU 40 000 |

### Remedies
| company        | decision_remedies                                                                                                                                                                                                                                     |
|:---------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Parker Pen Ltd | Cease and desist order not to adopt measures with the same object or effect as the infringement; revocation of the export ban clause in the distribution agreement; informing distributors they are free to supply customers outside their territory. |
| Herlitz AG     | Retroactive revision of the distribution agreement to remove the export ban clause.                                                                                                                                                                   |

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Parker Pen Ltd | False |
| Herlitz AG | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country   | jurisdiction   |
|:---------------------------------------|:----------|:---------------|
| Commission of the European Communities | Belgium   | European Union |

### Book Reference
NA

### Outcome
Commission imposed fines on Parker Pen Ltd (ECU 700,000) and Herlitz AG (ECU 40,000). Remedies included cease and desist orders, revocation of export ban clauses, and informing distributors they are free to supply customers outside their territory.


*(reported: 2026-11-11 11:36:06)*

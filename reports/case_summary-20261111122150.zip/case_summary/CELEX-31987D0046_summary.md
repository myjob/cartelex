# 'IV/30.176', 'The London Potato Futures Association Limited'

**CELEX ID:** CELEX-31987D0046  
**Industry:** commodity futures trading  
**Cartel Period:** 1986-02-01 : 1986-12-10  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0046 | IV/30176  |

### Case Title
The London Potato Futures Association Limited

### Overview
The European Commission investigated the London Potato Futures Association Limited and related entities for anticompetitive practices in commodity futures trading, specifically under Article 85 of the EC Treaty. The case involved horizontal price fixing collusion in the potato futures market.

### Industry
commodity futures trading

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 01.1: Growing of non-perennial crops
NACE class code: 01.13: Growing of vegetables and melons, roots and tubers

### Companies Undertakings
| companies                                          |
|:---------------------------------------------------|
| London Potato Futures Association Limited          |
| Association of Futures Brokers and Dealers Limited |
| International Commodities Clearing House Limited   |

### Market
United Kingdom
Market outside EU: True

### Cartel Period
1986-12-10 : 1986-12-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-09-16 | London Potato Futures Association Limited | notified Commission about articles of association and regulations |
| 1980-09-16 | London Potato Futures Association Limited | submitted notification and application for negative clearance |
| 1986-12-10 | Commission | adopted Decision addressing London Potato Futures Association Limited |
| 1986-12-10 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
Abolition of fixed minimum commission rates; free negotiation of commission rates; amendments to membership criteria to make them open and objective; requirement for the Committee to give reasons for decisions affecting members' rights; introduction of an appeal procedure for membership-related decisions; negative clearance issued by the Commission

### Company Recidivism
| companies                                 | recidivism   |
|:------------------------------------------|:-------------|
| London Potato Futures Association Limited | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85, imposing remedies to eliminate anticompetitive practices in the potato futures market. The decision included abolishing fixed minimum commission rates and introducing procedural reforms.


*(reported: 2026-10-16 19:56:41)*

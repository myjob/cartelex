# 'IV/28.812 Theal/Watts', 'NA'

**CELEX ID:** CELEX-31977D0129  
**Industry:** NA  
**Cartel Period:** 1956 : 1975  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31977D0129 | IV/28812  |

### Case Title
IV/28.812 Theal/Watts

### Overview
This case involves anticompetitive agreements in the electronics manufacturing sector, specifically vertical restraints related to territorial exclusivity and parallel trade bans. The case concerns the distribution of Watts' 'Dust Bug', 'Parostatik' Disc Preener, 'Manual Parastat', and Hi-Fi Parastat kit products.

### Industry
manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.1:Manufacture of electronic components and boards
NACE class code: 26.12: Manufacture of loaded electronic boards

### Companies Undertakings
| companies              |
|:-----------------------|
| Tepea B.V.             |
| Cecil E. Watts Ltd     |
| Theal N.V.             |
| Cecil E. Watts Limited |

### Market
Netherlands
United Kingdom

### Cartel Period
1956 : 1975

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1956-09-08 | Theal and Watts | made oral agreement |
| 1956-09-08 | Watts | appointed Theal as sole distributor for Watts products in the Netherlands |
| 1956-09-08 | Cecil E. Watts | appointed Theal as exclusive distributor in the Netherlands |
| 1963-01-24 | Theal | notified Commission |
| 1963-01-24 | Theal N.V. | notified Commission of agreement |
| 1969-04-08 | Theal | received notification of competition rules from Commission |
| 1969-04-18 | Commission | issued letter regarding exemption under Regulation No 67/67/EEC |
| 1971-11-25 | Court of Justice | ruled on exclusive distribution agreement under Article 85 of the Treaty |
| 1972-09-05 | Theal | complained about unauthorized sale of Watts products |
| 1972-11-10 | Theal | summoned Mr. Wilkes for trademark infringement |
| 1975-07-11 | Theal and Watts | became aware of grant |
| 1976-12-21 | Commission | issued decision in case |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Tepea B.V. | 10 000 units of account, that is 36 200 Dutch guilders |
| Cecil E. Watts Limited | 10 000 units of account, that is 4 166 pounds sterling |
| Tepea B.V. | 5 000 units of account, that is 18 100 Dutch guilders |

### Remedies
The undertakings shall bring the infringement referred to in Article 1 (1) to an end without delay. In particular these undertakings shall refrain from all further action of any kind calculated to prevent the importation into or resale in the Netherlands of any Watts products.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Tepea B.V. | False |
| Cecil E. Watts Limited | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
R. VOUEL

### Courts
| court                       | country        | jurisdiction                |
|:----------------------------|:---------------|:----------------------------|
| Leeuwarden District Court   | Netherlands    | Netherlands                 |
| District Court of Rotterdam | Netherlands    | Netherlands                 |
| District Court of Amsterdam | Netherlands    | Netherlands                 |
| District Court of the Hague | Netherlands    | Netherlands                 |
| European Court of Justice   | European Union | European Economic Community |

### Book Reference
NA

### Outcome
The Commission found that the undertakings had engaged in anticompetitive agreements under Article 85, resulting in a high gravity infringement. Fines were imposed on Tepea B.V. and Cecil E. Watts Limited, and remedies required the cessation of actions preventing importation or resale of Watts products in the Netherlands.


*(reported: 2026-11-11 10:16:40)*

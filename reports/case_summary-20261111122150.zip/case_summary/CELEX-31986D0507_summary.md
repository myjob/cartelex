# 'IV/31.362', "Irish Banks' Standing Committee"

**CELEX ID:** CELEX-31986D0507  
**Industry:** banking  
**Cartel Period:** 1984-10-15 : 1986-09-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31986D0507 | IV/31362  |

### Case Title
Irish Banks' Standing Committee

### Overview
The European Commission investigated the Irish Banks' Standing Committee and several major Irish banks for engaging in anticompetitive agreements under Article 85 of the EC Treaty. The investigation focused on horizontal restraints that affected banking services and direct debits.

### Industry
banking

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 64.1:Monetary intermediation
NACE class code: 64.11: Central banking

### Companies Undertakings
| companies                       |
|:--------------------------------|
| Irish Banks' Standing Committee |
| Allied Irish Banks plc          |
| Bank of Ireland                 |
| Northern Bank Ltd               |
| Ulster Bank Ltd                 |
| Midland Bank plc                |
| National Westminster Bank plc   |

### Market
Ireland
Oligopoly
NA

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | European Communities | adopted Council Regulation No 17 |
| 1985-05-31 | Central Bank | issued press release setting out new arrangements for Associated Banks' interest rates |
| 1986-09-30 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
None

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Commission of the European Communities | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission decided not to take action, and no formal decision was issued.


*(reported: 2026-10-16 20:13:16)*

# 'IV/26.912', 'Hennessy-Henkell'

**CELEX ID:** CELEX-31980D1333  
**Industry:** cognac  
**Cartel Period:** 1960-02-25 : 1974-11-15  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D1333 | IV/26912  |

### Case Title
Hennessy-Henkell

### Overview
The European Commission investigated Jas Hennessy & Co. (Ireland) and Henkell & Co. (Germany) for entering into anticompetitive agreements in the cognac market, including exclusive concession agreements and resale price maintenance. The infringement occurred from 1960 to 1974.

### Industry
cognac

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.01: Distilling, rectifying and blending of spirits

### Companies Undertakings
| company            |
|:-------------------|
| Jas Hennessy & Co. |
| Henkell & Co.      |

### Market
Germany

### Cartel Period
1960-02-25 : 1974-11-15

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1960-02-25 | Hennessy and Henkell | entered into exclusive concession agreement |
| 1960-02-25 | Hennessy and Henkell | entered into agreement fixing retail prices by agreement |
| 1971-02-23 | Jas Hennessy & Co. and Henkell & Co. | concluded exclusive concession agreement |
| 1971-04-20 | Hennessy and Henkell | was notified of exclusive concession agreement |
| 1971-07-01 | Hennessy and Henkell | exclusive concession agreement took effect |
| 1974-11-15 | Hennessy and Henkell | amended agreement to restrict competition |
| 1975-03-24 | Commission | requested information from Hennessy |
| 1975-04-18 | Hennessy | responded to Commission's request for information |
| 1978-07-29 | Jas Hennessy | applied for individual decision under Article 85(3) |
| 1980-05-08 | Commission | initiated proceedings |
| 1980-12-11 | Commission | adopted decision requiring parties to terminate infringements |
| 1980-12-11 | Commission | issued decision relating to exclusive concession agreement |

### Legal Framework
Article 85 (operative article)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure;Territorial Exclusivity / Parallel Trade Bans;Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
Jas Hennessy & Co. applied for individual decision under Article 85(3)

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist from applying the restrictive clauses in Articles 5 (4) and 6 of the exclusive concession agreement, specifically the provision protecting Henkell against parallel imports and the restriction on Henkell’s freedom to fix resale prices. The parties must bring the infringements to an end by deleting these clauses, thereby conforming to Regulation No 67/67/EEC.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Jas Hennessy & Co. | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission adopted a decision requiring the parties to terminate the infringements by deleting the restrictive clauses in their exclusive concession agreement, thereby conforming to Regulation No 67/67/EEC.


*(reported: 2026-11-11 10:34:54)*

# 'IV/31043', 'Tetra Pak II'

**CELEX ID:** CELEX-31992D0163  
**Industry:** | industry         |
|:-----------------|
| Rex              |
| Non-asepticbrick |
| Asepticbrick     |
| Machine          |
| Others           |  
**Cartel Period:** 1975-10-30 : 1983-09-19  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31992D0163 | IV/31043-2 |

### Case Title
Tetra Pak II

### Overview
The case concerns Tetra Pak International SA and its subsidiaries for abuse of dominance in the market for aseptic brick cartons and related machinery, specifically involving discriminatory pricing and contractual clauses that were found to be abusive.

### Industry
Rex, Non-asepticbrick, Asepticbrick, Machine, Others

### Oecd Nace
manufacturing, 22.2:Manufacture of plastics products, 22.22: Manufacture of plastic packing goods

### Companies Undertakings
| companies                  |
|:---------------------------|
| Tetra Pak International SA |
| Tetra Pak Italiana SpA     |
| Elopak Italia SRL          |
| Elopak Italia              |
| Tetra Pak Italiana         |
| Tetra Pak Carta            |
| Elopak                     |

### Market
Belgium/Luxembourg, France, Italy, Netherlands, Germany, Portugal, Denmark, Ireland, Greece, United Kingdom; oligopoly market; no turbulence

### Cartel Period
1975-10-30 : 1983-09-19

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-10-30 | Tetra Pak | offered discounted aseptic machine to influence purchase decision |
| 1981-12-04 | Tetra Pak Italiana | informed Tetra Pak of efforts to remove Resolvo machines and suggested pressure on Kornas Marma |
| 1981-12-11 | Tetra Pak Italiana | purchased Systempak/Resolvo machines and committed to return others |
| 1983-09-27 | Tetra Pak | filed complaint regarding pricing policies in Italy |
| 1983-09-27 | Elopak Italia | filed a complaint with the Commission |
| 1988-12-09 | Tetra Pak | initiated investigation |
| 1988-12-09 | Tetra Pak | initiated proceedings in case |
| 1991-02-01 | Tetra Pak | submitted final undertakings |
| 1991-02-01 | Tetra Pak Group Management | filed legal case regarding price index adjustments |
| 1991-07-24 | Commission | issued Commission Decision |
| 1992-01-01 | Tetra Pak | commenced compliance reporting to Commission |

### Legal Framework
Article 86, abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought: True; Applicants: NA

### Leniency
Leniency case: False; Applicants: NA; Granted: NA; Rejected: NA

### Fines
| company | amount |
| --- | --- |
| Tetra Pak | ECU 75 000 000 |

### Remedies
1. Tetra Pak shall amend or delete from its machine purchase/lease contracts and carton supply contracts the clauses listed under numbers (i) to (xxvii) so as to eliminate the aspects which have been found by the Commission to be abusive;
2. Tetra Pak shall ensure that any differences between the prices charged for its products in the various Member States result solely from the specific market conditions;
3. Tetra Pak shall not practice predatory or discriminatory prices and shall not grant to any customer any form of discount on its products or more favourable payment terms not justified by an objective consideration;
4. Tetra Pak may not refuse orders, at prevailing prices, on the ground that the orderer is not an end-user of Tetra Pak products;
5. Tetra Pak shall inform any customer purchasing or leasing a machine of the specifications which packaging cartons must meet in order to be used on its machines.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Tetra Pak | True |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Sir Leon Brittan

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-11-11 11:33:55)*

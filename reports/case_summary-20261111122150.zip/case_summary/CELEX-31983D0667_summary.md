# 'IV/30.671', 'IPTC Belgium'

**CELEX ID:** CELEX-31983D0667  
**Industry:** Household electrical appliances  
**Cartel Period:** 1978 : 1980-05-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0667 | IV/30671  |

### Case Title
IV/30.671 – IPTC Belgium

### Overview
The European Commission investigated an anticompetitive agreement involving IPTC Belgium and several other companies in the household electrical appliances industry, specifically related to horizontal restraints such as market sharing and quota cartels.

### Industry
Household electrical appliances

### Oecd Nace
OECD sector: manufacturing
NACE group code: 27.5: Manufacture of domestic appliances
NACE class code: 27.51: Manufacture of electric domestic appliances

### Companies Undertakings
| companies                                |
|:-----------------------------------------|
| IPTC Belgium                             |
| Robert Bosch SA/NV                       |
| ANSEAU-NAVEWA                            |
| UFARAL-ULEVO                             |
| Association nationale des services d'eau |
| Allumalux                                |
| CEG                                      |
| IPTC Belgium SA                          |

### Market
Belgium

### Cartel Period
1978 : 1980-05-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-12-13 | unknown | Agreement signed |
| 1980-06-01 | IPTC | stopped applying Agreement |
| 1983-12-05 | IPTC Belgium | fined by Commission |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| IPTC Belgium | 5000 ECU |

### Remedies
A fine of 5,000 ECU (Bfrs 229,502) was imposed on IPTC Belgium under Article 15(2) of Regulation No 17.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| IPTC Belgium | NA |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
IPTC Belgium was fined 5,000 ECU for participating in an anticompetitive agreement under Article 85.


*(reported: 2026-11-11 10:48:06)*

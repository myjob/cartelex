# 'IV/C/31.163', 'Extra alloy'

**CELEX ID:** CELEX-31985D0121  
**Industry:** air transport  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0121 | IV/31163  |

### Case Title
Extra alloy

### Overview
This case involved a complaint filed by the Association des Compagnie Aériennes de la Communauté alleging abuse of dominant position by Olympic Airways AE. The European Commission issued a decision under Article 11(5) of Council Regulation No 17 on 1985-01-23.

### Industry
air transport

### Oecd Nace
OECD sector: transport
NACE group code: 52.2: Support activities for transportation
NACE class code: 52.23: Service activities incidental to air transportation

### Companies Undertakings
| companies                                            |
|:-----------------------------------------------------|
| Olympic Airways AE                                   |
| Association des Compagnie Aériennes de la Communauté |

Countries:
- Olympic Airways AE: GR
- Association des Compagnie Aériennes de la Communauté: FR

### Market
Greece
Outside EU: False
Oligopoly: False
Turbulence: NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-02-28 | Association des Compagnie Aériennes de la Communauté | filed complaint alleging abuse of dominant position |
| 1985-01-23 | Commission | issued decision relating to proceeding under Article 11 (5) of Council Regulation No 17 |

### Legal Framework
Article 86
Infringement concept: abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
Olympic Airways must provide the requested information within four weeks of notification. Failure to comply results in a periodic penalty payment of 1000 ECU per day, and potential fines of up to 5000 ECU.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
| court                                        | country    | jurisdiction         |
|:---------------------------------------------|:-----------|:---------------------|
| Court of Justice of the European Communities | Luxembourg | European Communities |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 11(5) of Council Regulation No 17, ordering Olympic Airways to provide requested information within four weeks, with penalties for non-compliance.


*(reported: 2026-11-11 10:55:55)*

# 'IV/35.280', 'Sicasov'

**CELEX ID:** CELEX-31999D0006  
**Industry:** | industry                                        |
|:------------------------------------------------|
| Cereals                                         |
| Fodder plants and high-protein products         |
| Maize/Sorghum, vegetables, oil and fibre plants |
| Potatoes                                        |  
**Cartel Period:** 1994-10-26 : 2004-10-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0006 | IV/35280  |

### Case Title
Sicasov

### Overview
This case involves the European Commission's decision regarding Sicasov, a French agricultural cooperative. The case centers on an anticompetitive agreement under Article 85 of the EC Treaty. Sicasov applied for and received an exemption, which was granted by the Commission.

### Industry
Cereals
Fodder plants and high-protein products
Maize/Sorghum, vegetables, oil and fibre plants
Potatoes

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.1:Growing of non-perennial crops
NACE class code: 01.11: Growing of cereals (except rice), leguminous crops and oil seeds

### Companies Undertakings
Sicasov (Société coopérative d’intérêt collectif agricole anonyme à capital variable) - FR

### Market
European Union Member States
NA
NA

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 implementing Articles 85 and 86 of the Treaty |
| 1994-07-27 | Council | adopted Regulation (EC) No 2100/94 on Community plant-variety rights |
| 1994-10-26 | Sicasov | began exemption period and notified agreements |
| 1998-12-14 | Commission of the European Communities | issued Commission Decision relating to a proceeding under Article 85 of the EC Treaty |
| 2004-10-26 | redacted | exemption ended |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought and granted for Sicasov

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
True

### Book Reference
NA

### Outcome
The Commission took no action (case_commission_no_action: True) and issued a decision (case_commission_decision: True). The case involved an exemption application by Sicasov, which was granted.


*(reported: 2026-10-16 20:51:09)*

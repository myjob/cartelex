# 'IV/A‑03036', 'D.R.U.-BlondeI'

**CELEX ID:** CELEX-31965D0366  
**Industry:** household appliances  
**Cartel Period:** 1965-07-08 : 1970-03-13  

## Summary

### Celex Case Id
CELEX-31965D0366

### Case Title
D.R.U.-BlondeI

### Overview
The case involved exclusive distribution agreements between Koninklijke Fabrieken Diepenbrock en Reigers N.V. (Netherlands) and Etablissements Blondel S.A. (France) concerning household appliances made of enameled cast iron. The agreements were found to contribute to improved production or distribution and benefited consumers without substantially restricting competition, leading to the decision that the agreement was inapplicable under Article 85(3).

### Industry
household appliances

### Oecd Nace
OECD: manufacturing, NACE: 25.7:Manufacture of cutlery, tools and general hardware

### Companies Undertakings
| companies                                         |
|:--------------------------------------------------|
| Koninklijke Fabrieken Diepenbrock en Reigers N.V. |
| Etablissements Blondel S.A.                       |

### Market
France

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-11-11 | DiepenbrockenReigersN.V. | concluded exclusive distribution agreement |
| 1959-11-11 | Koninklijke Fabrieken Diepenbrock en Reigers N.V. | entered into agreement with Etablissements Blondel for exclusive distribution of household appliances |
| 1963-01-28 | Société Anonyme des Etablissements Blondel | registered agreement with Commission under Article 5(1) of Regulation No.17 |
| 1965-07-08 | Commission of the European Economic Community | issued decision about procedure under Article 85 |

### Legal Framework
NA

### Infringement Category
Territorial exclusivity and parallel import /export bans

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Walter HALLSTEIN

### Courts
NA

### Book Reference
IV/3036

### Outcome
The Commission declared the exclusive distribution agreement inapplicable under Article 85(3) of the Treaty establishing the European Economic Community, meaning no specific remedies or orders were issued. The agreement was found to contribute to improved production or distribution and benefited consumers without restricting competition substantially.


*(reported: 2026-10-16 19:10:59)*

# 'IV/30.846', 'Ivoclar'

**CELEX ID:** CELEX-31985D0559  
**Industry:** dental supplies  
**Cartel Period:** 1985-11-01 : 1993-01-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0559 | IV/30846  |

### Case Title
IV/30.846 – Ivoclar

### Overview
The European Commission investigated Ivoclar AG for an anticompetitive agreement under Article 85 of the EEC Treaty, specifically involving a vertical restraint in the form of selective distribution. Ivoclar sought and was granted a block exemption for its exclusive distribution agreement, but the Commission later initiated proceedings and declared certain provisions inapplicable.

### Industry
dental supplies

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.5: Manufacture of medical and dental instruments and supplies
NACE class code: 32.50: Manufacture of medical and dental instruments and supplies

### Companies Undertakings
Ivoclar AG (LI)

### Market
Liechtenstein, outside the EU, oligopoly market

### Cartel Period
1982-12-01 : 1993-01-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-12-01 | Ivoclar AG | signed exclusive distribution agreement |
| 1983-02-01 | Ivoclar AG | filed notification seeking exemption of its standard exclusive distribution agreement |
| 1983-02-01 | Ivoclar AG | notified the Commission of a standard exclusive distribution agreement |
| 1983-02-01 | Ivoclar AG | formally notified exclusive distribution agreement |
| 1983-07-01 | Commission | granted block exemption for exclusive distribution agreements |
| 1984-10-30 | Commission | initiated proceedings in this case |
| 1985-11-27 | Commission | issued Commission Decision relating to a proceeding under Article 85 of the EEC Treaty |
| 1985-11-27 | Peter SUTHERLAND | issued decision declaring provisions inapplicable |
| 1986-12-31 | redacted | ended block exemption under Regulation (EEC) No 1983/83 |
| 1993-01-31 | redacted | exemption period ended |

### Legal Framework
Article 85 (operative)
Article 85 (all relevant)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
medium

### Exemption
Ivoclar AG applied for and was granted a block exemption for its exclusive distribution agreement.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission initiated proceedings and declared certain provisions inapplicable, but no specific remedies were issued.


*(reported: 2026-10-16 20:06:12)*

# 'IV/28.553', 'Krups'

**CELEX ID:** CELEX-31980D0489  
**Industry:** | industry                      |
|:------------------------------|
| electrical kitchen appliances |
| personal care appliances      |
| clocks                        |
| kitchen and bathroom scales   |  
**Cartel Period:** 1975-08-01 : 1980-04-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0489 | IV/28553  |

### Case Title
Krups

### Overview
The European Commission investigated Robert Krups and its distribution agreement within the common market, determining that the agreement did not restrict competition in violation of Article 85(1).

### Industry
electrical kitchen appliances, personal care appliances, clocks, kitchen and bathroom scales

### Oecd Nace
manufacturing, 27.5:Manufacture of domestic appliances, 27.51: Manufacture of electric domestic appliances

### Companies Undertakings
| companies                         | location                    |
|:----------------------------------|:----------------------------|
| Robert Krups                      | Solingen                    |
| Krups Leasing GmbH                | Solingen                    |
| Krups Engineering Ltd             | Limerick                    |
| Pan Electric Haushaltsgerate GmbH | Federal Republic of Germany |

### Market
Federal Republic of Germany, outside EU

### Cartel Period
1975-10-01 : 1980-04-17

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-10-01 | Krups | introduced the agreement on the Krups international dealers' association for product distribution within the common market |
| 1979-12-29 | European Communities | published contents of the application |
| 1980-02-19 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion |
| 1980-04-17 | Commission | adopted decision on Krups distribution agreement |
| 1980-04-17 | Commission of the European Communities | issued decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
low

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement. The Commission granted negative clearance, meaning the agreement does not restrict competition in violation of Article 85(1) and no enforcement measures or commitments are imposed on Robert Krups.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted negative clearance, meaning the agreement does not restrict competition in violation of Article 85(1). No enforcement measures or commitments were imposed.


*(reported: 2026-10-16 19:34:49)*

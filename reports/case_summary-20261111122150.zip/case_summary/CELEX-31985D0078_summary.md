# 'IV/30.666', 'Mecaniver-PPG'

**CELEX ID:** CELEX-31985D0078  
**Industry:** Flat Glass Industry  
**Cartel Period:** 1980-01-01 : 1985-04-22  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0078 | IV/30666  |

### Case Title
Mecaniver-PPG

### Overview
This case involved anticompetitive agreements in the flat glass industry, specifically vertical restraints related to territorial exclusivity and parallel trade bans. The European Commission investigated companies including PPG Industries Inc., BSN-Gervais Danone, and Mecaniver SA.

### Industry
Flat Glass Industry

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 23.1: Manufacture of glass and glass products
NACE Class Code: 23.12: Shaping and processing of flat glass

### Companies Undertakings
| companies           |
|:--------------------|
| PPG Industries Inc. |
| BSN-Gervais Danone  |
| Mecaniver SA        |

### Market
Market Geography: Belgium, Italy, Switzerland, United Kingdom, Norway, Denmark
Market Outside EU: True
Market Oligopoly: True
Market Turbulence: NA

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-12-17 | BSN and Mecaniver | signed share purchase agreement |
| 1982-04-23 | PPG | completed share sale |
| 1984-12-12 | European Commission | adopted decision concluding no grounds under Article 86 for action |

### Legal Framework
Legal Framework: Articles 85 and 86 of the EC Treaty
Infringement Concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
low

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission concluded no grounds under Article 86 for action.


*(reported: 2026-10-16 20:02:20)*

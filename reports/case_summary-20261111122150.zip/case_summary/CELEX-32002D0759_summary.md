# 'COMP/37.800/F3', 'Luxembourg Brewers'

**CELEX ID:** CELEX-32002D0759  
**Industry:** brewing  
**Cartel Period:** 1966-09-01 : 1997-02-21  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32002D0759 | IV/37800  |

### Case Title
Luxembourg Brewers

### Overview
The European Commission investigated a cartel in the Luxembourg brewing industry, involving several breweries that engaged in anticompetitive agreements under Article 81 of the EC Treaty. The cartel operated from 1966 to 1997, with various agreements and modifications over time.

### Industry
brewing

### Oecd Nace
trade (wholesaling and retailing) and hotels

NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.05: Manufacture of beer

### Companies Undertakings
| company                                            |
|:---------------------------------------------------|
| SA Brasserie Nationale-Bofferding                  |
| Brasserie de Wiltz                                 |
| Brasserie Battin                                   |
| Brasserie de Diekirch                              |
| Brasseries Réunies de Luxembourg Mousel et Clausen |

### Market
Luxembourg

market_oligopoly: True
market_outside_eu: False

### Cartel Period
1966-09-01 : 1997-02-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1966-09-01 | redacted | entered into agreement honoring clienteles |
| 1975-06-13 | redacted | signed agreement imposing beer tie restrictions |
| 1983-04-28 | redacted | entered into agreement with competition restrictions |
| 1985-10-08 | parties | concluded agreement |
| 1986-10-07 | Luxembourg Brewers Federation | agreed to interpret term 'beer tie' more widely |
| 1986-12-02 | signatory brewers | supplemented the Agreement with a second declaration of intent |
| 1986-12-02 | Luxembourg Brewers Federation | circulated minutes confirming interpretation of 'beer tie' |
| 1995-12-01 | French courts | overturned case-law regarding beer ties |
| 1999-09-27 | Interbrew | took control of Mousel through holding company BM Investments |
| 2000-02-16 | Commission | informed of Agreement's existence |
| 2000-09-29 | Commission | initiated proceedings in this case |
| 2001-12-05 | Commission | issued decision in Luxembourg Brewers case

### Legal Framework
Article 81

law_article_all_relevant:
| law_article   |
|:--------------|
| Article 81    |
| Article 85    |

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
leniency_case: False
leniency_applicants: NA
leniency_granted:
| company                                 |   amount |
|:----------------------------------------|---------:|
| Brasserie de Luxembourg Mousel-Diekirch |        0 |
leniency_rejected: NA

### Fines
| company | amount |
| --- | --- |
| Brasserie Nationale-Bofferding | EUR 400 000 |
| Brasserie de Wiltz | EUR 24 000 |
| Brasserie Battin | EUR 24 000 |

### Remedies
The Commission ordered the cessation of the infringement by imposing fines on the involved undertakings as a deterrent measure. No explicit structural or behavioral remedies were mentioned in the decision.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Brasserie de Luxembourg Mousel-Diekirch, Brasserie Nationale-Bofferding, Brasserie de Wiltz, Brasserie Battin | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                     | country    | jurisdiction   |
|:--------------------------|:-----------|:---------------|
| European Court of Justice | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision in 2001, fining several breweries for their involvement in the cartel. The case was part of the EU's efforts to enforce competition law and deter anticompetitive behavior.


*(reported: 2026-11-11 12:13:18)*

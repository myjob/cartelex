# 'IV/33.133', 'Soda-ash — Solvay'

**CELEX ID:** CELEX-31991D0299  
**Industry:** soda-ash  
**Cartel Period:** 1978-02-07 : 1987-03-10  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31991D0299 | IV/33133-3 |

### Case Title
IV/33.133 – Soda-ash — Solvay

### Overview
This case involves the European Commission's investigation and decision against Solvay et Cie SA for abuse of dominance under Article 86 of the EC Treaty, specifically related to anticompetitive agreements in the soda-ash industry.

### Industry
soda-ash

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
Solvay et Cie SA (BE)

### Market
Market geography:
| country     |
|:------------|
| Belgium     |
| France      |
| Germany     |
| Italy       |
| Spain       |
| Portugal    |
| Austria     |
| Switzerland |

Market outside EU: True
Market oligopoly: True
Market turbulence: NA

### Cartel Period
1978-02-07 : 1987-03-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-02-07 | redacted | signed agreements with Solvay for five-year period |
| 1981-06-18 | Solvay | concluded exclusive supply contract with BSN requiring annual purchase of soda-ash |
| 1983-01-01 | St Gobain | entered into agreement with Solvay under most-favoured partner status |
| 1983-01-01 | redacted | concluded new agreements with specified tonnage |
| 1983-01-01 | redacted | contract established with basic terms |
| 1983-12-30 | Solvay | advised of competing offers and coordinated pricing adjustments |
| 1986-02-11 | Solvay | issued internal note regarding Belgian price determination |
| 1987-03-10 | St Gobain | terminated agreement with Solvay in France |
| 1988-02-01 | Deutsche Solvay Werke | agreed to supply Vegla with total requirements for 1988 and 1989 with rebate and cheque benefits |
| 1989-01-11 | BSN | extended rebate agreement |
| 1990-02-19 | redacted | opened proceeding under Article 3 of Regulation No 17 |
| 1990-12-19 | redacted | Decision was issued and signed

### Legal Framework
Legal framework applying to the case:

Operative articles: Article 86
All relevant articles:
| law_article   |
|:--------------|
| Article 85    |
| Article 86    |
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Solvay et Cie SA | ECU 20 million |

### Remedies
Solvay shall abandon its system of fidelity rebates;
Solvay shall notify the Commission of the details of any new system of discounts or rebates to ensure conformity with Community competition rules;
Solvay shall renegotiate all its supply agreements for soda-ash in the Community so as to conform with the requirements of this Decision;
all clauses in agreements, and any unofficial understanding or arrangement tending to tie the customer to Solvay for the whole or substantially the whole of its requirements must be deleted or terminated;
Competition clauses or other devices which operate in an anti-competitive manner must be deleted or amended so as not to deter or prevent the customer from ever purchasing from a competitor whose offer matches that of Solvay.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Solvay | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon Brittan

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission found Solvay et Cie SA guilty of abuse of dominance under Article 86, imposing a fine of ECU 20 million and ordering the abandonment of its system of fidelity rebates. The company was also required to renegotiate all supply agreements for soda-ash in the Community to ensure conformity with EU competition rules.


*(reported: 2026-11-11 11:28:03)*

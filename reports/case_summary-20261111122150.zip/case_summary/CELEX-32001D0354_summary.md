# 'NA', 'NA'

**CELEX ID:** CELEX-32001D0354  
**Industry:** NA  
**Cartel Period:** 1974-12-19 : 2000-10-19  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32001D0354 | IV/35141  |

### Case Title
NA

### Overview
The European Commission found Deutsche Post AG (DPAG) guilty of abuse of dominance under Article 82 of the EC Treaty. The infringement involved anti-competitive practices such as obligating customers to exclusively use DPAG's services for non-bulky parcels and implementing rebate systems based on heavy Infopost items. The Commission imposed a fine of EUR 24 million and ordered behavioral commitments and structural separation.

### Industry
- mail-order parcel services
- self-labelled parcels
- heavy Infopost
- catalogues
- commercial parcel services
- non-bulky parcels
- bulky parcels

### Oecd Nace
OECD sector: public service
NACE group code: 53.2: Other postal and courier activities
NACE class code: 53.20: Other postal and courier activities

### Companies Undertakings
Deutsche Post AG (DE)

### Market
Relevant market: Germany, oligopolistic structure, no turbulence

### Cartel Period
1974-12-19 : 2000-10-19

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1974-12-19 | DPAG | concluded economic cooperation contract with major mail-order customer |
| 1974-12-19 | DPAG | entered into cooperation contract obligating customers to obtain all non-bulky parcel services up to 10 or 20 kg exclusively from DPAG |
| 1987-02-13 | DPAG | entered into cooperation contract obligating customers to obtain all non-bulky parcel services up to 10 or 20 kg exclusively from DPAG |
| 1997-11-01 | DPAG | concluded cooperation agreements with four largest mail-order customers |
| 1998-07-22 | DPAG | concluded agreement including subsidiaries in contract |
| 1998-08-23 | DPAG | signed supplementary agreement to previous contract |
| 1998-12-01 | DPAG | began applying reduced pricing for heavy Infopost |
| 2000-01-03 | DPAG | signed cooperation contract with customer for rebate based on percentage of heavy Infopost items |
| 2000-10-19 | DPAG | announced termination of agreements on rebates |
| 2000-11-09 | DPAG | did not substantially contest facts presented during hearing |
| 2001-03-20 | DPAG | decision issued |
| 2001-12-31 | DPAG | transferred commercial parcel services to Newco

### Legal Framework
Legal framework: Article 82 (operative), Article 86 (relevant)
Canonical concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Deutsche Post AG | EUR 24 million |

### Remedies
| value                                                                                                                                                                                                                                                                                                                   |
|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Cease and desist order: DPAG must immediately bring to an end the infringements referred to in Article 1(1).                                                                                                                                                                                                            |
| Behavioral commitments: DPAG shall submit annually to the Commission statements of costs and revenue of Newco, itemized statements of transfer prices paid by Newco for goods or services procured from DPAG, and any agreements providing for rebates which Newco concludes with its six largest mail-order customers. |
| Structural separation: DPAG undertakes to transfer all its commercial parcel activities, including delivery of catalogues, to a legally separate company, Newco, by 31 December 2001. Revenues from the reserved area shall not be used to finance mail-order parcel services.                                          |

### Company Recidivism
Deutsche Post AG: True

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-11-11 12:07:21)*

# 'IV/31.697', 'Charles Jourdan'

**CELEX ID:** CELEX-31989D0094  
**Industry:** | industry         |
|:-----------------|
| Shoes            |
| Leather goods    |
| Fashion/clothing |  
**Cartel Period:** 1988-12-01 : 1988-12-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0094 | IV/31697  |

### Case Title
Charles Jourdan

### Overview
The European Commission investigated anticompetitive agreements in the footwear and fashion industry involving Charles Jourdan and Xavier Danaud. The case centered on licensing agreements that were found not to constitute a breach under Article 85(1) of the EC Treaty, leading to an exemption under Article 85(3).

### Industry
Shoes, Leather goods, Fashion/clothing

### Oecd Nace
Trade (wholesaling and retailing) and hotels; NACE group code 14.1: Manufacture of wearing apparel, except fur apparel; NACE class code 14.13: Manufacture of other outerwear

### Companies Undertakings
| company                                                        |
|:---------------------------------------------------------------|
| Société Anonyme des Chaussures Seducta Charles Jourdan et Fils |
| Charles Jourdan Holding AG                                     |
| Société Anonyme Xavier Danaud                                  |

### Market
France

### Cartel Period
1986-12-17 : 1996-12-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-11-05 | Société Anonyme des Chaussures Seducta Charles Jourdan et Fils, Charles Jourdan Holding AG, Société Anonyme Xavier Danaud | submitted notification for negative clearance |
| 1986-12-17 | Charles Jourdan Group | implemented amendments to standard-form retail franchise agreements |
| 1988-12-02 | Peter SUTHERLAND | adopted decision declaring provisions inapplicable |
| 1988-12-02 | Commission of the European Communities | issued decision under Article 85 |
| 1996-12-16 | redacted | exemption period for franchise agreements ended |

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
low

### Exemption
True

| company                                                   |
|:----------------------------------------------------------|
| La Société des Chaussures Seducta Charles Jourdan et Fils |
| Charles Jourdan Holding AG                                |
| La Société Xavier Danaud                                  |

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate any infringement; the decision concludes that there is no breach under Article 85(1) and exempts the agreements under Article 85(3).

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | EU Law         |

### Book Reference
NA

### Outcome
The Commission concluded that the agreements did not constitute a breach under Article 85(1) and granted an exemption under Article 85(3).


*(reported: 2026-10-16 20:18:35)*

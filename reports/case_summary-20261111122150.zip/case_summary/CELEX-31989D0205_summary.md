# 'IV/31.851', 'Magill TV Guide/ITP, BBC and RTE'

**CELEX ID:** CELEX-31989D0205  
**Industry:** Broadcasting  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0205 | IV/31.851 |
| CELEX-31989D0205 | IV/31851  |

### Case Title
Magill TV Guide/ITP, BBC and RTE

### Overview
The case involved the European Commission investigating broadcasting companies for abuse of dominance under Article 86 of the EEC Treaty. The companies were found to have engaged in practices that restricted competition by preventing entry into the market for advance weekly listings of television and radio programmes.

### Industry
Broadcasting

### Oecd Nace
OECD sector: communication
NACE group code: 58.1: Publishing of books, periodicals and other publishing activities
NACE class code: 58.14: Publishing of journals and periodicals

### Companies Undertakings
| companies                               | country   |
|:----------------------------------------|:----------|
| Independent Television Publications Ltd | GB        |
| British Broadcasting Corporation        | GB        |
| BBC Enterprises Ltd                     | GB        |
| Radio Telefis Eireann                   | IE        |

### Market
| country          |
|:-----------------|
| Ireland          |
| Northern Ireland |

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-04-04 | Magill TV Guide Ltd | lodged complaint against Independent Television Publications Ltd, British Broadcasting Corporation and Radio Telefis Eireann |
| 1988-12-21 | Commission | issued Commission Decision relating to a proceeding under Article 86 of the EEC Treaty |

### Legal Framework
Law articles: Article 86, Article 90
Infringement concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
ITP, BBC and RTE shall bring the infringements to an end forthwith by supplying each other and third parties on request and on a non-discriminatory basis with their individual advance weekly programme listings and by permitting reproduction of those listings by such parties. This requirement does not extend to information in addition to the listings themselves, as defined in this Decision. If they choose to supply and permit reproduction of the listings by means of licences, any royalties requested by ITP, BBC and RTE should be reasonable. Moreover, ITP, BBC and RTE may include in any licences granted to third parties such terms as are considered necessary to ensure comprehensive high-quality coverage of all their programmes, including those of minority and/or regional appeal, and those of cultural, historical and educational significance. The parties are therefore required, within two months from the date of notification of this Decision, to submit proposals for approval by the Commission of the terms upon which they consider third parties should be permitted to publish the advance weekly programme listings which are the subject of this Decision.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country        | jurisdiction       |
|:---------------------------------------|:---------------|:-------------------|
| European Commission                    | European Union | European Union     |
| Magill Court                           | Ireland        | Irish law          |
| Magill Court                           | United Kingdom | United Kingdom law |
| Court of Justice of the European Union | Ireland        | European Union     |

### Book Reference
IV/31.851

### Outcome
The Commission issued a decision requiring the companies to cease the infringing behavior and to supply each other and third parties with advance weekly programme listings on a non-discriminatory basis. Licenses for reproduction of listings were allowed, but royalties must be reasonable, and terms should ensure comprehensive coverage of all programmes.


*(reported: 2026-11-11 11:19:21)*

# '94/594/EC', 'relating to a proceeding under Article 85 of the EC Treaty and Article 53 of the EEA Agreement'

**CELEX ID:** CELEX-31994D0594  
**Industry:** | industry                                   |
|:-------------------------------------------|
| Railway Transport                          |
| Combined Transport of Goods                |
| Intermodal Freight Services                |
| Specialized Wagons for Container Transport |  
**Cartel Period:** 1992-02-02 : 1994-07-27  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0594 | IV/34518  |

### Case Title
94/594/EC – relating to a proceeding under Article 85 of the EC Treaty and Article 53 of the EEA Agreement

### Overview
The European Commission investigated anticompetitive agreements in the railway and intermodal freight transport sector involving companies from the UK and France. The case concerned a joint venture that was found to be in breach of EU competition law, specifically Article 85 of the EC Treaty.

### Industry
Railway Transport, Combined Transport of Goods, Intermodal Freight Services, Specialized Wagons for Container Transport

### Oecd Nace
OECD Sector: transport; NACE Group Code: 52.2: Support activities for transportation; NACE Class Code: 52.29: Other transportation support activities

### Companies Undertakings
| companies                                     |
|:----------------------------------------------|
| British Railways Board                        |
| Société Nationale des Chemins de Fer Français |
| Intercontainer                                |
| Allied Continental Intermodal Services Ltd    |
| Fret Manche Europe                            |
| Eurotunnel                                    |

### Market
Relevant market includes the United Kingdom and France. The market is oligopolistic, with limited turbulence.

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-07-19 | Commission | adopted Regulation (EEC) No 1017/68 |
| 1987-07-29 | Eurotunnel, BR and SNCF | concluded agreement for Channel Tunnel train paths |
| 1992-09-02 | BR, SNCF and IC | formed ACI for intermodal transport services |
| 1992-11-13 | British Railways Board, Société Nationale des Chemins de Fer Français, Intercontainer | submitted application for declaration under Article 5 of Regulation (EEC) No 1017/68 |
| 1993-05-27 | Commission | raised serious doubts under Article 12(3) of Regulation (EEC) No 1017/68 |
| 1994-07-27 | Commission | issued decision declaring inapplicability of articles and attaching conditions |

### Legal Framework
Legal framework: Article 85 (operative article), with relevant provisions from Regulation (EEC) No 1017/68. The canonical concept is anticompetitive_agreement.

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
Exemption sought by British Railways Board, Société Nationale de Chemins de Fer Française, and Intercontainer.

### Leniency
NA

### Fines
NA

### Remedies
Ensure same rail services are provided to all consignors and operators (non-discrimination), hire out specialized wagons under contracts of at least six months’ duration if unused for six months or more, give no priority to subsidiary or associated undertakings, and allow priority only for services using the Channel Tunnel.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued a decision declaring the agreements inapplicable under Article 85 and attached conditions to ensure fair competition.


*(reported: 2026-10-16 20:46:49)*

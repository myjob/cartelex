# 'IV/36.213/F2', 'GEAE/P & W'

**CELEX ID:** CELEX-32000D0182  
**Industry:** Aircraft Engine Manufacturing  
**Cartel Period:** 1996-08-16 : 2004-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0182 | IV/36213  |

### Case Title
GEAE/P & W

### Overview
The European Commission investigated a joint venture (Engine Alliance) formed between General Electric Aircraft Engines (GEAE) and Pratt & Whitney (P&W), involving the development of new jet engines for aircraft such as the Airbus A3XX and Boeing B747-400. The case concerned alleged anticompetitive agreements and abuse of dominance under Articles 81, 82, and 86 of the EC Treaty.

### Industry
Aircraft Engine Manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 30.3: Manufacture of air and spacecraft and related machinery
NACE class code: 30.30: Manufacture of air and spacecraft and related machinery

### Companies Undertakings
| company                         |
|:--------------------------------|
| General Electric Company        |
| United Technologies Corporation |

Countries:
- General Electric Company: US
- United Technologies Corporation: US

### Market
Worldwide
Market is oligopolistic
Market turbulence: NA

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1996-08-16 | Engine Alliance and Boeing | concluded Memorandum of Understanding concerning engine for 747-400 aircraft |
| 1996-08-28 | GE-P & W Engine Alliance LLC and Airbus Industrie | signed Transaction Agreement |
| 1996-08-28 | Engine Alliance, GEAE, P&W, and Boeing | included Transaction Agreement and Limited Liability Company Agreement |
| 1996-09-26 | General Electric Aircraft Engines and Pratt & Whitney | formed engine alliance to develop new jet engine for Boeing Growth 747 |
| 1996-09-26 | GEAE/P & W | submitted application for negative clearance and notification for exemption |
| 1997-11-06 | Engine Alliance | amended notification declaring new engine development for A3XX aircraft |
| 1998-05-27 | GE-P & W Engine Alliance LLC and Airbus Industrie | signed Memorandum of Understanding |
| 1998-05-27 | Engine Alliance and Airbus | concluded Memorandum of Understanding concerning A3XX aircraft |
| 1999-09-14 | Commission | finalized Decision |
| 1999-09-14 | Commission of the European Communities | issued decision relating to proceeding pursuant to Article 81 of the EC Treaty |
| 2011-09-26 | redacted | exemption ended |

### Legal Framework
Operative articles: Article 81, Article 82, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement, public_undertaking

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought and granted for the joint venture between GEAE/P & W and other parties.

### Leniency
NA

### Fines
NA

### Remedies
The Engine Alliance must be a separate legal entity trading at arm's length with its parents; it must maintain separate accounting records and undergo annual audits; the parties must notify the Commission of any proposed change in the scope of the Engine Alliance; P & W and GEAE personnel roles are limited and they cannot access responses given to clients by the Engine Alliance; if a customer requests a bid for multiple engines, the discounts, rebates or other terms of sale of the new engine will be stated separately and neither GEAE nor P & W will disclose the nature of the terms that either of them elects to offer on their respective engine offerings; information regarding actual P & W costs will not be shared with GEAE, and information regarding actual GEAE costs will not be shared with P & W; Engine Alliance personnel must sign confidentiality agreements.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued a final decision under Article 81 of the EC Treaty, finding that the joint venture violated EU competition law. Remedies were imposed to ensure the Engine Alliance operates independently and maintains confidentiality between the parent companies.


*(reported: 2026-10-16 22:18:26)*

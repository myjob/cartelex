# 'IV/34.237/F3', 'Anheuser-Busch Incorporated — Scottish & Newcastle'

**CELEX ID:** CELEX-32000D0146  
**Industry:** | industry   |
|:-----------|
| brewing    |
| brewing    |  
**Cartel Period:** 1995-05-06 : 1998-04-23  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0146 | IV/34237  |

### Case Title
Anheuser-Busch Incorporated — Scottish & Newcastle

### Overview
The European Commission investigated an anticompetitive agreement in the brewing industry involving Anheuser-Busch Incorporated, Scottish & Newcastle plc, and Anheuser-Busch European Trade Limited. The case centered on horizontal restraints in marketing and advertising agreements concerning Budweiser beer.

### Industry
brewing

### Oecd Nace
OECD: manufacturing
NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.05: Manufacture of beer

### Companies Undertakings
| company                               |
|:--------------------------------------|
| Anheuser-Busch Incorporated           |
| Scottish & Newcastle plc              |
| Anheuser-Busch European Trade Limited |

### Market
The relevant market is oligopolistic in the United States and United Kingdom.

### Cartel Period
1995-05-06 : 1998-04-23

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-02-24 | Anheuser-Busch and Courage | notified Commission of agreements concerning brewing, distribution and marketing of Budweiser beer |
| 1995-05-06 | S & N | signed Beer Supply Agreement |
| 1997-03-14 | S & N | informed Commission that relationship remained governed by 1995 Agreements |
| 1997-06-03 | Commission | requested information under Article 11 of Regulation No 17 |
| 1997-06-03 | Anheuser-Busch Inc. and ABET | replied to Commission's letter |
| 1997-07-02 | S & N and Anheuser-Busch | jointly replied to Commission's request for information |
| 1998-02-16 | Anheuser-Busch Inc. | furnished guidelines to the Commission |
| 1998-04-23 | S & N | sent unilateral letter without Anheuser-Busch's knowledge |
| 1998-07-13 | Commission | issued second warning letter concerning marketing guidelines |
| 1998-08-04 | Commission | issued Statement of Objections |
| 1999-12-14 | Commission | issued Commission Decision |
| 1999-12-14 | Commission | made Decision enforceable |

### Legal Framework
Legal framework applying to the case: the operative articles ('Article 81') and the canonical concept ('anticompetitive_agreement')

### Infringement Category
horizontal

### Infringement Sub Category
marketing and advertising agreements

### Infringement Gravity
medium

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

### Leniency
Leniency: applicants, reductions granted and applications rejected, from the 'leniency_case', 'leniency_applicants', 'leniency_granted' and 'leniency_rejected' facts. Preserve markdown lists and tables if present.

### Fines
| company | amount |
| --- | --- |
| Anheuser-Busch Incorporated | EUR 3 000 |
| Scottish & Newcastle plc | EUR 3 000 |

### Remedies
EUR 3 000 fine for Anheuser-Busch Incorporated and EUR 3 000 fine for Scottish & Newcastle plc

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Anheuser-Busch Incorporated | False |
| Scottish & Newcastle plc | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
Courts involved and their rulings, from the 'is_court_involved' and 'court_list' facts. Preserve markdown tables if present.

### Book Reference
NA

### Outcome
The Commission issued a decision imposing fines of EUR 3,000 on Anheuser-Busch Incorporated and Scottish & Newcastle plc for participating in an anticompetitive agreement.


*(reported: 2026-11-10 19:39:18)*

# 'IV/31.624', 'Vichy'

**CELEX ID:** CELEX-31991D0153  
**Industry:** Cosmetics  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0153 | IV/31624  |

### Case Title
IV/31.624 – Vichy

### Overview
This case involved anticompetitive practices in the cosmetics industry, specifically concerning exclusive distribution systems that were found to infringe Article 85 of the EEC Treaty.

### Industry
Cosmetics

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 20.5: Manufacture of other chemical products
NACE class code: 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| company                                                   |
|:----------------------------------------------------------|
| Société d'Hygiène Dermatologique de Vichy                 |
| Laboratoires d'Application Dermatologique de Vichy et Cie |
| L'Oréal group                                             |

### Market
Geographical market includes France, Germany, Italy, and United Kingdom. No indication of oligopoly or turbulence.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-07-26 | Vichy | notified Commission of exclusive distribution system |
| 1989-08-29 | Vichy | notified Commission of modified distribution system and preliminary notification for other Member States |
| 1991-01-11 | Commission of the European Communities | issued decision regarding exclusive distribution infringement |

### Legal Framework
Article 85 (operative article)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
Suspend immunity against imposition of fines

### Company Recidivism
| company | recidivism |
| --- | --- |
| Société d'Hygiène Dermatologique de Vichy | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| Court of Justice          | European Union | EEC Treaty     |
| Paris Court of Appeal     | France         | France         |
| French Court of Cassation | France         | France         |
| Conseil de la Concurrence | France         | France         |

### Book Reference
NA

### Outcome
The Commission found that the exclusive distribution system infringed Article 85 of the EEC Treaty. Remedies included suspension of immunity against imposition of fines.


*(reported: 2026-11-11 11:26:41)*

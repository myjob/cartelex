# 'IV/26.186', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31976D0593  
**Industry:** nitrate fertilizers  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31976D0593 | IV/26186-1 |

### Case Title
IV/26.186 – relating to a proceeding under Article 85 of the EEC Treaty

### Overview
This case involved the European Commission's enforcement action against anticompetitive agreements in the nitrate fertilizers industry in the Netherlands, specifically targeting a joint selling agency operated by Centraal Stikstof Verkoopkantoor BV (CSV) and its members. The Commission found that these agreements violated Article 85 of the EEC Treaty, which prohibits anticompetitive agreements. The case is significant as it illustrates early EU competition law enforcement in the context of horizontal cartels.

### Industry
nitrate fertilizers

### Oecd Nace
OECD sector: agriculture
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.15: Manufacture of fertilisers and nitrogen compounds

### Companies Undertakings
| companies                            | country   |
|:-------------------------------------|:----------|
| Centraal Stikstof Verkoopkantoor BV  | NL        |
| Unie van Kunstmestfabrieken NV       | NL        |
| Nederlandse Stikstof Maatschappij NV | NL        |

### Market
Relevant market: Netherlands and Switzerland

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 |
| 1967-03-13 | Commission | brought proceeding against CSV and its members |
| 1968-05-29 | CSV | received first statement of objections |
| 1974-12-23 | Commission | issued second statement of objections |
| 1975-03-27 | Unie van Kunstmestfabrieken NV, Nederlandse Stikstof Maatschappij NV, CSV | notified Commission of agreements referred to in statement of objections |
| 1975-12-22 | Commission | requested CSV to supply information under Article I of the Decision |
| 1976-01-14 | CSV and its lawyers | informed Commission about export activities via Nitrex AG |
| 1976-01-16 | Commission | wrote stating it would issue a decision requiring information to be supplied if necessary |
| 1976-02-19 | CSV | refused to supply the information citing legal concerns under Swiss law |
| 1976-06-25 | Commission | issued legal decision imposing information obligations on CSV |
| 1976-06-25 | Commission | issued decision ordering CSV to cease operating as joint selling agency |

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought by all three companies: Unie van Kunstmestfabrieken NV, Nederlandse Stikstof Maatschappij NV, Centraal Stikstof Verkoopkantoor BV

### Leniency
NA

### Fines
NA

### Remedies
CSV must cease operating as a joint selling agency

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Centraal Stikstof Verkoopkantoor BV | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
G.M. Thomson

### Courts
| court                                        | country    | jurisdiction   |
|:---------------------------------------------|:-----------|:---------------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision requiring CSV to cease operating as a joint selling agency, and imposed information obligations on the company. The case was decided by the Court of Justice of the European Communities.


*(reported: 2026-11-11 10:14:19)*

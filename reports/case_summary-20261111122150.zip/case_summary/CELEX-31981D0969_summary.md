# 'IV/29.491', 'Bandengroothandel Frieschebrug BV/NV Nederlandsche Banden-Industrie Michelin'

**CELEX ID:** CELEX-31981D0969  
**Industry:** Tyre Manufacturing and Heavy Tyre Replacement Market  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31981D0969 | IV/29491  |

### Case Title
IV/29491 Bandengroothandel Frieschebrug BV/NV Nederlandsche Banden-Industrie Michelin

### Overview
The case involves the European Commission's investigation into anti-competitive discount practices by NV Nederlandsche Banden-Industrie Michelin (NBIM) in the Dutch tyre market, specifically related to abuse of dominance under Article 86.

### Industry
Tyre Manufacturing and Heavy Tyre Replacement Market

### Oecd Nace
manufacturing; 22.1:Manufacture of rubber products; 22.11: Manufacture of rubber tyres and tubes; retreading and rebuilding of rubber tyres

### Companies Undertakings
| company                                    |
|:-------------------------------------------|
| NV Nederlandsche Banden-Industrie Michelin |
| Bandengroothandel Frieschebrug BV          |
| The Commission of the European Communities |

### Market
Netherlands; oligopoly market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-01-01 | NBIM | amended discount system linking percentages to sales figures |
| 1981-03-23 | NBIM | informed Commission about amendment of discount system |

### Legal Framework
Article 86; abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| NV Nederlandsche Banden-Industrie Michelin | 1 833 184·80 guilders |

### Remedies
The Commission imposed a fine of 680,000 ECU (1,833,184.80 guilders) and ordered NBIM to cease the anti-competitive discount practices. Additionally, NBIM was required to amend its business practices by implementing a new discount system that ensures written confirmation of sales targets and bonuses, aligns with Article 86 principles, and is based on genuine cost reductions rather than discriminatory incentives.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| NV Nederlandsche Banden-Industrie Michelin | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court          | country     | jurisdiction                |
|:---------------|:------------|:----------------------------|
| European Court | Netherlands | European Economic Community |

### Book Reference
IV/29491

### Outcome
The Commission imposed a fine of 680,000 ECU (1,833,184.80 guilders) and ordered NBIM to cease the anti-competitive discount practices. Additionally, NBIM was required to amend its business practices by implementing a new discount system that ensures written confirmation of sales targets and bonuses, aligns with Article 86 principles, and is based on genuine cost reductions rather than discriminatory incentives.


*(reported: 2026-11-11 10:35:46)*

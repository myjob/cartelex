# 'IV/31.029', 'French inland waterway charter traffic : EATE levy'

**CELEX ID:** CELEX-31985D0383  
**Industry:** | industry                  |
|:--------------------------|
| inland waterway transport |
| freight forwarding        |  
**Cartel Period:** 1983 : 1983  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0383 | IV/31029  |

### Case Title
IV/31.029 – French inland waterway charter traffic : EATE levy

### Overview
This case involved an infringement of EU competition law related to the imposition of an EATE levy on inland waterway charters in France, which was found to be contrary to Article 2 of Regulation (EEC) No 1017/68. The Commission ordered the termination of the infringement by refusing exemption under Article 5 of the same regulation.

### Industry
inland waterway transport, freight forwarding

### Oecd Nace
OECD sector: transport; NACE group code: 50.4: Inland freight water transport; NACE class code: 50.40: Inland freight water transport

### Companies Undertakings
| companies                                                                    |
|:-----------------------------------------------------------------------------|
| Association Nationale des Travailleurs Indépendants de la Batellerie (ANTIB) |
| Chambre Syndicale Nationale des Courtiers de fret fluviaux                   |

### Market
Geography: France, Belgium, Netherlands; Oligopoly: False; Turbulence: NA

### Cartel Period
1983 : 1983

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-06-13 | ANTIB and the National Federation of Inland Waterway Forwarding Agents | signed an agreement on the reorganization of small-scale inland waterway transport |
| 1983-06-13 | ANTIB and the French Forwarding Agents' Federation | signed inter-association agreement infringing Article 2 of Regulation (EEC) No 1017/68 |
| 1983-06-13 | Association Nationale des Travailleurs Indépendants de la Batellerie and Chambre Syndicale Nationale des Courtiers de fret fluviaux | signed agreement introducing 10% levy on charters for international destinations |
| 1983-06-20 | organizations of Belgium and Dutch waterway carriers | introduced retaliatory measures against French carriers by charging $10% of freights on charters to France |
| 1983-07-20 | EATE | established under Act No 83-657 of 20 July 1983 |
| 1983-08-02 | ANTIB | began refunding the EATE levy |
| 1983-08-02 | Commission | refunded EATE levy to French carriers intending to join EATE |
| 1983-10-17 | redacted | abolished the EATE levy |
| 1983-10-17 | Commission | refused exemption under Article 5 of Regulation (EEC) No 1017/68 |
| 1984-08-01 | Commission | decided to open proceedings in the case |
| 1985-02-27 | undertakings concerned | were given opportunity to reply to objections |
| 1985-06-19 | Advisory Committee on Restrictive Practices and Dominant Positions | was consulted |
| 1985-07-10 | Commission | issued decision

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought: True; Applicants: NA

### Leniency
Leniency case: False; Applicants: NA; Granted: NA; Rejected: NA

### Fines
NA

### Remedies
The Commission ordered the termination of the infringement by requiring the undertakings concerned to bring the infringements to an end. Specifically, it refused exemption under Article 5 of Regulation (EEC) No 1017/68 for the agreement, thereby effectively ordering that the infringing provisions—namely, the imposition of the EATE levy on international traffic only and the discretion to refund the levy selectively to EATE members—cease. This constitutes a behavioral remedy in the form of a cease and desist order.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                                      | country   | jurisdiction                |
|:-----------------------------------------------------------|:----------|:----------------------------|
| Court of Justice                                           | EEC       | European Economic Community |
| Chambre Syndicale Nationale des Courtiers de fret fluviaux | France    | French                      |

### Book Reference
NA

### Outcome
The Commission ordered the termination of the infringement by refusing exemption under Article 5 of Regulation (EEC) No 1017/68 for the agreement, thereby effectively ordering that the infringing provisions—namely, the imposition of the EATE levy on international traffic only and the discretion to refund the levy selectively to EATE members—cease. This constitutes a behavioral remedy in the form of a cease and desist order.


*(reported: 2026-11-11 10:57:35)*

# 'IV/34.983', 'Fenex'

**CELEX ID:** CELEX-31996D0438  
**Industry:** NA  
**Cartel Period:** 1989-01-10 : 1993-07-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31996D0438 | IV/34983  |

### Case Title
Fenex

### Overview
The European Commission found Nederlandse Organisatie voor Expeditie en Logistiek (Fenex) guilty of anticompetitive behavior under Article 85 of the EC Treaty. Fenex was involved in customs declaration and related services, operating within the Netherlands. The cartel period lasted from 1989 to 1993, during which time Fenex engaged in horizontal price fixing collusion.

### Industry
Transport

### Oecd Nace
OECD Sector: transport
NACE Group Code: 52.2: Support activities for transportation
NACE Class Code: 52.29: Other transportation support activities

### Companies Undertakings
Nederlandse Organisatie voor Expeditie en Logistiek (Fenex), Netherlands

### Market
Netherlands

### Cartel Period
1989-01-10 : 1993-07-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-06-22 | Fenex | created through merger of previous associations |
| 1992-11-24 | Fenex | held general assembly where chairman stated members need guidance on tariff adjustments |
| 1993-02-17 | Fenex | issued circular stating tariffs are minimum and serve as guidelines for individual member charges |
| 1993-07-01 | Fenex | ceased circulation of recommended tariffs and implemented lawful cost structure tables |
| 1995-05-26 | Fenex | notified Commission of decision |
| 1995-05-26 | Nederlandse Organisatie voor Expeditie en Logistiek | lodged request for exemption from infringement |
| 1996-06-05 | European Commission | adopted decision imposing fine and outlining enforcement |

### Legal Framework
Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Nederlandse Organisatie voor Expeditie en Logistiek applied for exemption from infringement.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Nederlandse Organisatie voor Expeditie en Logistiek | ECU 1 000 |

### Remedies
A fine of ECU 1,000 was imposed on Fenex.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court               | country   | jurisdiction   |
|:--------------------|:----------|:---------------|
| European Commission | Belgium   | European Union |

### Book Reference
NA

### Outcome
The European Commission imposed a fine of ECU 1,000 on Fenex for anticompetitive behavior under Article 85. The case was treated as an infringement, and no landmark status was assigned in the reference book.


*(reported: 2026-11-11 11:53:13)*

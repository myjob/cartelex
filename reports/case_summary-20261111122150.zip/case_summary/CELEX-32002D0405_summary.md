# 'COMP/E-2/36.041/PO', 'Michelin'

**CELEX ID:** CELEX-32002D0405  
**Industry:** NA  
**Cartel Period:** 1990-01-01 : 1999-01  

## Summary

### Celex Case Id
CELEX-32002D0405

### Case Title
Michelin

### Overview
The European Commission investigated Michelin for anticompetitive behavior involving abuse of dominance and horizontal restraints in the tyre market. The investigation spanned from 1990 to 1999, with violations continuing until 1998. In 1999, Michelin agreed to amend its commercial policy following Commission observations. The Commission opened proceedings and sent a statement of objections in June 1999. A hearing was held in December 1999. In July 2000, Michelin contested the validity of the analysis. Finally, in June 2001, the European Commission imposed a fine on Michelin for infringement.

### Industry
new replacement tyres, retreaded tyres, truck tyres, car tyres, van tyres, motorcycle tyres, agricultural tractor tyres, earthmover tyres, light plant tyres, forklift tyres

### Oecd Nace
manufacturing (OECD), 22.1:Manufacture of rubber products (NACE group), 22.11: Manufacture of rubber tyres and tubes; retreading and rebuilding of rubber tyres (NACE class)

### Companies Undertakings
Michelin (FR)

### Market
France, oligopoly market

### Cartel Period
1990-01-01 : 1999-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-01-01 | Michelin | began operating commercial policy in violation of competition rules |
| 1996-07-01 | Michelin | overhauled commercial policy following French law prohibiting selling at a loss |
| 1998-12-31 | Michelin | continued operating commercial policy in violation of competition rules |
| 1999-01-01 | Michelin | amended agreements to take account of Commission observations and put an end to the abuse |
| 1999-01-01 | Michelin | agreed to amend agreements regarding commercial policy |
| 1999-01-01 | Michelin | submitted amendments to commercial policy |
| 1999-02-04 | Michelin | submitted amended agreements in a meeting with the Commission |
| 1999-06-28 | Commission | sent statement of objections |
| 1999-06-28 | Commission | opened proceedings in this case |
| 1999-12-20 | Michelin and Bandag Inc. | held hearing of the parties |
| 2000-07-25 | Michelin | contested validity of analysis |
| 2001-06-20 | European Commission | imposed fine on Michelin for infringement

### Legal Framework
Article 81, Article 82, Article 86

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Michelin shall refrain from repeating any conduct described in Article 1, and from adopting any measure having equivalent effect.

### Company Recidivism
Michelin: True

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                | country            | jurisdiction   |
|:---------------------|:-------------------|:---------------|
| Commission           | European Community | EC             |
| Community judicature | France             | European Union |

### Book Reference
COMP/E-2/36.041, IV/29.491, IV/30.178

### Outcome
European Commission imposed a fine on Michelin for infringement of competition rules, specifically abuse of dominance and horizontal restraints.


*(reported: 2026-11-11 12:12:00)*

# 'IV/299', 'Association syndicale belge de la parfumerie (ASPA)'

**CELEX ID:** CELEX-31970D0333  
**Industry:** perfumery and toiletry  
**Cartel Period:** 1969-07-29 : 1970-06-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31970D0333 | IV/299    |

### Case Title
Association syndicale belge de la parfumerie (ASPA)

### Overview
The case involves the Association syndicale belge de la parfumerie (ASPA), a Belgian perfume and toiletry industry association. The Commission investigated ASPA's statutes and regulations for potential violations of Article 85(1) of the EEC Treaty, which concerns anti-competitive agreements. The Commission concluded that the amended version of ASPA's statutes and regulations no longer violated the treaty, resulting in a negative certificate being issued without imposing further remedies.

### Industry
perfumery and toiletry

### Oecd Nace
Trade (wholesaling and retailing) and hotels

### Companies Undertakings
Association syndicale belge de la parfumerie (ASPA), Belgium

### Market
Belgium

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-02-13 | Association syndicale belge de la parfumerie | founded for an indefinite period |
| 1962-10-31 | ASPA | notified decisions to Commission |
| 1962-10-31 | Association syndicale belge de la parfumerie | applied for the issuance of a negative test for the statutes and contracts |
| 1969-12-17 | General Assembly of ASPA | approved amendments to Statute and Règlement général |
| 1969-12-17 | Association General Assembly | approved amended regulation |
| 1969-12-18 | representatives of ASPA | confirmed request for negative test of amended statutes |
| 1970-06-11 | Advisory Committee for Cartel and Monopoly Issues | submitted a statement on Article 10 of Regulation No.17 |
| 1970-06-30 | Commission | issued decision on application of Article85(1) |
| 1970-06-30 | the Commission | issued a decision concerning a procedure under Article 85 of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
Price fixing collusion

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought and granted for ASPA's statutes and regulations.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued. The Commission concluded that the amended version of ASPA's statutes and regulations no longer violate Article 85(1) of the EEC Treaty, thus granting a negative certificate without imposing further remedies.

### Company Recidivism
Association syndicale belge de la parfumerie (ASPA) has prior infringement history (recidivism).

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/299

### Outcome
The Commission issued a negative certificate, concluding that the amended statutes and regulations of ASPA no longer violated Article 85(1) of the EEC Treaty.


*(reported: 2026-10-16 18:58:56)*

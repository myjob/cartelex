# 'IV/28.930', 'Milchförderungsfonds'

**CELEX ID:** CELEX-31985D0076  
**Industry:** dairy industry  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0076 | IV/28930  |

### Case Title
IV/28.930 – Milchförderungsfonds

### Overview
The European Commission found that the Milchförderungsfonds (Milk Promotion Fund) in Germany engaged in anticompetitive practices by supporting export cartels in the dairy industry, particularly in exports to non-EU countries such as the UK, Italy, France, and Greece. The case was initiated in 1982 and resulted in a Commission Decision in December 1984.

### Industry
dairy industry

### Oecd Nace
OECD sector: agriculture
NACE group code: 10.5: Manufacture of dairy products
NACE class code: 10.51: Operation of dairies and cheese making

### Companies Undertakings
| companies                                          |
|:---------------------------------------------------|
| Milchförderungsfonds                               |
| Deutscher Bauernverband                            |
| Deutscher Raiffeisenverband                        |
| Bundesverband der Raiffeisen-Warengenossenschaften |
| Zentralverband der Privatmolkereien                |
| Milchindustrieverband                              |

### Market
Relevant market includes geographical areas such as the United Kingdom, Italy, France, Greece, and non-member countries. The market is outside the EU.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1955-01-01 | Presidents of the German Farmers' Union and the German Raiffeisen Association | established the Milchförderungsfonds for promoting milk and dairy products |
| 1962-02-06 | redacted | Council adopted Regulation No 17 |
| 1962-04-04 | redacted | Council adopted Regulation No 26 |
| 1973-02-07 | redacted | amended the Guidelines on the financing and use of the MFF |
| 1973-04-25 | Central Association of the Private Dairy Industry | sent letter to MFF stating export support significantly assisted and boosted exports |
| 1978-12-12 | MFF | issued guidelines for use of MFF to promote butter exports to UK |
| 1978-12-12 | redacted | issued guidelines for marketing campaign to recover lost sales in UK |
| 1979-11-23 | MFF | issued guidelines for use of MFF to support marketing of German butter exports |
| 1979-11-23 | redacted | issued guidelines for marketing campaign to promote butter exports to UK |
| 1980-12-04 | MFF | issued guidelines for use of MFF to help exporters keep up sales levels and make up lost ground in UK market |
| 1980-12-04 | redacted | issued guidelines for marketing campaign to promote butter exports to UK |
| 1982-06-22 | Commission | initiated proceedings in this case |
| 1984-12-07 | Commission | issued Commission Decision

### Legal Framework
Legal framework applying to the case: Article 85 (operative article) and Article 85 (all relevant articles). Canonical concept: anticompetitive agreement.

### Infringement Category
horizontal

### Infringement Sub Category
export cartels

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders are mentioned in the provided context.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the Milchförderungsfonds engaged in anticompetitive practices under Article 85 of the EC Treaty, resulting in a formal decision issued in December 1984.


*(reported: 2026-11-11 10:54:44)*

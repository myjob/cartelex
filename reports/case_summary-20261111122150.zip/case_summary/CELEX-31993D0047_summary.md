# 'IV/32.447', 'NA'

**CELEX ID:** CELEX-31993D0047  
**Industry:** maritime transport  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0047 | IV/32447  |

### Case Title
IV/32.447

### Overview
This case involves Mewac, a company in the maritime transport industry, which was found to have infringed EU competition law by engaging in horizontal cartels involving market sharing, quota cartels, and specialization agreements. The infringement led to a decision by the European Commission imposing a fine of ECU 4000.

### Industry
maritime transport

### Oecd Nace
OECD sector: transport
NACE group code: 52.2: Support activities for transportation
NACE class code: 52.22: Service activities incidental to water transportation

### Companies Undertakings
Mewac

### Market
The market involves maritime trade and shipping services between Europe and West Africa, with countries including Spain, France, Italy, Yugoslavia, Mauritania, and Angola.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-12-22 | redacted | regulation adopted under Article 19 of Council Regulation (EEC) No 4056/86 |
| 1992-12-17 | Commission | adopted decision imposing a fine pursuant to Article 19 of Council Regulation (EEC) No 4056/86 |
| 1992-12-17 | Mewac | imposed fine of ECU 4000 for infringement of Article 18 |

### Legal Framework
The legal framework includes Articles 85 and 86, which pertain to anticompetitive agreements and abuse of dominance.

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Mewac | ECU 4000 |

### Remedies
Fine of ECU 4,000 imposed on Mewac for refusing to submit to an investigation ordered by the Commission

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission imposed a fine of ECU 4000 on Mewac for infringing EU competition law by participating in horizontal cartels.


*(reported: 2026-11-11 11:37:56)*

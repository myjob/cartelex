# 'NA', 'NA'

**CELEX ID:** CELEX-31969D0242  
**Industry:** watchmaking  
**Cartel Period:** 1967-01-01 : 1967-07-01  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31969D0242 | IV/26437-1 |

### Case Title
NA

### Overview
The European Commission investigated an anticompetitive agreement between Jaz S.A. (France) and Peter Uhren GmbH (Germany) in the watchmaking industry, involving vertical restraints such as exclusive dealing and territorial exclusivity.

### Industry
watchmaking

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.5:Manufacture of instruments and appliances for measuring, testing and navigation; watches and clocks
NACE class code: 26.52: Manufacture of watches and clocks

### Companies Undertakings
| company                                     |
|:--------------------------------------------|
| Jaz S.A., Paris, France                     |
| Peter Uhren GmbH, Rottweil (Baden), Germany |

### Market
Geographical market includes France and Germany. No indication of market outside EU, oligopoly, or turbulence.

### Cartel Period
1964-01-20 : 1967-01-11

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1967-01-11 | Jaz S.A. and Peter Uhren GmbH | concluded agreement concerning specialization and mutual supply |
| 1968-10-16 | redacted | increased dye prices by 8% in Germany, Netherlands, Belgium, and Luxembourg; increased by 12% in France; no increase in Italy |
| 1969-07-22 | Commission of the European Communities | issued decision under Article 85 of the EEC Treaty |
| 1977-01-10 | European Commission | decision expired |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure;Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
False

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared the agreement between Jaz S.A. and Peter Uhren GmbH not applicable under Article85 paragraph3 of the EEC Treaty, thus allowing it to continue without further coercive measures.

### Company Recidivism
| companies                  | recidivism   |
|:---------------------------|:-------------|
| Jaz S.A., Peter Uhren GmbH | True         |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission declared the agreement not applicable under Article 85 paragraph 3 of the EEC Treaty, allowing it to continue without further coercive measures.


*(reported: 2026-10-16 21:55:29)*

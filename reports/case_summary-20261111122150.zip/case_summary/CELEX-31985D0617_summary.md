# 'IV/30.839', 'Sperry New Holland'

**CELEX ID:** CELEX-31985D0617  
**Industry:** agricultural machinery  
**Cartel Period:** 1981 : 1983  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0617 | IV/30839  |

### Case Title
Sperry New Holland

### Overview
The European Commission investigated anticompetitive agreements in the agricultural machinery sector, focusing on vertical restraints such as territorial exclusivity and parallel trade bans. The case involved companies from multiple EU countries including Sperry New Holland (US), G. W. Van Driel en Van Dorsten BV (NL), P. J. Condellis SA (FR), and W. Burns Tractors Ltd (GB). The infringement occurred between 1981 and 1983, with the Commission taking action in December 1985.

### Industry
agricultural machinery

### Oecd Nace
OECD sector: manufacturing
NACE group code: 28.3: Manufacture of agricultural and forestry machinery
NACE class code: 28.30: Manufacture of agricultural and forestry machinery

### Companies Undertakings
| companies                         |
|:----------------------------------|
| Sperry New Holland                |
| Sperry New Holland — Sperry NV    |
| G. W. Van Driel en Van Dorsten BV |
| P. J. Condellis SA                |
| W. Burns Tractors Ltd             |

### Market
The relevant market includes the Netherlands, Greece, United Kingdom, Belgium, France, Germany, Italy, Denmark, and Luxembourg. The agricultural machinery sector is depressed, with 1984 recognized as a difficult year for manufacturers.

### Cartel Period
1981 : 1983

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-06-29 | Sperry New Holland | submitted notification regarding agreements |
| 1973-06-29 | SNH UK | notified the standard contract in use within the UK |
| 1973-06-29 | Commission | notified agreement containing contractual export ban |
| 1980-04-24 | the Commission | commented on the contract notified by SNH UK |
| 1980-11-20 | SNH UK | submitted a revised contract |
| 1981-01-01 | SNH I | banned exports to Greece |
| 1981-02-02 | Van Driel | discussed sales to Turkey |
| 1982-12-17 | SNH UK's sales manager | lodged a formal complaint with the Commission |
| 1983-06-03 | SNH | admitted infringements of competition rules |
| 1985-01-11 | Commission | sent statement of objections to SNH, Van Driel and Condellis |
| 1985-07-25 | SNH | participated in a hearing with Burns, Van Driel and their lawyers |
| 1985-12-16 | European Commission | adopted decision imposing fine |

### Legal Framework
Article 85 (operative)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought by Sperry New Holland — Sperry NV

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Sperry New Holland | 750 000 ECU |

### Remedies
To bring the infringements to an end forthwith; to remove all intra-Community territorial restrictions from their agreements and practice; to refrain from taking any measure having the same object or effect as the infringement; to adopt new contracts compatible with Community law; a fine of 750,000 ECU

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Sperry New Holland | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court           | country        | jurisdiction   |
|:----------------|:---------------|:---------------|
| Scottish courts | United Kingdom | Scotland       |

### Book Reference
NA

### Outcome
The European Commission imposed a fine of 750,000 ECU on Sperry New Holland for anticompetitive agreements. Remedies included ending the infringements, removing territorial restrictions, and adopting new contracts compatible with Community law. The case involved companies from multiple EU countries and was marked by recidivism in Sperry New Holland's history.


*(reported: 2026-11-11 11:01:20)*

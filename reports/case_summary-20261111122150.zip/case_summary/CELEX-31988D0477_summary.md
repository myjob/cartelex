# 'IV/31.593', 'British Dental Trade Association — BDTA'

**CELEX ID:** CELEX-31988D0477  
**Industry:** dental product and equipment  
**Cartel Period:** 1985 : 1986-12-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0477 | IV/31593  |

### Case Title
British Dental Trade Association — BDTA

### Overview
The European Commission investigated the British Dental Trade Association (BDTA) for anticompetitive behavior under Article 85 of the Treaty. The case involved a cartel period from 1985 to 1986, with BDTA found guilty of infringing Article 85(1). A fine was imposed, and an exemption was later granted with conditions.

### Industry
dental product and equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.5: Manufacture of medical and dental instruments and supplies
NACE class code: 32.50: Manufacture of medical and dental instruments and supplies

### Companies Undertakings
British Dental Trade Association (GB)

### Market
United Kingdom, outside EU

### Cartel Period
1985 : 1986-12-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-03-07 | British Dental Trade Association | made notification concerning exhibition policy |
| 1975-03-07 | BDTA | notified decision not to admit non-members to exhibition |
| 1985-07-03 | Commission | received complaint concerning BDTA's exhibition policy |
| 1985-12-16 | BDTA | confirmed general exhibition policy |
| 1985-12-17 | Commission | imposed fine on BDTA for infringement of Article 85(1) of the Treaty |
| 1985-12-17 | British Dental Trade Association | made second notification concerning exhibition policy |
| 1985-12-17 | BDTA | notified current Exhibition Policy, Rules and Regulations |
| 1986-12-16 | Commission | granted exemption |
| 1986-12-16 | BDTA | adopted Exhibition Policy, Rules and Regulations |
| 1986-12-16 | council of the BDTA | adopted the revised text of the Exhibition Policy, Rules and Regulations |
| 1987-04-29 | Commission | initiated proceedings in the case |
| 1988-07-11 | Commission | issued Commission Decision relating to BDTA exhibition policy |
| 1996-12-15 | Commission | exemption ended |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought and granted. The Commission granted an exemption with conditions such as notification of changes in policy and submission of annual exhibition calendars.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| British Dental Trade Association | 1 0 0 \ : 0 0 0 ^ { \cdot } \mathrm { E C U } |

### Remedies
Cease and desist order, imposition of a fine of ECU 1,000,000, and issuance of exemption with conditions such as notification of changes in policy and submission of annual exhibition calendars.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| British Dental Trade Association | True |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed a fine of ECU 1,000,000 on BDTA and granted an exemption with conditions. The case was concluded with the exemption ending in 1996.


*(reported: 2026-11-11 11:12:14)*

# 'IV/26623', 'International Chininkartell'

**CELEX ID:** CELEX-31969D0240  
**Industry:** quinine and cinchonidine  
**Cartel Period:** 1958-06-11 : 1966-03-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31969D0240 | IV/26623  |

### Case Title
International Chininkartell

### Overview
The International Chininkartell case involved an international cartel of chemical companies that coordinated the export pricing and distribution of quinine and quinidine from 1958 to 1966. The European Commission investigated and imposed monetary penalties on the participating companies, including N.V. Nederlandse Combinatie voor Chemische Industrie, Boehringer Mannheim GmbH, Buchler & Co., Société Chimique Pointet-Girard S.A., Société Nogentaise de Produits Chimiques, and Pharmacie Centrale de France. The cartel agreements were informally terminated in 1966 but continued in a dormant form.

### Industry
quinine and cinchonidine

### Oecd Nace
OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

OECD sector: manufacturing
NACE group code: 21.1:Manufacture of basic pharmaceutical products
NACE class code: 21.10: Manufacture of basic pharmaceutical products

### Companies Undertakings
| companies                                            | country   |
|:-----------------------------------------------------|:----------|
| N.V. Nederlandse Combinatie voor Chemische Industrie | NL        |
| Boehringer Mannheim GmbH                             | DE        |
| Buchler & Co.                                        | US        |
| Société Chimique Pointet-Girard S.A.                 | FR        |
| Société Nogentaise de Produits Chimiques             | FR        |
| Pharmacie Centrale de France                         | FR        |

### Market
Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

Geography:
| country     |
|:------------|
| Germany     |
| France      |
| Netherlands |
| Belgium     |
| Luxembourg  |
| Italy       |

Outside EU: true
Oligopoly: True
Turbulence:
raw material shortage, declining bark purchases, reduced deliveries from Congo and Indonesia, need to source from Bolivia, increased demand due to Vietnam war, political changes in Congo, economically and politically uncertain times

### Cartel Period
1958-06-11 : 1966-03-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1958-06-11 | Boehringer | signed contract concerning market reservation and pricing of quinine exports |
| 1959-04-01 | Federal Cartel Office | objected to export-cartel agreement between Boehringer and Nedchem |
| 1959-07-14 | Boehringer and Nedchem | concluded new agreement on export of quinine and quinidine |
| 1960-02-19 | redacted | issued note about quantity equalization |
| 1960-02-24 | redacted | issued circular regarding price maintenance |
| 1960-03-31 | Boehringer, Buchler, Nedchem | signed contract regulating export of quinine and quinidine |
| 1960-04-07 | redacted | signed contracts and gentlemen's agreements for distribution of chinidine and quinine |
| 1960-04-09 | companies involved in export agreements | signed gentlemen's agreements concerning export of quinine and quinidine |
| 1962-03-13 | redacted | began implementing competition-restricting cartel agreements |
| 1962-10-31 | members | submitted notifications of agreements to Commission |
| 1965-01-19 | Nedchem | extended validity of export contract and agreements |
| 1969-07-16 | Commission | issued decision imposing monetary penalties |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

Exemption case: True
Applicants: NA

### Leniency
Leniency: applicants, reductions granted and applications rejected, from the 'leniency_case', 'leniency_applicants', 'leniency_granted' and 'leniency_rejected' facts. Preserve markdown lists and tables if present.

Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
| company | amount |
| --- | --- |
| N.V. Nederlandse Combinatie voor Chemische Industrie | 210,000 billing units |
| Boehringer Mannheim GmbH | 190,000 billing units |
| Buchler & Co. | 65,000 billing units |
| Société Chimique Pointet-Girard S.A. | 12,500 billing units |
| Société Nogentaise de Produits Chimiques | 12,500 billing units |
| Pharmacie Centrale de France | 10,000 billing units |

### Remedies
The Commission imposed monetary fines on the infringing companies but did not issue specific cease and desist orders or structural remedies such as divestitures. The agreements were informally terminated in 1966, though continued behaviorally in a 'dormant' form.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
True

### Book Reference
NA

### Outcome
The Commission imposed monetary fines on the infringing companies but did not issue specific cease and desist orders or structural remedies such as divestitures. The agreements were informally terminated in 1966, though continued behaviorally in a 'dormant' form.


*(reported: 2026-11-11 09:48:27)*

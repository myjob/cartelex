# 'IV/30.299', "Grohe's distribution system"

**CELEX ID:** CELEX-31985D0044  
**Industry:** plumbing and sanitary ware  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0044 | IV/30299  |

### Case Title
IV/30299 – Grohe's distribution system

### Overview
The case concerns an anticompetitive agreement involving Friedrich Grohe Armaturenfabrik GmbH & Co. and several German trade associations, related to a selective distribution system that restricts resale to plumbing contractors. The European Commission found the agreement to be in violation of Article 85 of the EEC Treaty.

### Industry
plumbing and sanitary ware

### Oecd Nace
OECD sector: manufacturing
NACE group code: 46.7: Other specialised wholesale
NACE class code: 46.74: Wholesale of hardware, plumbing and heating equipment and supplies

### Companies Undertakings
| companies                                         | location                           |
|:--------------------------------------------------|:-----------------------------------|
| Friedrich Grohe Armaturenfabrik GmbH & Co.        | Hemer, Federal Republic of Germany |
| Bundesverband des Sanitar Fachhandels eV          | Bonn                               |
| Zentralverband Sanitar, Heizung, Klima            | St. Augustin                       |
| Bundesverband der Selbstbedienungs-Warenhäuser eV | Bonn                               |
| Hansa Metallwerke AG                              | NA                                 |

### Market
Relevant market includes Germany and several EU countries (France, Italy, United Kingdom, Netherlands, Belgium, Denmark). The market is described as oligopolistic with no turbulence noted. The market extends outside the EU.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-12-29 | Grohe | signed dealership agreement |
| 1981-02-12 | Grohe | notified dealership agreement |
| 1981-06-12 | BdsW | complained to Commission about introduction of dealership agreement |
| 1983-07-06 | Commission of the European Communities | decided to open proceedings in the case |
| 1983-07-19 | the Commission | sent Grohe a statement of objections questioning compatibility of dealership agreement terms with Article 85(1) of the EEC Treaty |
| 1984-10-31 | Grohe | informed Commission of intent to amend dealership agreement |
| 1984-12-10 | Commission of the European Communities | issued Commission Decision relating to a proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Legal framework: Article 85 (operative article), with relevant articles including Article 85. The canonical concept is anticompetitive_agreement.

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption was sought by Friedrich Grohe Armaturenfabrik GmbH & Co. but not granted.

### Leniency
NA

### Fines
NA

### Remedies
Refusal of exemption or negative clearance under Article 85(3) of the EEC Treaty, effectively ordering Grohe to cease the infringing conduct by not applying the selective distribution system that restricts resale to plumbing contractors.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Friedrich Grohe Armaturenfabrik GmbH & Co. | NA |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court                     | country        | jurisdiction       |
|:--------------------------|:---------------|:-------------------|
| European Court of Justice | European Union | European Community |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85 of the EEC Treaty, refusing exemption and ordering Grohe to cease the infringing conduct by not applying the selective distribution system that restricts resale to plumbing contractors.


*(reported: 2026-11-11 10:53:25)*

# 'COMP/E-1/37.027', 'Zinc phosphate'

**CELEX ID:** CELEX-32003D0437  
**Industry:** | industry           |
|:-------------------|
| paint and coatings |
| metal and mining   |
| chemicals          |
| chemicals          |  
**Cartel Period:** 1994-03-24 : 1998-05-13  

## Summary

### Celex Case Id
CELEX-32003D0437

### Case Title
Zinc phosphate

### Overview
This case involves a cartel of zinc phosphate producers operating within the European Economic Area (EEA) from 1994 to 1998. The cartel engaged in anticompetitive practices including price fixing and market allocation. The European Commission investigated and imposed significant fines on multiple companies involved, while also granting leniency reductions to certain applicants. The case was landmark in the context of EU competition law enforcement.

### Industry
paint and coatings, metal and mining, chemicals, chemicals

### Oecd Nace
manufacturing, 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms, 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
| company                                    | country   |
|:-------------------------------------------|:----------|
| Britannia Alloys & Chemicals Limited       | IN        |
| Dr. Hans Heubach GmbH & Co. KG             | DE        |
| James M. Brown Limited                     | GB        |
| Société Nouvelle des Couleurs Zinciques SA | FR        |
| Trident Alloys Limited                     | IN        |
| Waardals Kjemiske Fabrikker A/S            | NO        |
| ZIPHO                                      | CN        |
| VdMI                                       | IN        |

### Market
Netherlands, Market turbulence includes cheap imports from Asia, CEEC and Australia; strong fluctuations of zinc metal prices; buying power of multinational customers; substitutability of calcium phosphate; volatility in the zinc phosphate market.

### Cartel Period
1994-03-24 : 1998-05-13

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1994-03-24 | Britannia, Heubach, James Brown, SNCZ, Waardals | formed cartel to eliminate competition in EEA zinc phosphate market |
| 1994-03-24 | zinc phosphate producers | held first multilateral meeting |
| 1994-05-03 | Britannia, James Brown, Heubach, SNCZ, Waardals | agreed on details of implementing the cartel |
| 1994-08-09 | cartel members | allocated market share to Waardals |
| 1994-08-09 | cartel members | fixed bottom zinc phosphate prices for European countries |
| 1995-03-27 | Waardals | attended cartel meeting |
| 1996-05-21 | representatives of Britannia, Heubach, SNCZ and Waardals | held cartel meeting in London |
| 1997-03-15 | Britannia | sold zinc phosphate business to Trident |
| 1997-03-15 | Trident Alloys Ltd | began participation in continuing agreement in zinc phosphate sector |
| 1998-05-13 | Waardals | ended participation in the infringement |
| 1998-05-13 | Commission | carried out simultaneous investigations under Article 14(2) of Regulation No 17 |
| 2001-12-11 | European Commission | issued decision relating to proceeding |

### Legal Framework
Article 81, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
high

### Exemption
False

### Leniency
| company | amount |
| --- | --- |
| Waardals | 50% |
| Trident | 40% |
| Britannia | 10% |
| Heubach | 10% |
| James Brown | 10% |
| SNCZ | 10% |

### Fines
| company                                    | amount |
|:-------------------------------------------|:-------|
| Britannia Alloys & Chemicals Limited       | EUR 3,37 million |
| Dr Hans Heubach GmbH & Co. KG              | EUR 3,78 million |
| James M. Brown Limited                     | EUR 940 000 |
| Société Nouvelle des Couleurs Zinciques SA | EUR 1,53 million |
| Trident Alloys Limited                     | EUR 1,98 million |
| Waardals Kjemiske Fabrikker A/S            | EUR 350 000 |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                               | country        | jurisdiction                        |
|:------------------------------------|:---------------|:------------------------------------|
| European Court of Justice           | European Union | European Court of Justice           |
| General Court of the European Union | European Union | General Court of the European Union |

### Book Reference
COMP/E

### Outcome
The Commission ordered the undertakings to immediately bring to an end the infringements and to refrain from repeating any act or conduct referred to in Article 1, or from adopting any measure having equivalent object or effect.


*(reported: 2026-11-11 12:17:09)*

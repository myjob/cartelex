# 'IV/A-02702', 'Hummel-Isbecque'

**CELEX ID:** CELEX-31965D0426  
**Industry:** agricultural machinery  
**Cartel Period:** 1962-02-28 : 1965-04-07  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31965D0426 | IV/2702   |

### Case Title
Hummel-Isbecque

### Overview
This case involves two companies, Ludwig Hummel and Edmond Isbecque, who were investigated for cartel behavior in the agricultural machinery sector in Belgium. The investigation focused on an exclusive distribution agreement concluded in 1962 and amended in 1965.

### Industry
agricultural machinery

### Oecd Nace
OECD sector: manufacturing
NACE group code: 28.3:Manufacture of agricultural and forestry machinery
NACE class code: 28.30: Manufacture of agricultural and forestry machinery

### Companies Undertakings
| companies       |
|:----------------|
| Ludwig Hummel   |
| Edmond Isbecque |

### Market
Belgium

### Cartel Period
1962-02-28 : 1965-04-07

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-28 | Ludwig Hummel and Edmond Isbecque | concluded exclusive distribution agreement |
| 1965-04-07 | Ludwig Hummel and Edmond Isbecque | amended exclusive distribution agreement |
| 1970-09-01 | unknown | decision ceased to apply |

### Legal Framework
NA

### Infringement Category
Territorial exclusivity and parallel import /export bans

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
| company |
| --- |
| Ludwig Hummel |
| Edmond Isbecque |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders issued to terminate the infringement are explicitly mentioned in the provided text beyond the declaration that Article 85(1) is inapplicable to the agreement under certain conditions.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Walter Hallstein

### Courts
NA

### Book Reference
IV/2702

### Outcome
The case was determined to be an infringement case, but no specific remedies or fines were issued. The agreement was declared inapplicable to Article 85(1) under certain conditions.


*(reported: 2026-11-11 09:43:29)*

# 'IV/30.735', 'Deutsche Castrol Vertriebsgesellschaft mbH'

**CELEX ID:** CELEX-31983D0205  
**Industry:** motor vehicle lubricants  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0205 | IV/30735  |

### Case Title
Deutsche Castrol Vertriebsgesellschaft mbH

### Overview
The European Commission investigated Deutsche Castrol Vertriebsgesellschaft mbH for anticompetitive agreements under Article 85 of the EEC Treaty. The case involved vertical restraints, specifically Exclusive Dealing/Market Foreclosure.

### Industry
motor vehicle lubricants

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.5:Manufacture of other chemical products
NACE class code: 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
Deutsche Castrol Vertriebsgesellschaft mbH (DE)

### Market
Germany

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 |
| 1982-10-08 | Directorate-General for Competition | sent request for information to Castrol |
| 1982-11-29 | Directorate-General for Competition | sent follow-up request for information to Castrol |
| 1983-01-10 | redacted | adopted decision requiring replies to questions |
| 1983-01-10 | Commission | issued decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Étienne DAVIGNON

### Courts
| court                                        | country    | jurisdiction   |
|:---------------------------------------------|:-----------|:---------------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission found infringement under Article 85 and issued a decision requiring replies to questions. The case involved vertical restraints and was categorized as high gravity.


*(reported: 2026-11-11 10:44:24)*

# 'IV/29.132', 'Hugin/Liptons'

**CELEX ID:** CELEX-31978D0068  
**Industry:** cash register manufacturing  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0068 | IV/29132  |

### Case Title
Hugin/Liptons

### Overview
This case involved Hugin and Liptons, companies in the cash register manufacturing industry. The European Commission found that Hugin engaged in abuse of dominance by refusing to supply spare parts and services to Liptons, which was deemed an anticompetitive agreement under Articles 85 and 86 of the EC Treaty.

### Industry
cash register manufacturing

### Oecd Nace
manufacturing

OECD & NACE classifications:
- OECD sector: manufacturing
- NACE group code: 95.2: Repair of personal and household goods
- NACE class code: 95.21: Repair of consumer electronics

### Companies Undertakings
| company                                           |
|:--------------------------------------------------|
| Hugin Kassaregister AB                            |
| Hugin Cash Registers Ltd                          |
| Liptons Cash Registers and Business Equipment Ltd |

Countries:
- Hugin Kassaregister AB: SE
- Hugin Cash Registers Ltd: SE
- Liptons Cash Registers and Business Equipment Ltd: GB

### Market
Relevant market:
- Geography: United Kingdom, Belgium, France, Italy
- Structure: Oligopoly
- Turbulence: NA
- Outside EU: false

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1969-04-23 | Liptons | appointed main agent to sell Hugin cash registers in England, Scotland and Wales with right to service and repair |
| 1972-10-23 | Hugin UK | refused to supply cash registers or spare parts |
| 1973-01-01 | Hugin Kassaregister AB and Hugin Cash Registers Ltd | refused to supply spare parts for cash registers to Liptons |
| 1977-04-22 | Commission | initiated proceeding against Hugin Group |
| 1977-12-08 | Commission of the European Communities | issued Commission Decision

### Legal Framework
Legal framework applying to the case:
- Operative articles: Article 86
- All relevant articles: Article 85, Article 86
- Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Hugin Kassaregister AB | £20 833 |
| Hugin Cash Registers Ltd | £20 833 |

### Remedies
Hugin Kassaregister AB and Hugin Cash Registers Ltd must bring the infringements to an end without delay; Hugin Cash Registers Ltd shall submit proposals within one month for resuming supplies of spare parts to Liptons; a daily penalty of 1,000 units of account is payable for each day of delay in resuming supply; Hugin AB must submit proposals related to resumption of supplies and ensure sufficient long-term supply at appropriate market prices.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Hugin Kassaregister AB | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country            | jurisdiction   |
|:---------------------------------------|:-------------------|:---------------|
| Commission of the European Communities | European Community | EC Treaty      |
| High Court                             | England            | London         |

### Book Reference
NA

### Outcome
The Commission found Hugin guilty of abuse of dominance and anticompetitive agreements. Fines were imposed on Hugin Kassaregister AB and Hugin Cash Registers Ltd. Remedies included immediate cessation of the infringements, submission of proposals for resuming supplies, and daily penalties for delays.


*(reported: 2026-11-11 10:20:02)*

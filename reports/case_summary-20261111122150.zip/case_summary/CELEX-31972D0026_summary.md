# NA

**CELEX ID:** CELEX-31972D0026  
**Industry:** carbonless copy paper  
**Cartel Period:** 1963-01-31 : 1971-12-22  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0026 | IV/5405   |

### Case Title
IV/5405

### Overview
The European Commission investigated a cartel involving Geha-Werke GmbH and Burroughs Corporation in the carbonless copy paper industry. The investigation covered the period from 1962 to 1971, with the Commission ultimately determining that the agreement did not restrict competition.

### Industry
carbonless copy paper

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 17.2:Manufacture of articles of paper and paperboard
NACE_class_code: 17.23: Manufacture of paper stationery

### Companies Undertakings
| companies             |
|:----------------------|
| Geha-Werke GmbH       |
| Burroughs Corporation |

### Market
Germany, France, Italy
Market outside EU: true
Market oligopoly: NA
Market turbulence: NA

### Cartel Period
1962-10-31 : 1971-12-22

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-01-31 | BurroughsAG | registered license agreement under Regulation No.17 |
| 1971-01-01 | redacted | agreement amended |
| 1971-12-22 | European Commission | issued decision on license agreement |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders were issued. The Commission determined that the agreement did not restrict competition and therefore did not require any corrective measures.

### Company Recidivism
| companies                              | recidivism   |
|:---------------------------------------|:-------------|
| Geha-Werke GmbH, Burroughs Corporation | NA           |

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
IV/5405
Patents and other intellectual property rights

### Outcome
The European Commission took no action, concluding that the agreement did not restrict competition.


*(reported: 2026-10-16 19:12:47)*

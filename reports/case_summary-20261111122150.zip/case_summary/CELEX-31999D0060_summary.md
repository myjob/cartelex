# 'IV/35.691/E-4', 'Pre-Insulated Pipe Cartel'

**CELEX ID:** CELEX-31999D0060  
**Industry:** pre-insulated pipe industry  
**Cartel Period:** 1991-01-01 : 1996-03-25  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0060 | IV/35691  |

### Case Title
Pre-Insulated Pipe Cartel

### Overview
This case involves a cartel in the pre-insulated pipe industry, where companies engaged in horizontal restraints such as market sharing, quota cartels, and bid-rigging. The infringement occurred between 1991 and 1996 under Article 85 of the EC Treaty.

### Industry
pre-insulated pipe industry

### Oecd Nace
manufacturing
24.2:Manufacture of tubes, pipes, hollow profiles and related fittings, of steel
24.20: Manufacture of tubes, pipes, hollow profiles and related fittings, of steel

### Companies Undertakings
| company                                                               |
|:----------------------------------------------------------------------|
| ABB Asea Brown Boveri Ltd                                             |
| Brugg Rohrsysteme GmbH                                                |
| Dansk Rørindustri A/S                                                 |
| De Henss/Isoplus group                                                |
| Oy KWH Tech AB                                                        |
| Løgstør Rør A/S                                                       |
| Pan-Isovit GmbH                                                       |
| Sigma Tecnologie di Rivestimento Srl                                  |
| Tarco Energi A/S                                                      |
| HFB Holding für Fernwärmetechnik Beteiligungsgesellschaft mbH & Co KG |
| Isoplus Fernwärmetechnik GmbH                                         |
| Isoplus Fernwärmetechnik Ges mbH                                      |
| Isoplus Fernwärmetechnik Ges mbH — stille Gesellschaft                |
| European District Heating Pipe Manufacturers Association              |
| ABB IC Møller A/S                                                     |
| Dipl-Kfm Walter Henss GmbH                                            |
| Dipl-Kfm Walter Henss Fernwärmerohrleitungsbau GmbH                   |
| Isoplus Fernwärmetechnik GmbH                                         |
| Oy KWH Pipe AB                                                        |

### Market
The market includes Denmark, Germany, Sweden, Austria, Italy, Switzerland, Netherlands, France, United Kingdom, Poland, Hungary, Czech Republic, Russia, China, Finland, and Baltic republics. The market is outside the EU and is characterized as an oligopoly with high turbulence due to price wars, distrust, and competitive friction.

### Cartel Period
1991-01-01 : 1996-03-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-12-01 | ABB and Pan-Isovit | began discussions forming informal strategic alliance |
| 1991-01-01 | Danish producers | implemented concerted price increase in export markets |
| 1991-01-16 | the Popes | met to finalize detailed terms of the agreement |
| 1991-01-23 | ABB | compiled individual price lists into a single reference document |
| 1991-03-04 | producers | agreed on quotas |
| 1991-10-09 | producers | agreed on 6% price increase |
| 1992-01-01 | ABB | implemented price increase in accordance with cartel agreement |
| 1992-12-10 | managing directors of main suppliers to the German market | held meeting of managing directors |
| 1994-08-18 | ABB | implemented common price list agreement |
| 1995-01-01 | German Contact Group | implemented no discounts policy for orders after 1 January 1995 |
| 1996-04-18 | ABB and Løgstør | met in Denmark with a view to continuing cooperation |
| 1996-06-09 | redacted | held meeting in Zurich |
| 1998-10-21 | Commission | issued commission decision relating to pre-insulated pipe cartel |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)
infringement_concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements
bid-rigging and tender fixing

### Infringement Gravity
high

### Exemption
NA

### Leniency
| company   |
|:----------|
| ABB       |
| KWH       |

| company    | amount   |
|:-----------|:---------|
| Tarco      | 30%      |
| Starpipe   | 20%      |
| Pan-Isovit | 20%      |
| ABB        | 30%      |
| Løgstør    | 30%      |

KWH

### Fines
| company | amount |
| --- | --- |
| ABB Asea Brown Boveri Ltd | ECU 70,000,000 |
| Brugg Rohrsysteme GmbH | ECU 925,000 |
| Dansk Rørindustri A/S | ECU 1,475,000 |
| De Henss/Isoplus group | ECU 4,950,000 |
| Ke-Kelit Kunststoffwerk Ges mbH | ECU 360,000 |
| Oy KWH Tech AB | ECU 700,000 |
| Løgstør Rør A/S | ECU 8,900,000 |
| Pan-Isovit GmbH | ECU 1,500,000 |
| Sigma Tecnologie Di Rivestimento S. r. l. | ECU 400,000 |
| Tarco Energi A/S | ECU 1,475,000 |
| Starpipe | ECU 1,475,000 |
| Henss/Isoplus | ECU 4,950,000 |
| Pan-Isovit | ECU 1,500,000 |

### Remedies
The undertakings must bring the infringement to an end and refrain from any agreement, concerted practice, or decision that has the same or similar object or effect as the infringement, particularly in relation to market-sharing, price fixing, or bid-rigging.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission took action, requested information, and issued a decision. Fines were imposed on multiple companies, with ABB receiving the highest fine at ECU 70,000,000. Leniency was granted to several applicants, including ABB and Pan-Isovit, while KWH was rejected. The case involved the European Court of Justice.


*(reported: 2026-11-11 11:57:44)*

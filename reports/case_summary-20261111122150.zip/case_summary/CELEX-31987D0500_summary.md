# 'IV/32.279', 'Interim measures'

**CELEX ID:** CELEX-31987D0500  
**Industry:** brass band instruments  
**Cartel Period:** 1987-03-01 : 1987-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0500 | IV/32279  |

### Case Title
Interim measures

### Overview
This case involved an investigation into abuse of dominance by companies in the brass band instruments industry, specifically focusing on the cessation of supplies to certain customers. The European Commission took action under Article 86 of the EC Treaty.

### Industry
brass band instruments

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.2:Manufacture of musical instruments
NACE class code: 32.20: Manufacture of musical instruments

### Companies Undertakings
| companies                                          |
|:---------------------------------------------------|
| Boosey & Hawkes plc                                |
| Brass Band Instruments Ltd                         |
| Gabriel's Horn House (Band Instrument Company) Ltd |
| RCN Music                                          |

### Market
| country     |
|:------------|
| Netherlands |
| Belgium     |
| Denmark     |
| Germany     |

### Cartel Period
1987-03-12 : 1987-07-29

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted First Regulation implementing Articles 85 and 86 |
| 1987-03-12 | Brass Band Instruments Ltd and others | filed application alleging infringement |
| 1987-04-27 | Commission | opened a proceeding in the case |
| 1987-07-29 | Commission | issued Commission Decision |
| 1987-07-29 | redacted | decision adopted in Brussels |
| 1987-12-31 | B&H | obligation to supply GHH ends |

### Legal Framework
Article 86
infringement_concept: abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company             | amount    |
|:--------------------|:----------|
| Boosey & Hawkes plc | 1 000 ECU |

### Remedies
The Commission ordered B&H to resume supplies of instruments, spare parts, and materials to GHH and RCN. Supplies must be made at terms equivalent to those before the cessation of supplies. GHH is entitled to a 5% cash settlement discount if payment is made in cash or by banker's draft. Supplies to RCN must be at reasonable prices and paid in cash. B&H must notify the Commission of any change in list prices and terms of trade, ensure quality control, and inform the Commission if any item cannot be supplied immediately.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
False

### Book Reference
NA

### Outcome
The Commission ordered Boosey & Hawkes plc to resume supplies of instruments, spare parts, and materials to GHH and RCN under specific terms. A fine of 1,000 ECU was imposed on Boosey & Hawkes plc.


*(reported: 2026-10-16 20:25:22)*

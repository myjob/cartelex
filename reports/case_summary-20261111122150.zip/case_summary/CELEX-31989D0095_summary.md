# NA

**CELEX ID:** CELEX-31989D0095  
**Industry:** Banking and Payment Services  
**Cartel Period:** 1984-06-29 : 1988-12-19  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0095 | IV/31291  |

### Case Title
Eurocheque Case

### Overview
The European Commission investigated a cartel involving multiple banks and financial institutions in the banking and payment services sector. The case centered on anti-competitive agreements related to Eurocheques and related products, specifically focusing on vertical restraints such as Exclusive Dealing / Market Foreclosure.

### Industry
Banking and Payment Services

### Oecd Nace
OECD Sector: banking and insurance (including real estate)
NACE Group Code: 64.1: Monetary intermediation
NACE Class Code: 64.11: Central banking

### Companies Undertakings
| companies                                    | location                                                           |
|:---------------------------------------------|:-------------------------------------------------------------------|
| Eurocheque International sc                  | Avenue Louise 327, Boite 1, B-1050 Bruxelles                       |
| Agrupacion Española Eurocheque               | Los Madrazo 28, E-28014 Madrid                                     |
| Association for Payment Clearing Services    | Mercury House Triton Court, 14 Finsbury Square, UK-London EC21 1BR |
| Associazione Bancaria Italiana               | Piazza del Gesù, I-00186 Roma                                      |
| Bundesverband Deutscher Banken eV            | MohrenstraBe 35/41, Postfach 100246, D-5000 Koln 1                 |
| Communauté Luxembourgeoise Eurocheque        | Boulevard F. D. Roosevelt 14, L-2450 Luxembourg                    |
| Comunidade Portuguesa Eurocheque             | Rua de S. Nicolau 71-5o-dt, P-1100 Lisboa                          |
| Eurocheque Belgium                           | Avenue Louise 327, Boite 6, B-1050 Bruxelles                       |
| Groupement des cartes bancaires              | 29 rue de Lisbonne, F-75008 Paris                                  |
| Irish Banks' Standing Committee              | Nassau House, Nassau Street, IRL-Dublin 2                          |
| Pengeinstitutternes Betalingssystemer A/S    | Postboks 500, Lautrupbjerg 10, DK-2750 Ballerup                    |
| Stichting Bevordering Chequeverkeer          | Postbus 9120, NL-1006 CB Amsterdam                                 |
| Agrupacio Andorrana Eurocheque               | Boite Postale 60, Correus Francesos, AND-Andorra la Vella          |
| Association Suisse des Banquiers             | Aeschenplatz 7, CH-Bale                                            |
| Den Norske Bankforening                      | Dronning Maudsgt. 15, N-0116 Oslo 1                                |
| Bank of Cyprus (Holdings) Ltd                | 4 Diagoras Street, Nicosia, (Cyprus)                               |
| The Association of Yugoslav Banks            | Masarikova 5/IX, Yu-11000 Beograd                                  |
| The Finnish Bankers' Association             | Annankatu 32 A, SF-00100 Helsinki                                  |
| Svenska Bankföreningen                       | Box 7603, S-103 94 Stockholm                                       |
| Verband Osterreichischer Banken und Bankiers | Börsegasse 11, Postfach 132, A-1013 Wien                           |

### Market
The market involved multiple EU countries including Belgium, Spain, United Kingdom, Italy, Germany, Luxembourg, Portugal, France, Denmark, Netherlands, Andorra, Switzerland, Norway, Cyprus, Finland, Sweden, and Austria. It also extends beyond the EU.

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-10-31 | redacted | concluded agreement on Eurocheques drawn abroad in local currency |
| 1983-05-19 | Eurocheque Assembly | approved guidelines for the production of the uniform Eurocheque |
| 1983-05-20 | Eurocheque Assembly | continued work on guidelines for the production of the uniform Eurocheque |
| 1984-07-19 | Secretary-General of Eurocheque International | submitted notification and application for negative clearance concerning approved guidelines |
| 1987-06-04 | Eurocheque Assembly | adopted guidelines for production of uniform Eurocheque and uniform Eurocheque card |
| 1987-06-05 | Eurocheque Assembly | adopted guidelines for production of uniform Eurocheque and uniform Eurocheque card |
| 1987-06-05 | Eurocheque Assembly | continued work on amended versions of the guidelines |
| 1988-12-19 | Commission | issued Commission Decision |

### Legal Framework
Article 85 (operative article)
Infringement Concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
medium

### Exemption
True
Applicants:
| company                                   |
|:------------------------------------------|
| Eurocheque International sc               |
| Agrupacion Española Eurocheque            |
| Association for Payment Clearing Services |
| Associazione Bancaria Italiana            |
| Bundesverband Deutscher Banken eV         |
| Communauté Luxembourgeoise Eurocheque     |
| Comunidade Portuguesa Eurocheque          |
| Eurocheque Belgium                        |
| Groupement des cartes bancaires           |
| Irish Banks' Standing Committee           |
| Pengeinstitutternes Betalingssystemer A/S |
| Stichting Bevordering Chequeverkeer       |
| Agrupacio Andorrana Eurocheque            |
| Association Suisse des Banquiers          |
| Den Norske Bankforening                   |
| Bank of Cyprus (Holdings) Ltd             |

### Leniency
NA

### Fines
NA

### Remedies
The Commission did not issue specific cease and desist orders, divestiture requirements, or explicit behavioral remedies against any of the mentioned entities. Instead, it declared that the provisions of Article 85(1) of the EEC Treaty are inapplicable to the guidelines for finishing the uniform Eurocheque and card from 5 June 1987 to 4 June 2002.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
True

### Book Reference
NA

### Outcome
The Commission declared that the provisions of Article 85(1) of the EEC Treaty are inapplicable to the guidelines for finishing the uniform Eurocheque and card from 5 June 1987 to 4 June 2002, effectively granting an exemption.


*(reported: 2026-10-16 20:12:13)*

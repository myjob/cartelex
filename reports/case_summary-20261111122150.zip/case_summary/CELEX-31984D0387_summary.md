# 'IV/30.863', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31984D0387  
**Industry:** | industry        |
|:----------------|
| Chemicals       |
| Petro-chemicals |
| Plastics        |  
**Cartel Period:** 1982-08-01 : 1998-01-27  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31984D0387 | IV/30.863 |
| CELEX-31984D0387 | IV/30863  |

### Case Title
relating to a proceeding under Article 85 of the EEC Treaty

### Overview
This case concerns anticompetitive agreements between Imperial Chemical Industries plc (ICI) and BP Chemicals Limited (BPCL) in the chemicals industry, specifically involving horizontal cartels related to market sharing, quota cartels, and specialization agreements.

### Industry
Chemicals
Petro-chemicals
Plastics

### Oecd Nace
OECD sector: manufacturing
NACE group code: 06.2: Extraction of natural gas
NACE class code: 06.20: Extraction of natural gas

### Companies Undertakings
| companies                        |
|:---------------------------------|
| Imperial Chemical Industries plc |
| BP Chemicals Limited             |

### Market
Relevant market includes the United Kingdom and the European Economic Community, with market outside EU being true. The market is oligopolistic.

### Cartel Period
1982-08-01 : 1998-01-27

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-08-01 | redacted | agreements became effective |
| 1983-01-28 | Imperial Chemical Industries plc | submitted application and notification |
| 1983-02-08 | BP Chemicals Limited | submitted application and notification |
| 1984-07-19 | redacted | issued Commission Decision |
| 1987-01-01 | ICI | submitted report to Commission covering LDPE sales and production |
| 1989-12-31 | ICI | submitted report to Commission covering LDPE sales and production |
| 1989-12-31 | BPCL | submitted report on PVC production and sales in UK |
| 1998-01-27 | redacted | period of inapplicability of EEC Treaty provisions ends for agreements between ICI and BPCL |
| 1998-01-27 | redacted | exemption period for long-term strategies ended |

### Legal Framework
Article 85 (operative article)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company                          |
|:---------------------------------|
| Imperial Chemical Industries plc |
| BP Chemicals Limited             |

### Leniency
NA

### Fines
NA

### Remedies
ICI and BPCL must close down their respective LDPE and PVC plants not involved in the main agreements; ICI must submit annual reports on LDPE sales in the UK every three years; BPCL is required to operate its newly acquired LDPE plant for three years; ICI has a veto over any sale of BPCL's plant for a limited period; ICI and BPCL are bound by long-term strategies that dictate their operations; an exemption from Article 85(1) is granted for 15 years (until 27 January 1998) with conditions.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/30.863

### Outcome
NA


*(reported: 2026-10-16 20:06:46)*

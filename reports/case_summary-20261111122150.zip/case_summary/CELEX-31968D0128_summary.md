# 'NA', 'NA'

**CELEX ID:** CELEX-31968D0128  
**Industry:** | industry    |
|:------------|
| gypsum      |
| gypsum-rock |
| anhydrite   |  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31968D0128 | IV/26352  |

### Case Title
NA

### Overview
The case involves the Eurogypsum Association, which was investigated for cartel behavior in the gypsum industry. The cartel period spans from 1900-01-01 to 2030-12-31. Key events include the adoption and final approval of statutes by the association in 1961 and 1962, respectively, followed by a negative test decision issued by the Commission in 1968.

### Industry
gypsum, gypsum-rock, anhydrite

### Oecd Nace
OECD sector: manufacturing; NACE group code: 07.2:Mining of non-ferrous metal ores; NACE class code: 07.21: Mining of uranium and thorium ores

### Companies Undertakings
Eurogypsum Association

### Market
NA

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1961-04-28 | Eurogypsum Association | adopted statutes at General Assembly meeting |
| 1962-06-18 | Eurogypsum Association | final approval of statutes at meeting |
| 1968-02-26 | Commission of the European Communities | issued negative test decision |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision but did not take any action.


*(reported: 2026-10-16 19:21:37)*

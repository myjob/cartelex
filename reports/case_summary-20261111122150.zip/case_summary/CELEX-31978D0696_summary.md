# 'IV/29.440', 'Arthur Bell and Sons Ltd — conditions of sale'

**CELEX ID:** CELEX-31978D0696  
**Industry:** whisky distilling and distributing  
**Cartel Period:** 1973-01-01 : 1977-10-14  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0696 | IV/29.440 |
| CELEX-31978D0696 | IV/29440  |

### Case Title
Arthur Bell and Sons Ltd — conditions of sale

### Overview
The European Commission found that Arthur Bell and Sons Ltd infringed Article 85 of the Treaty by imposing conditions of sale that restricted trade customers from reselling Scotch whisky outside the UK, constituting vertical restraints related to territorial exclusivity and parallel trade bans.

### Industry
whisky distilling and distributing

### Oecd Nace
OECD: manufacturing
NACE group code: 11.0:Manufacture of beverages
NACE class code: 11.01: Distilling, rectifying and blending of spirits

### Companies Undertakings
Arthur Bell and Sons Ltd

### Market
United Kingdom
Market outside EU: true

### Cartel Period
1973-01-01 : 1977-10-14

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-01-01 | Bell | restricted trade customers from reselling Scotch whisky outside the UK |
| 1973-01-01 | Arthur Bell and Sons Ltd | infringed Article 85 of the Treaty |
| 1973-01-01 | Arthur Bell and Sons Ltd | began applying conditions of sale to trade customers |
| 1976-02-04 | Commission | made request for information under Article 11 of Regulation No 17 |
| 1976-03-05 | Bell | submitted reply to Commission's request |
| 1977-09-21 | Commission | opened proceedings against Bell's conditions of sale |
| 1977-10-14 | Arthur Bell and Sons Ltd | withdrew explicit export prohibition |
| 1977-10-14 | Arthur Bell and Sons Ltd | ended applying conditions of sale to trade customers |
| 1977-10-14 | Bell | implemented new conditions of sale limiting prohibition to export only to countries outside the European Economic Community |
| 1978-01-17 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on Bell's conditions of sale |
| 1978-07-28 | Commission | adopted decision addressing infringement |
| 1978-07-28 | Commission of the European Communities | issued decision on Bell's conditions of sale |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
Cease and desist order requiring Arthur Bell and Sons Ltd to refrain from further action by means of their sales conditions calculated to restrict the exportation from the United Kingdom to other EEC countries of Scotch whisky bought by trade customers established in the United Kingdom.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Arthur Bell and Sons Ltd | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
IV/29.440
Case is landmark in book: IV/29.440, IV/29440
Infringement type in book: Territorial exclusivity and parallel import /export bans

### Outcome
The Commission adopted a decision finding that Arthur Bell and Sons Ltd infringed Article 85 of the Treaty by imposing conditions of sale restricting trade customers from reselling Scotch whisky outside the UK. Remedies included a cease and desist order.


*(reported: 2026-11-11 10:24:53)*

# 'IV/31.559', 'Sippa'

**CELEX ID:** CELEX-31991D0128  
**Industry:** paper  
**Cartel Period:** 1985-01-01 : 1991-02-15  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0128 | IV/31559  |

### Case Title
Sippa

### Overview
The case concerns the Comité du Salon de la Papeterie, a French organization that organizes a paper goods exhibition. The Commission granted an exemption from EU competition law under Article 85 for horizontal restraints related to the organization's activities.

### Industry
paper

### Oecd Nace
manufacturing
17.2:Manufacture of articles of paper and paperboard
17.23: Manufacture of paper stationery

### Companies Undertakings
Comité du Salon de la Papeterie (FR)

### Market
France

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1901-07-01 | Comité du Salon de la Papeterie | established under French Law of 1 July 1901 |
| 1972-03-13 | Comité du Salon de la Papeterie | founded on 13 March 1972 |
| 1985-06-12 | Comité du Salon de la Papeterie | submitted application for negative clearance or exemption |
| 1986-02-20 | Commission | sent comfort letter endorsing regulations |
| 1989-02-07 | Commission | revoked comfort letter without retroactive effect |
| 1990-02-01 | Comité du Salon de la Papeterie | organized the beginning of the 1990 Salon |
| 1990-02-05 | Comité du Salon de la Papeterie | concluded the 1990 Salon |
| 1990-04-10 | Comité du Salon de la Papeterie | adopted new general regulations |
| 1990-04-10 | Comité | amended articles of association at extraordinary general meeting |
| 1991-02-15 | Commission | issued decision applying exemption from competition law |
| 1991-02-15 | Commission of the European Communities | issued decision relating to Sippa proceeding |
| 2000-04-18 | redacted | exemption period ended |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The Commission ordered the Comité du Salon de la Papeterie to inform the Commission immediately of any changes in or addition to Sippa's general regulations; to inform the Commission of any decision to refuse an exhibitor admission or to exclude an exhibitor from Sippa; and to send the Commission immediately a copy of any arbitration award refusing an exhibitor's application for admission or excluding an exhibitor from Sippa.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption from EU competition law under Article 85 for horizontal restraints related to the Comité du Salon de la Papeterie's activities, allowing it to operate without being subject to certain antitrust provisions.


*(reported: 2026-10-16 20:17:36)*

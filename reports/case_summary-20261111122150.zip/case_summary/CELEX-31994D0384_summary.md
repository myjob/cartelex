# 'IV/32.075', 'Bayer/BP Chemicals'

**CELEX ID:** CELEX-31994D0384  
**Industry:** NA  
**Cartel Period:** 1988-03-01 : 1994-06-06  

## Summary

### Celex Case Id
CELEX-31994D0384 / IV/32075-2

### Case Title
IV/32.075 – Bayer/BP Chemicals

### Overview
Investigation into a joint venture cartel involving Bayer AG, BP Chemicals International Ltd, and Erdölchemie GmbH in the polyethylene market. The cartel operated from March 1988 to June 1994, engaging in anticompetitive agreements under Article 85 of the EC Treaty.

### Industry
Manufacturing, specifically the production of plastics in primary forms (NACE 20.16)

### Oecd Nace
manufacturing / 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms / 20.16: Manufacture of plastics in primary forms

### Companies Undertakings
- Bayer AG (DE)
- BP Chemicals International Ltd (GB)
- Erdölchemie GmbH (DE)

### Market
The polyethylene market is changing rapidly, especially in terms of product types and production capacity, due to shifts from general-purpose to specialty grades and technological advancements.

### Cartel Period
1988-03-01 : 1994-06-06

### Key Timeline
- 1988-03-01: Agreement entered into force
- 1989-01-02: First report submitted (covering period from 1987-10-03 to 1989-01-02)
- 1992-01-02: Report submitted under new two-year reporting schedule
- 1992-01-03: Commission implemented new reporting requirements for polyethylene data
- 1994-01-03: Commission required annual reporting of polyethylene data
- 1994-06-06: Decision signed
- 1998-10-02: Final report received covering polyethylene data period

### Legal Framework
Article 85 (anticompetitive agreement)

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
Exemption sought by all three companies involved.

### Leniency
NA

### Fines
NA

### Remedies
Postponement of closure of EC's older LDPE unit (PE1) until end of 1994; annual reporting starting from 3 January 1994, within three weeks of period end; requirement to notify Commission in advance about initiatives or operations related to products concerned; obligation to inform Commission of renewals or extensions to agreements.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision in June 1994, imposing remedies to address the anticompetitive behavior, including reporting obligations and notification requirements.


*(reported: 2026-11-11 11:45:01)*

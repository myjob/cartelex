# 'IV/28.852', 'GB-Inno-BM/Fedetab'

**CELEX ID:** CELEX-31978D0670  
**Industry:** tobacco industry  
**Cartel Period:** 1962-03-13 : 1977-06-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0670 | IV/29149  |

### Case Title
GB-Inno-BM/Fedetab

### Overview
This case involves a cartel in the Belgian tobacco industry, where multiple companies engaged in anticompetitive agreements under Article 85 of the Treaty on the Functioning of the European Union. The infringement involved vertical restraints, specifically territorial exclusivity and selective distribution, with high gravity.

### Industry
tobacco industry

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 12.0:Manufacture of tobacco products
NACE_class_code: 12.00: Manufacture of tobacco products

### Companies Undertakings
| company                              |
|:-------------------------------------|
| Fedetab ASBL                         |
| Cinta SA                             |
| Ets Gosset SA                        |
| Jubilé SA                            |
| Vander Elst SA                       |
| Weltab SA                            |
| BAT Benelux SA                       |
| Heintz van Landewyck SARL            |
| GB-Inno-BM SA                        |
| Mestdagh Frères & Cie                |
| Eugène Huyghebaert                   |
| Éts Laurens SA                       |
| Ets Odon Warland SA                  |
| NV Tabalux                           |
| FNCG                                 |
| Association des détaillants en tabac |

### Market
Belgium, oligopoly market

### Cartel Period
1962-03-13 : 1977-06-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-03-13 | Fedetab | entered into agreements concerning organization of tobacco product distribution |
| 1967-10-05 | Fedetab | signed an additional agreement for interpretation of the resale price agreement |
| 1970-12-29 | Fedetab and FNCG | signed further amendment to the agreement |
| 1971-01-01 | Fedetab | continued enforcing fixed resale prices and restricting wholesale and retail pricing freedom |
| 1972-03-22 | Fedetab | implemented ban on resales to other wholesalers |
| 1972-06-30 | Fedetab | sent standard agreement to wholesalers |
| 1975-12-01 | Fedetab | implemented restrictive agreement dividing wholesalers and retailers into categories with fixed margins |
| 1976-05-10 | Fedetab | extended proceeding to notification |
| 1977-06-30 | redacted | agreement expired |
| 1977-12-23 | Fedetab | implemented joint measures on standard terms of payment |
| 1978-07-20 | Commission | addressed Decision to undertakings |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans;Selective Distribution

### Infringement Gravity
high

### Exemption
Exemption sought

### Leniency
NA

### Fines
NA

### Remedies
Terminate without delay the infringement referred to in Article 2; abstain from all acts having the same object as the Fedetab recommendation of 1 December 1975; inform all members to which this Decision has not been addressed of the contents thereof.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Fedetab ASBL | True |
| Cinta SA | True |
| Ets Gosset SA | True |
| Jubilé SA | True |
| Vander Elst SA | True |
| Weltab SA | True |
| BAT Benelux SA | True |
| Heintz van Landewyck SARL | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
| court                     | country    | jurisdiction              |
|:--------------------------|:-----------|:--------------------------|
| European Court of Justice | Luxembourg | European Court of Justice |

### Book Reference
NA

### Outcome
The Commission took a decision to terminate the infringement, and remedies were ordered to be implemented immediately.


*(reported: 2026-11-11 10:24:34)*

# 'IV/26699', 'Chiquita'

**CELEX ID:** CELEX-31976D0353  
**Industry:** Banana Trading  
**Cartel Period:** 1973-10 : 1975-02  

## Summary

### Celex Case Id
CELEX-31976D0353

| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31976D0353 | IV/26699  |

### Case Title
Chiquita

### Overview
The European Commission investigated United Brands Company and its subsidiaries for abuse of dominance and anticompetitive agreements in the banana trading market. The case involved a cartel period from October 1973 to February 1975, where the companies refused to supply Chiquita bananas to certain distributors under conditions that restricted competition.

### Industry
Banana Trading

### Oecd Nace
trade (wholesaling and retailing) and hotels

OECD & NACE classifications:
- OECD sector: trade (wholesaling and retailing) and hotels
- NACE group code: 10.3: Processing and preserving of fruit and vegetables
- NACE class code: 10.39: Other processing and preserving of fruit and vegetables

### Companies Undertakings
| companies                     | location                           |
|:------------------------------|:-----------------------------------|
| United Brands Company         | New York, United States of America |
| United Brands Continentaal BV | Rotterdam, the Netherlands         |
| UBC-Rotterdam                 | Rotterdam, the Netherlands         |

### Market
Oligopolistic market in several EU countries including Netherlands, Germany, Denmark, Ireland, and BLEU. No turbulence or outside EU market mentioned.

### Cartel Period
1973-10 : 1975-02

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-10-10 | United Brands Company | refused to supply Chiquita bananas to Th. Olesen A/S |
| 1973-10-10 | United Brands Company | informed Olesen that it would no longer supply Chiquita bananas |
| 1973-10-10 | UBC | withdrew Chiquita banana supplies from Olesen |
| 1973-12-19 | UBC | refused order and informed Olesen that Chiquita bananas could only be obtained in ripened condition |
| 1973-12-19 | Scipio | refused to supply green bananas to Olesen |
| 1975-02-11 | UBC | entered into agreement resuming supplies of bananas |
| 1975-02-11 | United Brands Company | ceased supplying Chiquita bananas to Th. Olesen A/S |
| 1975-02-11 | UBC | ended withdrawal of Chiquita banana supplies from Olesen |
| 1975-03-13 | Commission | initiated proceeding against United Brands Company |
| 1975-12-17 | Commission | issued Commission Decision imposing fine and penalties |
| 1976-01-20 | United Brands Company | informed distributors and Commission of ceasing prohibition on resale of green bananas |

### Legal Framework
Legal framework applying to the case:
- Operative articles: Article 86
- All relevant articles: Article 85, Article 86
- Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| United Brands Company | one million units of account |

### Remedies
UBC must bring to an end without delay the infringements referred to in Article 1, unless it has already done so of its own accord; specifically, UBC is required to stop applying the prohibition on resale of green bananas and delete this condition from general terms of sale; UBC must eliminate differences in prices charged to customers in equivalent transactions across Member States; UBC must not impose unfair prices for Chiquita bananas on its customers in specific Member States. Additionally, UBC must inform all distributor/ripeners in relevant Member States that it has ceased applying the prohibition on resale of green bananas and notify the Commission accordingly by 1 February 1976; UBC must submit detailed information of prices charged to customers in the relevant Member States to the Commission every six months, for a period of two years, to ensure prices are not abusive (by 20 April 1976 and then twice yearly until 20 July 1978). A fine of one million units of account is imposed for the infringements; periodic penalty payments of 1000 units of account per day are payable for each day of delay in fulfilling the obligations set out in Article 3(b), including informing the Commission and submitting price details.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| United Brands Company | NA |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
A. Borschette

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | EC Treaty      |

### Book Reference
NA

### Outcome
The Commission issued a decision imposing a fine of one million units of account on United Brands Company and ordered UBC to cease the infringements, including ending the prohibition on resale of green bananas, eliminating price differences across Member States, and submitting periodic price information to the Commission.


*(reported: 2026-11-11 10:13:59)*

# 'IV/29.535', 'white lead'

**CELEX ID:** CELEX-31979D0090  
**Industry:** | industry                                       |
|:-----------------------------------------------|
| lead, zinc and calcium products                |
| lead, zinc products, paints, plastics products |
| chemical industrial and trading                |  
**Cartel Period:** 1971-01-01 : 1972-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31979D0090 | IV/29535  |

### Case Title
IV/29.535 – white lead

### Overview
The case involves a cartel of white lead manufacturers in the European Economic Community (EEC) found to have engaged in anticompetitive agreements under Article 85 of the EEC Treaty. The cartel operated from 1971 to 1972, involving companies from the UK, Netherlands, and Germany.

### Industry
lead, zinc and calcium products
lead, zinc products, paints, plastics products
chemical industrial and trading

### Oecd Nace
manufacturing
24.4:Manufacture of basic precious and other non-ferrous metals
24.43: Lead, zinc and tin production

### Companies Undertakings
| companies                                                                   | location                 |
|:----------------------------------------------------------------------------|:-------------------------|
| Associated Lead Manufacturers Ltd                                           | United Kingdom           |
| BV Chemische Industrie- en Handelsmaatschappij Wed. Hondorff, Block & Braet | Schoonhoven, Netherlands |
| Lindgens & Söhne GmbH & Co.                                                 | Cologne, Germany         |

### Market
Netherlands
Germany
United Kingdom
USA
Brazil
Eastern bloc countries
market outside EU: true
oligopoly: True

### Cartel Period
1971-01-01 : 1972-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-06-01 | white lead manufacturers | held meeting raising legal doubts about including EEC countries |
| 1970-12-16 | white lead manufacturers | discussed draft agreement |
| 1971-01-01 | Associated Lead Manufacturers Ltd, BV Chemische Industrie- en Handelsmaatschappij Wed. Hondorff, Block & Braet and Lindgens & Söhne GmbH & Co. | exchanged monthly figures concerning deliveries of white lead, established quotas for export deliveries, and calculated monthly variations from those quotas |
| 1971-01-08 | Lindgens | clarified that EEC markets could not be omitted from export figures |
| 1971-01-20 | white lead manufacturers | prepared revised draft agreement |
| 1971-04-15 | white lead manufacturers | finalized and adopted agreement |
| 1971-07-22 | Lindgens | discussed balancing deliveries |
| 1972-10-31 | parties | decided to end the agreement and substitute a new one |
| 1972-12-31 | parties | ended the old agreement |
| 1978-02-03 | Commission of the European Communities | opened proceedings under Article 85 |
| 1978-12-12 | Commission of the European Communities | issued Commission Decision

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Terminate forthwith the infringement found in Article 1

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Associated Lead Manufacturers Ltd, BV Chemische Industrie- en Handelsmaatschappij Wed. Hondorff, Block & Braet, Lindgens & Söhne GmbH & Co. | True |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country            | jurisdiction   |
|:--------------------------|:-------------------|:---------------|
| European Court of Justice | European Community | EEC Treaty     |

### Book Reference
NA

### Outcome
The Commission found anticompetitive agreements under Article 85, and the European Court of Justice was involved in the case. Remedies were ordered to terminate the infringement.


*(reported: 2026-11-11 10:27:43)*

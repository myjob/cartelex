# 'IV/34.494', 'Tariff structures in the combined transport of goods'

**CELEX ID:** CELEX-31993D0174  
**Industry:** railway  
**Cartel Period:** 1992-01-01 : 1997-01-31  

## Summary

### Celex Case Id
CELEX-31993D0174 / IV/34494

### Case Title
Tariff structures in the combined transport of goods

### Overview
The case concerns the application of Article 85 of the EC Treaty to tariff structures in the combined transport of goods, involving railway companies from multiple EU countries. The Commission adopted a statement of objections in 1991 and issued a decision in 1993 after the companies submitted an amended tariff agreement.

### Industry
railway

### Oecd Nace
OECD: transport; NACE: 49.20 Freight rail transport

### Companies Undertakings
- Société nationale des chemins de fer luxembourgeois (LU)
- Córas Iompair Eireann (IE)
- British Railways Board (GB)
- Deutsche Bundesbahn (DE)
- SNCB (BE)
- Caminhos-de-Ferro Portugueses (PT)
- NV Nederlandse Spoorwegen (NL)
- Renfe (ES)
- Ente Ferrovie dello Stato (IT)
- SNCF (FR)
- DSB (DK)
- Chemins de fer helléniques (GR)

### Market
The relevant market includes railway transport services in the following countries: Luxembourg, Ireland, UK, Germany, Belgium, Portugal, Netherlands, Spain, Italy, France, Denmark, and Greece.

### Cartel Period
1991-08-02 : 1997-02-28

### Key Timeline
- 1968-07-19: Regulation on competition rules for transport adopted
- 1991-08-02: Commission adopted statement of objections concerning combined transport of goods
- 1992-01-21: Railway companies submitted substantially amended version of tariff agreement to Commission
- 1992-03-01: Railway companies commenced application of new tariff structure for five years
- 1993-01-01: Railway companies restricted competition by fixing standard-rate incidental charges
- 1993-02-24: Commission of the European Communities issued decision on tariff structures in combined transport
- 1993-03-30: Railway companies sent list of incidental costs
- 1993-12-31: Railway companies took measures to avoid discrimination in tariff structures
- 1997-02-28: End of applicability period

### Legal Framework
Article 85 (operative), Article 86 (relevant)

### Infringement Category
horizontal restraints

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought by all investigated companies.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders are detailed in the context for terminating an infringement.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
Courts were involved in the case, but specific rulings are not detailed in the context.

### Book Reference
NA

### Outcome
The Commission issued a decision on tariff structures in combined transport. No specific remedies or orders are detailed for terminating an infringement.


*(reported: 2026-10-16 20:46:07)*

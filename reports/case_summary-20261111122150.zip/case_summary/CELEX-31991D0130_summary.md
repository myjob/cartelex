# 'IV/32.524', 'Screensport/EBU Members'

**CELEX ID:** CELEX-31991D0130  
**Industry:** | industry                |
|:------------------------|
| Television Broadcasting |
| Sports Programming      |
| Media Services          |
| Commercial Broadcasting |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0130 | IV/32524  |

### Case Title
Screensport/EBU Members

### Overview
This case involved the European Commission's investigation into a joint venture among members of the Eurosport Consortium, including Sky Television plc, Satellite Sport Sales Ltd, Satellite Sports Services Ltd, and News International plc. The consortium was found to have engaged in anticompetitive behavior under Article 85 of the EEC Treaty, specifically through a joint venture that restricted competition in the television broadcasting and sports programming sector.

### Industry
Television Broadcasting, Sports Programming, Media Services, Commercial Broadcasting

### Oecd Nace
OECD: communication
NACE Group Code: 60.2: Television programming and broadcasting activities
NACE Class Code: 60.20: Television programming and broadcasting activities

### Companies Undertakings
| companies | location |
| --- | --- |
| Members of the Eurosport Consortium | NA |
| Sky Television plc | NA |
| Satellite Sport Sales Ltd | NA |
| Satellite Sports Services Ltd | NA |
| News International plc | NA |

### Market
The relevant market includes the United Kingdom, Germany, France, Netherlands, Belgium, Ireland, Italy, Spain, Portugal, Switzerland, Austria, Greece, Denmark, Sweden, Norway, Finland, Poland, Czech Republic, Hungary, Romania, Bulgaria, and Slovenia.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-12-02 | News Corporation Ltd | announced involvement in joint venture to launch Eurosport |
| 1987-12-02 | Sky | selected as partner for joint sports channel |
| 1987-12-17 | Screensport | submitted application for finding of infringement |
| 1987-12-17 | Screensport | registered complaint at the Commission |
| 1988-05-05 | EBU members | signed Eurosport Consortium Agreement |
| 1988-05-05 | redacted | formally signed agreement establishing Eurosport consortium |
| 1988-12-05 | Commission | initiated proceedings in the case |
| 1988-12-20 | Commission | sent statement of objections to the Eurosport Consortium and NI |
| 1988-12-23 | Sky Television plc and Eurosport Consortium | signed Shareholders Agreement and Services Agreement |
| 1988-12-23 | News Corporation Ltd | signed agreements finalizing Eurosport joint venture |
| 1988-12-23 | Sky | signed facilities agreement with service company |
| 1989-01-17 | Eurosport consortium, Sky Television plc, Satellite Sport Sales Ltd, Satellite Sports Services Ltd, News International plc | submitted notification and application for negative clearance |
| 1989-02-05 | Commission | launched satellite television sports channel |
| 1991-02-19 | Commission | issued Commission Decision relating to infringement proceeding |

### Legal Framework
Law Article Operative: Article 85
Law Article All Relevant:
| law_article   |
|:--------------|
| Article 85    |
| Article 90    |
Infringement Concept: anticompetitive_agreement, public_undertaking

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted:
- Exemption Case: True
- Exemption Applicants: Sky Television plc

### Leniency
Leniency Case: False
Leniency Applicants: NA
Leniency Granted: NA
Leniency Rejected: NA

### Fines
NA

### Remedies
The Commission ordered the undertakings listed in the Decision to cease their infringing conduct under Article 85(1) of the EEC Treaty. The decision terminated the infringement by requiring compliance with competition law, although specific structural or behavioral remedies are not detailed in this text.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
Courts involved and their rulings:
- Is Court Involved: True

### Book Reference
NA

### Outcome
The European Commission found that the joint venture among members of the Eurosport Consortium, including Sky Television plc, Satellite Sport Sales Ltd, Satellite Sports Services Ltd, and News International plc, constituted an infringement under Article 85 of the EEC Treaty. The Commission ordered the undertakings to cease their infringing conduct and required compliance with competition law.


*(reported: 2026-11-11 11:26:25)*

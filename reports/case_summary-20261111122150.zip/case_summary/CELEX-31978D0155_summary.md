# 'IV/29.146', 'BMW Belgium NV and Belgian BMW dealers'

**CELEX ID:** CELEX-31978D0155  
**Industry:** NA  
**Cartel Period:** 1975-09-29 : 1976-02-20  

## Summary

### Celex Case Id
CELEX-31978D0155

### Case Title
BMW Belgium NV and Belgian BMW dealers

### Overview
Overview of the case:

This case involved BMW Belgium NV and a number of Belgian BMW dealers who were found to have engaged in horizontal cartels restricting trade in new BMW vehicles. The infringement occurred between 1975 and 1976, with the Commission issuing its decision on 23 December 1977. The cartel was related to export restrictions and territorial exclusivity, which violated Article 85(1) of the EEC Treaty. The case is a landmark in the reference book IV/29.146.

### Industry
BMW vehicles

### Oecd Nace
OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

OECD Sector: trade (wholesaling and retailing) and hotels
NACE Group Code: 45.1:Sale of motor vehicles
NACE Class Code: 45.11: Sale of cars and light motor vehicles

### Companies Undertakings
| company                      |
|:-----------------------------|
| BMW Belgium NV               |
| Autohandel O. Cocquyt NV     |
| Etn W. Jorssen               |
| Garage Hindrickx             |
| Pvba J. Siau-Vermeesch       |
| Ets. J. De Smeth             |
| Ets. Jo Vallé                |
| Ets. J. Depotter             |
| Garage J. Wiliquet Sprl      |
| Ets. Rajans SA               |
| Garage Verhaeren             |
| S. C. Dewilde Motor          |
| Ets. Autogamas Sprl          |
| Ets. Houyoux                 |
| Garage Léon Louyet Sprl      |
| Station Albert 1er SA        |
| Sprl Auto-Service            |
| Ets. A. Petit & Co. SA       |
| Ets. Jean Blaise Sprl        |
| Ets. Cuisinier               |
| Ets. Briot Sprl              |
| Garage Georges Antoine       |
| Garage Hubert Scaillet       |
| Ets. Ferracin                |
| Ets. Le Stop                 |
| Autobedrijf De Ruysscher     |
| Garage W. Termont-Vermeire   |
| NV Centrauto                 |
| Garage R. Geurts & Zn Pvba   |
| Etn. Dekkers                 |
| Etn. J. Vandeperre Pvba      |
| J. Sebrechts                 |
| Garage Van Avondt&Zn Pvba    |
| Garage A. Ottevaere          |
| Ceres-Leterme Pvba           |
| Garage St Christophe Pvba    |
| Garage Aalbrecht W.          |
| Etn. Erco NV — W. Roefs      |
| Garage A. Liesens            |
| Garage Centrum-Mottoul       |
| Garage Vangoidsenhoven       |
| Garage Moderne-Ghyselinck J. |
| Garage R. Kellens-Behiels    |
| Garage S. De Mey             |
| Etn. J. & M. Sels Pvba       |
| Garage Tanghe Pvba           |
| Pvba Gebr. Van den Bulck     |
| Pvba De Kempische Molen      |

### Market
Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

Geography:
| country                     |
|:----------------------------|
| Belgium                     |
| Federal Republic of Germany |
| Netherlands                 |
| France                      |
| Italy                       |
| United Kingdom              |

Market circumstances affecting supply rationing:
Price controls imposed by the Belgian Government causing temporary freeze of retail prices for cars; disparities in price between Belgium and other Community countries leading to re-export opportunities; alignment of prices after November 1975 reducing incentives for re-exports; market circumstances affecting supply rationing.

### Cartel Period
1975-09-29 : 1976-02-20

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-07-18 | BMW Belgium | commenced business |
| 1975-01-13 | BMW Belgium | notified standard form distribution agreement and applied for exemption |
| 1975-06-12 | BMW Munich | informed MGH that dealers were prohibited from supplying vehicles to non-distributors |
| 1975-07-04 | BMW Belgium | issued circular referring to distribution agreement |
| 1975-07-22 | BMW Munich | sent letter informing BMW Belgium of breach of Article 85 (1) of the EEC Treaty |
| 1975-09-29 | BMW Belgium | issued circular initiating restrictive practices |
| 1975-09-29 | BMW dealers | restricted trade in new BMW vehicles affecting inter-State commerce |
| 1975-10-20 | MGH | made application regarding export restrictions |
| 1975-10-31 | BMW Belgium | considered circular on exports of new vehicles |
| 1976-02-20 | BMW Belgium | issued circular and stated position before Antwerp Commercial Court |
| 1976-02-20 | BMW Belgium | sent circular to all Belgian BMW dealers clarifying previous circular was null and void |
| 1977-12-23 | Commission | issued Decision relating to BMW Belgium NV and dealers |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
export cartels

### Infringement Gravity
medium

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

Applicants:
| company |
| --- |
| Automobilimporte C. Heuer, Dillingen |
| MGH Motorgesellschaft mbH, Herford |

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| BMW Belgium NV | 150 000 units of account or 750 000 Belgian francs |
| Autohandel O. Cocquyt NV | 2 000 units of account or 100 000 Belgian francs |
| Etn W. Jorssen | 2 000 units of account or 100 000 Belgian francs |
| Garage Hindrickx | 2 000 units of account or 100 000 Belgian francs |
| Pvba J. Siau-Vermeesch | 2 000 units of account or 100 000 Belgian francs |
| Ets. J. De Smeth | 2 000 units of account or 100 000 Belgian francs |
| Ets. Jo Vallé | 1 500 units of account or 75 000 Belgian francs |
| Ets. J. Depotter | 1 500 units of account or 75 000 Belgian francs |
| Garage J. Wiliquet Sprl | 1 500 units of account or 75 000 Belgian francs |
| Ets. Rajans SA | 1 000 units of account or 50 000 Belgian francs |
| Garage Verhaeren | 1 000 units of account or 50 000 Belgian francs |
| S. C. Dewilde Motor | 1 000 units of account or 50 000 Belgian francs |
| Ets. Autogamas Sprl | 1 000 units of account or 50 000 Belgian francs |
| Ets. Houyoux | 1 000 units of account or 50 000 Belgian francs |
| Garage Léon Louyet Sprl | 1 000 units of account or 50 000 Belgian francs |
| Station Albert 1er SA | 1 000 units of account or 50 000 Belgian francs |
| Sprl Auto-Service | 1 000 units of account or 50 000 Belgian francs |
| Ets. A. Petit & Co. SA | 1 000 units of account or 50 000 Belgian francs |
| Ets. Jean Blaise Sprl | 1 000 units of account or 50 000 Belgian francs |
| Ets. Cuisinier | 1 000 units of account or 50 000 Belgian francs |
| Ets. Briot Sprl | 1 000 units of account or 50 000 Belgian francs |
| Garage Georges Antoine | 1 000 units of account or 50 000 Belgian francs |
| Garage Hubert Scaillet | 1 000 units of account or 50 000 Belgian francs |
| Ets. Ferracin | 1 000 units of account or 50 000 Belgian francs |
| Ets. Le Stop | 1 000 units of account or 50 000 Belgian francs |
| Autobedrijf De Ruysscher | 1 000 units of account or 50 000 Belgian francs |
| Garage W. Termont-Vermeire | 1 000 units of account or 50 000 Belgian francs |
| NV Centrauto | 1 000 units of account or 50 000 Belgian francs |
| Garage R. Geurts & Zn Pvba | 1 000 units of account or 50 000 Belgian francs |
| Etn. Dekkers | 1 000 units of account or 50 000 Belgian francs |
| Etn. J. Vandeperre Pvba | 1 000 units of account or 50 000 Belgian francs |
| J. Sebrechts | 1 000 units of account or 50 000 Belgian francs |
| Garage Van Avondt&Zn Pvba | 1 000 units of account or 50 000 Belgian francs |
| Garage A. Ottevaere | 1 000 units of account or 50 000 Belgian francs |
| Ceres-Leterme Pvba | 1 000 units of account or 50 000 Belgian francs |
| Garage St Christophe Pvba | 1 000 units of account or 50 000 Belgian francs |
| Garage Aalbrecht W. | 1 000 units of account or 50 000 Belgian francs |
| Etn. Erco NV — W. Roefs | 1 000 units of account or 50 000 Belgian francs |
| Garage A. Liesens | 1 000 units of account or 50 000 Belgian francs |
| Garage Centrum-Mottoul | 1 000 units of account or 50 000 Belgian francs |
| Garage Vangoidsenhoven | 1 000 units of account or 50 000 Belgian francs |
| Garage Moderne-Ghyselinck J. | 1 000 units of account or 50 000 Belgian francs |
| Garage R. Kellens-Behiels | 1 000 units of account or 50 000 Belgian francs |
| Garage S. De Mey | 1 000 units of account or 50 000 Belgian francs |
| Etn. J. & M. Sels Pvba | 1 000 units of account or 50 000 Belgian francs |
| Garage Tanghe Pvba | 1 000 units of account or 50 000 Belgian francs |
| Pvba Gebr. Van den Bulck | 1 000 units of account or 50 000 Belgian francs |
| Pvba De Kempische Molen | 1 000 units of account or 50 000 Belgian francs |

### Remedies
Imposition of fines as sanctions under Article 15(2) of Regulation No 17 for the infringement under Article 85(1) of the EEC Treaty; specific fine amounts are specified per company in Article 2.

### Company Recidivism
| company | recidivism |
| --- | --- |
| BMW Belgium NV | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
| court                    | country            | jurisdiction   |
|:-------------------------|:-------------------|:---------------|
| Antwerp Commercial Court | Belgium            | Belgium        |
| Bielefeld Landgericht    | Germany            | Germany        |
| Commission               | European Community | EEC            |

### Book Reference
IV/29.146

### Outcome
Outcome of the case:

The Commission found that BMW Belgium NV and its dealers had infringed Article 85(1) of the EEC Treaty by restricting trade in new BMW vehicles affecting inter-State commerce through export cartels. The Commission imposed fines on BMW Belgium NV and several dealers, with specific amounts detailed in the 'fines' chapter.


*(reported: 2026-11-11 10:21:00)*

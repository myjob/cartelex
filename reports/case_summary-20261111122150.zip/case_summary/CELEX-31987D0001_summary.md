# 'IV/31.128', 'Fatty Acids'

**CELEX ID:** CELEX-31987D0001  
**Industry:** oleochemical industry  
**Cartel Period:** 1979-09-27 : 1983-01  

## Summary

### Celex Case Id
CELEX-31987D0001

### Case Title
Fatty Acids

### Overview
The case involves a cartel in the oleochemical industry where companies exchanged information on prices and sales, violating Article 85 and 86 of the EC Treaty. The infringement period was from 1979 to 1983, with the Commission issuing a decision in December 1986. Fines were imposed on Unichema, Henkel, and Oleofina.

### Industry
oleochemical industry

### Oecd Nace
manufacturing; 20.5:Manufacture of other chemical products; 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| companies   |
|:------------|
| Unichema    |
| Henkel KGaA |
| Oleofina SA |
| Unilever NV |

| companies_investigated   | country   |
|:-------------------------|:----------|
| Unichema                 | DE        |
| Henkel KGaA              | DE        |
| Oleofina SA              | BR        |
| Unilever NV              | NL        |

### Market
Belgium, Germany, Netherlands; oligopoly; economic recession, surplus production capacity, declining prices and margins, structural overcapacity, low or stagnant growth rates, increasing competition from developing countries, uncertainty around Unichema's capacity reduction plans leading to potential loss of market share

### Cartel Period
1979-09-27 : 1983-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1979-09-27 | Unichema | exchanged sales figures with competitors |
| 1980-01-01 | Unichema | collated and communicated information to other parties |
| 1983-01-01 | Unichema, Henkel and Oleofina | terminated agreement exchanging information about sales of fatty acids |
| 1986-12-02 | Commission | issued a decision relating to the case |

### Legal Framework
Article 85, Article 86

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Unichema | 50000 ECU |
| Henkel | 50000 ECU |
| Oleofina | 50000 ECU |

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Unichema | False |
| Henkel | False |
| Oleofina | False |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | European Union |

### Book Reference
IV/31.128

### Outcome
Termination of the agreement to exchange information about sales of fatty acids with effect from 1 January 1983; imposition of fines on each of Unichema, Henkel, and Oleofina.


*(reported: 2026-11-11 11:04:07)*

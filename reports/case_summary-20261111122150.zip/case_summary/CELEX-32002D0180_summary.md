# 'COMP/37.859', 'De Post-La Poste'

**CELEX ID:** CELEX-32002D0180  
**Industry:** insurance  
**Cartel Period:** 1996 : 2001-06-28  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32002D0180 | IV/37859  |

### Case Title
COMP/37.859 – De Post-La Poste

### Overview
The European Commission investigated La Poste, a public undertaking in Belgium, for abuse of dominance in the postal services market. The case involved agreements and terminations related to preferential tariffs and business-to-business mail services between 1996 and 2001. La Poste was found to have abused its dominant position under Article 82 of the EC Treaty.

### Industry
insurance

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 53.1: Postal activities under universal service obligation
NACE class code: 53.10: Postal activities under universal service obligation

### Companies Undertakings
| company                        | country   |
|:-------------------------------|:----------|
| La Poste                       | FR        |
| Hays Information Management SA | GB        |
| Key Mail                       | GB        |
| ABB                            | CH        |
| UPEA                           | GB        |
| Hays plc                       | GB        |
| eXbo Services International SA | FR        |
| Commercial Union               | GB        |
| AXA                            | FR        |
| Fortis                         | BE        |
| eXbo                           | FR        |

### Market
Geographical: Belgium
Outside EU: False
Oligopoly: NA
Turbulence: NA

### Cartel Period
1996 : 2001-06-28

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-06-14 | UPEA | signed subscription agreement with Hays |
| 1991-03-21 | La Poste | established postal monopoly under Act of 21 March 1991 |
| 1996-04-06 | UPEA | concluded 2026 agreement with La Poste for preferential tariff |
| 1998-04-08 | La Poste | signed 2026 agreement |
| 1998-04-08 | La Poste | concluded preferential tariff agreement |
| 1998-10-30 | La Poste | unilaterally terminated 2026 agreement |
| 2000-01-27 | UPEA | signed business-to-business agreement |
| 2000-01-27 | La Poste | renewed 2026 agreement for three years and signed business-to-business agreement |
| 2001-06-06 | La Poste | received Commission's statement of objections |
| 2001-06-20 | La Poste | terminated business-to-business agreement with UPEA |
| 2001-06-28 | La Poste | ended all collections under business-to-business agreement |
| 2001-12-05 | De Post-La Poste | imposed fine of EUR 2.5 million

### Legal Framework
Law articles: Article 82, Article 86
Canonical concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance, public_undertaking

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| La Poste | EUR 2,5 million |

### Remedies
A fine of EUR 2.5 million was imposed on La Poste, with the decision being enforceable under Article 256 of the EC Treaty.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court | country | jurisdiction |
| --- | --- | --- |
| Court of Justice of the European Union | European Union | European Union

### Book Reference
NA

### Outcome
La Poste was fined EUR 2.5 million for abuse of dominance in the postal services market under Article 82 of the EC Treaty.


*(reported: 2026-11-11 12:10:27)*

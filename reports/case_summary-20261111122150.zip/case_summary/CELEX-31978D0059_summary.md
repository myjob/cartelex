# 'NA', 'NA'

**CELEX ID:** CELEX-31978D0059  
**Industry:** | industry           |
|:-------------------|
| bicycles           |
| bicycle components |
| spare parts        |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0059 | IV/147    |

### Case Title
NA

### Overview
This case involves the European Commission's investigation into anticompetitive agreements among Dutch bicycle industry stakeholders, including Centraal Bureau voor de Rijwielhandel (CBR) and others. The Commission found that these entities engaged in vertical restraints such as Exclusive Dealing and Resale Price Maintenance, which were deemed to be in violation of Article 85 of the EC Treaty. An exemption application was submitted but rejected by the Commission on 1977-12-02.

### Industry
bicycles, bicycle components, spare parts

### Oecd Nace
OECD_sector: trade (wholesaling and retailing) and hotels
NACE_group_code: 30.9:Manufacture of transport equipment n.e.c.
NACE_class_code: 30.92: Manufacture of bicycles and invalid carriages

### Companies Undertakings
| companies                                                             | location   |
|:----------------------------------------------------------------------|:-----------|
| Centraal Bureau voor de Rijwielhandel                                 | Amsterdam  |
| RAI : Nederlandse Vereniging van de Rijwwiel- en Automobielindustrie  | Amsterdam  |
| COT: Centrale Organisatie in de Tweewielerbranche                     | Amsterdam  |
| NCBRM: Nederlandse Christelijke Bond van Rijwiel- en Motorhanderlaren | Rijswijk   |
| P. Donck                                                              | Rotterdam  |

### Market
market_oligopoly: True
market_outside_eu: true

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1920-05-14 | CBR | adopted Algemeen Reglement |
| 1962-02-06 | redacted | Council Regulation No 17 was established |
| 1962-03-13 | redacted | regulation entered into force |
| 1962-03-13 | redacted | became operative with provisions establishing infringements |
| 1962-10-25 | Centraal Bureau voor de Rijwielhandel | notified general regulations |
| 1971-01-20 | Henk Kokke Sport | filed complaint |
| 1971-03-03 | Commission | sent letter to CBR requesting adaptation of Algemeen Reglement |
| 1971-04-01 | Commission | discussed with CBR regarding Algemeen Reglement |
| 1971-04-27 | Commission | sent letter to CBR concerning Algemeen Reglement |
| 1974-04-23 | undertaking recognized by CBR | filed application for more evidence on imports impeded by Algemeen Reglement |
| 1976-01-29 | Commission | stayed action pending Commission decision |
| 1976-06-17 | CBR | notified of statement of objections |
| 1976-07-16 | CBR | amended Algemeen Reglement took effect |
| 1976-07-16 | redacted | provisions ceased to be in force |
| 1976-07-27 | CBR | notified amended Algemeen Reglement before hearing |
| 1976-07-27 | CBR | requested exemption under Article 85 (3) |
| 1977-05-25 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion under Article 10 of Regulation No 17 |
| 1977-12-02 | redacted | decision was made rejecting exemption application

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure
Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
Exemption sought under Article 85 (3) by Centraal Bureau voor de Rijwielhandel

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders issued by the Commission are explicitly stated within the provided document.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                      | country     | jurisdiction   |
|:---------------------------|:------------|:---------------|
| Rotterdam Cantonal Court   | Netherlands | Rotterdam      |
| Commissie van Hoger Beroep | Netherlands | Administrative |
| European Court of Justice  | Netherlands | European Union |

### Book Reference
IV/147

### Outcome
The Commission rejected the exemption application under Article 85 (3).


*(reported: 2026-11-11 10:19:20)*

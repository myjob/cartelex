# 'IV/496—498—532—511—26.238—26.577', 'central heating'

**CELEX ID:** CELEX-31972D0390  
**Industry:** | industry                                                 |
|:---------------------------------------------------------|
| central heating equipment manufacturing and installation |
| boiler manufacturing                                     |
| radiator manufacturing                                   |
| ventilation systems                                      |
| pipe installation                                        |  
**Cartel Period:** 1955-02-08 : 1971-02-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0390 | IV/496    |

### Case Title
IV/496—498—532—511—26.238—26.577 – Central Heating

### Overview
This case involves a cartel among Belgian manufacturers and installers of central heating equipment, including boilers, radiators, and related systems. The cartel operated from 1955 to 1971, engaging in restrictive practices such as price fixing collusion.

### Industry
central heating equipment manufacturing and installation, boiler manufacturing, radiator manufacturing, ventilation systems, pipe installation

### Oecd Nace
OECD sector: manufacturing; NACE group code: 25.2: Manufacture of tanks, reservoirs and containers of metal; NACE class code: 25.21: Manufacture of central heating radiators and boilers

### Companies Undertakings
| companies                                                                                                        | location             |
|:-----------------------------------------------------------------------------------------------------------------|:---------------------|
| Chambre syndicale du matériel de chauffage central et des industries connexes (section chaudières et radiateurs) | Brussels             |
| Union belge des installateurs en chauffage central, ventilation et tuyauteries (UBIC)                            | Brussels             |
| Chambre nationale des installateurs en chauffage central, ventilations et climatisations                         | Brussels             |
| Ets Defounes                                                                                                     | Brussels             |
| Ets Chavee                                                                                                       | Brussels             |
| Ets Verbeeck                                                                                                     | Brussels             |
| S.A. Ateliers A.C.V.                                                                                             | Ruysbroek            |
| S.A. Acomal                                                                                                      | Mechelen             |
| Usines Antverpia                                                                                                 | Mortsel              |
| S.A. Cerac                                                                                                       | Grand-Bigard         |
| S.A. Thomas Defawes                                                                                              | Liège                |
| S.A. Heurtey                                                                                                     | Liège                |
| S.A. Ideal-Standard                                                                                              | Brussels             |
| S.A. Saint-Roch Factories and Foundries                                                                          | Couvin               |
| S.A. Socother                                                                                                    | Aalter               |
| N.V. Sogaz                                                                                                       | Machelen             |
| S.A. Nimy Tubes                                                                                                  | Nimy                 |
| S.A. Warneton Chappee                                                                                            | Brussels             |
| Ets Ritschie                                                                                                     | Schoten              |
| N.V. Rateau Company                                                                                              | Muizen-near-Machelen |
| S.p.r.l. Soudron-Sacre                                                                                           | Ans-lez-Liège        |
| N.V. Veha                                                                                                        | Grobbendonk          |
| N.V. Eurocalor                                                                                                   | Wilrijk              |

### Market
Belgium

### Cartel Period
1955-02-08 : 1971-02-18

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1955-02-08 | Belgian manufacturers, wholesalers, and UBIC | concluded agreement |
| 1955-02-08 | CSM/UBIC | concluded convention |
| 1962-10-18 | CSM and UBIC | concluded contract establishing committee for admission of manufacturers |
| 1962-10-18 | parties to the commission | terminated the agreement |
| 1962-10-18 | CSM and UBIC | concluded the approval contract imposing exclusive procurement obligation |
| 1962-10-18 | two associations acting on behalf of their members | concluded agreement restricting competition in the Common Market |
| 1962-10-18 | parties | terminated the convention |
| 1962-10-18 | CSM and UBIC | concluded an agreement |
| 1962-10-30 | CSM/UBIC | registered convention |
| 1962-10-30 | Chambre syndicale du matériel de chauffage central et des industries connexes | submitted application for exemption |
| 1962-10-31 | Union belge des installateurs en chauffage central, ventilation et tuyauteries (UBIC) | submitted application for exemption |
| 1962-11-01 | Commission | entered into force of regulation |
| 1966-06-10 | CSM members | signed mutual exclusivity obligations |
| 1966-08-25 | UBIC installers | signed mutual exclusivity obligations |
| 1971-02-17 | Admissions Committee | terminated contract concluded in 1962 |
| 1971-02-18 | manufacturers and wholesalers | unanimously decided to rescind agreements with UBIC |
| 1971-02-22 | UBIC | transmitted communication to Commission |
| 1972-10-20 | the Commission | issued a decision concerning a procedure pursuant to Article 85 of the EEC Treaty

### Legal Framework
NA

### Infringement Category
Price fixing collusion

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
N.V. Veha applied for exemption.

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist from continuing the agreement and its restrictive practices; rectify the violations related to the contract by ensuring compliance with EU law.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Chambre syndicale du matériel de chauffage central et des industries connexes (CSM), Union belge des installateurs en chauffage central, ventilation et tuyauteries (UBIC) | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/496 – Price fixing collusion

### Outcome
The Commission took a decision concerning the infringement, and the cartel was terminated. Remedies were imposed to ensure compliance with EU law.


*(reported: 2026-11-11 09:59:05)*

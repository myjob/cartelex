# 'IV/29.869', 'Italian cast glass'

**CELEX ID:** CELEX-31980D1334  
**Industry:** glass manufacturing  
**Cartel Period:** 1976-03-30 : 1978-03-30  

## Summary

### Celex Case Id
CELEX-31980D1334

### Case Title
Italian cast glass

### Overview
This case involved a cartel among Italian glass manufacturers, including Fabbrica Pisana SpA, Società Italiana Vetro SpA, Fabbrica Lastre di Vetro Sciarra SpA, and Fides-Unione Fiduciaria SpA. The cartel operated from 1976 to 1978, engaging in market sharing, quota cartels, and specialization agreements. The European Commission found infringement under Article 85 of the EEC Treaty with a high gravity classification. No specific remedies or orders were issued by the Commission to terminate the infringement as per the decision text.

### Industry
glass manufacturing

### Oecd Nace
manufacturing, 23.1:Manufacture of glass and glass products, 23.19: Manufacture and processing of other glass, including technical glassware

### Companies Undertakings
| company                                        |
|:-----------------------------------------------|
| Fabbrica Pisana SpA, Pisa                      |
| Società Italiana Vetro SpA, San Salvo (Chieti) |
| Fabbrica Lastre di Vetro Sciarra SpA, Rome     |
| Fides-Unione Fiduciaria SpA, Milan             |

### Market
Italy, oligopoly market

### Cartel Period
1976-03-30 : 1978-03-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-03-30 | Fabbrica Pisana, SIV, and Fabbrica Sciarra | concluded agreement on supervision of glass manufacturing and sales quotas |
| 1976-03-30 | redacted | signed memorandum of understanding |
| 1976-03-30 | manufacturers | established memorandum |
| 1976-03-30 | Fabbrica Pisana, SIV and Fabrica Sciarra | concluded memorandum controlling production and sale of cast glass |
| 1976-03-30 | Fides | facilitated exchange of commercial information among competitors |
| 1976-03-30 | Fabbrica Pisana SpA, Società Italiana Vetro SpA, Fabbrica Lastre di Vetro Sciarra SpA | concluded agreements |
| 1976-04-01 | redacted | authority conferred upon Fides began |
| 1976-05-10 | Fides | began monthly reporting and verification of shipment data |
| 1978-03-30 | redacted | ceased implementation of agreements |
| 1978-03-30 | redacted | agreements expired |
| 1979-12-11 | redacted | initiated proceedings under Article 85 |
| 1980-12-17 | redacted | decision issued

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement as per the decision text.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Fabbrica Pisana SpA | NA |
| Società Italiana Vetro SpA | NA |
| Fabbrica Lastre di Vetro Sciarra SpA | NA |
| Fides-Unione Fiduciaria SpA | NA |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court      | country        | jurisdiction                |
|:-----------|:---------------|:----------------------------|
| Commission | European Union | European Economic Community |

### Book Reference
IV/29.869

### Outcome
The Commission found infringement under Article 85 of the EEC Treaty for horizontal restraints in the form of market sharing, quota cartels, and specialization agreements. No specific remedies or orders were issued by the Commission to terminate the infringement as per the decision text.


*(reported: 2026-11-11 10:35:14)*

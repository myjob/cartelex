# 'COMP.F.1/35.918', 'JCB'

**CELEX ID:** CELEX-32002D0190  
**Industry:** | industry                             |
|:-------------------------------------|
| construction equipment manufacturing |
| spare parts and services             |  
**Cartel Period:** 1973-06 : 1995-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32002D0190 | IV/35918  |

### Case Title
COMP.F.1/35.918 – JCB

### Overview
The case involves the European Commission's investigation into anticompetitive agreements among JCB Service and its subsidiaries, including JC Bamford Excavators Ltd, JCB SpA, ECI JCB, and Watling JCB. The infringement occurred in the construction equipment manufacturing sector, involving vertical restraints such as exclusive dealing, territorial exclusivity, resale price maintenance, and selective distribution.

### Industry
construction equipment manufacturing, spare parts and services

### Oecd Nace
manufacturing (OECD_sector), 25.99: Manufacture of other fabricated metal products n.e.c. (NACE_class_code)

### Companies Undertakings
| company                   |
|:--------------------------|
| JCB Service               |
| JC Bamford Excavators Ltd |
| JCB SpA                   |
| ECI JCB                   |
| Watling JCB               |

### Market
Relevant market includes the United Kingdom, France, Italy, Germany, Netherlands, Austria, Ireland, Spain, and Denmark. The market is oligopolistic and outside the EU.

### Cartel Period
1973-06 : 1995-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-06-30 | JCB | notified agreements |
| 1975-10-27 | Commission | informed JCB of decision |
| 1975-12-18 | JCB | notified new forms of distribution agreements |
| 1995-12-29 | JCB | sent new version of distributor agreement |
| 1996-02-15 | Commission | lodged a complaint with the Commission |
| 1996-11-05 | Commission | undertook an inspection at the premises of JCB and related entities |
| 1998-03-24 | Commission | initiated the procedure and sent a statement of objections to JCB |
| 1998-10-16 | JCB | presented written and oral submissions at the hearing |
| 1999-07-30 | Commission | sent a new statement of objections to JCB |
| 2000-01-16 | JCB | presented written and oral submissions at the hearing |
| 2000-12-21 | Commission of the European Communities | issued Commission Decision relating to a proceeding under Article 81 of the EC Treaty |

### Legal Framework
Articles 81 and 85 of the EC Treaty

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans; Resale Price Maintenance (RPM); Selective Distribution

### Infringement Gravity
high

### Exemption
JC Bamford Excavators Ltd sought an exemption.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| JCB Service | EUR 39 614 000 |

### Remedies
JCB Service and its subsidiaries must (a) inform authorised distributors in the Community that they may carry out passive sales to end-users and authorised distributors; (b) amend their agreements with authorised distributors either by allowing passive sales to unauthorised distributors inside other authorised distributors' exclusive territories, active and passive sale to unauthorised distributors within their own territories, or active and passive sales by authorised distributors to other authorised distributors, end-users, or their duly appointed agents outside their exclusive territories; (c) amend agreements in Italy and France by allowing purchases of contract goods from other authorised distributors in the Community; (d) inform authorised distributors that requests seeking service support fees without evidence of prior disagreement are void; (e) inform authorised distributors in the UK that allowances under the multiple deal trade support are granted regardless of sales territory; (f) send copies of all correspondence and amended agreements to the Commission.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| JCB Service | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued a decision finding JCB Service in breach of Article 81 and 85 of the EC Treaty. JCB Service was fined EUR 39,614,000 and ordered to amend its distribution agreements to comply with EU competition law.


*(reported: 2026-11-11 12:10:47)*

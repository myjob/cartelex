# 'IV/32.659', 'IATA Passenger Agency Programme'

**CELEX ID:** CELEX-31991D0480  
**Industry:** NA  
**Cartel Period:** 1988-03-21 : 1998-03-20  

## Summary

### Celex Case Id
CELEX-31991D0480

### Case Title
IATA Passenger Agency Programme

### Overview
The European Commission investigated the International Air Transport Association (IATA) Passenger Agency Programme for potential violations of Article 85 of the EEC Treaty, which prohibits anti-competitive agreements. The case involved a large number of airlines from around the world and focused on horizontal restraints in the air travel agency services sector.

### Industry
air travel agency services, international air transportation

### Oecd Nace
OECD: transport; NACE group code: 51.1; NACE class code: 51.10

### Companies Undertakings
| companies                                                               | location   |
|:------------------------------------------------------------------------|:-----------|
| International Air Transport Association                                 | NA         |
| Adria Airways                                                           | SI         |
| Aer Lingus plc                                                          | IE         |
| Aeroflot Soviet Airlines                                                | RU         |
| Aerolineas Argentinas                                                   | AR         |
| Aerolineas Nicaraguenses SA (AERONIC)                                   | NI         |
| Aerovias de Mexico SA de CV (AEROMEXICO)                                | MX         |
| Aerovias Nacionales de Colombia SA (AVIANCA)                            | CO         |
| Affretair (PVT) Ltd                                                     | PK         |
| Air Afrique                                                             | Ivory Coast|
| Air Algerie                                                             | DZ         |
| Air Botswana                                                            | BW         |
| Air Bremen GmbH & Co. Air Bridge Carriers Ltd                           | DE         |
| Air Canada                                                              | CA         |
| Air Europe Ltd                                                          | IT         |
| Air France                                                              | FR         |
| Air Gabon                                                               | GA         |
| Air Guinee                                                              | GN         |
| Air Jamaica Ltd                                                         | JM         |
| Air Littoral                                                            | Ivory Coast|
| Air Madagascar                                                          | MG         |
| Air Malawi Ltd                                                          | MW         |
| Air Malta Company Ltd                                                   | MT         |
| Air Martinique                                                          | MQ         |
| Air Mauritius                                                           | MU         |
| Air New Zealand Ltd                                                     | NZ         |
| Air Niugini                                                             | PG         |
| Air Pacific Ltd                                                         | FJ         |
| Air Seychelles Ltd                                                      | SC         |
| Air Tanzania Corporation                                                | TZ         |
| Air Tungaru Corporation                                                 | KI         |
| Air UK                                                                  | GB         |
| Air Zaire                                                               | Democratic Republic of the Congo|
| Air Zimbabwe Corporation                                                | ZW         |
| Air India                                                               | IN         |
| Airline of the Marshall Islands                                         | MH         |
| Alaska Airlines Inc.                                                    | US         |
| Alisarda SpA                                                            | IT         |
| Alitalia — Linee Aeree Italiane SpA                                     | IT         |
| All Nippon Airways Co., Ltd                                             | JP         |
| American Airlines Inc.                                                  | US         |
| America West Airlines, Inc.                                             | US         |
| Ariana Afghan Airlines Co. Ltd                                          | AF         |
| Austrian Airlines                                                       | AT         |
| Balkan Bulgarian Airlines                                               | BG         |
| Berlin European UK Ltd                                                  | GB         |
| Birmingham European Airways plc                                         | GB         |
| Brymon Airways                                                          | GB         |
| Cameroon Airlines                                                       | CM         |
| Canadian Airlines International Ltd                                     | CA         |
| Caribbean Air Cargo Company Ltd                                         | BB         |
| Ceskoslovenske Aerolinie (CSA)                                          | CZ         |
| Compañia Mexicana de Aviación SA de CV (MEXICANA)                       | MX         |
| Continental Airlines Inc.                                               | US         |
| Cook Islands International Airlines Ltd                                 | CK         |
| Crossair                                                                | CH         |
| Cruzeiro do Sul SA — Servicos Aereos                                    | BR         |
| Cyprus Airways Ltd                                                      | CY         |
| Dan-Air Services Ltd                                                    | GB         |
| Delta Air Regionalflugverkehr GmbH                                      | DE         |
| Democratic Yemen Airlines (ALYEMOA)                                     | YE         |
| Deutsche Lufthansa AG (LUFTHANSA)                                       | DE         |
| Eastern Air Lines Inc.                                                  | US         |
| Egyptair                                                                | EG         |
| El Al Israel Airlines Ltd                                               | IL         |
| Emirates                                                                | AE         |
| Empresa Consolidada Cubana de Aviación (CUBANA)                         | CU         |
| Empresa de Transporte Aereo del Perú (AEROPERU)                         | PE         |
| Empresa Ecuatoriana de Aviación SA (ECUATORIANA)                        | EC         |
| Ethiopian Airlines Corporation                                          | ET         |
| Federal Express Corporation                                             | US         |
| Finnair Oy                                                              | FI         |
| Friendly Islands Airways Ltd                                            | TV         |
| Gambia Air Shuttle Ltd                                                  | GM         |
| Garuda Indonesia                                                        | ID         |
| German Wings Luftfahrtunternehmen GmbH                                  | DE         |
| Ghana Airways Corporation                                               | GH         |
| Gulf Air Company GSC                                                    | BH         |
| Hong Kong Dragon Airlines Ltd (DRAGONAIR)                               | HK         |
| IBERIA, Lineas Aereas de España SA                                      | ES         |
| Icelandair                                                              | IS         |
| Indian Airlines                                                         | IN         |
| Iran Air, The Airline of the Islamic Republic of Iran                   | IR         |
| Iraqi Airways                                                           | IQ         |
| Jamahiriya Libyan Arab Airlines                                         | LY         |
| Japan Airlines Co. Ltd                                                  | JP         |
| Japan Air System Co. Ltd                                                | JP         |
| Jugoslovenski Aerotransport (JAT)                                       | RS         |
| Kenya Airways Ltd                                                       | KE         |
| KLM Royal Dutch Airlines                                                | NL         |
| Korean Air                                                              | KR         |
| Kuwait Airways Corporation                                              | KW         |
| LAM — Linhas Aereas de Moçambique                                       | MZ         |
| Lauda Air                                                               | AT         |
| Luffahrt AG                                                             | DE         |
| Lesotho Airways Corporation                                             | LS         |
| Linea Aerea del Cobre SA (LADECO)                                       | CL         |
| Linea Aerea Nacional  Chile SA (LAN-CHILE)                              | CL         |
| Lineas Aereas Costarricenses SA (LACSA)                                 | CR         |
| Lineas Aereas Paraguayas — LAP                                          | PY         |
| Lloyd Aereo Boliviano SA (LAB)                                          | BO         |
| Loganair Ltd                                                            | GB         |
| London City Airways                                                     | GB         |
| MALEV — Hungarian Airlines                                              | HU         |
| Manx Airlines Ltd                                                       | IM         |
| Middle East Airlines Airliban (MEA)                                     | LB         |
| Nationair Canada                                                        | CA         |
| NFD Luftverkehrs AG                                                     | DE         |
| Nigeria Airways Ltd                                                     | NG         |
| Nippon Cargo Airlines (NCA)                                             | JP         |
| Olympic Airways, SA                                                     | GR         |
| Pakistan International Airlines Corp. (PIA)                             | PK         |
| Pan American World Airways, Inc.                                        | US         |
| Philippine Airlines Inc.                                                | PH         |
| PLUNA — Primeras Lineas Uruguayas de Navegación Aerea                   | UY         |
| Polskie Linie Lotnicze (LOT)                                            | PL         |
| Polynesian Airlines Ltd                                                 | Tahiti     |
| Qantas Airways Ltd                                                      | AU         |
| Royal Air Maroc                                                         | MA         |
| Royal Jordanian (ALIA - The Royal Jordanian Airline)                    | JO         |
| Royal Swazi National Airways Corp. Ltd                                  | Swaziland  |
| Ryanair Ltd                                                             | IE         |
| SABENA (Societé anonyme belge d'exploitation de la navigation aerienne) | BE         |
| Saudi Arabian Airlines Corp. (SAUDIA)                                   | SA         |
| Scandinavian Airlines System (SAS)                                      | SE         |
| Scottish European Airways                                               | GB         |
| Solomon Airlines                                                        | SB         |
| Somali Airlines                                                         | SO         |
| South African Airways (SAA)                                             | ZA         |
| Sudan Airways Company Ltd                                               | SD         |
| Swedair AB                                                              | SE         |
| Swiss Air Transport Co. Ltd (SWISSAIR)                                  | CH         |
| Syrian Arab Airlines                                                    | SY         |
| TAGG — Linhas Aereas de Angola (ANGOLA AIRLINES)                        | AO         |
| TAP — Air Portugal                                                      | PT         |
| Tempelhof Airways USA Inc.                                              | US         |
| Tower Air Inc.                                                          | US         |
| Trans-Mediterranean Airways SAL (TMA)                                   | LB         |
| Transavia Holland BV d/b/a Transavia Airlines                           | NL         |
| Trans World Airlines Inc. (TWA)                                         | US         |
| Trinidad & Tobago (BWIA International) Airways Corp.                    | TT         |
| Tunis Air                                                               | TN         |
| Turk Hava Yollari AO (TURKISH AIRLINES)                                 | Turkey     |
| United Airlines                                                         | US         |
| USAir, Inc.                                                             | US         |
| UTA (Union de Transports Aeriens)                                       | FR         |
| VARIG SA (Viaçao Aerea Rio-Grandense)                                   | BR         |
| Venezolana Internacional de Aviación SA (VIASA)                         | VE         |
| Virgin Atlantic Airways                                                 | GB         |
| YEMENIA                                                                 | YE         |
| Yemen Airways                                                           | YE         |
| Zambia Airways Corporation Ltd                                          | ZM         |
| ZAS Airline of Egypt                                                    | EG         |
| Aero Lloyd Flugreisen GmbH & Co.                                        | NA         |
| Luftverkehrs-KG                                                         | NA         |
| Air America (Air Specialities Corp. d/b/a Ail America)                  | NA         |
| Air Ecosse Ltd                                                          | NA         |
| Air Inter (Lignes Aeriennes Interieures)                                | NA         |
| Air Reunion                                                             | NA         |
| Air Tahiti                                                              | NA         |
| Aloha Airlines, Inc.                                                    | NA         |
| Ansett Airlines of Australia                                            | NA         |
| Ansett New Zealand                                                      | NA         |
| Austral Lineas Aereas SA                                                | NA         |
| Australian Airlines Ltd                                                 | NA         |
| Aviación y Comercio, SA (AVIACO)                                        | NA         |
| Commercial Airways (Pty) Ltd                                            | NA         |
| DLT Deutsche Luftverkehrsgesellschaft mbH Douglas Airways Pty Ltd       | NA         |
| East-West Airlines                                                      | NA         |
| Falcon Cargo AB                                                         | NA         |
| Flight West Airlines Ltd                                                | NA         |
| INTAIR                                                                  | NA         |
| IPEC Aviation                                                           | NA         |
| Kendell Airlines                                                        | NA         |
| LAR Transregional (Linhas Regionais SA)                                 | NA         |
| Mount Cook Airlines                                                     | NA         |
| Namib Air (Pty) Ltd                                                     | NA         |
| Salair AB                                                               | NA         |
| Sunflower Airlines Ltd                                                  | NA         |
| Sunstate Airlines                                                       | NA         |
| TALAIR Pty Ltd                                                          | NA         |
| Transbrasil SA Linhas Aereas (Trans Brasil)                             | NA         |
| Trans-Jamaican Airlines Ltd                                             | NA         |
| Transport Aerien Transregional (TAT)                                    | NA         |
| Vayudoot Ltd                                                            | NA         |
| Viaçao Aerea Sao Paulo SA (VASP)                                        | NA         |
| Wairarapa Airlines Ltd                                                  | NA         |
| Wideroe Flyveselskap A/S                                                | NA         |

### Market
Oligopolistic market structure; no specific geographical or turbulence details provided.

### Cartel Period
1988-03-21 : 1998-03-20

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 implementing Articles 85 and 86 |
| 1988-03-21 | IATA | submitted application for negative clearance and notifications for exemption |
| 1988-03-21 | IATA | notified Commission about resolutions |
| 1988-03-21 | International Air Transport Association | exemption declared inapplicable for IATA resolutions |
| 1989-06-15 | Commission | sent statement of objections to IATA based on Regulation No 17 |
| 1989-11-06 | IATA | submitted notification for exemption |
| 1989-11-06 | IATA | notified new resolution series 814 |
| 1989-11-06 | International Air Transport Association | exemption declared inapplicable for specific provision of resolution 814 |
| 1990-01-25 | IATA | provided undertakings on interpretation of clauses |
| 1990-12-31 | IATA | implementation of IATA resolutions 814, 814d, and 814e completed |
| 1991-07-30 | Commission of the European Communities | issued decision on IATA passenger agency programme |
| 1991-07-30 | Commission | adopted this decision

### Legal Framework
Article 85 (operative article); infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
The Commission granted an exemption under Article 85(3) of the EEC Treaty to IATA resolutions 814, 814d, and 814e for the period 21 March 1988 to 20 March 1998.

### Leniency
NA

### Fines
NA

### Remedies
The Commission granted an exemption under Article 85(3) of the EEC Treaty to IATA resolutions 814, 814d, and 814e for the period 21 March 1988 to 20 March 1998. The exemption was conditional on behavioral commitments by IATA including implementing a neutral review and arbitration procedure for disputes involving individual member decisions affecting agents, ensuring non-discrimination in implementation, and requiring that these resolutions be implemented in all Member States not later than 31 December 1990.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) of the EEC Treaty to IATA resolutions 814, 814d, and 814e for the period 21 March 1988 to 20 March 1998. The exemption was conditional on behavioral commitments by IATA.


*(reported: 2026-10-16 20:30:14)*

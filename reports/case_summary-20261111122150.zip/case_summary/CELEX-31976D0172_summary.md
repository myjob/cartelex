# 'IV/27.073', 'Bayer / Gist-Brocades'

**CELEX ID:** CELEX-31976D0172  
**Industry:** | industry               |
|:-----------------------|
| pharmaceuticals        |
| chemical manufacturing |  
**Cartel Period:** 1969-05-07 : 1975-06-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31976D0172 | IV/27073  |

### Case Title
Bayer / Gist-Brocades

### Overview
The case involved anticompetitive agreements between Bayer AG and Gist-Brocades NV concerning the manufacture and distribution of raw penicillin and 6-aminopenicillanic acid. The European Commission found that these agreements constituted a cartel under Article 85, with high gravity. The Commission granted an exemption under specific conditions, requiring the termination of joint subsidiaries, removal of restrictive clauses in licensing agreements, and specialization in production to avoid direct competition.

### Industry
pharmaceuticals
chemical manufacturing

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 21.1:Manufacture of basic pharmaceutical products
NACE_class_code: 21.10: Manufacture of basic pharmaceutical products

### Companies Undertakings
| companies        | location   |
|:-----------------|:-----------|
| Bayer AG         | Leverkusen |
| Gist-Brocades NV | Delft      |

### Market
market_oligopoly: True
market_outside_eu: true

### Cartel Period
1969-05-07 : 1975-06-05

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1969-05-07 | Bayer AG and GistBrocades NV | made agreements relating to manufacture and distribution of raw penicillin and 6-aminopenicillanic acid |
| 1971-05-19 | Bayer and Gist-Brocades | concluded basic agreement covering financing of production plants, transfer of plants to joint subsidiaries, creation of cooperation committee, and exchange of information and research results |
| 1973-03-14 | Bayer AG and GistBrocades NV | amended agreements relating to manufacture and distribution of raw penicillin and 6-aminopenicillanic acid |
| 1974-12-18 | Commission | opened proceeding under Article 3 of Regulation No 17 |
| 1975-05-05 | Bayer and Gist-Brocades | formally notified of agreements |
| 1975-05-05 | Bayer AG and GistBrocades NV | notified agreements on manufacture and supply of raw penicillin and 6-aminopenicillanic acid |
| 1975-06-05 | Bayer AG and GistBrocades NV | adapted agreements to satisfy tests of Article 85 (3), exemption took effect |
| 1975-06-05 | Bayer and Gist-Brocades | made amendments to agreements |
| 1975-06-05 | Bayer and Gist-Brocades | agreed to terminate the basic agreement and extend supply contracts |
| 1975-06-05 | Bayer and Gist-Brocades | agreed to release each other from obligation not to contest validity of industrial property rights |
| 1975-08-29 | redacted | decision took effect |
| 1975-10-21 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion pursuant to Article 10 of Regulation No 17 |
| 1975-12-15 | redacted | decision was signed |

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company          |
|:-----------------|
| Bayer AG         |
| Gist-Brocades NV |

### Leniency
NA

### Fines
NA

### Remedies
| value                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|:----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| The Commission required each undertaking to inform it annually by 30 June of any changes or additions to the agreements, including details on licenses issued, investments, capacities, production figures, quantities processed and supplied, prices charged, and wholesale prices to pharmacies. Additionally, any linkages such as shareholdings exceeding 2.5%, common directors or managers, or formation of joint subsidiaries must be reported promptly. |
| The Commission ordered the termination of the joint subsidiaries formed earlier that had the effect of bringing production and investment under joint control; these were either wound up or through sale of shares to end such joint control.                                                                                                                                                                                                                  |
| The agreements were amended to remove the no-challenge clause in licensing agreements, which was deemed unnecessary and restrictive. Licenses are now issued non-exclusively to allow other firms to benefit from improvements or new processes.                                                                                                                                                                                                                |
| Each undertaking committed to specialize in production of specific products (Bayer stopped manufacturing raw penicillin; Gist-Brocades ceased making 6-APA), with long-term supply contracts in place so as not to compete directly.                                                                                                                                                                                                                            |

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
A. BORSCHEITE

### Courts
NA

### Book Reference
NA

### Outcome
The Commission required each undertaking to inform it annually by 30 June of any changes or additions to the agreements, including details on licenses issued, investments, capacities, production figures, quantities processed and supplied, prices charged, and wholesale prices to pharmacies. Additionally, any linkages such as shareholdings exceeding 2.5%, common directors or managers, or formation of joint subsidiaries must be reported promptly.

The Commission ordered the termination of the joint subsidiaries formed earlier that had the effect of bringing production and investment under joint control; these were either wound up or through sale of shares to end such joint control.

The agreements were amended to remove the no-challenge clause in licensing agreements, which was deemed unnecessary and restrictive. Licenses are now issued non-exclusively to allow other firms to benefit from improvements or new processes.

Each undertaking committed to specialize in production of specific products (Bayer stopped manufacturing raw penicillin; Gist-Brocades ceased making 6-APA), with long-term supply contracts in place so as not to compete directly.


*(reported: 2026-10-16 19:31:19)*

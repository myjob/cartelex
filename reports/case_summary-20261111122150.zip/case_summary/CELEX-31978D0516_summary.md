# 'IV/29.559', 'RAI/UNITEL'

**CELEX ID:** CELEX-31978D0516  
**Industry:** NA  
**Cartel Period:** 1978-05-01 : 1978-05-26  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0516 | IV/29559  |

### Case Title
IV/29.559 – RAI/UNITEL

### Overview
The case involves the European Commission's decision against UNITEL Film- und Fernseh-Produktionsgesellschaft mbH & Co. for an anticompetitive agreement under Article 85 of the Treaty on the Functioning of the European Union (TFEU). The Commission requested information from UNITEL, which refused to provide it, leading to a decision imposing fines and periodic penalty payments.

### Industry
NA

### Oecd Nace
OECD Sector: communication
NACE Group Code: 06.2: Extraction of natural gas
NACE Class Code: 06.20: Extraction of natural gas

### Companies Undertakings
UNITEL Film- und Fernseh-Produktionsgesellschaft mbH & Co.
Country: DE

### Market
NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission | adopted Regulation No 17 |
| 1977-11-23 | Commission | sent request for information to UNITEL |
| 1977-12-12 | UNITEL | refused to provide information |
| 1978-05-26 | Commission | issued decision relating to proceeding under Article 85

### Legal Framework
Law Article Operative: Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered UNITEL to supply complete and correct information within one month, and imposed fines and periodic penalty payments for non-compliance.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
| court                                  | country    | jurisdiction   |
|:---------------------------------------|:-----------|:---------------|
| Court of Justice of the European Union | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85, ordering UNITEL to provide complete and correct information within one month and imposing fines and periodic penalty payments for non-compliance. The case involved a refusal by UNITEL to provide requested information.


*(reported: 2026-10-16 19:47:32)*

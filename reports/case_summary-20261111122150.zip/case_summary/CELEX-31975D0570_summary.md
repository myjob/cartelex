# 'IV/28.967', 'Bronbemaling V., Heidemaatschappij'

**CELEX ID:** CELEX-31975D0570  
**Industry:** NA  
**Cartel Period:** 1971 : 1974-07-03  

## Summary

### Celex Case Id
CELEX-31975D0570

### Case Title
Bronbemaling V., Heidemaatschappij

### Overview
The case involves a cartel of Dutch companies in the construction sector (specifically utility projects for fluids) that engaged in anticompetitive patent licensing agreements between 1971 and 1974. The European Commission investigated these practices under Article 85, finding high gravity infringement involving abuse of dominance and anticompetitive agreements. Remedies included ceasing restrictive licensing and removing immunity from notification, enabling potential fines under Article 15 (2) (a) of Regulation No 17.

### Industry
construction

### Oecd Nace
OECD sector: construction, NACE group code: 42.2, NACE class code: 42.21

### Companies Undertakings
| company                                                                              |
|:-------------------------------------------------------------------------------------|
| NV Heidemaatschappij Beheer, Lovinklaan 1, Arnhem                                    |
| Landdevelopment and Reclamation Company (Lareco) BV, Zijpendaalseweg 87, Arnhem      |
| BV Grondboorbedrijf J. Mos, Kleidijk, Rhoon                                          |
| De Ruiter Boringen en Bemalingen BV, Haarlemmerstraatweg 79, Halfweg-Haarlemmerliede |
| Reinders-Wessemius Grondboorbedrijven BV, Kanaal ANZ 133-1, Emmer-Compascuum         |

### Market
Netherlands, market is oligopolistic

### Cartel Period
1971 : 1974-07-03

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-06-17 | Heidemaatschappij Beheer NV | concluded patent licensing agreements with Lareco, Mos, and De Ruiter |
| 1971-07-17 | Heidemaatschappij Beheer NV | concluded additional licensing agreements and firm merger occurred |
| 1971-07-17 | Heidemaatschappij Beheer NV | concluded patent licensing agreements with Reinders and Wessemius |
| 1974-01-01 | Heidemaatschappij Beheer NV | concluded new licensing agreement with retroactive effect |
| 1974-06-20 | Heidemaatschappij | concluded agreement with opposing firms granting licences in exchange for withdrawal of opposition to patent |
| 1974-07-03 | Heidemaatschappij Beheer NV | concluded final licensing agreement |
| 1974-08-06 | Dutch undertakings | notified agreements regarding patent licensing |
| 1974-08-06 | Heidemaatschappij | notified the licensing agreements to the Commission |
| 1974-08-06 | Grondboorbedrijf J. Mos BV, Reinders-Wessemius Grondboorbedrijven BV, De Ruiter Boringen en Bemalingen BV, Landdevelopment and Reclamation Company (Lareco) BV | notified the patent licensing agreements |
| 1975-07-25 | redacted | issued Commission Decision |

### Legal Framework
Article 85, Article 86

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
| company |
| --- |
| NV Heidemaatschappij Beheer |
| Landdevelopment and Reclamation Company (Lareco) BV |
| BV Grondboorbedrijf J. Mos |
| De Ruiter Boringen en Bemalingen BV |
| Reinders-Wessemius Grondboorbedrijven BV |

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist from restricting the grant of identical or similar licenses to other firms in the Netherlands without consent of the majority of parties to the agreement; removal of immunity from notification, enabling imposition of fines under Article 15 (2) (a) of Regulation No 17.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                 | country     | jurisdiction             |
|:----------------------|:------------|:-------------------------|
| Arnhem District Court | Netherlands | arrondissementsrechtbank |

### Book Reference
IV/28.967

### Outcome
Commission Decision taken; remedies imposed including cessation of restrictive licensing practices and removal of immunity from notification.


*(reported: 2026-11-11 10:11:04)*

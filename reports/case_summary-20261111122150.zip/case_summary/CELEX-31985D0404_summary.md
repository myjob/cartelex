# 'IV/29.420', "Grundig's EEC distribution system"

**CELEX ID:** CELEX-31985D0404  
**Industry:** consumer electronics  
**Cartel Period:** 1977-04-01 : 1989-03-28  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31985D0404 | IV/29420-1 |

### Case Title
Grundig's EEC distribution system

### Overview
The case involves Grundig AG, a German company in the consumer electronics industry, which implemented a selective distribution system for television sets, video recorders, hi-fi equipment, and related accessories within the European Economic Community (EEC). The Commission investigated the system under Article 85 of the EEC Treaty, finding it to be an anticompetitive agreement. The case resulted in a decision by the Commission, with remedies imposed on Grundig AG.

### Industry
consumer electronics

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.4: Manufacture of consumer electronics
NACE class code: 26.40: Manufacture of consumer electronics

### Companies Undertakings
Grundig AG (DE)

### Market
Germany, Italy, France
Market outside EU: False
Market oligopoly: False
Market turbulence: NA

### Cartel Period
1977-03-29 : 1989-03-28

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-03-29 | Grundig AG | filed notification of EEC dealership agreements |
| 1977-04-01 | Grundig | introduced selective distribution system |
| 1977-10-24 | redacted | Court of Justice delivered judgment in Case 26/76 (Metro) |
| 1984-04-01 | Philips | acquired control of Grundig |
| 1985-07-10 | Commission | issued decision relating to Grundig's EEC distribution system |
| 1985-07-10 | Commission | adopted this Decision |
| 1989-03-28 | redacted | exemption period ended |
| 1989-03-28 | redacted | exemption period under Article 8(1) of Regulation No 17 ends |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
low

### Exemption
Grundig AG sought and was granted an exemption.

### Leniency
NA

### Fines
NA

### Remedies
Grundig AG shall submit annual reports to the Commission detailing cases where it has refused to grant a wholesaler or retailer a dealership, terminated a dealership, withdrawn supplies, or inspected dealer records.

### Company Recidivism
Grundig AG: NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court      | country            | jurisdiction   |
|:-----------|:-------------------|:---------------|
| COMMISSION | European Community | EEC            |

### Book Reference
NA

### Outcome
The Commission took a decision and requested information. No formal leniency applications were made, but an exemption was granted to Grundig AG. Remedies were imposed requiring annual reporting on dealership practices.


*(reported: 2026-10-16 21:59:39)*

# 'IV/27.393 and IV/27.394', 'Publishers Association — Net Book Agreements'

**CELEX ID:** CELEX-31989D0044  
**Industry:** NA  
**Cartel Period:** 1973-06-12 : 1988-12-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0044 | IV/27394  |

### Case Title
Publishers Association — Net Book Agreements

### Overview
The European Commission investigated the Publishers Association's implementation of standard conditions of sale for net books, which were found to constitute anticompetitive agreements under Article 85 of the EEC Treaty. The infringement involved vertical restraints, specifically Resale Price Maintenance (RPM), and was concluded through a Commission decision in 1988.

### Industry
books, pamphlets, maps, printed matter

### Oecd Nace
trade (wholesaling and retailing) and hotels
58.1:Publishing of books, periodicals and other publishing activities
58.19: Other publishing activities

### Companies Undertakings
| companies                                                   | location   |
|:------------------------------------------------------------|:-----------|
| Publishers Association                                      | NA         |
| Abacus Press                                                | NA         |
| Association of County Councils                              | NA         |
| Abson Books                                                 | NA         |
| Athlone Press                                               | NA         |
| Academy Editions                                            | NA         |
| Automobile Association Publishing Division                  | NA         |
| Addison-Wesley Publishers Ltd                               | NA         |
| Bailey Bros & Swinfen Ltd                                   | NA         |
| Advisory Unit for Microtechnology in Education              | NA         |
| Batsford (B.T.) Ltd                                         | NA         |
| Agricultural Training Board                                 | NA         |
| Aldwych Press Ltd                                           | NA         |
| Beaconsfield Publishers' Ltd                                | NA         |
| Philip Allan Publishers Ltd                                 | NA         |
| Bedford Square Press                                        | NA         |
| Allen J.A.) & Co. Ltd                                       | NA         |
| Better Books                                                | NA         |
| Alpine Fine Art Collection (UK) Ltd                         | NA         |
| Ian Allan Ltd                                               | NA         |
| W.H. Allen & Co. plc                                        | NA         |
| Peter Andrew Publishing Co.                                 | NA         |
| Anglo-German Foundation for the Study of Industrial Society | NA         |
| Artemis Press Ltd                                           | NA         |
| Art Guide Publications Ltd                                  | NA         |
| Artworks Publicity & Publishing Ltd                         | NA         |
| Aurum Press                                                 | NA         |
| Bachman & Turmer                                            | NA         |
| Blandford Publishing Ltd                                    | NA         |
| Book Club Associates                                        | NA         |
| Carcanet Press                                              | NA         |
| Frank Cass & Co. Ltd                                        | NA         |
| Catholic Truth Society Inc.                                 | NA         |
| University of Chicago Press                                 | NA         |
| Child's Play (International) Ltd                            | NA         |
| Clio Press Ltd                                              | NA         |
| William Clowes & Sons Ltd                                   | NA         |

### Market
United Kingdom
false
True

### Cartel Period
1973-06-12 : 1988-12-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-06-12 | Publishers Association | notified two agreements on standard conditions of sale of net books |
| 1986-10-08 | Publishers Association | initiated proceedings in these cases |
| 1988-12-12 | Publishers Association | issued decision ending infringement of EEC Treaty |
| 1988-12-12 | Commission | issued Commission Decision (89/44/EEC) |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The Publishers Association shall take all steps necessary for bringing the infringement to an end forthwith. The Publishers Association shall inform the undertakings listed in Annexes I and II to this Decision, the book clubs established in the United Kingdom and the booksellers mentioned in the directory of booksellers, in writing of this Decision and of the fact that the infringement has been brought to an end, stating the practical effects which this will have on the terms under which trade in books is carried on between the United Kingdom and the other Member States. The Publishers Association shall submit for approval by the Commission a proposal for a notice to that effect within two months of receipt of this Decision.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Publishers Association | NA |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                       | country        | jurisdiction   |
|:----------------------------|:---------------|:---------------|
| Restrictive Practices Court | United Kingdom | British law    |

### Book Reference
NA

### Outcome
The European Commission found that the Publishers Association's standard conditions of sale for net books constituted anticompetitive agreements under Article 85 of the EEC Treaty. The infringement was concluded through a Commission decision in 1988, with remedies requiring the association to end the infringement and inform relevant parties of the decision.


*(reported: 2026-11-11 11:16:19)*

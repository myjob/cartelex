# 'IV/261-A', 'Belgische Vereniging der Banken/Association Belge des Banques'

**CELEX ID:** CELEX-31987D0013  
**Industry:** NA  
**Cartel Period:** 1976-01-01 : 1986-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0013 | IV/261    |

### Case Title
Belgische Vereniging der Banken/Association Belge des Banques

### Overview
The case involves the Belgische Vereniging der Banken/Association Belge des Banques (BVB/ABB), a Belgian banking association, which was found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty. The infringement involved horizontal restraints related to the exchange of information on prices and sales.

### Industry
Banking

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 64.1: Monetary intermediation
NACE class code: 64.11: Central banking

### Companies Undertakings
| companies | location |
| --- | --- |
| Belgische Vereniging der Banken / Association Belge des Banques | NA |

### Market
European Union

### Cartel Period
1962-10-31 : 1986-04-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1936-12-01 | Belgische Vereniging der Banken / Association Belge des Banques | established |
| 1962-10-31 | BVB/ABB | notified Commission of conventions, agreements, and recommendations |
| 1962-10-31 | Belgische Vereniging der Banken / Association Belge des Banques | submitted notification and application for negative clearance |
| 1975-11-06 | Commission | sent request for information to BVB/ABB |
| 1976-01-23 | BVB/ABB | responded to Commission's request with list of practices and documents |
| 1981-07-14 | Court of Justice | gave ruling on applicability of competition rules to bank agreements |
| 1983-05-03 | Commission | sent request for information to BVB/ABB following Court judgment |
| 1983-06-21 | BVB/ABB | informed Commission of amendments to restrictive practices |
| 1984-09-05 | BVB/ABB | responded to Commission's updating request with major amendments |
| 1986-04-01 | BVB/ABB | terminated restrictive practices with effect from date |
| 1986-05-30 | BVB/ABB | sent definitive versions of three conventions to the Commission |
| 1986-12-11 | Commission | issued Commission Decision

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission issued an order requiring the Belgische Vereniging der Banken/Association Belge des Banques to inform the Commission forthwith of any addition or amendment to the three conventions referred to in Article 1, and of any new agreement concluded between its members within the association.

### Company Recidivism
| company                                                       | recidivism   |
|:--------------------------------------------------------------|:-------------|
| Belgische Vereniging der Banken/Association Belge des Banques | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | Belgium   | European Union |

### Book Reference
IV/261
Agreements on standards

### Outcome
The Commission took no action initially but later issued a decision requiring the association to inform the Commission of any additions or amendments to conventions.


*(reported: 2026-10-16 18:58:40)*

# 'NA', 'NA'

**CELEX ID:** CELEX-31972D0403  
**Industry:** foam glass  
**Cartel Period:** 1970-10-01 : 1972-06-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0403 | IV/26.876 |
| CELEX-31972D0403 | IV/26876  |

### Case Title
NA

### Overview
The case involves an antitrust infringement by companies in the foam glass industry, specifically Pittsburgh Corning Europe S.A., Formica Belgium N.V., and N.V. Hertel en Co., for coordinated price discrimination violating Article 85 of the Treaty on the Functioning of the European Union (TFEU). The cartel period lasted from October 1, 1970, to June 1, 1972.

### Industry
foam glass, insulating material

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 23.9:Manufacture of abrasive products and non-metallic mineral products n.e.c.
NACE_class_code: 23.99: Manufacture of other non-metallic mineral products n.e.c.

### Companies Undertakings
| companies                   |
|:----------------------------|
| PittsburghCorningEuropeS.A. |
| FormicaBelgium              |
| HertelenCo.                 |

### Market
The relevant market includes Germany, Belgium, and the Netherlands. The market is not described as oligopolistic or turbulent.

### Cartel Period
1970-10-01 : 1972-06-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1969-01-01 | P.C.E. | signed contract |
| 1969-01-01 | P.C.E. and Formica | concluded long-term agency agreement |
| 1970-10-01 | P.C.E. | initiated coordinated price discrimination violating Article85 |
| 1970-10-01 | Formica | began coordinated pricing behavior |
| 1970-10-01 | P.C.E. and Formica | introduced price discrimination |
| 1970-10-01 | P.C.E. | implemented new discriminatory tariff system |
| 1970-10-01 | P.C.E. | ordered Formica and Hertel to apply new sales tariff |
| 1971-01-06 | PittsburghCorningEurope, FormicaBelgium, Hertel | submitted application for negative test and exemption |
| 1971-02-23 | P.C.E. | submitted application for negative test and exemption |
| 1971-02-23 | PittsburghCorningEurope, Hertel | submitted further application for exemption |
| 1972-06-01 | Pittsburgh Corning Europe S.A. | ended violation period under Article 85(1) involving discriminatory pricing |
| 1972-11-23 | Commission of the European Communities | issued decision |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was sought by Pittsburgh Corning Europe S.A. but rejected under Article 85(3).

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Pittsburgh Corning Europe S.A. | 100000 invoice units |

### Remedies
A fine of 100000 invoice units (equivalent to 5000000 Belgian francs) was imposed on Pittsburgh Corning Europe S.A. The Commission rejected applications for a negative test and exemption under Article 85(3). All companies involved—Pittsburgh Corning Europe S.A., Formica Belgium N.V., and N.V. Hertel en Co.—were ordered to cease applying discriminatory prices effective 1 June 1972.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Pittsburgh Corning Europe S.A. | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
S.L. MANSHOLT

### Courts
| court          | country   | jurisdiction   |
|:---------------|:----------|:---------------|
| The Commission | Belgium   | European Union |

### Book Reference
IV/26.876 (landmark IV/E) under the category of 'Territorial exclusivity and parallel import /export bans'

### Outcome
The Commission imposed a fine on Pittsburgh Corning Europe S.A., rejected exemption applications, and ordered all companies involved to cease discriminatory pricing.


*(reported: 2026-11-11 09:59:58)*

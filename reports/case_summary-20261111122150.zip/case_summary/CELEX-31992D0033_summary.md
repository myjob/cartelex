# 'IV/33.242', 'Yves Saint Laurent Parfums'

**CELEX ID:** CELEX-31992D0033  
**Industry:** cosmetic products  
**Cartel Period:** 1991-06-01 : 1997-05-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31992D0033 | IV/33242  |

### Case Title
Yves Saint Laurent Parfums

### Overview
The European Commission investigated anticompetitive agreements involving Yves Saint Laurent Parfums and related companies in the cosmetic products industry, specifically focusing on vertical restraints. The case involved an exemption granted under Article 85(3) of the EC Treaty.

### Industry
cosmetic products

### Oecd Nace
manufacturing

### Companies Undertakings
| companies                     |
|:------------------------------|
| Yves Saint Laurent Parfums SA |
| Yves Saint Laurent SA         |
| Groupe Yves Saint Laurent     |

### Market
France

### Cartel Period
1991-06-01 : 1997-05-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1989-07-06 | Yves Saint Laurent Parfums SA | submitted application for negative clearance or exemption |
| 1991-06-01 | Yves Saint Laurent Parfums | amended contracts entered into force |
| 1991-12-16 | Commission of the European Communities | issued Commission Decision |
| 1992-05-31 | Yves Saint Laurent Parfums | completed transitional period |
| 1993-06-01 | Yves Saint Laurent Parfums SA | commenced reporting obligations |
| 1997-05-31 | Yves Saint Laurent Parfums SA | end of exemption period under Article 8(1) of Regulation No 17 |

### Legal Framework
Article 85

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared the provisions of Article 85(1) inapplicable pursuant to Article 85(3). The exemption is conditional on Yves Saint Laurent Parfums submitting detailed reports every two years specifying, for each Member State, the amount set annually and the average purchases figures. It also requires adherence to limits on minimum annual purchases (not exceeding 40% of average yearly purchases), requirements regarding stockholding, cooperation in advertising, and a prohibition on selling new products within one year of launch. Verification of invoices is allowed only where there is concrete evidence of breach.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) with specific conditions, including reporting obligations and restrictions on purchases, stockholding, advertising cooperation, and new product sales.


*(reported: 2026-10-16 20:38:36)*

# 'NA', 'NA'

**CELEX ID:** CELEX-31980D0335  
**Industry:** NA  
**Cartel Period:** 1976-03-30 : 1976-04-08  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0335 | IV/400-3  |

### Case Title
NA

### Overview
This case involves an anticompetitive agreement in the flat glass industry in Italy, investigated under Regulation No 17. The company Fabbrica Lastre di Vetro Pietro Sciarra SpA was found to have engaged in horizontal restraints and was fined for producing incomplete documentation during the investigation.

### Industry
flat glass

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.1:Manufacture of glass and glass products
NACE class code: 23.11: Manufacture of flat glass

### Companies Undertakings
Fabbrica Lastre di Vetro Pietro Sciarra SpA (IT)

### Market
Italy

### Cartel Period
1976-03-30 : 1976-04-08

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-03-30 | unknown | signed memorandum of agreement |
| 1976-04-01 | unknown | agreement became effective |
| 1978-06-01 | Fabbrica P. Sciarra | underwent investigation under Article 14 of Regulation No 17 for agreements in glass manufacturing industry |
| 1978-06-01 | Fides | refused to submit to investigation concerning agreements in glass manufacturing industry |
| 1979-02-07 | Commission's inspectors | carried out investigation at head office of Fides |
| 1979-07-23 | Fabbrica P. Sciarra | responded to Commission's statement of objections |
| 1979-11-30 | Advisory Committee on Restrictive Practices and Monopolies | delivered opinion |
| 1979-12-20 | Commission of the European Communities | imposed fine on Fabbrica Lastre di Vetro Pietro Sciarra |
| 1979-12-20 | Commission | imposed a fine of 5 000 units of account on Fabbrica P. Sciarra

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Fabbrica P. Sciarra | 5 000 units of account or Lit 5 795 050 |

### Remedies
A fine of 5,000 units of account (equivalent to Lit 5,795,050) was imposed on Fabbrica P. Sciarra for producing incomplete documentation during the investigation under Regulation No 17.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed a fine of 5,000 units of account (equivalent to Lit 5,795,050) on Fabbrica Lastre di Vetro Pietro Sciarra SpA for producing incomplete documentation during the investigation under Regulation No 17.


*(reported: 2026-11-11 10:31:58)*

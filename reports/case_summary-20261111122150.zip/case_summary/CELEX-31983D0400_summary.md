# 'NA', 'NA'

**CELEX ID:** CELEX-31983D0400  
**Industry:** | industry   |
|:-----------|
| sailboard  |
| sailboard  |
| sailboard  |
| sailboard  |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0400 | IV/29395  |

### Case Title
NA

### Overview
The European Commission investigated anticompetitive agreements among companies in the sailboard industry, specifically focusing on patent licensing and distribution practices that restricted competition. The case involved multiple undertakings from the US, Germany, and Netherlands, who engaged in cartel behavior under Article 85 of the EC Treaty.

### Industry
sailboard

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.3:Manufacture of sports goods
NACE class code: 32.30: Manufacture of sports goods

### Companies Undertakings
| companies                                  |
|:-------------------------------------------|
| Windsurfing International Inc.             |
| Windglider Fred Ostermann GmbH             |
| Shark Wassersportgerate GmbH               |
| Akutec Angewandte Kunststofftechnik GmbH   |
| S.A.N. Warenvertriebsgesellschaft mbH      |
| Klepper BeteiligungsGmbH & Co. Bootsbau KG |
| Marker Surf GmbH                           |
| Windsurfing Central GmbH                   |
| Ten Cate Sports BV                         |

### Market
Relevant market: Netherlands, Belgium, France, Italy, Luxembourg
Market structure: Oligopoly
Market turbulence: NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | redacted | adopted Council Regulation No 17 implementing Articles 85 and 86 |
| 1963-07-25 | redacted | hearing as laid down in Article 19 (1) and (2) of Council Regulation No 17 |
| 1968-03-27 | Hoyle Schweitzer and James Drake | filed priority application in United States |
| 1969-02-28 | WSI | filed main patent No 1.258.317 |
| 1973-01-01 | WSI | granted exclusive right to manufacture and market Windsurfer in Europe |
| 1974-06-27 | German Patent Office | patent published |
| 1978-03-31 | German Patent Office | granted patent in form not substantially different from specification |
| 1978-07-01 | Akutec | entered into licensing agreement with WSI |
| 1978-07-06 | WSI | took over position of licensor for patent licensing agreements |
| 1979-08-09 | WSI | established exclusive right to conclude further licensing agreements |
| 1980-10-09 | licensees | agreed to show only complete sailboards in advertisements and exhibitions |
| 1982-06-07 | redacted | initiated proceedings in case IV/29.395 |
| 1983-07-11 | Commission | issued legal decision |

### Legal Framework
Legal framework: Article 85 (operative article), Article 85 (all relevant articles)
Canonical concept: anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Reductions granted: NA
Applications rejected: NA

### Fines
| company | amount |
| --- | --- |
| WsI | 50 000 ECU or DM 113 793 |
| Ostermann | 15 000 ECU or DM 34 138 |
| Akutec | 10 000 ECU or DM 22 759 |
| Klepper | 10 000 ECU or DM 22 759 |
| Shark | 5 000 ECU or DM 11 379 |
| WsC | 5 000 ECU or DM 11 379 |

### Remedies
The Commission ordered the termination of infringing patent licensing and distribution agreements, and imposed fines on undertakings involved in the infringements as a behavioral remedy to cease anti-competitive conduct.

### Company Recidivism
| company | recidivism |
| --- | --- |
| WSI | NA |
| Ostermann | NA |
| Akutec | NA |
| Klepper | NA |
| Shark | NA |
| WSC | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court                     | country        | jurisdiction                        |
|:--------------------------|:---------------|:------------------------------------|
| Bundespatentgericht       | Germany        | Patent                              |
| Bundesgerichtshof         | Germany        | Federal Court of Justice of Germany |
| Landgericht München I     | Germany        | Bavaria                             |
| Oberlandesgericht München | Germany        | Bavaria                             |
| High Court of Justice     | United Kingdom | London                              |

### Book Reference
NA

### Outcome
The European Commission found the companies involved in anticompetitive agreements under Article 85. Fines were imposed on several undertakings, and the Commission ordered the termination of infringing patent licensing and distribution agreements.


*(reported: 2026-11-11 10:45:35)*

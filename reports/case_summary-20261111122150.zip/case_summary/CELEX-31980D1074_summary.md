# 'IV/197', 'Industrieverband Solnhofener Natursteinplatten eV'

**CELEX ID:** CELEX-31980D1074  
**Industry:** Solnhofen natural stone slabs  
**Cartel Period:** 1961-08-02 : 1980-06-30  

## Summary

### Celex Case Id
CELEX-31980D1074

### Case Title
Industrieverband Solnhofener Natursteinplatten eV

### Overview
The case involves a cartel of manufacturers of Solnhofen natural stone slabs that was established in 1961 and dissolved in 1980. The cartel was found to have engaged in anticompetitive practices, specifically price fixing collusion, under Article 85 of the EC Treaty. The Commission took no action initially but later adopted a decision. The outcome included the dissolution of the original cartel and the formation of a new association as a remedy.

### Industry
Solnhofen natural stone slabs

### Oecd Nace
mining, 08.1:Quarrying of stone, sand and clay, 08.11: Quarrying of ornamental and building stone, limestone, gypsum, chalk and slate

### Companies Undertakings
| companies                                         |
|:--------------------------------------------------|
| Exportkartell Solnhofener Natursteinplatten       |
| Industrieverband Solnhofener Natursteinplatten eV |

Companies and undertakings investigated, from the 'companies_investigated' fact, with their country from the 'companies_country' fact. Preserve markdown lists if present.

### Market
NA

### Cartel Period
1961-08-02 : 1980-06-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1961-08-02 | manufacturers of Solnhofen natural stone slabs | established contract of association |
| 1962-03-13 | Exportkartell Solnhofener Natursteinplatten | established contract of association |
| 1962-10-25 | Exportkartell Solnhofener Natursteinplatten | filed notification to Commission under Article 5 of Regulation No 17 |
| 1977-12-19 | Commission | issued notice concerning agreements of minor importance |
| 1980-06-30 | Exportkartell Solnhofener Natursteinplatten | was dissolved and replaced by Industrieverband Solnhofener Natursteinplatten eV |
| 1980-07-15 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion under Article 10 of Regulation No 17 |
| 1980-10-16 | Commission | adopted decision |

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies                                   | recidivism   |
|:--------------------------------------------|:-------------|
| Exportkartell Solnhofener Natursteinplatten | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
IV/197

### Outcome
Dissolution of Exportkartell Solnhofener Natursteinplatten and formation of new association 'Industrieverband Solnhofener Natursteinplatten eV'


*(reported: 2026-10-16 18:56:46)*

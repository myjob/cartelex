# 'IV/30.077', 'Cafeteros de Colombia'

**CELEX ID:** CELEX-31982D0860  
**Industry:** NA  
**Cartel Period:** 1960-11-09 : 1983-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0860 | IV/30077  |

### Case Title
Cafeteros de Colombia

### Overview
The European Commission investigated the Federación Nacional de Cafeteros de Colombia (FNC) and its practices related to resale prohibition clauses in contracts with coffee roasters in the European Economic Community (EEC). The FNC was found to have engaged in an anticompetitive agreement under Article 85(1) of the EC Treaty, which prohibits agreements that prevent competition. The Commission refused exemption under Article 85(3), and imposed remedies requiring the FNC to refrain from including specific clauses in future contracts.

### Industry
Agriculture, specifically growing beverage crops

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.2: Growing of perennial crops
NACE class code: 01.27: Growing of beverage crops

### Companies Undertakings
| company                                         |
|:------------------------------------------------|
| Federación Nacional de Cafeteros de Colombia    |
| Installe                                        |
| SACA                                            |
| La Federación Nacional de Cafeteros de Colombia |

### Market
The relevant market includes Germany, Denmark, France, Italy, Netherlands, United Kingdom, Belgium, and Luxembourg.

### Cartel Period
1960-11-09 : 1983-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1960-11-09 | Federación Nacional de Cafeteros | formalized functions under Decree No 2630 |
| 1980-04-29 | FNC | notified contracts to the Commission and applied for negative clearance |
| 1981-03-02 | FNC | supplemented notification in accordance with Article 4 of Regulation No 17 |
| 1982-07-20 | Commission | opened proceedings in the case |
| 1982-09-22 | FNC | informed Commission of decision to delete resale prohibition clauses |
| 1982-12-10 | Commission | adopted decision on infringement of Article 85(1) and refusal of exemption under Article 85(3) |
| 1983-01-01 | FNC | implemented deletion of resale prohibition clauses for Colombian green coffee |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption was sought by Federación Nacional de Cafeteros de Colombia.

### Leniency
NA

### Fines
NA

### Remedies
FNC must refrain from including clause 15 (or its equivalent) in any contract concluded henceforth with coffee roasters in the EEC or with Installe or SACA.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found infringement of Article 85(1) and refused exemption under Article 85(3). The FNC was required to refrain from including specific resale prohibition clauses in future contracts.


*(reported: 2026-11-11 10:42:51)*

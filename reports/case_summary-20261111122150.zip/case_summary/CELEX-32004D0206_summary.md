# 'COMP/C.37.671', 'Flood flavour enhancers'

**CELEX ID:** CELEX-32004D0206  
**Industry:** | industry                                   |
|:-------------------------------------------|
| Chemicals, Pharmaceuticals, Food Products  |
| Chemicals, Pharmaceuticals, Food Additives |
| Chemicals, Food Additives, Animal Feed     |
| Chemicals, Pharmaceuticals, Food Products  |  
**Cartel Period:** 1988-07-16 : 1997-07-25  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32004D0206 | IV/37671  |

### Case Title
COMP/C.37.671 – Flood flavour enhancers

### Overview
The European Commission investigated a cartel involving nucleotide producers from Japan and South Korea, found to have engaged in horizontal price fixing collusion, market sharing, and exchange of information on prices and sales under Article 81 of the Treaty.

### Industry
Chemicals, Pharmaceuticals, Food Products
Chemicals, Pharmaceuticals, Food Additives
Chemicals, Food Additives, Animal Feed
Chemicals, Pharmaceuticals, Food Products

### Oecd Nace
manufacturing
20.5:Manufacture of other chemical products
20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| company                            |
|:-----------------------------------|
| Ajinomoto Company Incorporated     |
| Takeda Chemical Industries Limited |
| Daesang Corporation                |
| Cheil Jedang Corporation           |

### Market
Austria, Finland, Iceland, Liechtenstein, Norway, Sweden
Market outside EU
Oligopoly market with turbulence due to price fluctuations after 1997, increase in production capacity leading to price drops, economic instability due to currency devaluation, demand stagnation from 1997 onwards, and excess capacity.

### Cartel Period
1988-07-16 : 1997-07-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-07-16 | Takeda | initiated P-meeting for nucleotides to avert competition |
| 1988-10-05 | Japanese nucleotide producers | held meeting with Miwon representatives to discuss limiting market penetration and possible cooperation |
| 1988-11-08 | Japanese nucleotide producers | held meeting discussing prices for European end-users |
| 1988-11-08 | Japanese producers | discussed and agreed upon prices for forthcoming negotiations with big three customers |
| 1988-12-19 | Daesang | concluded a counterpurchasing agreement with Ajinomoto |
| 1989-03-07 | manufacturers of nucleotide | held first meeting in which Cheil participated |
| 1989-06-07 | Cheil and other manufacturers | agreed upon target prices for 1989 |
| 1992-04-27 | Ajinomoto | participated in high-level meeting with competitors on nucleotides cooperation |
| 1993-03-02 | Ajinomoto, Takeda, Miwon, and Cheil | adjusted regional prices and clarified terms of counterpurchasing agreements |
| 1997-05-26 | unknown | meeting organized in Seoul to set overseas price at USD $25/kg for 1997 |
| 1998-06-02 | Cheil | infringed Article 81(1) of the Treaty |
| 2002-12-17 | European Commission | imposed fines on undertakings |

### Legal Framework
Article 81
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
| company | amount |
| --- | --- |
| Takeda | 100% |
| Ajinomoto | 30% |
| Daesang | 50% |
| Cheil | 40% |

### Fines
| company | amount |
| --- | --- |
| Ajinomoto Company Incorporated | EUR 15 540 000 |
| Daesang Corporation | EUR 2 280 000 |
| Cheil Jedang Corporation | EUR 2 736 000 |
| Takeda Chemical Industries Limited | EUR 0 |

### Remedies
The Commission ordered each participant in the infringement to immediately bring to an end the infringement referred to in Article 1 of the Decision, and to refrain from any agreements or concerted practices in relation to their activities in nucleotides that may have the same or similar object or effect as the infringement, particularly in terms of pricing and market behaviour.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
NA

### Book Reference
COMP/C

### Outcome
NA


*(reported: 2026-11-11 12:19:58)*

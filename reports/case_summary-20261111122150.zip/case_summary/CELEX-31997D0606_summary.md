# '97/606/EC', 'exclusive right to broadcast television advertising in Flanders'

**CELEX ID:** CELEX-31997D0606  
**Industry:** | industry                |
|:------------------------|
| television broadcasting |
| publishing              |
| media                   |
| cable distribution      |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
97/606/EC

### Case Title
97/606/EC – exclusive right to broadcast television advertising in Flanders

### Overview
The European Commission initiated proceedings against the Kingdom of Belgium for failure to meet obligations under Article 52 of the EC Treaty, specifically regarding the exclusive broadcasting rights granted to VTM by the Flemish executive. The case involved a dispute over the authorization of VTM as the sole private broadcaster in Flanders, which was found to be incompatible with EU law.

### Industry
television broadcasting, publishing, media, cable distribution

### Oecd Nace
OECD: communication; NACE: 60.20 Television programming and broadcasting activities

### Companies Undertakings
| company                                 |
|:----------------------------------------|
| Vlaamse Televisie Maatschappij NV       |
| Vlaamse Media Holding                   |
| De Persgroep NV                         |
| Roularta Media Group NV                 |
| Tijdschriften Uitgevers Maatschappij NV |
| Tijdschriften Vereniging Vlaanderen NV  |
| Perexma NV                              |
| Vlaamse Uitgevers Maatschappij NV       |
| Concentra Holding NV                    |
| VT4 Ltd                                 |
| Scandinavian Broadcasting System SA     |
| Belgian authorities                     |
| Flemish community                       |
| BRTN                                    |
| Verenigde Nederlandse Uitgeverijen      |

### Market
Belgium, not an oligopoly, no turbulence

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-11-19 | Flemish executive | recognized VTM as sole private television company broadcasting to Flemish community |
| 1987-12-03 | Flemish executive | authorized VTM to broadcast |
| 1987-12-03 | Royal Order | authorized VTM to include commercial advertising in its programmes |
| 1987-12-03 | Royal Government | granted authorization to broadcast advertising |
| 1987-12-11 | Flemish executive | confirmed authorization of VTM as sole private broadcaster |
| 1991-08-08 | Commission | initiated proceedings against Kingdom of Belgium for failure to meet obligations under Article 52 of the EC Treaty |
| 1995-02-01 | VT4 | began broadcasting television programmes |
| 1995-07-13 | Commission | requested details from Belgian Government |
| 1995-09-14 | Belgian Government | responded to Commission's request |
| 1995-09-14 | Belgian Government | issued letter stating rules on executive right |
| 1995-09-14 | redacted | Belgian authorities pointed out broadcasting of advertising aimed at Flemish public in letter dated 14 September 1995 |
| 1995-10-17 | UK authorities | informed Commission of jurisdiction over VT4 |
| 1997-01-10 | Commission | sent letter to Flemish Government |
| 1997-02-11 | Flemish Government | replied to Commission's letter |
| 1997-06-05 | Court of Justice | ruled on jurisdiction of VT4 under Directive 89/552/EEC |
| 1997-06-26 | European Commission | declared Belgian laws incompatible with EC Treaty

### Legal Framework
Article 90 (operative), Article 90 (all relevant); infringement concept: public_undertaking

### Infringement Category
member states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Belgian authorities shall bring to an end the infringement referred to in Article 1, and shall inform the Commission within two months of notification of this Decision of the measures they have taken to comply therewith.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court               | country   | jurisdiction   |
|:--------------------|:----------|:---------------|
| Court of Justice    | Belgium   | European Union |
| Belgian authorities | Belgium   | Federal        |
| VRT                 | Belgium   | Flemish        |

### Book Reference
NA

### Outcome
The European Commission declared Belgian laws incompatible with the EC Treaty, specifically Article 90, due to the exclusive broadcasting rights granted to VTM by the Flemish executive.


*(reported: 2026-11-10 19:28:30)*

# 'IV/29.011', 'Rennet'

**CELEX ID:** CELEX-31980D0234  
**Industry:** dairy industry  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0234 | IV/29011  |

### Case Title
Rennet

### Overview
This case concerns a cartel in the Dutch dairy industry involving the production and distribution of rennet and colouring agents. The infringement was found to be in breach of Article 85 of the EC Treaty, specifically under vertical restraints involving Exclusive Dealing / Market Foreclosure.

### Industry
dairy industry

### Oecd Nace
OECD & NACE classifications:
- OECD sector: manufacturing
- NACE group code: 10.5: Manufacture of dairy products
- NACE class code: 10.51: Operation of dairies and cheese making

### Companies Undertakings
| companies                                                                           |
|:------------------------------------------------------------------------------------|
| Coöperatieve Stremsel- en Kleurselfabriek                                           |
| Coöperatieve Zuivelfabriek en Melkinrichting 'Linge'                                |
| Asser Coöperatieve Melkinr. en Melkprod. fabriek 'Acmesa'                           |
| Coöperatieve Ver. tot Expl. van Zuivel. en Melkprod. fabrieken De Combinatie       |
| Coöperatieve Melkproduktenbedrijven 'Domo-(Bedum)'                                  |
| Coöperatieve Fabriek van Melkprodukten De Stichting'                                |
| Coöperatieve Zuivelfabriek 'Noord-Oostergo'                                         |
| Coöperatieve Zuivelfabriek 'Het Klaverblad'                                         |
| Coöperatieve Zuivelfabriek 'Ee en Omstreken'                                        |
| Coöperatieve Zuivelvereniging 'Campina'                                             |
| Coöperatieve Zuivelfabriek 'Ezinge'                                                 |
| Melkunie Gelderen B.V. v/h Coöperatieve Melkverw. ver. Land van Heusden en Altena'  |
| Coöperatieve Zuivelindustrie Twee Provincien'                                       |
| Coöperatieve Zuivelfabriek 'Trynwalden en Omstreken'                                |
| Coöperatieve Zuivelfabriek 'Samenwerking'                                           |
| Coöperatieve Zuivelfabriek De Goede Verwachting'                                    |
| Melkunie v/h Coöperatieve Melkcentrale le v.d. Kunstraat 116, 's-Gravenhage'        |
| Coöperatieve Zuivelfabriek De Eensgezindheid'                                       |
| Vecolac  v/h Coöperatieve Zuivelfabriek Juliana'                                    |
| Coöperatieve Zuivelfabriek Havelte'                                                 |
| Coöperatieve Zuivelfabriek 'Heerde'                                                 |
| Coöperatieve Zuivelindustrie 'De Toekomst'                                          |
| Coöperatieve Zuivelfabriek 'Ameland'                                                |
| Coöperatieve Melkverwerkingsvereniging DOC'                                         |
| Coöperatieve Zuivelfabriek Koekange'                                                |
| Friesche Coöperatieve Zuivel-Export Vereeniging'                                    |
| Zuivelfabriek De Vereeniging'                                                       |
| Coöperatieve Zuivelfabriek De Eendracht'                                            |
| Coöperatieve Zuivelfabriek Zuidelijk Westerkwartier'                                |
| Coöperatieve Zuivelfabriek De Venen'                                                |
| Coöperatieve Zuivelfabriek 'Norg'                                                   |
| Coöperatieve Zuivelfabriek De Goede Verwachting'                                    |
| Coöperatieve Zuivelfabriek en Melkinrichting 'Oldewe'                               |
| Coöperatieve Zuivelindustrie 'De Zuid-Oosthoek'                                     |
| Coöperatieve Zuivelfabriek 'De Eendracht'                                           |
| Coöperatieve Ver. tot Expl. van Melkprod. fabrieken Noord-Holland'                  |
| Coöperatieve Zuivelfabriek Huisternoord'                                            |
| Coöperatieve Melkproduktenfabriek 'Hovo'                                            |
| Coöperatieve Zuivelfabriek De Toekomst'                                             |
| Coöperatieve Fabriek van Melkprodukten Roden-Zevenhuizen'                           |
| Zuivelfabriek Campina v/h Coöperatieve Centrale Zuivelvereniging De Maasvallei'     |
| Zuivelfabriek Campina v/h Coöperatieve Zuivelbedrijven Brabant-Zeeland'             |
| Coöperatieve Zuivelfabriek De Vlijt'                                                |
| Coöperatieve Zuivelfabriek De Eendracht'                                            |
| Coöperatieve Zuivelfabriek De Kleine Winst'                                         |
| Coöperatieve Zuivelfabriek Algemeen Belang'                                         |
| Coöperatieve Zuivelfabriek Ons Belang'                                              |
| Coöperatieve Zuivelfabriek 'De Toekomst'                                            |
| Coöperatieve Biol. Zuivelveren 'Skylge' v/h Coöperatieve Zuivelfabriek Terscheling' |
| Zuiveifabriek Campina v/h Coöperatieve Zuivelvereniging Centraal Brabant'           |
| Coöperatieve Zuivelfabriek De Eendracht'                                            |
| Coöperatieve Vereniging v/h Coöperatieve Zuivelindustrie Novac'                     |
| Coöperatieve Zuivelindustrie De Foarutgong'                                         |
| Coöperatieve Fabr. Melk- en Zuivelpr. Vecolac-Vollenhove'                           |
| Vordense Coöperatieve Zuivelfabriek'                                                |
| Coöperatieve Zuivelfabriek 'Wapserveen'                                             |
| Coöperatieve Zuivelfabriek 'Westerbork'                                             |
| Ver. Coöperatieve Zuivelfabriek Combinatie O. Groningen'                            |
| Coöperatieve Zuivelindustrie De Goede Verwachting'                                  |
| Coöperatieve Fabriek van Melkprodukten 'Rogat'                                      |
| Coöperatieve Melkverwerkingsver. DOC v/h Coöperatieve Zuivelfabriek Eendracht'      |
| Verenigde Coöperatieve Melkindustrie Coberco'

### Market
Relevant market:
- Geography: Netherlands, Germany, France, Denmark, United Kingdom, Belgium
- Structure: Oligopoly
- Turbulence: NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1905-04-07 | undertakings | established cooperative for producing rennet and colouring agents |
| 1905-04-07 | Coöperatieve Stremsel- en Kleurselfabriek | established cooperative for manufacturing rennet |
| 1905-04-07 | Cooperative | entered into agreement establishing rules for cooperative members |
| 1970-01-07 | Minister for Agriculture | issued order prohibiting use of synthetic rennet |
| 1975-03-05 | Coöperatieve Stremselen Kleurselfabriek | notified rules to the Commission |
| 1978-02-14 | Commission | initiated proceedings in the case |
| 1979-04-03 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on restrictive practices |
| 1979-07-17 | Cooperative | sent revised rules to the Commission |
| 1979-12-05 | Commission | issued decision in the case

### Legal Framework
Legal framework applying to the case:
- Operative articles: Article 85
- Canonical concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Exemption sought or granted:
- Exemption case: True
- Applicants: Coöperatieve Zuivelfabriek en Melkinrichting 'Linge', Asser Coöperatieve Melkinr. en Melkprod. fabriek 'Acmesa', Coöperatieve Ver. tot Expl. van Zuivel. en Melkprod. fabrieken De Combinatie, Coöperatieve Melkproduktenbedrijven 'Domo-(Bedum)', Coöperatieve Fabriek van Melkprodukten De Stichting, Coöperatieve Zuivelfabriek 'Noord-Oostergo', Coöperatieve Zuivelfabriek 'Het Klaverblad', Coöperatieve Zuivelfabriek 'Ee en Omstreken', Coöperatieve Zuivelvereniging 'Campina', Coöperatieve Zuivelfabriek 'Ezinge', Melkunie Gelderen B.V. v/h Coöperatieve Melkverw. ver. Land van Heusden en Altena, Coöperatieve Zuivelindustrie Twee Provincien, Coöperatieve Zuivelfabriek 'Trynwalden en Omstreken', Coöperatieve Zuivelfabriek 'Samenwerking', Coöperatieve Zuivelfabriek De Goede Verwachting, Melkunie v/h Coöperatieve Melkcentrale le v.d. Kunstraat 116, 's-Gravenhage, Coöperatieve Zuivelfabriek De Eensgezindheid, Vecolac  v/h Coöperatieve Zuivelfabriek Juliana, Coöperatieve Zuivelfabriek Havelte', Coöperatieve Zuivelfabriek 'Heerde', Coöperatieve Zuivelindustrie 'De Toekomst', Coöperatieve Zuivelfabriek 'Ameland', Coöperatieve Melkverwerkingsvereniging DOC, Coöperatieve Zuivelfabriek Koekange', Friesche Coöperatieve Zuivel-Export Vereeniging, Zuivelfabriek De Vereeniging', Coöperatieve Zuivelfabriek De Eendracht', Coöperatieve Zuivelfabriek Zuidelijk Westerkwartier', Coöperatieve Zuivelfabriek De Venen', Coöperatieve Zuivelfabriek 'Norg', Coöperatieve Zuivelfabriek De Goede Verwachting', Coöperatieve Zuivelfabriek en Melkinrichting 'Oldewe', Coöperatieve Zuivelindustrie 'De Zuid-Oosthoek', Coöperatieve Zuivelfabriek 'De Eendracht', Coöperatieve Ver. tot Expl. van Melkprod. fabrieken Noord-Holland', Coöperatieve Zuivelfabriek Huisternoord', Coöperatieve Melkproduktenfabriek 'Hovo', Coöperatieve Zuivelfabriek De Toekomst', Coöperatieve Fabriek van Melkprodukten Roden-Zevenhuizen', Zuivelfabriek Campina v/h Coöperatieve Centrale Zuivelvereniging De Maasvallei, Zuivelfabriek Campina v/h Coöperatieve Zuivelbedrijven Brabant-Zeeland, Coöperatieve Zuivelfabriek De Vlijt', Coöperatieve Zuivelfabriek De Eendracht', Coöperatieve Zuivelfabriek De Kleine Winst', Coöperatieve Zuivelfabriek Algemeen Belang', Coöperatieve Zuivelfabriek Ons Belang', Coöperatieve Zuivelfabriek 'De Toekomst', Coöperatieve Biol. Zuivelveren 'Skylge' v/h Coöperatieve Zuivelfabriek Terscheling, Zuiveifabriek Campina v/h Coöperatieve Zuivelvereniging Centraal Brabant, Coöperatieve Zuivelfabriek De Eendracht', Coöperatieve Vereniging v/h Coöperatieve Zuivelindustrie Novac', Coöperatieve Zuivelindustrie De Foarutgong, Coöperatieve Fabr. Melk- en Zuivelpr. Vecolac-Vollenhove', Vordense Coöperatieve Zuivelfabriek, Coöperatieve Zuivelfabriek 'Wapserveen', Coöperatieve Zuivelfabriek 'Westerbork', Ver. Coöperatieve Zuivelfabriek Combinatie O. Groningen', Coöperatieve Zuivelindustrie De Goede Verwachting', Coöperatieve Fabriek van Melkprodukten 'Rogat'

### Leniency
Leniency:
- Leniency case: False
- Applicants: NA
- Reductions granted: NA
- Applications rejected: NA

### Fines
NA

### Remedies
The Commission ordered the undertakings concerned, including the Coöperatieve Stremsel- en Kleurselfabriek and its member undertakings, to bring the infringement referred to in Article 1 to an end without delay, as required under Article 3 of Council Regulation No 17.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision in the case, ordering the undertakings to end the infringement without delay.


*(reported: 2026-11-11 10:30:54)*

# 'IV/28.948', 'Cauliflowers'

**CELEX ID:** CELEX-31978D0066  
**Industry:** vegetable production and trade  
**Cartel Period:** 1961 : 1975  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0066 | IV/28948  |

### Case Title
Cauliflowers

### Overview
The European Commission investigated anticompetitive agreements among several French agricultural cooperatives and shipping organizations involved in the trade of cauliflowers, artichokes, and early potatoes. The practices included exclusive buying obligations, packing centre requirements, and admission rules that restricted competition.

### Industry
vegetable production and trade

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.1: Growing of non-perennial crops
NACE class code: 01.13: Growing of vegetables and melons, roots and tubers

### Companies Undertakings
| companies                                                                                                                      | location               |
|:-------------------------------------------------------------------------------------------------------------------------------|:-----------------------|
| Société d'Investissements et de Coopération Agricoles                                                                          | Saint-Pol-de-Leon      |
| Union des Expéditeurs et Exportateurs en Fruits et Legumes du Finistère                                                        | Saint-Pol-de-Leon      |
| Société Interprofessionnelle des Producteurs et Expéditeurs de Fruits, Légumes, Bulbes et Fleurs d'lle et Vilaine SICA-SIPEFEL | Saint-Méloir-des-Ondes |
| Syndicat des Expéditeurs et Exportateurs en Légumes et Pommes de terre primeurs de la région Malouine                          | Saint-Méloir-des-Ondes |

### Market
France, Germany, United Kingdom, Belgium, Netherlands, Luxembourg
Market outside EU: true
Market oligopoly: NA
Market turbulence: NA

### Cartel Period
1961 : 1975

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1961-03-31 | about 3 000 farmers | formed an agricultural cooperative called SICA-Marché de Vente aux Enchères du Nord-Finistère |
| 1961-11-22 | SICA de Saint-Pol-de-Léon and the Union des Expéditeurs | signed agreement establishing auction admission requirements |
| 1961-11-22 | SICA de Saint-Pol-de-Léon and the Union des Expéditeurs et Exportateurs en Fruits et Legumes du Finistere | signed an agreement requiring shippers to obtain supplies only from the auction sales held by the SICA |
| 1961-11-22 | SICA de Saint-Pol-de-Léon and the Union des Expéditeurs | imposed exclusive purchasing obligation on dealers |
| 1962-04-04 | redacted | Council Regulation No 26 adopted |
| 1962-08-08 | redacted | French Law No 62-933 enacted, enabling producer organizations to extend rules to production and marketing |
| 1972-05-18 | Council of the European Economic Community | adopted Council Regulation (EEC) No 1035/72 on common organization of market in fruit and vegetables |
| 1973-11-05 | Syndicat des Expéditeurs de Saint-Malo | adopted statutes requiring packing facilities and staff for auction admission |
| 1973-11-05 | Syndicat des Expéditeurs de Saint-Malo | adopted original clause requiring two-thirds approval for new member admission |
| 1974-10-24 | SICA de Saint-Pol-de-Léon | imposed more stringent terms of payment on GREX |
| 1975-09-03 | Commission | informed SICA de Saint-Pol-de-Léon of discriminatory terms and proposed infringement finding |
| 1977-12-02 | Commission | issued decision addressing infringements under Article 85(1) of the EEC Treaty

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Exemption sought: True
Exemption applicants: NA

### Leniency
Leniency case: False
Leniency applicants: NA
Leniency granted: NA
Leniency rejected: NA

### Fines
NA

### Remedies
The Commission ordered SICA de Saint-Pol-de-Léon, the Union des Expéditeurs, SIPEFEL and the Syndicat des Expéditeurs de Saint-Malo to forthwith bring to an end the infringements referred to in Article 1, which includes ceasing the restrictive practices such as exclusive buying obligations, packing centre requirements, and admission rules that limit competition.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-11-11 10:19:43)*

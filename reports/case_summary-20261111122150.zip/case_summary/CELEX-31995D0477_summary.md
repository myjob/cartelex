# 'IV/33.802', 'BASF Lacke $^ +$ Farben AG, and Accinauto SA'

**CELEX ID:** CELEX-31995D0477  
**Industry:** | industry                         |
|:---------------------------------|
| Motor vehicle refinishing paints |
| Chemicals                        |  
**Cartel Period:** 1981 : 1991-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31995D0477 | IV/33802  |

### Case Title
IV/33.802 – BASF Lacke + Farben AG, and Accinauto SA

### Overview
This case involved a vertical anticompetitive agreement between BASF Lacke + Farben AG (Germany) and Accinauto SA (Switzerland) concerning the distribution of motor vehicle refinishing paints. The agreement included territorial exclusivity clauses that restricted parallel trade, violating Article 85 of the EC Treaty.

### Industry
Motor vehicle refinishing paints, Chemicals

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.3: Manufacture of paints, varnishes and similar coatings, printing ink and mastics
NACE class code: 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
| company                | country   |
|:-----------------------|:----------|
| BASF Lacke + Farben AG | DE        |
| Accinauto SA           | CH        |

### Market
United Kingdom, outside EU

### Cartel Period
1981 : 1991-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-01-01 | parties | entered into exclusive distribution agreement with retroactive effect |
| 1991-01-28 | IMF and Calbrook | lodged complaint against BASF L+F and Accinauto |
| 1991-06-26 | Commission | carried out investigations at business premises of BASF L+F, BASF C&I, Accinauto and Technipaint |
| 1991-12-31 | BASF L+F and Accinauto | ended infringement period |
| 1992-01-01 | BASF L+F and Accinauto | ended infringement by concluding new distribution agreement |
| 1993-01-22 | BASF L+F and Accinauto | signed new distribution agreement again |
| 1993-05-12 | Commission | sent statements of objections to BASF L+F and Accinauto |
| 1993-05-19 | Commission | sent statement of objections with evidence |
| 1993-06-03 | Commission | transmitted documents in the form of copies to BASF L+F |
| 1993-09-23 | Commission | held hearing in the case |
| 1995-07-12 | Commission | issued Commission Decision |
| 1995-07-12 | Karel VAN MIERT | issued decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| BASF Lacke + Farben AG | ECU 2 700 000 |
| Accinauto SA | ECU 10 000 |

### Remedies
BASF Lacke + Farben AG and Accinauto SA were ordered to end the infringement by concluding a new distribution agreement effective retroactively as of 1 January 1992, which no longer contained the clause requiring Accinauto to pass on customer inquiries from outside the contract territory to BASF Lacke + Farben AG.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
True

### Book Reference
NA

### Outcome
The European Commission found that the exclusive distribution agreements between BASF Lacke + Farben AG and Accinauto SA constituted an anticompetitive agreement under Article 85 of the EC Treaty. Fines were imposed on both companies, and they were ordered to terminate the infringement by concluding a new distribution agreement without territorial exclusivity clauses.


*(reported: 2026-11-11 11:52:18)*

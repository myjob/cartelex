# 'IV/31.204', 'MELDOC'

**CELEX ID:** CELEX-31986D0596  
**Industry:** dairy industry  
**Cartel Period:** 1974 : 1985  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31986D0596 | IV/31204  |

### Case Title
MELDOC

### Overview
This case involves a cartel in the Dutch dairy industry, where companies engaged in horizontal restraints such as market sharing, quota cartels, and specialization agreements. The cartel operated from 1974 to 1985, with significant cooperation among major dairy producers in the Netherlands.

### Industry
dairy industry

### Oecd Nace
agriculture
NACE group code: 10.5: Manufacture of dairy products
NACE class code: 10.51: Operation of dairies and cheese making

### Companies Undertakings
| company                                            | country   |
|:---------------------------------------------------|:----------|
| Melkunie Holland Bv                                | NL        |
| Coöperatieve Melkproduktenbedrijven DOMO-Bedum' GA | NL        |
| Verenigde Coöperatieve Melkindustrie 'Coberco'     | NL        |
| DMV 'Campina' BV                                   | NL        |
| Menken-Landbouw BV                                 | NL        |

### Market
Netherlands
Market volatility due to take-overs, mergers, concentration in retail businesses; economic instability from restructuring, high market concentration, influence of imports from Belgium, pressure on prices and shares by foreign competition, regulatory uncertainties, and forced cooperation among companies like Campina and ML

### Cartel Period
1974 : 1985

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1974-09-24 | MU, DOMO and Coberco | formed the lesser Meldoc cartel |
| 1977-12-25 | Meldoc partners | initiated cooperation forming a cartel |
| 1978-12-19 | Meldoc's Policy Group | adopted Dairy Industry Basic Cooperation Agreement |
| 1980-05-02 | Meldoc members | expressed interest in forcing back Belgians' share of Netherlands market |
| 1980-06-06 | Liquid Milk Steering Committee | decided to attempt freezing Belgian sales in Netherlands and capture growth |
| 1983-05-24 | Meldoc partners | discussed proposed price quotations in detail |
| 1983-06-03 | Meldoc | continued discussions on preventing German milk imports |
| 1983-07-29 | Dutch authorities | took specific measures to stem tide of fresh milk imports |
| 1983-10-18 | MU | began campaign of dumping long-life milk in Belgium |
| 1983-10-24 | Meldoc partners | documented results of Meldoc's policy protecting sales volume |
| 1985-09-25 | Commission | initiated proceedings in this case |
| 1986-11-26 | Commission | issued Commission Decision |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Verenigde Coöperatieve Melkindustrie 'Coberco' | 1 360 000 ECU |
| DMV 'Campina' BV | 1 020 000 ECU |
| Menken-Landbouw BV | 425000 ECU |
| Melkunie Holland BV | 3150 000 ECU |
| Coöperatieve Melkproduktie Bedrijven DOMO-Bedum | 600 000 ECU |

### Remedies
The companies shall refrain from the behaviour described in Article 1.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Melkunie Holland BV | True |
| Coöperatieve Melkproduktenbedrijven DOMO-Bedum | True |
| Verenigde Coöperatieve Melkindustrie 'Coberco' | True |
| DMV 'Campina' BV | True |
| Menken-Landbouw BV | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                     | country     | jurisdiction   |
|:--------------------------|:------------|:---------------|
| European Court of Justice | Netherlands | European Union |

### Book Reference
NA

### Outcome
The European Commission found the companies guilty of participating in an anticompetitive cartel and imposed significant fines. The case was landmark in demonstrating the EU's enforcement against horizontal cartels in the dairy industry.


*(reported: 2026-11-11 11:03:50)*

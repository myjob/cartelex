# 'NA', 'NA'

**CELEX ID:** CELEX-31999D0473  
**Industry:** NA  
**Cartel Period:** 1989-01-01 : 1997-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0473 | IV/36081  |

### Case Title
NA

### Overview
The European Commission investigated a cartel case involving companies in the UK, primarily related to vertical restraints in the beer industry. The case involved an exemption request by Bass plc, which was granted for a limited period from 1996-06-11 to 2002-12-31.

### Industry
trade (wholesaling and retailing) and hotels

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 06.2: Extraction of natural gas
NACE class code: 06.20: Extraction of natural gas

### Companies Undertakings
| company                    |
|:---------------------------|
| Bass plc                   |
| Bass Holdings Limited      |
| Bass Lease Company Limited |
| Beechley Limited           |
| Avebury Limited            |
| Punch Taverns Limited      |
| BT Capital Partners Europe |

### Market
Relevant market: UK, with market outside EU (True), oligopoly structure (True)

### Cartel Period
1996-06-11 : 2002-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission of the European Communities | adopted First Regulation implementing Articles 85 and 86 of the Treaty |
| 1963-07-25 | redacted | issued Commission Regulation No 996/63 |
| 1983-06-22 | Commission | adopted regulation on application of Article 85(3) of the Treaty to categories of exclusive purchasing agreements |
| 1991-03-01 | Commission | exemption applies from this date |
| 1991-03-01 | Commission | Decision began to apply |
| 1995-05-16 | OFT | issued press release on brewers' wholesale pricing policy report |
| 1996-06-11 | Bass plc | submitted application for negative clearance and notification for exemption |
| 1996-06-11 | Bass Holdings Limited and the Bass Lease Company Limited | notified standard form of lease under Regulation No 17 |
| 1997-09-08 | Bass Holdings Limited and the Bass Lease Company Limited | notified standard lease agreements for Scotland |
| 1997-09-30 | Bass | reported annual turnover of GBP 5,254 million |
| 1997-12-25 | Bass | introduced 36 beer brands including Orkney Raven and Caledonian Christmas |
| 1999-06-16 | Commission | Decision was made |
| 2002-12-31 | Commission | exemption period ends on this date |
| 2002-12-31 | Commission | Decision ceased to apply |

### Legal Framework
Legal framework: Article 81 (operative), with references to Articles 85 and 86. Canonical concept: anticompetitive_agreement.

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought and granted by Bass plc for a limited period from 1996-06-11 to 2002-12-31.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                                  | country        | jurisdiction              |
|:---------------------------------------|:---------------|:--------------------------|
| Court of Justice of the European Union | European Union | European Court of Justice |

### Book Reference
NA

### Outcome
The Commission granted an exemption to Bass plc for a limited period, allowing certain vertical restraints in the beer industry. The decision was made on 1999-06-16 and ceased to apply on 2002-12-31.


*(reported: 2026-10-16 22:17:49)*

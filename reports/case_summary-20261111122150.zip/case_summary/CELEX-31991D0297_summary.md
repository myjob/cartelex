# 'IV/33.133-A', 'Soda-ash — Solvay, ICI'

**CELEX ID:** CELEX-31991D0297  
**Industry:** | industry            |
|:--------------------|
| Glass manufacturing |
| Chemical industry   |
| Metallurgy          |  
**Cartel Period:** 1973-01-01 : 1973-07-26  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31991D0297 | IV/33133-1 |

### Case Title
IV/33.133-A – Soda-ash — Solvay, ICI

### Overview
This case involves Solvay et Cie and Imperial Chemical Industries plc (ICI) for participation in a concerted practice that restricted competition in the soda-ash market from 1973 to 1973. The infringement was found to be in violation of Article 85 of the Treaty of Rome, and both companies were fined ECU 7 million each.

### Industry
Glass manufacturing, Chemical industry, Metallurgy

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.14: Manufacture of other organic basic chemicals

### Companies Undertakings
| companies                        | location   |
|:---------------------------------|:-----------|
| Solvay et Cie                    | Brussels   |
| Imperial Chemical Industries plc | London     |

### Market
The relevant market includes Belgium, France, Germany, Italy, Portugal, Spain, Austria, United Kingdom, and Ireland. The market is outside the EU and is characterized as an oligopoly.

### Cartel Period
1973-01-01 : 1973-07-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-10-12 | Solvay | sent letter terminating agreement stating it had long been considered outdated |
| 1972-10-26 | ICI | resolved to cancel 1949 minute confirming Page 1000° agreement |
| 1972-12-31 | redacted | agreement terminated with effect from this date |
| 1973-01-01 | Solvay and ICI | commenced infringement by participating in concerted practice |
| 1973-01-01 | Solvay and ICI | continued observing and applying terms of restrictive market-sharing agreement |
| 1973-07-26 | ICI | sent letters of termination after legal advice that agreements contravened Article 85 of the Treaty of Rome |
| 1990-02-19 | Commission | opened a proceeding under Article 3 of Regulation No 17 |
| 1990-12-19 | Commission | issued Decision relating to infringement by Solvay and ICI |
| 1990-12-19 | Solvay et Cie | imposed fines on undertakings |

### Legal Framework
Legal framework applying to the case includes:
- Operative article: Article 85
- All relevant articles: Article 85, Article 86
- Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought by Ansac.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Solvay et Cie | ECU 7 million |
| Imperial Chemical Industries plc | ECU 7 million |

### Remedies
Solvay and ICI shall forthwith bring the infringement to an end and shall in the future refrain from any agreement or concerted practice which may have the same or equivalent object or effect.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Solvay et Cie | True |
| Imperial Chemical Industries plc | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | European Union |
| European Court of Justice | Belgium        | European Union |

### Book Reference
NA

### Outcome
The Commission found that Solvay and ICI engaged in an infringement under Article 85 of the Treaty of Rome. Both companies were fined ECU 7 million each, and were ordered to cease any future agreements or concerted practices with similar effects.


*(reported: 2026-11-11 11:27:23)*

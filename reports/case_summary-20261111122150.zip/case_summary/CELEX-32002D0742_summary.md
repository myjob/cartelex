# 'COMP/E-1/36 604', 'Citric acid'

**CELEX ID:** CELEX-32002D0742  
**Industry:** NA  
**Cartel Period:** 1991-03-06 : 1995-05-22  

## Summary

### Celex Case Id
CELEX-32002D0742

### Case Title
Citric acid

### Overview
This case involves a horizontal cartel in the citric acid market, operating from 1991 to 1995. The cartel included major players such as Archer Daniels Midland Company Inc., Cerestar Bioproducts BV, F. Hoffmann-La Roche AG, Haarmann & Reimer Corporation, and Jungbunzlauer AG. The infringement was classified as very serious under Article 81 of the EC Treaty. Leniency applications were made by several companies, with varying degrees of reduction granted. Fines were imposed ranging from EUR 170,000 to EUR 63.5 million. Remedies ordered included immediate cessation of the infringement.

### Industry
manufacturing (citric acid, xantham gum, citrates, gluconates, glucose, syrups, sweeteners, lactic acids, ethanol, vegetable oils, salad oils, margarine, industrial chemicals, pulp, wheat flour, durum flour)

### Oecd Nace
manufacturing (OECD sector: manufacturing; NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; NACE class code: 20.14: Manufacture of other organic basic chemicals)

### Companies Undertakings
| Archer Daniels Midland Company Inc. (US) |
| Cerestar Bioproducts BV (NL) |
| F. Hoffmann-La Roche AG (CH) |
| Haarmann & Reimer Corporation (US) |
| Jungbunzlauer AG (CH) |

### Market
Austria, Finland, Iceland, Liechtenstein, Norway, Sweden (outside EU); oligopoly; increasing competition from Chinese imports, price fluctuations, internal cartel tensions, currency fluctuations (DEM vs USD), inconsistent interpretations of market impact

### Cartel Period
1991-03-06 : 1995-05-22

### Key Timeline
| 1991-03-06 | Hoffmann-La Roche led the first meeting of the cartel |
| 1991-03-06 | ADM participated in the cartel meeting, claimed follow-my-leader role |
| 1991-03-06 | Haarmann & Reimer, ADM, Jungbunzlauer, Hoffmann-La Roche agreed on basic principles for cartelisation of the market |
| 1991-03-06 | ADM formulated citric acid cartel arrangement |
| 1994-01-01 | Cartel members held meeting reviewing citric acid market situation |
| 1994-11-16 | ADM assigned bidding prices for orders in individual countries |
| 1995-05-22 | Jungbunzlauer was told agreement was at an end due to damage caused |
| 1998-10-29 | Cerestar Bioproducts requested meeting with Commission to cooperate under Leniency Notice and provided oral description of cartel activity |
| 1998-12-11 | ADM met with Commission to express willingness to cooperate under Leniency Notice and provided oral account of anti-competitive activity |
| 1999-04-23 | Jungbunzlauer filed application under leniency notice |
| 1999-04-28 | Bayer plc filed application under leniency notice on behalf of Haarmann & Reimer |
| 2001-12-05 | Commission issued Commission Decision |

### Legal Framework
Article 81 (anticompetitive agreement)

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
very serious

### Exemption
False

### Leniency
| Haarmann & Reimer Corporation |
| ADM |
| Cerestar Bioproducts BV |
| Jungbunzlauer AG |

| Cerestar Bioproducts BV | 90% |
| F. Hoffmann-La Roche AG | 20% |
| Haarmann & Reimer Corporation | 30% |
| Jungbunzlauer AG | 40% |

ADM - rejected

### Fines
| Archer Daniels Midland Company Inc. | EUR 39,69 million |
| Cerestar Bioproducts BV | EUR 170 000 |
| F. Hoffmann-La Roche AG | EUR 63,5 million |
| Haarmann & Reimer Corporation | EUR 14,22 million |
| Jungbunzlauer AG | EUR 17,64 million |

### Remedies
The Commission ordered the undertakings named in Article 1 to immediately bring the infringement to an end, and to refrain from any act or conduct which, in object or effect, is the same as the infringement or equivalent thereto.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| United States Federal Court (United States) |
| United States District Court (United States) |
| Commission (European Community) |

### Book Reference
COMP/E

### Outcome
Commission Decision issued on 2001-12-05 with fines imposed and remedies ordered to end the infringement


*(reported: 2026-11-11 12:12:25)*

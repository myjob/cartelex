# 'IV/30.261', "Ideal-Standard's distribution system"

**CELEX ID:** CELEX-31985D0045  
**Industry:** plumbing and sanitary ware  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0045 | IV/30261  |

### Case Title
IV/30261 – Ideal-Standard's distribution system

### Overview
This case involves the European Commission's decision regarding an anticompetitive agreement between Ideal-Standard GmbH and several German trade associations in the plumbing and sanitary ware industry. The agreement was found to infringe Article 85 of the EEC Treaty, specifically through vertical restraints such as selective distribution and exclusive dealing.

### Industry
plumbing and sanitary ware

### Oecd Nace
OECD sector: manufacturing
NACE group code: 46.7: Other specialised wholesale
NACE class code: 46.74: Wholesale of hardware, plumbing and heating equipment and supplies

### Companies Undertakings
| companies                                         | location                          |
|:--------------------------------------------------|:----------------------------------|
| Ideal-Standard GmbH                               | Bonn, Federal Republic of Germany |
| Hansa Metallwerke AG                              | NA                                |
| Bundesverband des SanitarFachhandels eV           | Bonn                              |
| Zentralverband Sanitar, Heizung, Klima            | St. Augustin                      |
| Bundesverband der Selbstbedienungs-Warenhäuser eV | Bonn                              |

### Market
The relevant market includes the Federal Republic of Germany, France, Italy, United Kingdom, Netherlands, and Belgium. The market is influenced by external factors such as a general decline in activity in the building industry and fiercer competition.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-01-06 | Ideal-Standard GmbH | notified dealership agreement |
| 1981-06-12 | Bdsw | complained to Commission about introduction of dealership agreement |
| 1983-07-06 | Commission | decided to open proceedings in the case |
| 1983-07-19 | Commission | sent email attaching Statement of Objections questioning compatibility with Article 85 (1) of the Treaty |
| 1983-10-25 | Court of Justice | delivered judgment in case 107/82 AEG-Telefunken |
| 1984-11-22 | Ideal | informed Commission of intention to amend dealership agreement |
| 1984-12-10 | Commission | issued decision refusing exemption |
| 1984-12-10 | Commission | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty

### Legal Framework
Legal framework applying to the case: the operative article is Article 85 and the canonical concept is anticompetitive_agreement.

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution; Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Exemption was sought by Ideal-Standard GmbH but refused by the Commission.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders are explicitly listed in the document beyond declaring the agreement as infringing and refusing an exemption.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court            | country                     | jurisdiction   |
|:-----------------|:----------------------------|:---------------|
| Court of Justice | European Union              | EU             |
| Commission       | Federal Republic of Germany | EU             |

### Book Reference
NA

### Outcome
The European Commission found the agreement to be anticompetitive under Article 85 of the EEC Treaty and refused to grant an exemption. The case was decided in December 1984.


*(reported: 2026-11-11 10:53:43)*

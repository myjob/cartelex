# 'IV/30.129', 'Carlsberg'

**CELEX ID:** CELEX-31984D0381  
**Industry:** brewing  
**Cartel Period:** 1970-05-01 : 1991-09-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31984D0381 | IV/30129  |

### Case Title
Carlsberg

### Overview
This case involves the European Commission's investigation into anticompetitive agreements among major brewing companies in the United Kingdom and Denmark, specifically focusing on restrictive practices related to the sale of Carlsberg beers. The Commission found that certain provisions of agreements violated Article 85 of the EC Treaty, which prohibits agreements that may affect trade between Member States and have as their object or effect the prevention, restriction or distortion of competition within the common market.

### Industry
brewing

### Oecd Nace
manufacturing
NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.04: Manufacture of other non-distilled fermented beverages

### Companies Undertakings
| companies                                                 |
|:----------------------------------------------------------|
| De forenede Bryggerier A/S (The United Breweries Limited) |
| Grand Metropolitan Ltd                                    |
| Carlsberg Brewery Limited                                 |
| Grand Metropolitan plc                                    |
| Carlsberg                                                 |

| companies_investigated                                    | country   |
|:----------------------------------------------------------|:----------|
| De forenede Bryggerier A/S (The United Breweries Limited) | DK        |
| Grand Metropolitan Ltd                                    | GB        |
| Carlsberg Brewery Limited                                 | DK        |
| Grand Metropolitan plc                                    | GB        |
| Carlsberg                                                 | DK        |

### Market
United Kingdom
market outside EU: True
market oligopoly: True

### Cartel Period
1979-10-01 : 1991-09-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-05-01 | Carlsberg | set up new company for brewing beer |
| 1970-06-10 | De forenede Bryggerier A/S | was formed |
| 1970-12-01 | Carlsberg and Watney Mann Ltd | signed Shareholders Agreement and Sales Agreement |
| 1979-10-01 | parties | agreement came into effect |
| 1980-06-02 | United Breweries (Carlsberg), Carlsberg Brewery Limited, Grand Metropolitan group, Watney Mann & Truman Brewers Ltd | signed Lager Agreement to cooperate on sale of Carlsberg products |
| 1980-06-12 | De forenede Bryggerier A/S and Grand Metropolitan Limited | filed application for negative clearance |
| 1980-06-12 | Commission | received notification |
| 1983-12-21 | parties | deleted provision restricting competition |
| 1984-07-12 | redacted | issued commission decision |
| 1991-09-30 | Carlsberg Ltd | end of tolerance period for restrictive practices under the Lager Agreement |
| 1991-09-30 | redacted | agreement termination on specified end date |
| 1991-09-30 | redacted | exemption due to expire |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
| company                                                   |
|:----------------------------------------------------------|
| De forenede Bryggerier A/S (The United Breweries Limited) |
| Grand Metropolitan Ltd                                    |

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared the provisions of Article 85(1) inapplicable for the period from 21 December 1983 until 30 September 1991, and required the parties to send the Commission copies of the minutes of meetings of the Consultative Committee set up under clause 11 of the Agreement.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the agreements violated Article 85(1) of the EC Treaty, which prohibits anticompetitive agreements. The Commission declared certain provisions inapplicable for a period from December 21, 1983, to September 30, 1991, and required parties to submit meeting minutes of the Consultative Committee established under the agreement.


*(reported: 2026-10-16 19:56:09)*

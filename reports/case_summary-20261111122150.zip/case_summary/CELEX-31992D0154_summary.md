# 'IV/33.157', 'Eco System/Peugeot'

**CELEX ID:** CELEX-31992D0154  
**Industry:** | industry   |
|:-----------|
| Automotive |
| Retail     |  
**Cartel Period:** 1989 : 1989-05  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31992D0154 | IV/33157  |

### Case Title
Eco System/Peugeot

### Overview
This case involved an investigation into anticompetitive agreements within the automotive sector, focusing on vertical restraints such as territorial exclusivity and parallel trade bans. The European Commission found that certain practices by Peugeot companies were in breach of Article 85 of the EC Treaty.

### Industry
Automotive, Retail

### Oecd Nace
trade (wholesaling and retailing) and hotels; 29.1: Manufacture of motor vehicles; 29.10: Manufacture of motor vehicles

### Companies Undertakings
| companies                  |
|:---------------------------|
| Eco System SA              |
| Peugeot SA                 |
| Automobiles Peugeot SA     |
| Peugeot Talbot Belgique SA |
| Peugeot Talbot Service SA  |
| G. Gewelt bvba             |
| Carrefour                  |
| CLCA/CCMC                  |
| CECRA                      |
| BEUC                       |

### Market
Belgium, Luxembourg, France; Price differences between France, Belgium, and Luxembourg for Peugeot vehicles, leading to increased interest in cross-border imports

### Cartel Period
1989 : 1989-05

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-07-01 | Automobiles Peugeot SA | regulation came into force granting exemption for exclusive motor vehicle distribution agreements |
| 1989-01-01 | Peugeot dealers | published list prices substantially higher in France than in Belgium and Luxembourg |
| 1989-04-19 | Eco System SA | filed application alleging infringement of Article 85(1) |
| 1989-12-06 | Commission | sent two statements of objections to Peugeot companies |
| 1990-03-26 | Commission | adopted decision imposing interim measures |
| 1990-04-24 | Peugeot | lodged appeal before Court of First Instance |
| 1990-05-21 | Court | rejected application for suspension |
| 1991-07-12 | Peugeot | lodged appeal before Court of Justice |
| 1991-07-12 | Court | issued judgment rejecting application for withdrawal |
| 1991-12-04 | Commission | issued decision relating to proceeding under Article 85

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered Peugeot SA and Automobiles Peugeot SA to send a new circular within two months of notification of this Decision to all dealers, cancelling the 9 May 1989 circular, and to refrain from any conduct having the same effect.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | European Union

### Book Reference
NA

### Outcome
The Commission found that the practices were in breach of Article 85 and imposed remedies, including ordering the cancellation of a previous circular and prohibiting similar conduct.


*(reported: 2026-11-11 11:33:11)*

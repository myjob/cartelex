# 'IV/33.686', 'Coapi'

**CELEX ID:** CELEX-31995D0188  
**Industry:** | industry                                                           |
|:-------------------------------------------------------------------|
| Patents                                                            |
| European patents                                                   |
| Trade marks                                                        |
| International trade marks                                          |
| Labels                                                             |
| Utility models                                                     |
| Industrial and artistic designs                                    |
| International designs                                              |
| Commercial names and signs                                         |
| Cinematographic films                                              |
| Assignments                                                        |
| Investigations                                                     |
| Opposition, replies in suspensory proceedings, certification, etc. |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31995D0188 | IV/33686  |

### Case Title
IV/33.686 – Coapi

### Overview
The case involves the Spanish organization Coapi, which was found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty. The infringement pertains to a joint venture that restricted competition by imposing fixed charges on members.

### Industry
Patents
European patents
Trade marks
International trade marks
Labels
Utility models
Industrial and artistic designs
International designs
Commercial names and signs
Cinematographic films
Assignments
Investigations
Opposition, replies in suspensory proceedings, certification, etc.

### Oecd Nace
OECD sector: public service
NACE group code: 77.4:Leasing of intellectual property and similar products, except copyrighted works
NACE class code: 77.40: Leasing of intellectual property and similar products, except copyrighted works

### Companies Undertakings
Colegio Oficial de Agentes de la Propiedad Industrial (ES)

### Market
Spain

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1926-02-27 | Royal Decree | ratified principle of obligatory affiliation for industrial property agents |
| 1926-11-29 | Coapi Regulations | established with provisions on decision-making bodies, charges, advertising, rights, duties, and sanctions |
| 1927-02-28 | Royal Decree | approved the regulations of 29 November 1926 |
| 1974-02-13 | Law No 2/1974 | established the basis of current Coapi Regulations |
| 1987-01-29 | administrative board | approved proposal of administrative board |
| 1987-01-29 | Coapi | held general meeting discussing charge scales |
| 1987-11-24 | Coapi | adopted annual increase in foreign scales of charges |
| 1987-11-24 | administrative board | proposed general increase of 5% applicable to national and foreign scales of charges |
| 1990-08-29 | complainant | submitted informal complaint to Commission against Coapi |
| 1990-12-11 | Coapi | approved proposal to increase charges |
| 1990-12-11 | general meeting | implemented new scales of minimum charges |
| 1995-01-30 | Commission | adopted decision requiring Coapi to bring infringements to an end |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
NA

### Remedies
| value                                                                                                                                                                                                                                                                                                          |
|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| The Coapi shall inform its members in writing of the content of this Decision and that it has terminated the infringements referred to in Article 1, specifying the practical consequences which flow therefrom, in particular the freedom of the individual members to establish their own scales of charges. |
| The Coapi shall, within two months of notification of this Decision, communicate to the Commission the information transmitted to its members pursuant to the foregoing paragraph.                                                                                                                             |

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                                 | country        | jurisdiction              |
|:--------------------------------------|:---------------|:--------------------------|
| European Court of Justice             | European Union | European Court of Justice |
| Spanish Constitutional Court          | Spain          | national                  |
| Tribunal de Defensa de la Competencia | Spain          | Administrative Courts     |

### Book Reference
NA

### Outcome
The Commission found that Coapi had engaged in anticompetitive agreements under Article 85, and required it to bring the infringements to an end. Remedies were ordered, including informing members of the termination of the infringement and communicating this information to the Commission.


*(reported: 2026-11-11 11:51:39)*

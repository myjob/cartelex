# 'IV/28.775', 'UNIDI'

**CELEX ID:** CELEX-31975D0498  
**Industry:** dental equipment  
**Cartel Period:** 1974-05-01 : 1983-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31975D0498 | IV/28775-1 |

### Case Title
UNIDI

### Overview
This case involved a cartel in the Italian dental equipment industry, where Unione Nazionale Industrie Dentarie Italiane (UNIDI) and several other companies engaged in anticompetitive practices under Article 85 of the Treaty. The Commission found that UNIDI's rules restricting participation in exhibitions were incompatible with EU competition law.

### Industry
dental equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.5: Manufacture of medical and dental instruments and supplies
NACE class code: 32.50: Manufacture of medical and dental instruments and supplies

### Companies Undertakings
| companies                                            |
|:-----------------------------------------------------|
| Unione Nazionale Industrie Dentarie Italiane (UNIDI) |
| Dentaurum HP                                         |
| Compagnia Internazionale Prodotti Dentali (CIPD)     |
| Risen                                                |
| Unital                                               |

### Market
Relevant market: Italy
Market structure: oligopoly
Market turbulence: NA

### Cartel Period
1974-07-25 : 1983-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1969-05-27 | UNIDI | formed under Italian law |
| 1973-12-21 | Unione Nazionale Industrie Dentarie Italiane (UNIDI) | submitted application for negative clearance |
| 1974-04-16 | Dentaurum HP | submitted application on behalf of Dentaurum HP and others |
| 1974-04-30 | Risen | joined the application |
| 1974-07-25 | Commission | entered into force |
| 1974-07-25 | Expo Dental organizing committee | decided to hold future exhibitions every 18 months |
| 1974-07-25 | UNIDI | amended rules to permit participation in multiple exhibitions |
| 1974-07-25 | UNIDI | adopted decision amending rules governing future Expo Dental exhibitions |
| 1975-06-25 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion |
| 1975-07-17 | Commission | issued decision |

### Legal Framework
Legal framework: Article 85 (operative article)
Canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
Exemption sought by German Firm, Italian Firm 1, Italian Firm 2, and Italian Firm 3; exemption not granted.

### Leniency
NA

### Fines
NA

### Remedies
The Commission required UNIDI to modify its rules effective from 25 July 1974, specifically the provisions in Article 22, to align with Article 85(3) of the Treaty. This change was interpreted as a behavioral remedy ensuring compliance with EU competition law by reducing overly restrictive participation rules for exhibitors.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
François-Xavier ORTOLI

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 21:58:33)*

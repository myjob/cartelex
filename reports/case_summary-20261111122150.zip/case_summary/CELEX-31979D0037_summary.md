# 'IV/93 — EMO', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31979D0037  
**Industry:** NA  
**Cartel Period:** 1969-03-01 : 1988-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31979D0037 | IV/93-2   |

### Case Title
IV/93 – EMO

### Overview
This case concerns a proceeding under Article 85 of the EEC Treaty involving a cartel of machine tool manufacturers. The European Commission investigated anticompetitive agreements among companies in the machine tool industry, particularly focusing on exclusive dealing and market foreclosure practices.

### Industry
Machine tools, machine tool implements, accessories, fittings, machine grinders, polishers, watchmakers' lathes, universal punching machines, shearing machines, reinforcing-bar cutters, tools for metal-working

### Oecd Nace
OECD sector: manufacturing
NACE group code: 28.4: Manufacture of metal forming machinery and machine tools
NACE class code: 28.49: Manufacture of other machine tools

### Companies Undertakings
| companies                                                                       | location          |
|:--------------------------------------------------------------------------------|:------------------|
| European Committee for Cooperation of the Machine Tool Industries               | Brussels          |
| Fachverband der Maschinen- und Stahlbauindustrie Osterreichs                    | Vienna            |
| Syndicat des constructeurs belges de machines-outils pour le travail des métaux | Brussels          |
| Verein Schweizerischer Maschinen-Industrieller                                  | Zurich            |
| Verein Deutscher Werkzeugmaschinenfabriken e. V.                                | Frankfurt-on-Main |
| Foreningen af Danske Værktojsmaskinfabrikanter                                  | Copenhagen        |
| Asociación Española de Fabricantes de MáquinasHerramientas                      | San Sebastián     |
| Syndicat des constructeurs frangais de machines-outils                          | Neuilly-sur-Seine |
| The Machine Tool Trades Association                                             | London            |
| Unione Costruttori Italiani Macchine Utensili                                   | Milan             |
| Mekaniske Verksteders Landsforening                                             | Oslo              |
| Vereniging voor Metaal- en Electrotechnische Industrie                          | The Hague         |
| Centro de Cooperaçao dos Industriais de MaquinasFerramientas                    | Oporto            |
| Föreningen Svenska Verktygmaskintillverkare                                     | Stockholm         |

### Market
Market geography includes Austria, Belgium, Switzerland, Germany, Denmark, Spain, France, United Kingdom, Italy, Norway, Netherlands, Portugal, Sweden. Market is outside the EU.

### Cartel Period
1969-03-13 : 1988-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-09-20 | CECIMO | submitted notification under Article 2 of Regulation No 17 |
| 1969-03-13 | CECIMO | applied for renewal of exemption under Article 85 (3) |
| 1969-03-13 | CECIMO | took measures on EMO rules that constitute a decision restricting competition |
| 1969-03-13 | redacted | Commission Decision renewed |
| 1975-07-01 | CECIMO | submitted application for renewal of Commission Decision |
| 1976-04-02 | CECIMO | submitted second application for renewal of Commission Decision |
| 1978-03-15 | Commission | published CECIMO's basic rules on participation in exhibitions |
| 1978-03-15 | Commission | published notice pursuant to Article 19(3) of Regulation No 17 and asked CECIMO to make amendments to EMO rules |
| 1978-09-26 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion under Article 10 of Regulation No 17 |
| 1978-12-07 | redacted | decision issued at Brussels |
| 1978-12-31 | CECIMO | submitted renewal applications |
| 1979-01-01 | CECIMO | took effect from date |
| 1988-12-31 | Commission | decision expires |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
medium

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
No specific orders or remedies are explicitly stated in the document as being issued by the Commission to terminate any infringement.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
| court      | country   | jurisdiction         |
|:-----------|:----------|:---------------------|
| COMMISSION | EEC       | European Communities |

### Book Reference
NA

### Outcome
The case resulted in no specific orders or remedies being issued by the Commission to terminate the infringement. The Commission took no action, and the exemption was renewed under Article 85(3) of the Treaty.


*(reported: 2026-10-16 22:08:20)*

# 'IV/26.624', 'Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31971D0222  
**Industry:** ammunition manufacturing  
**Cartel Period:** 1967-11-27 : 1978-03-26  

## Summary

### Celex Case Id
CELEX-31971D0222

### Case Title
IV/26.624 – Article 85 of the EEC Treaty

### Overview
This case involves an anticompetitive agreement between Fabrique Nationale d'Armes de Guerre S.A. (Belgium) and La Cartoucherie Française S.A. (France) in the ammunition manufacturing industry. The companies engaged in horizontal cartels involving market sharing, quota cartels, and specialization agreements. The European Commission found the agreement to be contrary to Article 85 of the EEC Treaty, with a low gravity infringement. The cartel period lasted from 1967 to 1978, during which time the companies submitted applications for approval of their cooperation agreement. The Commission issued a decision under Article 85 and ordered reporting remedies but took no action regarding information requests or leniency applications.

### Industry
ammunition manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 25.4:Manufacture of weapons and ammunition
NACE class code: 25.40: Manufacture of weapons and ammunition

### Companies Undertakings
| company                                   |
|:------------------------------------------|
| Fabrique Nationale d'Armes de Guerre S.A. |
| La Cartoucherie Française S.A.            |

### Market
| country     |
|:------------|
| Belgium     |
| France      |
| Germany     |
| Italy       |
| Netherlands |
| Luxembourg  |

market outside EU: true

market oligopoly: True

### Cartel Period
1967-11-27 : 1978-03-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1967-11-27 | Fabrique Nationale d'Armes de Guerre S.A. and La Cartoucherie Française S.A. | concluded agreement |
| 1967-11-27 | Fabrique Nationale d'Armes de Guerre and La Cartoucherie Française | concluded cooperation agreement on manufacture and distribution of ammunition |
| 1968-03-27 | Fabrique Nationale d'Armes de Guerre and La Cartoucherie Française | submitted application for approval of cooperation agreement |
| 1968-03-27 | Commission | decision became effective |
| 1971-05-28 | redacted | issued decision under Article85 of the EEC Treaty |
| 1978-03-26 | Commission | decision expired |

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
low

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
NA

### Outcome
The Commission ordered the companies to report every two years on specialization measures, effects, sales prices and discounts, and market shares in each EEC member state.


*(reported: 2026-10-16 19:23:46)*

# 'IV/30.615 - BL', 'NA'

**CELEX ID:** CELEX-31984D0379  
**Industry:** automotive  
**Cartel Period:** 1981-06-18 : 1982-01-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31984D0379 | IV/30615  |

### Case Title
IV/30.615 – BL

### Overview
This case concerns allegations of abuse of dominance by BL plc, an automotive company based in the United Kingdom. The company was found to have engaged in practices that restricted competition within the European Union market for LHD and RHD variants of vehicles, including refusing to provide necessary documentation (NTA numbers) for these vehicles sold in other Member States.

### Industry
automotive

### Oecd Nace
OECD sector: manufacturing
NACE group code: 29.1: Manufacture of motor vehicles
NACE class code: 29.10: Manufacture of motor vehicles

### Companies Undertakings
BL plc

### Market
United Kingdom market, with implications outside the EU

### Cartel Period
1981-06-18 : 1982-01-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-06-18 | BL | informed Auto Europa of Birmingham that no certificates of conformity were available for LHD Metros and declined to provide the relevant NTA numbers |
| 1981-06-23 | BL | wrote to International Cars RHT Ltd of Edgware in similar terms |
| 1981-08-11 | BL | wrote to Mrs Fox of Pevensey denying, in effect, that NTA for LHD Metros applied to vehicles sold in Member States other than the United Kingdom |
| 1981-11-04 | BL | informed Dealer Council about ending type approval for LHD cars |
| 1981-11-06 | Derek Merson | lodged application under Article 3 of Regulation No 17 |
| 1981-11-16 | BL | informed Royal Cars AMS Autos Ltd of London that it would not provide NTA numbers for LHD Metros |
| 1981-11-17 | BL | wrote to Mr Merson, the complainant in this case, to inform him that BL was not able to provide NTA numbers for any LHD Metro |
| 1982-01-12 | BL | informed Mr Doyle of Preston that LHD Metros were not type-approved |
| 1982-06-28 | Commission of the European Communities | initiated proceedings in case |
| 1983-03-16 | BL | reduced charge for granting certificate of conformity from £2.5 to £100 |
| 1983-03-16 | BL | charged £100 for same service to independent dealers and individuals |
| 1984-07-02 | Commission of the European Communities | issued Commission decision |

### Legal Framework
Article 86 (abuse of dominance)

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
No leniency applicants or grants

### Fines
| company | amount |
| --- | --- |
| BL | £2,078,76.55 |

### Remedies
BL shall bring the infringement to an end and inform the Commission of the measures taken. A fine of 350,000 ECU (approximately £2,078,76.55) is imposed on BL.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| BL | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
Courts involved but no specific rulings listed

### Book Reference
NA

### Outcome
BL plc was found guilty of abuse of dominance and fined £2,078,76.55 (approximately 350,000 ECU). The Commission ordered BL to end the infringement and inform the Commission of the measures taken.


*(reported: 2026-11-11 10:51:17)*

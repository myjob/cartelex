# 'IV/31.503', 'Konica'

**CELEX ID:** CELEX-31988D0172  
**Industry:** photographic goods and equipment, video tapes, video cameras  
**Cartel Period:** 1985 : 1985-02-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0172 | IV/31503  |

### Case Title
Konica

### Overview
This case involves Konica UK Ltd and Konica Europe GmbH for an infringement of Article 85(1) of the EEC Treaty related to vertical restraints, specifically territorial exclusivity and parallel trade bans. The companies were found to have engaged in anticompetitive behavior by restricting grey exports and protecting dealers' margins, leading to a fine of 75,000 ECU each.

### Industry
photographic goods and equipment, video tapes, video cameras

### Oecd Nace
trade (wholesaling and retailing) and hotels
26.7:Manufacture of optical instruments and photographic equipment
26.70: Manufacture of optical instruments and photographic equipment

### Companies Undertakings
| companies                          |
|:-----------------------------------|
| Konica UK Ltd                      |
| Konica Europe GmbH                 |
| Konishiroku Photo Industry Co. Ltd |
| Konica France                      |
| Konica Netherlands BV              |

### Market
United Kingdom, Federal Republic of Germany, France
Market outside EU: True
Oligopoly: True
Turbulence: NA

### Cartel Period
1985 : 1985-02-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-07-01 | Konica Europe GmbH | merged with Konica Europe GmbH for practical purposes |
| 1984-11-14 | Konica Europe | bought several consignments of Konica colour film from a German wholesaler |
| 1984-11-29 | Konica Europe | bought another consignment of Konica colour film from a German wholesaler |
| 1984-12-14 | Konica Burope | sent telex to Konica UK informing it that Metro had begun offering Konica colour film at its 32 cash-and-carry stores in the Federal Republic of Germany |
| 1985-02-01 | Konica Europe | bought up Konica film from grey channels to protect German market against parallel imports |
| 1985-02-01 | Konica UK | sent circular instructing wholesalers not to engage in grey exporting |
| 1985-02-01 | Konica UK | sent circular concerning grey exports and monitoring systems |
| 1985-02-16 | Konica UK | raised basic prices to dealers by approximately 10% |
| 1985-03-15 | Konica UK | sent telex to Konica Europe investigating grey exporters |
| 1987-12-18 | Commission | adopted decision imposing fines on Konica UK Ltd and Konica Europe GmbH for infringement of Article 85(1) of the EEC Treaty |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Konica UK Ltd | 75 000 ECU |
| Konica Europe GmbH | 75 000 ECU |

### Remedies
Konica UK Ltd must not obligate or try to oblige customers to refrain from exporting or reselling Konica film. Konica Europe GmbH must not engage in behavior designed to prevent parallel imports and protect its dealers’ margins. These commitments are sufficient to end the infringement without a formal cease and desist order.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Konica UK Ltd | False |
| Konica Europe GmbH | False |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed fines of 75,000 ECU on Konica UK Ltd and Konica Europe GmbH for infringement of Article 85(1) of the EEC Treaty. Remedies were ordered to end the infringement without a formal cease and desist order.


*(reported: 2026-11-11 11:11:18)*

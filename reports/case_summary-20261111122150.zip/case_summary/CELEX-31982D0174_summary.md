# 'IV/30.307', 'Fire insurance (D)'

**CELEX ID:** CELEX-31982D0174  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31982D0174 | IV/30307-1 |

### Case Title
IV/30.307–Fire insurance (D)

### Overview
This case involved an investigation into anticompetitive agreements in the fire insurance industry, specifically focusing on horizontal price fixing collusion under Article 85 of the EC Treaty. The European Commission examined the practices of The Northern Assurance Co. Ltd and Verband der Sachversicherer E.V., with a focus on their conduct in Germany.

### Industry
industrial fire insurance, consequential loss insurance

### Oecd Nace
banking and insurance (including real estate), 65.1:Insurance, 65.12: Non-life insurance

### Companies Undertakings
| company                          |
|:---------------------------------|
| The Northern Assurance Co. Ltd   |
| Verband der Sachversicherer E.V. |

### Market
Germany, oligopolistic market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-08-01 | VdS | issued premium recommendations affecting trade between Member States |
| 1981-03-20 | Commission | sent request for information to Northern |
| 1981-06-25 | Commission | requested exhaustive reply from Northern |
| 1981-12-09 | Northern Assurance Co. Ltd | issued decision requiring response to questions about German business in industrial fire and consequential loss insurance |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
False

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered Northern Assurance Company Limited to answer specific questions regarding its industrial fire and consequential loss insurance business in Germany, including premium income, rates, compensation, costs, and contract details for the years 1978, 1979, and 1980, as well as information on contracts and changes in premium rates since July 1980. This order was issued under the authority of Regulation No 17, Article 11(5), with a time limit of two months from notification for supplying the required information.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Northern Assurance Co. Ltd | False |

### Case Commission Info Request
| company                    | requested_by   | request_date   | request_date_2   |
|:---------------------------|:---------------|:---------------|:-----------------|
| Northern Assurance Co. Ltd | Commission     | 20 March 1981  | 25 June 1981     |

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court                                        | country    | jurisdiction   |
|:---------------------------------------------|:-----------|:---------------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission ordered Northern Assurance Company Limited to answer specific questions regarding its industrial fire and consequential loss insurance business in Germany, including premium income, rates, compensation, costs, and contract details for the years 1978, 1979, and 1980, as well as information on contracts and changes in premium rates since July 1980. This order was issued under the authority of Regulation No 17, Article 11(5), with a time limit of two months from notification for supplying the required information.


*(reported: 2026-11-11 10:37:46)*

# 'IV/34.410', 'Olivetti-Digital'

**CELEX ID:** CELEX-31994D0771  
**Industry:** computer and technology industry  
**Cartel Period:** 1993-04-01 : 1997-06-25  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0771 | IV/34410  |

### Case Title
Olivetti–Digital

### Overview
This case involves an anticompetitive agreement between Ing. C. Olivetti & C., SpA and Digital Equipment Corporation concerning the purchase of Alpha AXP technology products, leading to a Commission decision granting an individual exemption under Article 85(3).

### Industry
computer and technology industry

### Oecd Nace
manufacturing
26.2:Manufacture of computers and peripheral equipment
26.20: Manufacture of computers and peripheral equipment

### Companies Undertakings
| companies                                     | location             |
|:----------------------------------------------|:---------------------|
| Digital Equipment Corporation                 | NA                   |
| Ing. C. Olivetti & C., SpA                    | NA                   |
| CIR                                           | Leiní (Turin), Italy |
| Cofide-Compagnia Finanziaria de Benedetti SpA | NA                   |

### Market
Increased competition from new entrants due to strategic alliances; risk of market startup and financial instability for new product entry; lack of comparable RISC technology and financial resources for Olivetti

### Cartel Period
1992-07-30 : 2002-06-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-06-25 | Olivetti and Digital | signed Share Purchase Agreement and Strategic Alliance Agreement |
| 1992-07-30 | Digital and Ing. C. Olivetti & C., SpA | notified cooperation agreement in the field of computer systems to the Commission for negative clearance or exemption |
| 1992-07-30 | redacted | granted exemption |
| 1993-04-01 | Olivetti | commenced purchasing commitment to acquire Alpha AXP products from Digital |
| 1994-06-30 | Olivetti | completed initial purchase of US$980 million in Alpha AXP products |
| 1994-08-24 | Digital Equipment Corporation | sold all shares in Olivetti |
| 1994-11-11 | Commission of the European Communities | issued decision on proceeding |
| 1994-11-11 | Commission | issued Decision |
| 2002-06-25 | Olivetti | reached end of tacitly renewed commitment to purchase Alpha AXP products |
| 2002-06-25 | redacted | ended exemption period |
| 2002-06-25 | redacted | period of inapplicability for Article 85(1) ends |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
high

### Exemption
True
| company                       |
|:------------------------------|
| Ing. C. Olivetti & C., SpA    |
| Digital Equipment Corporation |

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an individual exemption under Article 85 (3) for the period from 30 July 1992 to 25 June 2002 for the purchasing commitment concerning products based on Alpha AXP technology contained in the 'Strategic Alliance Agreement' between Olivetti and Digital.

### Company Recidivism
| companies                                                 | recidivism   |
|:----------------------------------------------------------|:-------------|
| Digital Equipment Corporation, Ing. C. Olivetti & C., SpA | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an individual exemption under Article 85(3) for the period from 30 July 1992 to 25 June 2002 for the purchasing commitment concerning products based on Alpha AXP technology contained in the 'Strategic Alliance Agreement' between Olivetti and Digital.


*(reported: 2026-10-16 20:45:04)*

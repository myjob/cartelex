# 'NA', 'NA'

**CELEX ID:** CELEX-31969D0243  
**Industry:** dye  
**Cartel Period:** 1964-01-07 : 1967-10-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31969D0243 | IV/26267  |

### Case Title
NA

### Overview
This case involves a cartel of dye manufacturers from Germany, France, Italy, Switzerland, and Great Britain, found guilty of horizontal price fixing collusion under Article 85 of the EEC Treaty. The cartel operated from January 1964 to October 1967, with coordinated price increases across various dye products.

### Industry
dye

### Oecd Nace
manufacturing
NACE group code: 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.12: Manufacture of dyes and pigments

### Companies Undertakings
| companies                                                              |
|:-----------------------------------------------------------------------|
| Badische Anilin- und Soda-Fabrik AG (BASF), Ludwigshafen (Germany)     |
| Cassella Farbwerke Mainkur AG, Frankfurt/Main (Germany)                |
| Farbenfabriken Bayer AG, Leverkusen (Germany)                          |
| Farbwerke Hoechst AG, Frankfurt/Main (Germany)                         |
| Frangaise des Matières Colorantes S.A. (Francolor), Paris (France)     |
| Aziende Colori Nazionali Affini S.p.A. (ACNA), Milan (Italy)           |
| S.A. Ciba, Basel (Switzerland)                                         |
| J.R. Geigy S.A., Basel (Switzerland)                                   |
| Sandoz S.A., Basel (Switzerland)                                       |
| Imperial Chemical Industries Ltd. (I.C.I.), Manchester (Great Britain)   |

### Market
Germany, France, Italy, Switzerland, Great Britain
Market is outside the EU
Market is oligopolistic

### Cartel Period
1964-01-07 : 1967-10-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1964-01-07 | dye manufacturers | uniformly increased prices of aniline dyes by 15v.H. |
| 1964-01-09 | Geigy and Hoechst | sent telegrams instructing Italian subsidiaries to raise prices |
| 1964-01-20 | dye manufacturers | uniformly increased prices of aniline dyes by 15v.H. |
| 1965-01-01 | dye manufacturers | uniformly increased prices of dyes and pigments by 10v.H. |
| 1967-01-11 | JazS.A. and PeterUhrenGmbH | concluded agreement |
| 1967-05-31 | Commission | initiated procedure ex officio against dye manufacturers |
| 1967-08-18 | J.R.GeigyS.A. | announced intention to raise selling prices before end of year |
| 1967-10-16 | J.R.GeigyS.A. | increased prices for tar dyes by 8% |
| 1967-10-16 | Badische Anilin- und Soda-Fabrik AG (BASF) | implemented price increase |
| 1967-11-28 | Federal Cartel Office | made decision on coordinated behavior |
| 1969-07-24 | Commission | issued decision on procedure under Article85 of the EEC Treaty |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Badische Anilin- und Soda-Fabrik AG (BASF), Ludwigshafen (Germany) | fifty thousand invoice units |
| Cassella Farbwerke Mainkur AG, Frankfurt/Main (Germany) | fifty thousand invoice units |
| Farbenfabriken Bayer AG, Leverkusen (Germany) | fifty thousand invoice units |
| Farbwerke Hoechst AG, Frankfurt/Main (Germany) | fifty thousand invoice units |
| Frangaise des Matières Colorantes S.A. (Francolor), Paris (France) | fifty thousand invoice units |
| Aziende Colori Nazionali Affini S.p.A. (ACNA), Milan (Italy) | forty thousand invoice units |
| S.A. Ciba, Basel (Switzerland) | fifty thousand invoice units |
| J.R. Geigy S.A., Basel (Switzerland) | fifty thousand invoice units |
| Sandoz S.A., Basel (Switzerland) | fifty thousand invoice units |
| Imperial Chemical Industries Ltd. (I.C.I.), Manchester (Great Britain) | fifty thousand billing units |

### Remedies
Imposition of monetary fines: fifty thousand invoice units for most companies, forty thousand invoice units for ACNA. Payment must be made to the Commission within three months of service of the decision.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
Article 85 paragraph 3 is declared not applicable

### Case Commission Decision
True

### Commissioner
Jean REY

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission found the companies guilty of anticompetitive agreements under Article 85 of the EEC Treaty. Fines were imposed, and remedies included monetary penalties.


*(reported: 2026-11-11 09:49:34)*

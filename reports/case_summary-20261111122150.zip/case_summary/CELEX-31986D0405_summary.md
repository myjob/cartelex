# 'IV/30.320', 'optical fibres'

**CELEX ID:** CELEX-31986D0405  
**Industry:** Optical Fibres  
**Cartel Period:** 1975-01-01 : 1985-12-31  

## Summary

### Celex Case Id
CELEX-31986D0405 (IV/30.320, IV/30320)

### Case Title
optical fibres

### Overview
The case concerns a joint venture in the optical fibres industry involving companies from the US, UK, and Germany. The European Commission investigated anticompetitive agreements related to this joint venture under Article 85 of the EC Treaty.

### Industry
Optical Fibres

### Oecd Nace
manufacturing (26.3: Manufacture of communication equipment)

### Companies Undertakings
- Corning Glass Works (US)
- BICC plc (GB)
- Siemens AG (DE)
- Optical Fibres
- Siecor GmbH (DE)

### Market
The relevant market includes the USA, Canada, Japan, United Kingdom, France, Germany, Italy, Netherlands, Denmark, Australia, Brazil, and Korea. The market is characterized as an oligopoly with no turbulence.

### Cartel Period
1973-04-12 : 2001-01-07

### Key Timeline
| Date | Event |
| --- | --- |
| 1973-04-12 | Corning Glass Works and Siemens AG established joint venture 'Siecor GmbH' |
| 1978-01-01 | Corning Glass Works and Siemens AG entered licence agreement with Siecor GmbH |
| 1981-02-06 | Corning Canada Inc and BICC plc signed partnership agreement for joint venture |
| 1981-03-17 | Agreements notified to the Commission |
| 1983-06-24 | Agreements notified to the Commission |
| 1985-09-26 | Corning Glass Works and Siemens AG amended joint venture agreement and licence agreement |
| 1985-11-05 | Commission declared inapplicable joint venture agreements under Article 85(3) |
| 1985-12-31 | Corning Canada Inc and BICC plc amended partnership agreement and know-how licence agreement |
| 1986-01-08 | Commission declared inapplicable Corning-BICC joint venture agreements under Article 85(3) |
| 1986-07-14 | Commission adopted Decision addressing joint ventures |
| 2000-11-04 | Joint venture agreements ended |
| 2001-01-07 | Corning-BICC joint venture agreements ended

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
medium

### Exemption
Exemption was sought and granted for the joint venture agreements under Article 85(3).

### Leniency
NA

### Fines
NA

### Remedies
The Commission allowed the amended agreements under Article 85(3) upon acceptance of behavioral commitments including: reduction of Corning's voting rights and management powers in the German joint venture; removal of Corning’s representatives from the boards of both the German and UK joint ventures; limitation of sales rights to passive sales in territories where exclusive licensees exist; obligations for non-discriminatory sales terms, purchase of supplies from independent sources, and right to require expansion of production capacity; prohibition on sharing sensitive competitive information; and a 15-year term with renewal subject to Commission approval.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
IV/30.320 (landmark case in book)

### Outcome
The Commission allowed the amended agreements under Article 85(3) upon acceptance of behavioral commitments.


*(reported: 2026-10-16 19:58:34)*

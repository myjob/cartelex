# 'IV/29.525 and IV/30.000  SSI', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31982D0506  
**Industry:** cigarette industry  
**Cartel Period:** 1974 : 1980  

## Summary

### Celex Case Id
CELEX-31982D0506

### Case Title
IV/29.525 and IV/30.000 – SSI

### Overview
This case involved a cartel among Dutch cigarette manufacturers under the Stichting Sigarettenindustrie (SSI) that engaged in anticompetitive practices including price fixing and selective distribution. The European Commission found violations of Article 85 of the EEC Treaty, imposing fines and ordering termination of infringing agreements.

### Industry
cigarette industry

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels; NACE group code: 12.0; NACE class code: 12.00

### Companies Undertakings
| company                                        |
|:-----------------------------------------------|
| Stichting Sigarettenindustrie                  |
| British-American Tobacco Co. (Nederland) BV    |
| Sigarettenfabrick Ed. Laurens BV               |
| De Koninklijke Bedrijven Theodorus Niemeyer BV |
| Philip Morris Holland BV                       |
| R. J. Reynolds Tobacco BV                      |
| Turmac Tobacco Co. BV                          |
| Tabaksfabriek Gruno BV                         |
| Imperial Tobacco (Holland) BV                  |
| Reemtsma Nederland BV                          |
| Yohai and Co. Dutch Tobacco Company BV         |
| Theodorus Niemeyer                             |
| La Paz Siagrenfabriek                          |
| Rcemtsma Zigarettenfabriken GmbH               |

### Market
Netherlands, oligopolistic market structure

### Cartel Period
1974 : 1980

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1950-06-22 | Government | introduced Economic Offences Law making infringement of Prices Order a criminal offence |
| 1974-08-01 | SSI | signed price agreement |
| 1974-08-12 | SSI | implemented price increase |
| 1974-12-04 | SSI members and Tabaksfabriek Gruno | signed bonus scheme agreement |
| 1975-04-23 | cigarette manufacturers and/or importers | agreed on rules of conduct in cigarette trade |
| 1975-11-07 | members of the Stichting Sigarettenindustrice | entered into price agreement |
| 1976-12-20 | SSI and cigarette manufacturers/importers/wholesalers/retailers | entered into master agreement |
| 1977-09-20 | Stichting Sigarettenindustrie | notified master agreement and bonus scheme to commission |
| 1978-02-01 | SSI members, Tabaksfabrick Gruno, wholesalers and their associations | implemented maximum margin rate of 9.8% for wholesalers to specialist retailers |
| 1979-12-31 | SSI members, Tabaksfabrick Gruno, wholesalers and their associations | concluded maximum margin rate of 9.8% for wholesalers to specialist retailers |
| 1980-01-01 | cigarette manufacturers and/or importers | increased excise duty and prices |
| 1982-07-15 | commission | issued Commission Decision |

### Legal Framework
Article 85 (operative), EEC Treaty; canonical concept: anticompetitive agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
high

### Exemption
Exemption sought by Stichting Sigarettenindustrie

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| British-American Tobacco Co. (Nederland) BV | 350 000 ECU |
| Sigarettenfabrick Ed. Laurens BV | 425 000 ECU |
| De Koninklijke Bedrijven Theodorus Niemeyer BV | 100 000 ECU |
| Philip Morris Holland BV | 125 000 ECU |
| R. J. Reynolds Tobacco BV | 150 000 ECU |
| Turmac Tobacco Co. BV | 325 000 ECU |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court            | country        | jurisdiction                  |
|:-----------------|:---------------|:------------------------------|
| Committee        | Netherlands    | Specialist Retailer Committee |
| Appeals Board    | Netherlands    | Appeals Board                 |
| Court of Justice | European Union | European Court                |

### Book Reference
IV/29.525

### Outcome
Commission Decision issued in 1982, requiring termination of specific infringing agreements and practices.


*(reported: 2026-11-11 10:41:11)*

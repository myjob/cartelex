# 'IV/35.545 — LH/SAS', 'NA'

**CELEX ID:** CELEX-31996D0180  
**Industry:** air transport  
**Cartel Period:** 1995-05-11 : 1996-01-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31996D0180 | IV/35545  |

### Case Title
IV/35.545 — LH/SAS

### Overview
The European Commission investigated cooperation agreements between Deutsche Lufthansa AG and Scandinavian Airlines System (SAS) in the air transport industry, finding violations under Articles 85 and 86 of the EC Treaty. The case involved a joint venture that was granted an exemption but later required to terminate specific cooperation agreements.

### Industry
air transport

### Oecd Nace
OECD sector: transport
NACE group code: 51.2:Freight air transport and space transport
NACE class code: 51.21: Freight air transport

### Companies Undertakings
| companies_investigated       | country   |
|:-----------------------------|:----------|
| Deutsche Lufthansa AG        | DE        |
| Scandinavian Airlines System | SE        |

### Market
Relevant market includes Denmark, Norway, Sweden, and Germany. The market is oligopolistic and outside the EU.

### Cartel Period
1995-05-11 : 2005-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1995-05-11 | Deutsche Lufthansa AG and Scandinavian Airlines System | concluded cooperation agreement |
| 1995-05-11 | Commission | evaluated fleet composition for competitive advantage |
| 1995-05-11 | Commission | made decision granting exemption |
| 1995-06-07 | Commission | published summary of the application |
| 1995-07-26 | Commission | sent letter notifying parties of serious doubts |
| 1995-08-05 | Commission | published notice inviting third parties to submit observations |
| 1996-01-01 | Swissair | terminated cooperation agreement with SAS |
| 1996-01-16 | Commission | issued Decision addressed to Lufthansa and SAS |
| 1996-01-31 | SAS | terminated cooperation agreement with Swissair |
| 1997-01-01 | SAS | terminated cooperation agreement with Austrian Airlines |
| 1997-01-01 | Lufthansa | terminated cooperation agreement with Transwede |
| 1997-01-01 | Lufthansa | terminated cooperation agreement with Finnair |

### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |

Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was granted for the cooperation agreements.

### Leniency
NA

### Fines
NA

### Remedies
SAS shall terminate its cooperation agreement with Swissair within the European Quality Alliance by 31 January 1996; SAS shall terminate its cooperation agreement with Austrian Airlines within the European Quality Alliance by 1 January 1997. Lufthansa shall terminate its cooperation agreement with Transwede within the Marketing Alliance in Scandinavia by 1 January 1997; Lufthansa shall terminate its cooperation agreement with Finnair in respect of routes between Scandinavia and Germany by 1 January 1997.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
The case involved the European Commission, and no court rulings are specified in the context.

### Book Reference
NA

### Outcome
The Commission granted an exemption but required termination of specific cooperation agreements to address anticompetitive behavior.


*(reported: 2026-10-16 20:52:12)*

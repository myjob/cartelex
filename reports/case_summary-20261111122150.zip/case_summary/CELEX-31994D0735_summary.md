# '94/735/EC', 'imposing a fine pursuant to Article 15 (1)(c) of Council Regulation No 17 on Akzo Chemicals BV'

**CELEX ID:** CELEX-31994D0735  
**Industry:** chemical  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0735 | IV/34887  |

### Case Title
94/735/EC imposing a fine pursuant to Article 15 (1)(c) of Council Regulation No 17 on Akzo Chemicals BV

### Overview
The European Commission imposed a fine on Akzo Chemicals BV for infringement of EU competition law, specifically cartel behavior. The case involved investigation, non-compliance with information requests, and imposition of a periodic penalty payment and a final fine of ECU 5,000.

### Industry
chemical

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.5:Manufacture of other chemical products
NACE class code: 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
Akzo Chemicals BV (NL)

### Market
NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-09-22 | Commission | ordered investigation into Akzo Chemicals BV |
| 1993-10-06 | Commission | began investigation into Akzo Chemicals BV |
| 1993-10-06 | Akzo Chemicals BV | supplied incorrect information |
| 1993-10-07 | Akzo Chemicals BV | did not comply with request for access to office of designated director |
| 1993-10-15 | Commission | imposed periodic penalty payment on Akzo Chemicals BV |
| 1993-10-19 | Commission officials | notified Decision imposing periodic penalty payments and sought access to Mr. Vogelaar's office |
| 1994-10-14 | Commission | imposed fine on Akzo Chemicals BV |
| 1994-10-14 | Commission | adopted Decision

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Akzo Chemicals BV | ECU 5 000 |

### Remedies
Periodic penalty payment and a fine of ECU 5,000

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission imposed a fine of ECU 5,000 on Akzo Chemicals BV for cartel infringement and ordered periodic penalty payments.


*(reported: 2026-11-11 11:47:16)*

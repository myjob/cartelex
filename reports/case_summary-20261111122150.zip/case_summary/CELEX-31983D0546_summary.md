# 'IV/30.064', 'Cast iron and steel rolls'

**CELEX ID:** CELEX-31983D0546  
**Industry:** NA  
**Cartel Period:** 1968 : 1979-07-10  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0546 | IV/30064  |

### Case Title
Cast iron and steel rolls

### Overview
This case involves a horizontal cartel of manufacturers of cast iron and steel rolls, operating from 1968 to 1979. The cartel engaged in international agreements and concerted practices, including price consultation, market sharing, and quota cartels. The European Commission investigated the infringement under Article 85 of the EEC Treaty and issued a decision imposing fines and ordering cessation of the infringing conduct.

### Industry
manufacturing (metal casting)

### Oecd Nace
OECD: manufacturing
NACE group code: 24.5:Casting of metals
NACE class code: 24.52: Casting of steel

### Companies Undertakings
| companies                                                             | location             |
|:----------------------------------------------------------------------|:---------------------|
| N. V. Griffin SA                                                      | Merksem              |
| SA des Fonderies J. Marichal, Ketin & Cie                             | Sclessin-Ougrée      |
| SAFAK SA                                                              | Sclessin-Ougrée      |
| Achenbach Buschhütten GmbH                                            | Kreuztal-Buschhütten |
| Eduard Breitenbach GmbH                                               | Siegen 21            |
| Leonhard Breitenbach Walzengieerei und Dreherei GmbH                  | Siegen 1             |
| Karl Buch WalzengieBerei                                              | Siegen 21            |
| Gontermann-Peipers GmbH                                               | Siegen               |
| Walzen Irle GmbH                                                      | Netphen 3            |
| Fried. Krupp GmbH                                                     | Essen 1              |
| Walzengielßerei Roland GmbH                                           | Siegen 1             |
| Thyssen Gieferei AG                                                   | Mülheim/Ruhr         |
| Fachgemeinschaft WalzengieBereien                                     | Siegen 1             |
| Chambre syndicale des fabricants de cylindres en fonte                | Paris                |
| Societé Chavanne-Delattre                                             | Paris la Defense     |
| Societé frangaise des cylindres de laminoirs J. Marichal, Ketin & Cie | Berlaimont           |
| SARL Ateliers et fonderies de Gorcy                                   | Paris                |
| Usinor SA                                                             | Paris la Défense     |
| SA Fonderies de Chenée                                                | Chenee               |
| SA des Fonderies J. Marichal, Ketin                                   | Sclessin-Ougrée      |
| Concordia                                                             | Hameln               |
| Davy Roll Company Ltd                                                 | Sheffield            |
| Midland Rollmakers Ltd                                                | Crewe                |
| R. B. Tennent Ltd                                                     | Coatbridge           |
| C. Akrill Ltd                                                         | Crewe                |
| Thomas Perry Ltd                                                      | Bilston              |
| Johnson's Rolls Ltd                                                   | West Bromwich        |
| British Rollmakers' Corporation Ltd                                   | Crewe                |
| Roll Export Association of Great Britain                              | Birmingham           |
| Eisenwerk Sulzau-Werfen, R &x E. Weinberger GmbH                      | Vienna               |
| AB Bofors Akers                                                       | Akers Styckebruk     |
| Innocenti Santeustacchio SpA                                          | Brescia              |
| Fonderie officine meccaniche Sant'Agostino SpA                        | Legnano              |
| Fonderia officina San Gregorio SAS                                    | San Macario (Varese) |
| Fonderie San Zeno                                                     | Brescia              |

### Market
The relevant market is international, including Belgium, France, Germany, Italy, United Kingdom, Austria, and Sweden. The market is characterized as oligopolistic and outside the EU.

### Cartel Period
1968 : 1979-07-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-01-01 | redacted | engaged in international agreements and concerted practices involving prior consultation on prices |
| 1969-05-09 | international roll-makers (Belgian, French, German, Italian, Austrian, UK, Swedish) | held international meeting in Rome to discuss price consultation and fixing arrangements |
| 1969-05-21 | European product manufacturers | agreed to apply 8% quotation price increase |
| 1971-05-10 | European roll-makers | formed International Rolls Manufacturers' Association (IRMA) |
| 1971-05-24 | ATAG | commenced reporting scheme for handling enquiries from interested parties |
| 1975-06-26 | Commission officials | initiated investigation interrupting limitation period |
| 1976-01-01 | French group | entered into and operated market-sharing agreement for cast iron rolls |
| 1976-05-21 | IRMA | agreed to apply an allocation system for home market orders during a six-month trial period |
| 1977-06-10 | contracting parties | signed Export Aid Agreement |
| 1978-02-23 | roll-makers | confirmed need for continued cooperation and committed to increasing prices by about 5 to 10% |
| 1981-01-01 | contracting parties | new agreement entered into force |
| 1983-10-17 | Commission | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85 (operative article), with all relevant articles being Article 85. Infringement concept: anticompetitive_agreement.

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought by Santeustacchio.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| N. V. Grifin SA, Marksem | 45 000 ECU or 2 064 749 Belgian francs |
| SA des Fonderies J. Marichal, Ketin, Sclessin-Ougrée, on its own behalf and on behalf of SA Fonderies de Chènée, Chènée | 80 000 ECU or 3 670 664 Belgian francs |
| SAFAK SA, Sclessin-Ougrée | 75 000 ECU or 3 441 248 Belgian francs |
| Achenbach Buschhüitten GmbH, KreuztalBuschhütten | 27 000 ECU or 60 926 German marks |
| Eduard Breitenbach GmbH, Siegen | 16 000 ECU or 36 104 German marks |
| Leonard Breitenbach Walzengieferei und Dreherei, Siegen | 17 000 ECU or 38 361 German marks |
| Karl Buch WalzengieBerei, Siegen | 65 000 ECU or 146 673 German marks |
| Gontermann-Peipers GmbH, Siegen | 26 000 ECU or 58 669 German marks |
| Walzen Irle GmbH, Netphen-Deuz | 72 000 ECU or 162 469 German marks |
| Fried. Krupp GmbH, Essen | 9 000 ECU or 20 309 German marks |
| Walzengieferei Roland GmbH, Siegen | 21 000 ECU or 47 387 German marks |
| Thyssen Gießerei AG, Mülheim-Ruhr | 42 000 ECU or 94 773 German marks |
| Chambre Syndicale des Fabricants de Cylindres. en Fonte, Paris | 29 000 ECU or 199 923 French francs |
| Société Chavanne-Delattre, Paris la Defense | 40 000 ECU or 275 756 French francs |
| Société Frangaise des Cylindres de Laminoirs J. Marichal, Ketin et Cie, Berlaimont | 86 000 ECU or 592 875 French francs |
| SARL Ateliers et Fonderies de Gorcy, Paris | 13 000 ECU or 89 621 French francs |
| Usinor SA, Paris la Defense | 24 000 ECU or 165 453 French francs |
| Innocenti Santeustacchio SpA, Brescia | 111 000 ECU or 152 080 000 Italian lire |
| Fonderie officine meccaniche Sant'Agostino SpA, Legnano | 14 000 ECU or 19 181 000 Italian lire |
| Fonderia officina San Gregorio SAS, San Macario (Varese) | 10 000 ECU or 13701 000 Italian lire |
| Fonderie San Zeno, Brescia | 8 000 ECU or 10 961 000 Italian lire |
| Davy Roll Company Ltd, Sheffield | 85 000 ECU or 48 941 pounds sterling |
| Midland Rollmakers Ltd, Crewe | 63 000 ECU or 36 274 pounds sterling |
| R. B. Tennent Ltd, Coatbridge | 26 000 ECU or 14 970 pounds sterling |
| Eisenwerk Sulzau-Werfen, R. &x E. Weinberger GmbH | 71 000 ECU or 1 127 352 Austrian schillings |
| AB Bofors Akers, Styckebruk | 100 000 ECU or 673 382 Swedish crowns |
| Société Chavanne-Delattre, Paris la Defense | 25 000 ECU or 172 347 French francs |
| Société Frangaise des Cylindres de Laminoirs J. Marichal, Ketin et Cie, Berlaimont | 25 000 ECU or 172 347 French francs |
| SARL Ateliers et Fonderies de Gorcy Paris | 12 500 ECU or 86 174 French francs |
| Usinor SA, Paris la Défense | 12 500 ECU or 86 174 French francs |

### Remedies
Cease and desist order to forthwith bring to an end the infringements established in Article 1.

### Company Recidivism
| company | recidivism |
| --- | --- |
| N. V. Griffin SA | True |
| SA des Fonderies J. Marichal, Ketin & Cie | True |
| SAFAK SA | True |
| Achenbach Buschhütten GmbH | True |
| Eduard Breitenbach GmbH | True |
| Leonhard Breitenbach Walzengieerei und Dreherei GmbH | True |
| Karl Buch WalzengieBerei | True |
| Gontermann-Peipers GmbH | True |
| Walzen Irle GmbH | True |
| Fried. Krupp GmbH | True |
| Walzengielßerei Roland GmbH | True |
| Thyssen Gieferei AG | True |
| Chambre syndicale des fabricants de cylindres en fonte | True |
| Societé Chavanne-Delattre | True |
| Societé frangaise des cylindres de laminoirs J. Marichal, Ketin & Cie | True |
| SARL Ateliers et fonderies de Gorcy | True |
| Usinor SA | True |
| Innocenti Santeustacchio SpA | True |
| Fonderie officine meccaniche San'Agostino SpA | True |
| Fonderia officina San Gregorio SAS | True |
| Fonderie San Zeno | True |
| The Davy Roll Company Ltd | True |
| Midland Rollmakers Ltd | True |
| R. B. Tennent Ltd | True |
| Eisenwerk Sulzau-Werfen R. & E. Weinberger GmbH | True |
| AB Bofors Akers | True |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRiESSEN

### Courts
| court                                                  | country        | jurisdiction                |
|:-------------------------------------------------------|:---------------|:----------------------------|
| B Kart A                                               | Germany        | Federal Republic of Germany |
| UK Restrictive Practices Court                         | United Kingdom | UK                          |
| Chambre Syndicale des Fabricants de Cylindres en Fonte | France         | Paris                       |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85 of the EEC Treaty, imposing fines and ordering cessation of the infringing conduct. The case is marked as an infringement case with high gravity.


*(reported: 2026-11-11 10:46:53)*

# 'IV/32.363', 'KSB/Goulds/Lowara/ITT'

**CELEX ID:** CELEX-31991D0038  
**Industry:** Industrial Pumps  
**Cartel Period:** 1985-11-05 : 1995-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0038 | IV/32363  |

### Case Title
KSB/Goulds/Lowara/ITT

### Overview
This case involves a cartel in the industrial pumps sector, where KSB Aktiengesellschaft, Goulds Pumps Inc., Lowara SpA, and ITT Fluid Handling Division engaged in anticompetitive joint ventures for pump development and production. The infringement was classified as an anticompetitive agreement under Article 85 with high gravity.

### Industry
Industrial Pumps

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 25.9:Manufacture of other fabricated metal products
NACE Class Code: 25.92: Manufacture of light metal packaging

### Companies Undertakings
| company                     |
|:----------------------------|
| KSB Aktiengesellschaft      |
| Goulds Pumps Inc.           |
| Lowara SpA                  |
| ITT Fluid Handling Division |

Countries:
- KSB Aktiengesellschaft: DE
- Goulds Pumps Inc.: US
- Lowara SpA: IT
- ITT Fluid Handling Division: US

### Market
Geographical: Entire Common Market
Market outside EU: True
Oligopoly: True
Market turbulence includes concerns over KSB's strong market position exceeding 20% in certain countries, slow market penetration of new pumps, uncertainty regarding consumer adoption of new stainless steel pumps compared to conventional ones, and potential monopolistic effects from the cooperation. Competitors fear market domination by the participating firms due to limited competition and exclusion of third-party access to know-how.

### Cartel Period
1985-08-16 : 1993-05-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-11-05 | Quattro Tech SA | formed joint venture for pump development |
| 1987-07-22 | KSB, Lowara, Goulds, ITT | concluded agreements for joint research, development and production |
| 1987-07-22 | ITT and Goulds | concluded new joint agreement |
| 1987-07-22 | parties | entered into agreement |
| 1988-06-01 | KsB | put pumps on the market |
| 1990-04-11 | Commission | indicated position on applications and afforded SIHI opportunity to express views |
| 1990-12-12 | Commission | issued Commission Decision |
| 1993-05-31 | KsB | exemption period ended |

### Legal Framework
Law Article Operative: Article 85
Law Article All Relevant: Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought and granted by the Commission.
Applicants:
| company           |
|:------------------|
| KSB AG            |
| Lowara SpA        |
| Goulds Pumps Inc. |
| ITT Corporation   |

### Leniency
No leniency applications were made in this case.

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 20:26:29)*

# 'IV/30.810', 'Synthetic fibres'

**CELEX ID:** CELEX-31984D0380  
**Industry:** | industry               |
|:-----------------------|
| Acrylic staple         |
| Polyester staple       |
| Polyamide staple       |
| Polyamide carpet yarn  |
| Polyamide textile yarn |
| Polyester textile yarn |  
**Cartel Period:** 1982-10-21 : 1985-12-31  

## Summary

### Celex Case Id
CELEX-31984D0380

### Case Title
Synthetic fibres

### Overview
This case involves a cartel among synthetic fibre producers operating in the European market from October 21, 1982, to December 31, 1985. The cartel engaged in horizontal restraints by exchanging information on prices and sales. The European Commission took action, initiated proceedings, and issued a decision on July 4, 1984. Remedies included refraining from sharing output data and not increasing capacity during the agreement's term. Fines were imposed including liability for damages of 2000 ECU per tonne of excess annual capacity and additional penalties for delays.

### Industry
Acrylic staple, Polyester staple, Polyamide staple, Polyamide carpet yarn, Polyamide textile yarn, Polyester textile yarn

### Oecd Nace
manufacturing, 20.6:Manufacture of man-made fibres, 20.60: Manufacture of man-made fibres

### Companies Undertakings
| companies                        |
|:---------------------------------|
| Imperial Chemical Industries plc |
| Courtaulds plc                   |
| Rhòne-Poulenc SA                 |
| Enka BV                          |
| Montefibre SpA                   |
| Anicfibre SpA                    |
| SNIA Fibre                       |
| Enka AG                          |
| Bayer AG                         |
| Hoechst AG                       |

### Market
Relevant market includes United Kingdom, Germany, France, Netherlands, Belgium, Italy, Austria, Switzerland, Spain, Portugal; outside EU; oligopoly; turbulence due to overcapacity, weak demand trend, increased import penetration, price instability, economic restructuring, social implications of capacity cuts

### Cartel Period
1982-10-21 : 1985-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-03-09 | producers | amended agreement |
| 1982-10-21 | European synthetic-fibre producers | signed an agreement on synthetic fibres |
| 1982-11-10 | producers | notified the Commission of the agreement |
| 1983-07-19 | producers | amended agreement |
| 1983-11-09 | Commission | initiated proceedings in this case |
| 1983-11-19 | Commission | published summary of agreement in Official Journal |
| 1984-07-04 | Commission | issued decision relating to synthetic fibres proceeding |
| 1985-12-31 | redacted | agreement expiry date moved forward |
| 1985-12-31 | redacted | agreement expired

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
True

### Book Reference
IV/30.810

### Outcome
The Commission ordered the signatories to refrain from communicating data on their individual output and deliveries of synthetic fibres either directly or through a trustee body or a third party. It also required the parties to not increase capacity during the agreement's term (until 31 December 1985). Additionally, pecuniary sanctions were imposed, including liability to pay damages of 2000 ECU per tonne of excess annual capacity and a further sum for each year of delay.


*(reported: 2026-11-11 10:51:34)*

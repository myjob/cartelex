# 'IV/28.838', 'INTERGROUP'

**CELEX ID:** CELEX-31975D0482  
**Industry:** retail food trade  
**Cartel Period:** 1973-01-01 : 1975-07-14  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0482 | IV/28838  |

### Case Title
INTERGROUP

### Overview
The European Commission investigated INTERGROUP TRADING B.V. and INTERNATIONALE SPAR CENTRALE BV for an anticompetitive agreement under Article 85 of the Treaty. The case involved retail food trade, specifically citrus fruits such as lemons, mandarins, pineapples, and pears. No infringement was found under Article 85(1), and no remedies were issued.

### Industry
retail food trade

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 01.2: Growing of perennial crops
NACE class code: 01.23: Growing of citrus fruits

### Companies Undertakings
| companies                       |
|:--------------------------------|
| INTERGROUP TRADING B.V.         |
| INTERNATIONALE SPAR CENTRALE BV |

### Market
| country        |
|:---------------|
| Netherlands    |
| United Kingdom |
| Germany        |
| Italy          |
| Austria        |
| France         |
| Spain          |
| Denmark        |
| Finland        |
| Ireland        |
| Portugal       |
| South Africa   |
| Rhodesia       |

market outside EU: no

### Cartel Period
1973-05-22 : 1975-07-14

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission of the European Communities | adopted Regulation No 17 |
| 1973-01-01 | redacted | began operations as intermediary |
| 1973-05-22 | INTERGROUP TRADING B.V. | concluded agreement with INTERNATIONALE SPAR CENTRALE BV |
| 1973-05-22 | ISC | concluded licensing agreement with INTERGROUP |
| 1973-12-28 | redacted | founded intergroup under dutch law |
| 1974-11-06 | Commission of the European Communities | published essential content of notification in Official Journal |
| 1975-01-29 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered Opinion on restrictive practices |
| 1975-07-14 | European Commission | issued decision concerning company statutes and agreement |
| 1975-07-14 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No remedies or orders were issued by the Commission as no infringement was found under Article 85(1) of the Treaty.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
François-Xavier Ortoli

### Courts
False

### Book Reference
NA

### Outcome
The Commission found no infringement under Article 85(1) of the Treaty, and thus no remedies or orders were issued.


*(reported: 2026-10-16 19:36:21)*

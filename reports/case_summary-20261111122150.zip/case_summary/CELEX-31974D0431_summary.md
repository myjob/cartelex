# 'IV/426', 'Papiers peints de Belgique'

**CELEX ID:** CELEX-31974D0431  
**Industry:** wallpaper manufacturing and distribution  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31974D0431 | IV/426    |

### Case Title
Papiers peints de Belgique

### Overview
This case involved a cartel in the wallpaper manufacturing and distribution industry in Belgium, where companies engaged in price fixing collusion. The European Commission investigated and took action against the anticompetitive practices under Article 85 of the Treaty on the Functioning of the European Union.

### Industry
wallpaper manufacturing and distribution

### Oecd Nace
OECD sector: manufacturing
NACE group code: 17.2:Manufacture of articles of paper and paperboard
NACE class code: 17.24: Manufacture of wallpaper

### Companies Undertakings
| companies                                               |
|:--------------------------------------------------------|
| Groupement des Fabricants de Papiers peints de Belgique |
| S.C. Usines Peters Lacroix S.A.                         |
| Les Papeteries de Genval S.A.                           |
| Etablissements Vanderborght Frères S.A.                 |
| Papiers peints Brepols S.A.                             |
| Mr Jean-Marie Pex                                       |
| G.B. Entreprises S.A.                                   |
| Rath & Doodeheefver S.A.                                |
| Interessengemeinschaft der Deutschen Tapetenfabrikanten |

### Market
Relevant market: Belgium, oligopoly structure, no turbulence

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-30 | De Coninck and Laine | sent Form B to Commission notifying anticompetitive practices |
| 1962-10-30 | Groupement des Fabricants de Papiers peints de Belgique | submitted notification |
| 1970-12-29 | Commission | made decision on aggregated rebates restricting competition |
| 1970-12-29 | Commission | issued decision on rebates |
| 1971-10-04 | Papiers peints de Brepols S.A. | severed business connections with wholesaler Pex due to price undercutting |
| 1971-10-29 | Groupement | ceased supplying Pex and International Decor |
| 1971-10-29 | Groupement | reminded customers of obligation to comply with fixed prices in Pex case |
| 1973-03-01 | Nivelles Tribunal de Commerce | delivered judgment pointing out illegality |
| 1973-06-14 | Commission | initiated proceeding in case |
| 1973-10-22 | Groupement | undercutting prices |
| 1973-10-26 | Commission | issued statement of objections |
| 1974-07-23 | Commission | issued decision

### Legal Framework
Legal framework: Article 85 (operative), infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| S.C. Usines Peters Lacroix S.A. | 135 000 units of account |
| Les Papeteries de Genval S.A. | 120 000 units of account |
| Ets. Vanderborght Frères S.A. | 36 000 units of account |
| Papiers peints Brepols S.A. | 67 500 units of account |

### Remedies
| value                                                                                                                                                                                                   |
|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| S.C. Usines Peters-Lacroix S.A. must terminate the infringement related to the Reglement d'ordre intérieur, Circulars 619, 620, 617 C and 617 V, and the refusal to supply Pex and International Decor. |
| Les Papeteries de Genval S.A. must terminate the infringement related to the Reglement d'ordre intérieur, Circulars 619, 620, 617 C and 617 V, and the refusal to supply Pex and International Decor.   |
| Ets. Vanderborght Frères S.A. must terminate the infringement related to the Reglement d'ordre intérieur, Circulars 619, 620, 617 C and 617 V, and the refusal to supply Pex and International Decor.   |
| Papiers peints Brepols S.A. must terminate the infringement related to the Reglement d'ordre intérieur, Circulars 619, 620, 617 C and 617 V, and the refusal to supply Pex and International Decor.     |

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                         | country   | jurisdiction   |
|:------------------------------|:----------|:---------------|
| Nivelles Tribunal de Commerce | Belgium   | Belgium        |

### Book Reference
IV/426

### Outcome
The European Commission found the companies guilty of engaging in anticompetitive practices under Article 85, imposed fines, and ordered the termination of the infringement. The case was part of a broader investigation into cartel activity in the wallpaper industry.


*(reported: 2026-11-11 10:06:04)*

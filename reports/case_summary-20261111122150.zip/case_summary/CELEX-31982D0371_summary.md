# 'IV/29.995 —NAVEWA-ANSEAU', 'Extra alloy'

**CELEX ID:** CELEX-31982D0371  
**Industry:** NA  
**Cartel Period:** 1978 : 1979  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0371 | IV/29995  |

### Case Title
IV/29.995 — NAVEWA-ANSEAU

### Overview
The European Commission investigated an anticompetitive agreement concerning the NAVEWA-ANSEAU conformity label for domestic appliances, including washing machines, dishwashers, refrigerators, freezers, and industrial catering equipment. The agreement was found to restrict competition in breach of Article 85 of the EEC Treaty.

### Industry
Domestic appliances (washing machines, dishwashers, refrigerators, freezers, industrial catering equipment)

### Oecd Nace
OECD sector: manufacturing
NACE group code: 27.5: Manufacture of domestic appliances
NACE class code: 27.51: Manufacture of electric domestic appliances

### Companies Undertakings
| company                                                                                          |
|:-------------------------------------------------------------------------------------------------|
| Communauté de l'Électricité (CEG)                                                                |
| Fédération du Commerce de l'Appareillage Électrique (FCAE-FHEA)                                  |
| Union des Fournisseurs des Artisans de l'Alimentation - Division Grandes Cuisines (UFARAL-ULEVO) |
| Association Nationale des Services d'Eau (ANSEAU-NAVEWA)                                         |
| Bauknecht                                                                                        |
| ACFC                                                                                             |
| AEG                                                                                              |
| Philips                                                                                          |
| Miele                                                                                            |
| Van Assche                                                                                       |
| Associated Consumer Brands                                                                       |
| Bosch                                                                                            |
| Hoover                                                                                           |
| Zanker                                                                                           |
| Despagne                                                                                         |
| Disem-Andries                                                                                    |
| Asogem                                                                                           |
| Hobart                                                                                           |
| Artsel                                                                                           |
| IAZ                                                                                              |
| Indesit                                                                                          |
| Electrolux-Martin                                                                                |
| Siemens                                                                                          |
| Van Maercke                                                                                      |
| Bell-Telephone                                                                                   |
| BBC Hausgeräte GmbH (succ. belge)                                                                |
| SBR                                                                                              |
| GB-INNO-BM                                                                                       |
| Olympia                                                                                          |
| Expert                                                                                           |
| Primus                                                                                           |
| Mench                                                                                            |
| Novolec                                                                                          |
| Saltini                                                                                          |
| Vox                                                                                              |
| Ets. Abel Falisse                                                                                |
| Werkhuizen Fobelets                                                                              |
| Le Chauffage                                                                                     |
| Santos Palace                                                                                    |
| Ets. Meurice                                                                                     |

### Market
Geographical market: Belgium, Luxembourg
Outside EU: False
Oligopoly: NA
Turbulence: NA

### Cartel Period
1978 : 1979

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-12-13 | parties involved | concluded Agreement concerning NAVEWA-ANSEAU conformity label |
| 1979-01-01 | CEG | implemented Agreement governing NAVEWA-ANSEAU conformity label for washing machines and dishwashers |
| 1979-12-31 | ANSEAU | transitional period ends |
| 1980-11-14 | Commission | initiated proceeding under Article 85 of EEC Treaty |
| 1981-12-17 | Commission | issued Decision relating to proceeding under Article 85

### Legal Framework
Law article operative: Article 85
Law articles all relevant:
| law_article   |
|:--------------|
| Article 85    |
| Article 90    |
Canonical concept: anticompetitive_agreement, public_undertaking

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Despagne | 1583455 |
| Asogem | 1583455 |
| Hobart | 1583455 |
| Indesit | 1583455 |
| Bell-Telephone | 1583455 |
| BBC Hausgerate GmbH (succ. belge) | 1583455 |
| Van Assche | 3146346 |
| Hoover | 3146346 |
| Zanker | 3146346 |
| Disem-Andries | 3146346 |
| Artsel | 3146346 |
| IAZ | 3146346 |
| Electrolux-Martin | 3146346 |
| Siemens | 3146346 |
| Van Maercke | 3146346 |
| Bauknecht | 3146346 |
| ACEC | 3146346 |
| AEG | 3146346 |
| Philips | 3146346 |
| Miele | 3146346 |
| Associated Consumer Brands | 3146346 |
| Bosch | 3146346 |

### Remedies
The parties to the Agreement shall forthwith bring to an end the infringements established in Article 1. They shall amend the Agreement in such a way that it does not prevent importers other than sole importers from obtaining the NAVEWA-ANSEAU conformity labels directly. ANSEAU shall take all measures necessary to ensure that such importers may obtain the labels direct from ANSEAU itself, without having to recognize the CEG as their representative, and on non-discriminatory terms by comparison with those granted to manufacturers and sole importers. These amendments and measures must be communicated to the Commission within two months of the notification of this Decision.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
True

### Book Reference
NA

### Outcome
The Commission found that the agreement violated Article 85 of the EEC Treaty. Fines were imposed on several companies, and remedies were ordered to end the infringement and ensure non-discriminatory access to conformity labels.


*(reported: 2026-11-11 10:40:27)*

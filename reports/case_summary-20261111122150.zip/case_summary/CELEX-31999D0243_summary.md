# 'NA', 'NA'

**CELEX ID:** CELEX-31999D0243  
**Industry:** NA  
**Cartel Period:** 1992-08-28 : 1995-03-09  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0243 | IV/35134  |

### Case Title
NA

### Overview
This case involves a cartel of maritime shipping companies engaged in price-fixing collusion, violating Articles 85 and 86 of the EC Treaty. The infringement occurred between 1992 and 1995, with the Commission taking action in 1998.

### Industry
Transport

### Oecd Nace
OECD Sector: transport
NACE Group Code: 20.5: Manufacture of other chemical products
NACE Class Code: 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| companies                                 | location   |
|:------------------------------------------|:-----------|
| A.P. Mùller-Maersk Line                   | NA         |
| Atlantic Container Line AB                | NA         |
| Hapag-Lloyd AG                            | NA         |
| Nedlloyd Lijnen BV                        | NA         |
| P&O Containers Limited                    | NA         |
| Sea-Land Service, Inc.                    | NA         |
| Mediterranean Shipping Co.                | NA         |
| Orient Overseas Container Line (UK) Ltd   | NA         |
| Polish Ocean Lines                        | NA         |
| DSR/Senator Lines                         | NA         |
| Cho Yang Shipping Co., Ltd                | NA         |
| Neptune Orient Lines Ltd                  | NA         |
| Nippon Yusen Kaisha                       | NA         |
| Transportación Marítima Mexicana SA de CV | NA         |
| Tecomar SA de CV                          | NA         |
| P&O Nedlloyd Container Line Ltd           | NA         |
| Hapag Lloyd Container Linie GmbH          | NA         |
| Hanjin Shipping Co., Ltd                  | NA         |

### Market
Geographical: Northern Europe
Oligopoly: True
Turbulence: NA

### Cartel Period
1992-08-28 : 1995-03-09

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-08-28 | Commission | notified Trans-atlantic Agreement |
| 1992-08-28 | redacted | notification of the TAA |
| 1994-07-05 | TACA parties | offered to make undertakings to the Commission including producing interim reports on capacity and demand |
| 1994-07-05 | TACA parties | offered to notify business plans and rate modifications three months before their entry into force |
| 1994-07-05 | TACA parties | offered to review rate modifications causing substantial competitive disadvantage and refer unresolved matters to a panel of representatives |
| 1994-07-05 | TACA parties | offered not to exchange confidential business information with other carriers except for rationalising services |
| 1994-07-05 | TACA parties | offered to provide quarterly reports to the Commission on the operation of the Agreement |
| 1994-07-05 | TACA parties | offered to inform the Commission of any contacts with other carriers concerning price-fixing or capacity regulation |
| 1994-07-05 | TACA parties | notified Commission of TACA |
| 1994-07-05 | redacted | filed application for exemption |
| 1994-07-05 | redacted | notification of the TACA |
| 1995-03-09 | TACA parties | amended TACA to allow individual service contracts without approval of five other parties |
| 1995-03-09 | TACA parties | agreed with American Federal Maritime Commission to reduce tariff and service contract rates for remainder of 1995 |
| 1996-03-01 | Commission | adopted supplementary Statement of Objections addressing TACA parties |
| 1996-05-24 | Commission | adopted Statement of Objections addressing TACA parties |
| 1997-01-01 | TACA parties | notified implementation of hub-and-spoke system with effect from 1 January 1997 |
| 1998-09-16 | Commission of the European Communities | issued Commission Decision relating to a proceeding pursuant to Articles 85 and 86 of the EC Treaty |

### Legal Framework
Law Articles: Article 85, Article 86
Canonical Concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
| company |
| --- |
| A.P. Mùller-Maersk Line |
| Atlantic Container Line AB |
| Hapag-Lloyd AG |
| Nedlloyd Lijnen BV |
| P&O Containers Limited |
| Sea-Land Service, Inc. |
| Mediterranean Shipping Co. |
| Orient Overseas Container Line (UK) Ltd |
| Polish Ocean Lines |
| DSR/Senator Lines |
| Cho Yang Shipping Co., Ltd |
| Neptune Orient Lines Ltd |
| Nippon Yusen Kaisha |
| Transportación Marítima Mexicana SA de CV |
| Tecomar SA de CV |

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| A.P. Moller-Maersk Line Atlantic Container Line AB | 27500000 |
| Hapag Lloyd Container Linie GmbH | 20630000 |
| P&O Nedlloyd Container Line Limited | 41260000 |
| Sea-Land Service, Inc. | 27500000 |
| Mediterranean Shipping Co. | 13750000 |
| Polish Ocean Lines | 6880000 |
| DSR/Senator Lines | 13750000 |
| Cho Yang Shipping Co., Ltd | 13750000 |
| Neptune Orient Lines Ltd | 13750000 |
| Nippon Yusen Kaisha | 20630000 |
| Transportación Marítima Mexicana S.A. de CV/Tecomar S.A. de CV | 6880000 |
| Hanjin Shipping Co., Ltd | 20630000 |
| Hyundai Merchant Marine Co., Ltd | 18560000 |

### Remedies
Cease and desist orders from putting an end to infringements, refrain from future agreements or concerted practices of same or similar object or effect; inform customers with whom they have concluded joint service contracts that those customers are entitled to renegotiate the terms of those contracts or terminate them forthwith; impose fines on specific undertakings.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| DSR/Senator Lines ECU 13 750 000 Cho Yang Shipping Co., Ltd ECU 13 750 000 Neptune Orient Lines Ltd ECU 13 750 000 Nippon Yusen Kaisha ECU 20 630 000 Transportación Marítima Mexicana S.A. de CV/Tecomar S.A. de CV ECU 6 880 000 Hanjin Shipping Co., Ltd ECU 20 630 000 Hyundai Merchant Marine Co., Ltd ECU 18 560 000 | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                  | country        | jurisdiction           |
|:---------------------------------------|:---------------|:-----------------------|
| Court of Justice of the European Union | European Union | European Union         |
| COMMISSION                             | European Union | European Economic Area |

### Book Reference
NA

### Outcome
The Commission issued a decision finding violations under Articles 85 and 86 of the EC Treaty, imposing fines and ordering remedies to cease the infringing practices.


*(reported: 2026-11-11 11:59:22)*

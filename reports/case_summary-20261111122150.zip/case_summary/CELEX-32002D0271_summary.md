# 'COMP/E-1/36.490', 'Graphite electrodes'

**CELEX ID:** CELEX-32002D0271  
**Industry:** | industry            |
|:--------------------|
| graphite electrodes |
| carbon products     |
| steel               |
| aluminium           |
| chemicals           |
| electronics         |
| inorganic materials |  
**Cartel Period:** 1991-11-12 : 1998-02-13  

## Summary

### Celex Case Id
CELEX-32002D0271

### Case Title
COMP/E-1/36.490 – Graphite electrodes

### Overview
This case involves a cartel among international producers of graphite electrodes, operating from 1991 to 1998. The cartel engaged in horizontal restraints including price-fixing and market allocation. The European Commission investigated the infringement under Article 81 of the Treaty, finding high gravity. Leniency applicants received reductions, while VAW Carbon was rejected. Fines were imposed on all companies involved, with significant penalties. Remedies ordered include immediate cessation of infringing conduct and refraining from repeating such actions.

### Industry
graphite electrodes, carbon products, steel, aluminium, chemicals, electronics, inorganic materials

### Oecd Nace
manufacturing (OECD sector), 28.91: Manufacture of machinery for metallurgy (NACE class code)

### Companies Undertakings
| SGL Carbon AG (DE) |
| UCAR International Inc. (US) |
| VAW Aluminium AG (CH) |
| Showa Denko K.K. (JP) |
| Tokai Carbon Co. Ltd (JP) |
| Nippon Carbon Co. Ltd (JP) |
| SEC Corporation (US) |
| The Carbide Graphite Group Inc. (US) |

### Market
Relevant market in EU countries including Germany, France, Italy, Spain, Austria, Belgium, Netherlands, Portugal, Greece, United Kingdom, Denmark, Finland, Luxembourg, Ireland, Sweden, Norway; outside EU market exists; oligopoly structure

### Cartel Period
1991-11-12 : 1998-02-13

### Key Timeline
| 1991-11-12 | competitors | agreed on price implementation measures |
| 1992-01-01 | VAW Carbon | participated in regular meetings planning and implementing a cartel |
| 1992-05-21 | top executives of major graphite electrode producers | met in London and agreed on structure and operation of worldwide cartel |
| 1992-05-25 | VAW Carbon | attended first Working Level meeting in Zurich allocating markets and producing price list |
| 1992-06-03 | SGL, UCAR | agreed on target prices for EEA market during price-fixing meeting |
| 1993-01-01 | UCAR and SGL | agreed on European prices using German mark as reference currency |
| 1994-01-01 | cartel | operated in violation of Article 53(1) EEA Agreement and Article 81(1) Treaty |
| 1996-01-01 | SGL | communicated price increase and requested sales restraint in Europe |
| 1996-07-01 | redacted | increased price to DEM 5,400 |
| 1998-01-01 | UCAR | implemented price increase |
| 1998-02-13 | SGL, UCAR and Japanese producers | attended last Working Level meeting |
| 1998-06-18 | purchasers | instituted civil proceedings |
| 2000-01-24 | Commission | sent Statement of Objections |
| 2001-07-18 | redacted | decision issued |

### Legal Framework
Article 81 (operative), Article 81 (all relevant); anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
False

### Leniency
| SDK | 70% |
| Tokai | 10% |
| SEC | 10% |
| Nippon | 10% |
| SGL | 30% |
| UCAR | 40% |
| VAW Aluminium AG | 20% |
| C/G | 20% |

### Fines
| SGL Carbon AG | EUR 80.29 million |
| UCAR International Inc. | EUR 84.1 million |
| VAW Aluminium AG | EUR 11.6 million |
| Showa Denko K.K. | EUR 17.4 million |
| Tokai Carbon Co. Ltd | EUR 24.5 million |
| Nippon Carbon Co. Ltd | EUR 12.2 million |
| SEC Corporation | EUR 12.2 million |
| The Carbide Graphite Group Inc. | EUR 10.3 million |

### Remedies
To immediately bring the infringement to an end, in so far as they have not already done so; to refrain from repeating any act or conduct referred to in Article 1; and to refrain from adopting any measure having equivalent object or effect

### Company Recidivism
| SGL Carbon AG | True |
| UCAR International Inc. | True |
| VAW Aluminium AG | True |
| Showa Denko K.K. | True |
| Tokai Carbon Co. Ltd | True |
| Nippon Carbon Co. Ltd | True |
| SEC Corporation | True |
| The Carbide Graphite Group Inc. | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| Court of First Instance | European Union | European Union |
| United States District Court | United States | Federal |

### Book Reference
COMP/E

### Outcome
Decision issued by the European Commission under Mario Monti's signature; fines imposed on all companies involved; remedies ordered to immediately end infringement and refrain from repeating such conduct


*(reported: 2026-11-11 12:11:13)*

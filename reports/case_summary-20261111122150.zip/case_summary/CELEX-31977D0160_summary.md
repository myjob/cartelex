# 'IV/27.442', 'Vacuum Interrupters Ltd'

**CELEX ID:** CELEX-31977D0160  
**Industry:** Electrical Equipment  
**Cartel Period:** 1970-03-25 : 1980-03-25  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31977D0160 | IV/27442-1 |

### Case Title
Vacuum Interrupters Ltd

### Overview
This case involves an anticompetitive agreement in the vacuum interrupter market, which is part of the electrical equipment industry. The European Commission investigated several UK-based companies for their involvement in a cartel that lasted from 1970 to 1980.

### Industry
Electrical Equipment

### Oecd Nace
manufacturing
NACE group code: 27.9
NACE class code: 27.90

### Companies Undertakings
| companies                                               |
|:--------------------------------------------------------|
| Vacuum Interrupters Ltd                                 |
| Associated Electrical Industries Ltd                    |
| Reyrolle Parsons Ltd                                    |
| The General Electric Co. Ltd                            |
| The English Electric Co. Ltd                            |
| A. Reyrolle and Co. Ltd                                 |
| The General Electric and English Electric Companies Ltd |

### Market
United Kingdom
market outside EU: True
market oligopoly: True

### Cartel Period
1970-03-25 : 1980-03-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1967-12-04 | Associated Electrical Industries Ltd | became subsidiary of The General Electric Co. Ltd |
| 1970-03-25 | Associated Electrical Industries Ltd and Reyrolle Parsons Ltd | entered into agreement restricting competition in vacuum interrupter market |
| 1972-11-17 | Vacuum Interrupters Ltd | incorporated and bound by agreement of 28 March 1970 |
| 1972-11-24 | Vacuum Interrupters Ltd | submitted further agreement |
| 1973-06-28 | Vacuum Interrupters Ltd | notified the agreement |
| 1976-08-04 | Commission | published summary of the notification in Official Journal |
| 1976-08-04 | Commission | published notice in Official Journal |
| 1976-10-19 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion |
| 1977-01-20 | R. VOUEL | signed by Commission |
| 1980-03-25 | redacted | expired |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
high

### Exemption
| company                              |
|:-------------------------------------|
| Associated Electrical Industries Ltd |
| Reyrolle Parsons Ltd                 |

### Leniency
NA

### Fines
NA

### Remedies
The Commission granted an exemption for Vacuum Interrupters Ltd from 1 January 1973 to 25 March 1980 under Article 85(3). The exemption is conditional upon Vacuum Interrupters Ltd notifying the Commission within 28 days of any changes in share capital or ownership, and any authorization from AEI or RP allowing it to carry on other businesses.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
False

### Commissioner
R. VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption for Vacuum Interrupters Ltd under Article 85(3) with specific conditions, while no action was taken against the other companies involved in the cartel.


*(reported: 2026-10-16 21:57:15)*

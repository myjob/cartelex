# 'COMP/33.133-B', 'Soda-ash  Solvay, CFK'

**CELEX ID:** CELEX-32003D0005  
**Industry:** | industry            |
|:--------------------|
| synthetic soda ash  |
| glass manufacturing |
| chemical industry   |  
**Cartel Period:** 1986 : 1990-07  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32003D0005 | IV/39003  |

### Case Title
COMP/33.133-B – Soda-ash

### Overview
The case involves the European Commission's investigation into anticompetitive agreements and abuse of dominance in the synthetic soda ash market, involving Solvay SA and CFK. The infringement occurred between 1986 and July 1990, with horizontal restraints such as market sharing and quota cartels.

### Industry
synthetic soda ash, glass manufacturing, chemical industry

### Oecd Nace
manufacturing; 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
| companies   |
|:------------|
| Solvay SA   |
| CFK         |

| companies_investigated | country |
| --- | --- |
| Solvay SA | BE |
| CFK | DE |

### Market
Germany, France, Belgium, Italy, Spain, Portugal, Austria; oligopoly market; no turbulence

### Cartel Period
1986 : 1990-07

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1989-03-14 | CFK/Kali & Salz and DSW | held meeting to resolve retrospective compensation issue |
| 1989-03-14 | Solvay | discussed acquisition of interest in CFK's soda activities and indicated intention to help CFK survive |
| 1990-02-19 | Commission | opened a proceeding on its own initiative pursuant to Article 3 of Regulation No 17 |
| 1990-07-01 | most producers | raised list prices to USD 98/short ton |
| 1990-12-19 | Commission | adopted decision finding infringement and imposing fines |
| 1991-05-02 | Solvay | brought action for annulment before Court of First Instance |
| 1992-02-27 | Court of First Instance | delivered judgment in Joined Cases T-79/89, 84/89, etc. |
| 1995-06-29 | Court of First Instance | delivered judgment in Case T-31/91 Solvay v Commission |
| 1995-08-30 | Commission | appealed to Court of Justice |
| 1999-04-20 | Court of First Instance | upheld Commission's interpretation of regulation and right to re-adopt decisions |
| 2000-04-06 | Court of Justice | dismissed Commission's appeal in Joined Cases C-287/95 and C-288/95 |
| 2000-12-13 | Commission | issued Decision relating to a proceeding under Article 81 of the EC Treaty |

### Legal Framework
| law_article |
| --- |
| Article 81 |
| Article 85 |

The operative articles are Article 81 and Article 85. The canonical concept is abuse_of_dominance, anticompetitive_agreement.

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Ansac sought exemption

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Solvay SA | EUR 3 million |

### Remedies
A fine of EUR 3 million is imposed on Solvay

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Solvay SA | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                   | country            | jurisdiction   |
|:------------------------|:-------------------|:---------------|
| Court of Justice        | European Union     | European Union |
| Court of First Instance | European Union     | European Union |
| Commission              | European Community | EC Treaty      |

### Book Reference
NA

### Outcome
The Commission found infringement and imposed a EUR 3 million fine on Solvay. The Court of Justice upheld the Commission's decision, dismissing its appeal.


*(reported: 2026-11-11 12:14:33)*

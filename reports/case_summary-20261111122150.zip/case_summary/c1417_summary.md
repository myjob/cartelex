# 'IV/35.613', 'Alpha Flight Services/Aéroports de Paris'

**CELEX ID:** c1417  
**Industry:** | industry                 |
|:-------------------------|
| airport management       |
| ground handling services |
| airline catering         |  
**Cartel Period:** 1992 : 1996  

## Summary

### Celex Case Id
| celex_id   | case_id   |
|:-----------|:----------|
| c1417      | IV/35613  |

### Case Title
Alpha Flight Services/Aéroports de Paris

### Overview
This case involves a cartel investigation in the airport ground handling services sector in France, focusing on anti-competitive practices by Aéroports de Paris (ADP) and several other companies. The cartel period spanned from 1992 to 1996.

### Industry
airport management, ground handling services, airline catering

### Oecd Nace
OECD sector: transport; NACE group code: 52.2: Support activities for transportation; NACE class code: 52.23: Service activities incidental to air transportation

### Companies Undertakings
| company                        |
|:-------------------------------|
| Aéroports de Paris             |
| Alpha Flight Services S.A.R.L. |
| Orly Air Traiteur              |
| Servair                        |
| Skychef                        |
| France Handling                |
| SFS                            |
| Witra                          |
| Trafic                         |
| Air France                     |
| Air Canada                     |
| JAL                            |
| TWA                            |
| FedEx                          |
| UPS                            |
| Aéropostale                    |
| Lufthansa                      |
| Alitalia                       |
| Swissair                       |
| Forte Airport Services         |
| LaToqueDorée                   |
| SAP                            |
| HRS                            |
| ACNA                           |
| Euronetec                      |

### Market
France, not an outside EU market, not an oligopoly, turbulence status: NA

### Cartel Period
1992 : 1996

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-05-21 | ADP and Forte Airport Services | signed 25-year concession agreement |
| 1992-07-17 | ADP | reminded airlines at Orly about authorization granted to LaToqueDorée |
| 1993-02-26 | AFS and ADP | agreed on reducing the commercial fee rate |
| 1993-12-29 | AFS | informed ADP of unequal royalty rates for competing providers |
| 1994-05-31 | ADP | responded to AFS's request for stricter control measures |
| 1994-05-31 | ADP | responded to AFS's request by stating the rate reduction resulted in equivalent levels |
| 1995-05-24 | ADP | informed AFS that its request for authorization at CDG could not be accepted |
| 1995-06-22 | AFS | filed formal complaint with Commission against ADP |
| 1996-12-04 | Commission | adopted notice of complaints against ADP under Article86 of the Treaty |
| 1996-12-24 | ADP | responded to AFS and instructed services to terminate non-compliant practice |
| 1997-02-28 | ADP | submitted observations on the notice of complaints |
| 2002-12-31 | Directive 96/67/EC | ended gradual opening of access to ground-handling market |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought

### Leniency
No leniency applicants or grants; no rejections noted.

### Fines
NA

### Remedies
Aéroports de Paris must offer a non-discriminatory commercial fee regime to ground handling service providers before the expiry of a period of two months from the notification of this decision.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
NA

### Commissioner
Karel Van Miert

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | France    | European Union |

### Book Reference
NA

### Outcome
The Commission took action against Aéroports de Paris under Article 86 of the Treaty, and a remedy was imposed requiring a non-discriminatory commercial fee regime.


*(reported: 2026-11-11 12:20:44)*

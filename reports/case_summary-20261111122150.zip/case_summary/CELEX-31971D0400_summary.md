# 'NA', 'NA'

**CELEX ID:** CELEX-31971D0400  
**Industry:** | industry               |
|:-----------------------|
| pharmaceuticals        |
| chemicals              |
| agricultural chemicals |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
NA

### Case Title
NA

### Overview
This case involves cartel activities in the pharmaceutical and chemical industries, specifically focusing on agreements related to quinine, quinidine, and chinchona products. The companies involved are from Germany and China, with Boehringer Mannheim GmbH being a repeat offender.

### Industry
pharmaceuticals, chemicals, agricultural chemicals

### Oecd Nace
manufacturing (OECD), 21.1:Manufacture of basic pharmaceutical products (NACE)

### Companies Undertakings
| companies                                   |
|:--------------------------------------------|
| Boehringer Mannheim GmbH                    |
| Vereinigte Chininfabriken Zimmer & Co. GmbH |
| Nedchem                                     |
| Buchler                                     |
| United China Factories Zimmer & Co. GmbH    |

### Market
United States, oligopolistic market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-04-07 | parties | entered into gentlemen's agreements |
| 1969-07-16 | Commission of the European Communities | imposed a fine on Boehringer MannheimGmbH |
| 1970-07-15 | Court of Justice of the European Communities | reduced the fine imposed by the Commission |
| 1971-11-25 | Commission of the European Communities | made a decision concerning a procedure under Article 85 of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Boehringer Mannheim GmbH | $80,000 |
| Boehringer Mannheim GmbH | 180000 accounting units |

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Boehringer Mannheim GmbH | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
NA

### Commissioner
NA

### Courts
| court                                            | country        | jurisdiction   |
|:-------------------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union           | European Union | European Union |
| US District Court, Southern District of New York | United States  | Federal        |

### Book Reference
NA

### Outcome
The Commission imposed a fine on Boehringer Mannheim GmbH in 1969, which was later reduced by the Court of Justice in 1970. A final decision was made by the Commission in 1971 under Article 85 of the EEC Treaty.


*(reported: 2026-11-11 09:54:31)*

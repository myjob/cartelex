# 'IV/412', 'ASBL for the promotion of electrically welded steel tube'

**CELEX ID:** CELEX-31970D0346  
**Industry:** | industry                        |
|:--------------------------------|
| electrically welded steel pipes |
| electrically welded steel pipes |
| electrically welded steel pipes |
| electrically welded steel pipes |  
**Cartel Period:** 1962-05-23 : 1970-06-29  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31970D0346 | IV/412    |

### Case Title
ASBL for the promotion of electrically welded steel tube

### Overview
This case involved several companies in the electrically welded steel pipe industry based in Belgium and Luxembourg. The companies submitted applications for a negative test, and an opinion was submitted by the Advisory Committee for Cartel and Monopoly Issues before the Commission issued its decision on 1970-06-29 under Article 85(1) of the Treaty establishing the European Economic Community.

### Industry
electrically welded steel pipes

### Oecd Nace
manufacturing
24.2:Manufacture of tubes, pipes, hollow profiles and related fittings, of steel
24.20: Manufacture of tubes, pipes, hollow profiles and related fittings, of steel

### Companies Undertakings
| companies                                                                            | location       |
|:-------------------------------------------------------------------------------------|:---------------|
| Société anonyme des Usines à tubes de la Meuse                                       | Flémalle-Haute |
| Aciéries Reunies de Burbach-Eich-Dudelange, Arbed                                    | Luxembourg     |
| Société anonyme des Tubes de Nimy                                                    | Nimy-lez-Mons  |
| Ateliers Remy Claeys                                                                 | Lichtervelde   |
| Association sans but lucratif pour la promotion du tube d'acier soudé électriquement | Brussels       |

### Market
Belgium, Luxembourg
Oligopoly market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-30 | Société anonyme des Usines à tubes de la Meuse, Société anonyme des Hauts Fourneaux et Aciéries de Differdange, Société anonyme des Tubes de Nimy, Ateliers Remy Claeys | submitted application for negative test |
| 1970-03-18 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion on the case |
| 1970-06-29 | Commission | issued decision under Article 85(1) of the Treaty establishing the European Economic Community |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission as it found no grounds for intervention under Article 85(1) of the Treaty.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/412

### Outcome
The Commission found no grounds for intervention under Article 85(1) of the Treaty establishing the European Economic Community.


*(reported: 2026-10-16 19:01:36)*

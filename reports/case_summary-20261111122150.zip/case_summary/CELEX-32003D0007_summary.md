# 'COMP/33.133-D', 'Soda-ash ICI'

**CELEX ID:** CELEX-32003D0007  
**Industry:** soda-ash  
**Cartel Period:** 1981 : 1989-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32003D0007 | IV/39046  |

### Case Title
COMP/33.133-D – Soda-ash ICI

### Overview
The case involves Imperial Chemical Industries plc (ICI) for abuse of dominance and anticompetitive agreements in the soda-ash market. The infringement occurred between 1981 and 1989, with various agreements and price adjustments documented over time.

### Industry
soda-ash; glass; detergents

### Oecd Nace
manufacturing; 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
Imperial Chemical Industries plc (GB)

### Market
United Kingdom; outside the EU; not oligopolistic

### Cartel Period
1981 : 1989-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-04-01 | ICI | signed agreement |
| 1982-12-14 | ICI | ceased offering total requirements contracts terminable at short notice and amended non-competition clauses |
| 1985-11-12 | ICI | confirmed oral agreement for 1986 supply terms including rebate |
| 1985-11-18 | ICI | increased prices by 6.5% and unofficially raised minimum-price undertaking to GBP 120 |
| 1988-04-01 | ICI | set out 24-month agreement |
| 1989-02-28 | Rockware | agreed with ICI to cease all Polish purchases |
| 1990-01-01 | ICI | abandoned system of top-slice rebates |
| 1990-02-19 | Commission | opened a proceeding under Article 3 of Regulation No 17 |
| 1990-12-19 | Commission | adopted Decision 91/300/EEC finding infringement by ICI |
| 1991-05-14 | ICI | applied to Court of First Instance for annulment of decision |
| 1992-02-27 | Court of First Instance | ruled on Joined Cases T-79/89, 84/89, 85/89, 86/89, 89/89, 91/89, 92/89, 94/89, 96/89, 98/89, 102/89 and C-104/89 |
| 1995-06-29 | Court of First Instance | delivered judgment |
| 2000-12-13 | Commission | issued a decision in the proceeding |

### Legal Framework
| law_article |
| --- |
| Article 82 |
| Article 86 |

| law_article   |
|:--------------|
| Article 81    |
| Article 82    |
| Article 86    |

abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse of dominance, anticompetitive agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought by Ansac

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Imperial Chemical Industries plc | EUR 10 million |

### Remedies
A fine of EUR 10 million is imposed on ICI in respect of the infringement specified in Article 1.

### Company Recidivism
Imperial Chemical Industries plc (True)

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                   | country        | jurisdiction   |
|:------------------------|:---------------|:---------------|
| Court of First Instance | European Union | European Union |
| Court of Justice        | European Union | European Union |
| European Commission     | Belgium        | European Union |

### Book Reference
NA

### Outcome
ICI was fined EUR 10 million for abuse of dominance and anticompetitive agreements. The case involved multiple court proceedings, including a ruling by the Court of First Instance.


*(reported: 2026-11-11 12:15:16)*

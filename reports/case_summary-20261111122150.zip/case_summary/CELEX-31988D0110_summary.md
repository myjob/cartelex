# 'IV/27.093', 'De Laval-Stork'

**CELEX ID:** CELEX-31988D0110  
**Industry:** | industry                      |
|:------------------------------|
| turbine                       |
| compressor                    |
| boiler-feed pump              |
| heavy equipment manufacturing |
| light machinery               |  
**Cartel Period:** 1977-01-01 : 1986-12-01  

## Summary

### Celex Case Id
CELEX-31988D0110

### Case Title
De Laval-Stork

### Overview
The case involves a joint venture between De Laval Turbine International Inc. (US) and Koninklijke Machinefabriek Stork BV (NL), later expanded to include other entities, which was found to have engaged in anticompetitive behavior under Article 85 of the EC Treaty. The venture operated from 1971 to 1986, with the Commission being notified in 1973 and issuing a decision in 1987. Exemption was sought and granted for several applicants. Some companies involved had prior infringement history (recidivism).

### Industry
turbine, compressor, boiler-feed pump, heavy equipment manufacturing, light machinery

### Oecd Nace
manufacturing, 28.9:Manufacture of other special-purpose machinery, 28.99: Manufacture of other special-purpose machinery n.e.c.

### Companies Undertakings
| companies                                       |
|:------------------------------------------------|
| De Laval Turbine International Inc.             |
| Koninklijke Machinefabriek Stork BV             |
| Stork Roterende Werktuigen BV                   |
| De Laval-Stork VOF                              |
| De Laval Turbine Incorporated                   |
| Imo Delaval Inc.                                |
| Verenigde Machinefabrieken NV (VMF)             |
| Verenigde Machinefabrieken Stork NV (VMF Stork) |

### Market
Netherlands, USA; outside EU; no oligopoly; worldwide recession, production overcapacity, fierce competition from Japan, tendency to buy domestic products, fall of the U.S. dollar, fire damage in 1978

### Cartel Period
1971-09-01 : 1986-09-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-09-01 | Stork | entered into agreements with De Laval to create joint venture |
| 1973-03-02 | Stork | notified Commission of the agreements under Article 4 |
| 1986-07-02 | Stork and De Laval | applied for renewal of exemption under Article 8(2) |
| 1986-09-01 | Commission | published summary of agreements and changes |
| 1987-12-22 | Commission | issued decision on the proceeding |
| 2006-09-01 | Commission | renewing the decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
| company                                     |
|:--------------------------------------------|
| De Laval Turbine International Incorporated |
| Koninklijke Machinefabriek Stork BV         |
| Stork Roterende Werktuigen BV               |
| De Laval-Stork VOF                          |

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies                                                                                                                           | recidivism   |
|:------------------------------------------------------------------------------------------------------------------------------------|:-------------|
| De Laval Turbine International Incorporated, Koninklijke Machinefabriek Stork BV, Stork Roterende Werktuigen BV, De Laval-Stork VOF | True         |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
R&D joint ventures

### Outcome
NA


*(reported: 2026-10-16 21:56:58)*

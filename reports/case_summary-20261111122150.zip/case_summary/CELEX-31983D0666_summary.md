# 'IV/27.492', 'SMM & T Exhibition Agreement'

**CELEX ID:** CELEX-31983D0666  
**Industry:** | industry                        |
|:--------------------------------|
| motor industry                  |
| car manufacturers               |
| freight container manufacturers |  
**Cartel Period:** 1973-01-01 : 1994-12-31  

## Summary

### Celex Case Id
CELEX-31983D0666

### Case Title
SMM & T Exhibition Agreement

### Overview
The case involved an anticompetitive agreement between motor manufacturers in the UK, specifically the Society of Motor Manufacturers and Traders (SMM & T), which was found to violate Article 85 of the EEC Treaty due to horizontal restraints such as market sharing and quota cartels. The Commission took action after the SMM & T submitted an amended Exhibition Agreement, leading to a decision that required changes to ensure compliance with EU competition law.

### Industry
motor industry, car manufacturers, freight container manufacturers

### Oecd Nace
manufacturing, 29.1:Manufacture of motor vehicles, 29.10: Manufacture of motor vehicles

### Companies Undertakings
| companies                                      |
|:-----------------------------------------------|
| Society of Motor Manufacturers and Traders Ltd |
| Earls Court and Olympia Ltd                    |
| Fernston Ltd                                   |

### Market
United Kingdom

### Cartel Period
1980-07-01 : 1994-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-06-25 | SMM & T | submitted application for negative clearance and notification |
| 1973-06-25 | SMM & T | notified Exhibition Agreement to Commission |
| 1980-07-01 | SMM & T | submitted amended Exhibition Agreement to Commission |
| 1983-12-05 | Commission of the European Communities | issued Commission Decision |
| 1983-12-05 | Commission | issued Decision addressing SMM & T and signatories to Exhibition Agreement |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Society of Motor Manufacturers and Traders Ltd

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies   | recidivism   |
|:------------|:-------------|
| SMM & T     | False        |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court      | country   | jurisdiction                |
|:-----------|:----------|:----------------------------|
| COMMISSION | EEC       | European Economic Community |

### Book Reference
NA

### Outcome
The Commission ordered the SMM & T to amend the Exhibition Agreement to ensure it complies with the requirements of Article 85(3) of the EEC Treaty. This included changes that allowed fairer participation in exhibitions not organized by the SMM & T and ensured no discriminatory treatment. Additionally, the SMM & T was required to submit annually a calendar of international motor exhibitions, and to inform the Commission immediately of any changes in the Agreement or refusal of approval for other exhibitions.


*(reported: 2026-10-16 19:32:23)*

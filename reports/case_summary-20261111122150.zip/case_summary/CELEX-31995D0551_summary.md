# 'IV/34.179, 34.202, 216', 'Stichting Certificatie Kraanverhuurbedrijf and the Federatie van Nederlandse Kraanverhuurbedrijven'

**CELEX ID:** CELEX-31995D0551  
**Industry:** | industry      |
|:--------------|
| construction  |
| petrochemical |
| transport     |  
**Cartel Period:** 1993-02-17 : 1993-11-04  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31995D0551 | IV/34179-2 |

### Case Title
Stichting Certificatie Kraanverhuurbedrijf and the Federatie van Nederlandse Kraanverhuurbedrijven

### Overview
The case involved a cartel in the construction sector related to crane and lifting equipment rental in the Netherlands, Belgium, and Germany. The companies involved, Stichting Certificatie Kraanverhuurbedrijf (SCK) and Federatie van Nederlandse Kraanverhuurbedrijven (FNK), were found to have engaged in anticompetitive practices under Article 85 of the EC Treaty, specifically price fixing collusion. The infringement period was from February 17, 1993, to November 4, 1993. Both companies had prior infringement history. The Commission imposed significant fines (ECU 11,500,000 for FNK and ECU 300,000 for SCK) and ordered the termination of the infringement. The case was decided by Commissioner Karel Van Miert.

### Industry
construction, petrochemical, transport

### Oecd Nace
construction (NACE 77.32)

### Companies Undertakings
| companies                                       |
|:------------------------------------------------|
| Stichting Certificatie Kraanverhuurbedrijf      |
| Federatie van Nederlandse Kraanverhuurbedrijven |

### Market
Netherlands, Belgium, Germany; oligopolistic

### Cartel Period
1993-02-17 : 1993-11-04

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-03-13 | FNK | established |
| 1984-07-13 | SCK | established |
| 1984-07-13 | FNK | introduced SCK certification system restricting eligibility to FNK members |
| 1991-01-01 | SCK | introduced inhuurverbod |
| 1992-01-01 | SCK | ended obligation for SCK certificate-holders to apply general conditions |
| 1992-04-28 | FNK | ended enforcement of internal regulations on preference and rate-setting practices |
| 1992-07-09 | SCK | ended infringement period |
| 1993-02-17 | SCK | began infringement period |
| 1993-11-04 | SCK | terminated infringement |
| 1994-04-13 | Commission | adopted Decision 94/272/EC lifting immunity from fines |
| 1995-11-29 | Commission | issued decision |

### Legal Framework
Article 85, anticompetitive agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
| company |
| --- |
| Federatie van Nederlandse Kraanverhuurbedrijven |
| Stichting Certificatie Kraanverhuurbedrijf |

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| FNK | ECU 11 500 000 |
| SCK | ECU 300 000 |

### Remedies
| company                                         | decision_remedies                                                                            |
|:------------------------------------------------|:---------------------------------------------------------------------------------------------|
| Stichting Certificatie Kraanverhuurbedrijf      | terminate the infringement referred to in Article 1 forthwith, if it has not already done so |
| Federatie van Nederlandse Kraanverhuurbedrijven | terminate the infringement referred to in Article 3 forthwith, if it has not already done so |

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Federatie van Nederlandse Kraanverhuurbedrijven | True |
| Stichting Certificatie Kraanverhuurbedrijf | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                     | country     | jurisdiction    |
|:--------------------------|:------------|:----------------|
| Utrecht District Court    | Netherlands | district court  |
| Amsterdam Court of Appeal | Netherlands | court of appeal |

### Book Reference
NA

### Outcome
Commission took action, imposed fines and ordered termination of infringement


*(reported: 2026-11-11 11:52:40)*

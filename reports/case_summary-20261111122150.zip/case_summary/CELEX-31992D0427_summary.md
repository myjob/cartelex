# 'IV/32.800 and IV/33.335', 'Quantel International-Continuum/Quantel SA'

**CELEX ID:** CELEX-31992D0427  
**Industry:** | industry           |
|:-------------------|
| laser industry     |
| aerospace industry |
| optics industry    |  
**Cartel Period:** 1985-07-17 : 1992-04-08  

## Summary

### Celex Case Id
NA

### Case Title
IV/32.800 and IV/33.335 – Quantel International-Continuum/Quantel SA

### Overview
This case involves a cartel in the laser industry, specifically involving Quantel SA and Continuum, which entered into agreements restricting competition in the common market. The agreements were found to infringe Article 85(1) of the EEC Treaty.

### Industry
laser industry, aerospace industry, optics industry

### Oecd Nace
manufacturing; 26.7: Manufacture of optical instruments and photographic equipment

### Companies Undertakings
| companies   |
|:------------|
| Quantel SA  |
| Continuum   |

### Market
Germany, France, Netherlands, United Kingdom, Italy, Switzerland

### Cartel Period
1985-07-17 : 1992-04-08

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-07-17 | QSA and QLI/C | entered into agreement restricting competition in the common market |
| 1985-07-26 | QSA | signed share transfer agreement and accompanying protocol |
| 1985-07-26 | QLI/C | entered into distribution agreements in Germany, the Netherlands, the United Kingdom and Italy |
| 1988-07-20 | Commission | received complaint from QLI/C |
| 1988-07-20 | Quantel International (now Continuum) | submitted application to the Commission requesting finding of infringement |
| 1989-08-02 | Commission | informed QSA that the agreements infringed Article 85(1) of the EEC Treaty |
| 1990-07-04 | Commission | initiated proceedings |
| 1990-08-13 | Conseil de la Concurrence | sent a statement of objections to QSA |
| 1991-03-25 | Court of Cassation | overturned the judgment and declared the agreement null and void due to restrictions on competition under Community and domestic law |
| 1991-04-30 | Commission | sent statement of objections to QSA |
| 1992-04-08 | QSA | terminated protocol by settlement agreement |
| 1992-07-27 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The Commission found that the agreements infringed Article 85(1) and required the undertakings to bring the infringement to an end, effectively issuing a cease and desist order.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
NA

### Commissioner
Leon BRITTAN

### Courts
| court                                  | country        | jurisdiction          |
|:---------------------------------------|:---------------|:----------------------|
| Paris Court of Appeal                  | France         | Court of Appeal       |
| Court of Cassation                     | France         | national              |
| Court of Justice of the European Union | European Union | European Union        |
| Conseil de la Concurrence              | France         | competition authority |
| Munich Court of Appeal                 | Germany        | appellate court       |
| Corbeil Essonne Commercial Court       | France         | commercial court      |
| Court of First Instance                | European Union | European Court System

### Book Reference
NA

### Outcome
The Commission found infringement under Article 85(1) and required the undertakings to cease the infringement. The case involved multiple courts including the Court of Cassation and the Court of Justice of the European Union.


*(reported: 2026-11-10 19:06:20)*

# '94/119/EC', 'concerning a refusal to grant access to the facilities of the port of Rodby [Denmark]'

**CELEX ID:** CELEX-31994D0119  
**Industry:** ferry services  
**Cartel Period:** NA  

## Summary

### Celex Case Id
94/119/EC

### Case Title
concerning a refusal to grant access to the facilities of the port of Rodby [Denmark]

### Overview
The European Commission investigated a case concerning a refusal by Danish authorities to grant access to port facilities for ferry services operating on the Rodby-Puttgarden route. The case involved companies such as Stena Rederi AB, Euro-Port A/S, DSB, Deutsche Bundesbahn, Scan-Port GmbH, and Europort A/S. The infringement was categorized as abuse of dominance with high gravity.

### Industry
ferry services

### Oecd Nace
transport (50.1: Sea and coastal passenger water transport)

### Companies Undertakings
| companies           |
|:--------------------|
| Stena Rederi AB     |
| Euro-Port A/S       |
| DSB                 |
| Deutsche Bundesbahn |
| Scan-Port GmbH      |
| Europort A/S        |

### Market
The relevant market includes Denmark and Germany, with an oligopolistic structure.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-05-09 | Danish Transport Minister | refused to allow Euro-Port A/S to build a private commercial port |
| 1990-05-09 | Danish Government | refused to allow EuroPort A/S to build a new port near Rodby |
| 1990-08-06 | Danish Minister | rejected request by Euro-Port A/S to operate ferry services |
| 1990-08-08 | Danish Government | refused to allow EuroPort A/S to operate from existing Radby facilities |
| 1992-11-24 | Commission | sent letter of formal notice to Danish authorities regarding Stena's access to port facilities |
| 1993-02-22 | Danish authorities | replied to Commission's letter of formal notice, rejecting the request and citing technical reasons and obligations to public undertakings |
| 1993-12-21 | Commission of the European Communities | issued decision concerning refusal to grant access to port facilities |
| 1993-12-21 | Danish Government | adopted decision to end infringement and inform Commission of measures taken |

### Legal Framework
The legal framework includes Articles 86 and 90 of the EC Treaty, with the canonical concept being abuse_of_dominance, public_undertaking.

### Infringement Category
abuse_of_dominance, member_states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Danish Government shall bring to an end the infringement and shall inform the Commission within two months of the date of notification of this decision of the measures it has taken to bring to an end its prohibition on Euro-Port and Scan-Port either to build a new port in the vicinity of the public port of Rodby or to operate from the existing port facilities.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                  | country        | jurisdiction               |
|:---------------------------------------|:---------------|:---------------------------|
| Court of Justice of the European Union | European Union | EC Treaty, competition law |

### Book Reference
NA

### Outcome
The Commission issued a decision concerning the refusal to grant access to port facilities. The Danish Government was required to end the infringement and inform the Commission of the measures taken.


*(reported: 2026-11-10 19:13:32)*

# '97/744/EC', 'provisions of Italian ports legislation relating to employment'

**CELEX ID:** CELEX-31997D0744  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
97/744/EC

### Case Title
provisions of Italian ports legislation relating to employment

### Overview
This case concerns the infringement of EU competition law by Italian ports legislation, specifically Article 86 and Article 90, related to employment practices in the port sector. The Italian Government and several port-related companies were investigated for abuse of dominance by a public undertaking.

### Industry
Port operations including loading, unloading, embarkation, disembarkation, storage, and transhipment of all types of goods; Temporary labour; Subcontracted services with a high labour content

### Oecd Nace
OECD sector: transport; NACE group code: 52.2: Support activities for transportation; NACE class code: 52.24: Cargo handling

### Companies Undertakings
| companies                                                                                                                       |
|:--------------------------------------------------------------------------------------------------------------------------------|
| Italian Government                                                                                                              |
| Associazione Nazionale Compagnie e Imprese Portuali (ANCIP)                                                                     |
| Compagnia Unica fra i Lavoratori delle Merci Varie del Porto di Genova (CULMV)                                                  |
| Federazione Italiana Imprese di Servizi (Ausitra)                                                                               |
| Comitato Nazionale degli Utenti e degli Operatori Portuali                                                                      |
| Assocazione degli operatori dei magazzini e deposito merci e delle imprese operanti nel settore della logistica (Assologistica) |
| Associazione degli operatori terminalisti (Assotop)                                                                             |

### Market
Italy

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1960-10-23 | Law No 1369/60 | prohibited contractors from subcontracting labor |
| 1991-12-10 | Court of Justice of the European Communities | ruled on incompatibility of Italian ports legislation with Community competition law |
| 1992-07-31 | Commission | extended concept of substantial part of the common market to ports of Taranto, Venice, Livorno, Naples, and Ravenna |
| 1992-07-31 | Commission | sent letter of formal notice |
| 1994-01-28 | Italian Government | adopted law No 84 on port reform |
| 1995-03-18 | Italian authorities | failed to monitor compliance with legal deadline for forming undertakings |
| 1996-10-21 | Italian Government | renewed decree-law |
| 1996-12-23 | Italian Government | converted Law No 647 |
| 1996-12-31 | firms authorized under Article 16 | ended obligation to recruit former port company members first |
| 1997-05-07 | Commission | sent letter of formal notice to Italian Government |
| 1997-05-07 | Commission | issued supplementary letter of formal notice assessing all Italian ports dealing with intraCommunity traffic |
| 1997-06-18 | Italian Parliament | approved new law on liberalization of temporary work |

### Legal Framework
Article 86; Article 90

### Infringement Category
abuse_of_dominance, public_undertaking

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Italy must bring to an end the infringements referred to in Article 1 and inform the Commission of the measures it has taken to that end within two months of the notification of this Decision.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | Italy     | European Union |

### Book Reference
NA

### Outcome
The Commission found that the Italian ports legislation infringed EU competition law, specifically Articles 86 and 90. The case resulted in a formal notice to the Italian Government and required remedial actions to end the infringement.


*(reported: 2026-11-10 19:29:34)*

# 'IV/34.010', 'Nederlandse Vereniging van Banken (1991 GSA agreement)'

**CELEX ID:** CELEX-31999D0687  
**Industry:** NA  
**Cartel Period:** 1991-01-21 : 1999-01-21  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0687 | IV/34010  |

### Case Title
Nederlandse Vereniging van Banken (1991 GSA agreement)

### Overview
The case involved an investigation by the European Commission into a Giro Settlement Agreement (GSA) among Dutch banks, which was alleged to constitute an anticompetitive agreement under Article 81(1) of the EC Treaty. The investigation concluded that the agreement did not appreciably affect trade between Member States.

### Industry
banking and insurance (including real estate)

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 64.1:Monetary intermediation
NACE class code: 64.11: Central banking

### Companies Undertakings
| company                                             |
|:----------------------------------------------------|
| Nederlandse Vereniging van Banken                   |
| ABN AMRO Bank NV                                    |
| Coöperatieve Centrale Raiffeisen-Boerenleenbank BA  |
| ING Bank NV                                         |
| Postbank NV                                         |
| Nederlandse Spaarbankbond                           |
| Interpay/BankGiroCentrale                           |
| Nederlandse Postorderbond                           |
| Verenigde Nederlandse Uitgeversbedrijven            |
| Nederlandse Organisatie van Tijdschriften Uitgevers |
| Nederlandse Christelijke Radio Vereniging           |
| ANWB                                                |
| Centraal Bureau Fondsenwerving                      |

### Market
Netherlands
Oligopoly
False (outside EU)

### Cartel Period
1991-07-01 : 1992-03-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-07-01 | ABN AMRO | introduced charge of NLG 0,45 for using acceptance giros |
| 1991-07-10 | Nederlandse Vereniging van Banken | notified agreement concerning introduction of joint payment and acceptance giro procedure |
| 1992-02-07 | Commission | rejected request for interim measures by Nederlandse Postorderbond |
| 1992-03-26 | banks participating in the GSA agreement | changed interbank commission from fixed to maximum charge |
| 1992-03-26 | Commission department concerned | removed restrictive clauses from GSA agreement |
| 1993-06-14 | Commission | sent statement of objections to Nederlandse Postorderbond |
| 1997-06-20 | Commission | withdrew statement of objections |
| 1997-09-09 | Commission | published notice stating intention to take favourable view of agreement |
| 1999-01-21 | Commission | concluded that GSA agreement does not fall within scope of Article 81(1) |
| 1999-09-08 | unknown | adopted decision regarding GSA agreement |

### Legal Framework
Article 81
Article 82
abuse_of_dominance, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
medium

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement; the decision concluded that there was no breach under Article 81(1) because the GSA agreement did not appreciably affect trade between Member States.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court      | country     | jurisdiction       |
|:-----------|:------------|:-------------------|
| Commission | Netherlands | European Community |

### Book Reference
NA

### Outcome
The Commission concluded that the GSA agreement did not fall within the scope of Article 81(1) of the EC Treaty because it did not appreciably affect trade between Member States.


*(reported: 2026-10-16 22:35:19)*

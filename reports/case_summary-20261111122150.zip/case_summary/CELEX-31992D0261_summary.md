# 'IV/32.290', 'Newitt/Dunlop Slazenger International and Others'

**CELEX ID:** CELEX-31992D0261  
**Industry:** NA  
**Cartel Period:** 1985-08-05 : 1986-06-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31992D0261 | IV/32290  |

### Case Title
Newitt/Dunlop Slazenger International and Others

### Overview
This case involved the European Commission's investigation into anticompetitive practices by Dunlop Slazenger International Ltd and its distributors, including All Weather Sports Benelux BV, Pinguin Sports BV, Newitt & Co. Ltd, and BTR plc. The infringement concerned vertical restraints related to territorial exclusivity and parallel trade bans in the tennis-balls, tennis-rackets, golfing equipment, squash-balls, sports equipment, clothes, and shoes markets.

### Industry
Sports equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.3: Manufacture of sports goods
NACE class code: 32.30: Manufacture of sports goods

### Companies Undertakings
| company                            |
|:-----------------------------------|
| Dunlop Slazenger International Ltd |
| All Weather Sports Benelux BV      |
| Pinguin Sports BV                  |
| Newitt & Co. Ltd                   |
| BTR plc                            |

### Market
The relevant market covers the European Union, including Belgium, Luxembourg, Denmark, Ireland, France, Germany, Netherlands, Italy, Portugal, Spain, United Kingdom, and Greece. The market is characterized as an oligopoly.

### Cartel Period
1985-08-05 : 1986-06-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Council Regulation No 17 |
| 1977-12-14 | DSI | imposed export ban on Dunlop products |
| 1985-08-05 | DSI | confirmed export policy restricting shipments to markets with local legal distributor agreements |
| 1986-06-16 | DSI | specified measures to prevent parallel exports and changed pricing/discounts for squash-balls |
| 1987-03-18 | Newitt | filed complaint against DSI for alleged infringement |
| 1987-06-23 | DSI | received complaint from Newitt concerning resale of products outside the UK |
| 1987-08-12 | DSI | sent letter to distributors warning of investigation and requesting coordinated responses |
| 1987-09-03 | BTR | attempted to re-establish export possibilities with conditions that effectively nullify incentive for exporting |
| 1987-10-20 | Commission | issued warning to DSI regarding conduct |
| 1987-11-09 | DSI | justified conduct to Commission by citing obligation to support exclusive distributors |
| 1990-05-29 | Commission | issued Statement of Objections |
| 1990-07-16 | DSI | acknowledged infringements of Article 85 and gave undertakings regarding future action |
| 1992-03-18 | Commission of the European Communities | issued decision in proceeding |

### Legal Framework
Legal framework applying to the case:

Operative articles: Article 85
All relevant articles: Article 85, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Dunlop Slazenger International Ltd | ECU 5 000 000 |
| All Weather Sports Benelux BV | ECU 1 50 000 |

### Remedies
| value                                                                                                                                                                      |
|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| DSI must terminate the infringements referred to in Article 1 of this Decision and refrain from adopting any measure having an equivalent effect.                          |
| AWS and All Weather Sports Benelux BV must cease their infringing practices related to concerted measures aimed at preventing parallel imports into the Benelux countries. |

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Dunlop Slazenger International Ltd | True |
| All Weather Sports Benelux BV | True |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court               | country        | jurisdiction   |
|:--------------------|:---------------|:---------------|
| European Commission | European Union | European Union |
| Challenge Court     | United Kingdom | England        |

### Book Reference
NA

### Outcome
The European Commission issued a decision finding infringements of Article 85 and imposed fines on Dunlop Slazenger International Ltd and All Weather Sports Benelux BV. Remedies ordered include termination of infringing practices and cessation of measures aimed at preventing parallel imports.


*(reported: 2026-11-11 11:35:42)*

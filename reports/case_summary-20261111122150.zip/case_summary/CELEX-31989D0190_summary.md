# 'IV/31.865', 'PVC'

**CELEX ID:** CELEX-31989D0190  
**Industry:** NA  
**Cartel Period:** 1980-09-18 : 1983-03-02  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31989D0190 | IV/31865-1 |

### Case Title
IV/31.865 – PVC

### Overview
This case involves a cartel of PVC producers operating in the European Union, found to have engaged in anticompetitive agreements under Article 85 of the EEC Treaty. The cartel operated from 1980 to 1983, engaging in price fixing collusion and market sharing.

### Industry
PVC production (manufacturing, NACE 20.16)

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.16: Manufacture of plastics in primary forms

### Companies Undertakings
| company                                  | country   |
|:-----------------------------------------|:----------|
| Atochem SA                               | FR        |
| BASF AG                                  | DE        |
| DSM NV                                   | NL        |
| Enichem SpA                              | IT        |
| Hoechst AG                               | DE        |
| Huels AG                                 | DE        |
| Imperial Chemical Industries plc         | GB        |
| Limburgse Vinyl Maatschappij             | NL        |
| Montedison SpA                           | IT        |
| Norsk Hydro AS                           | NO        |
| Société artésienne de vinyl              | FR        |
| Shell International Chemical Company Ltd | NL        |
| Solvay et Cie                            | BE        |
| Wacker Chemie GmbH                       | DE        |

### Market
Market geography: Belgium, Germany, France, Italy, United Kingdom, Netherlands
Market outside EU: True
Market oligopoly: True
Market turbulence: NA

### Cartel Period
1980-09-18 : 1983-03-02

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-09-18 | ICI | scheduled meeting to secure commitment for planned October/December price initiative |
| 1980-11-01 | ICI | announced price increase to bring West European suspension prices to minimum of DM 1,50 |
| 1980-11-12 | ICI | issued internal report confirming existence of concerted price initiative |
| 1983-03-02 | PVC producers | held meeting in Paris to discuss market discipline and set new price targets |
| 1983-03-13 | Shell | planned major price initiative to stop erosion with targets of DM 1.50/1.65 per kilogram |
| 1983-09-01 | redacted | set price target of DM 1.80 per kilogram |
| 1983-11-01 | redacted | set price target of DM 1.90 per kilogram |
| 1983-11-21 | Commission | initiated investigation into suspected cartel |
| 1983-11-21 | ICI | underwent investigation visit |
| 1983-11-23 | Shell | underwent investigation visit |
| 1984-01-01 | redacted | updated prevailing and target prices |
| 1988-12-21 | Commission | issued Commission Decision relating to a proceeding pursuant to Article 85 of the EEC Treaty |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
False

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Atochem SA | ECU 3 200 000 |
| BASF AG | ECU 1 500 000 |
| DSM NV | ECU 600 000 |
| Enichem SpA | ECU 2 500 000 |
| Hoechst AG | ECU 1 500 000 |
| Huels AG | ECU 2 200 000 |
| Imperial Chemical Industries plc | ECU 2 500 000 |
| Limburgse Vinyl Maatschappij | ECU 750 000 |
| Montedison SpA | ECU 1 750 000 |
| Norsk Hydro AS | ECU 750 000 |
| Société artésienne de vinyl | ECU 400 000 |
| Shell International Chemical Company Ltd | ECU 850 000 |
| Solvay et Cie | ECU 3 500 000 |
| Wacker Chemie GmbH | ECU 1 500 000 |

### Remedies
The Commission issued orders requiring undertakings still active in the PVC sector to bring the infringement to an end and refrain in the future from any collusive arrangements having a similar object or effect, including agreements or concerted practices concerning pricing and volume targets.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| BASF, Hoechst, ICI | True |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | EU Law         |

### Book Reference
NA

### Outcome
The European Commission found the companies guilty of anticompetitive agreements under Article 85 and imposed significant fines. Remedies were issued to end the infringement and prevent future collusion.


*(reported: 2026-11-11 11:18:32)*

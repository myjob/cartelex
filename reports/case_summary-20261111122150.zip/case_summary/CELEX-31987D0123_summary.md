# 'IV/31.302', 'Boussois/Interpane'

**CELEX ID:** CELEX-31987D0123  
**Industry:** | industry                       |
|:-------------------------------|
| glass production               |
| insulation-glass manufacturing |
| building materials             |  
**Cartel Period:** 1986-12-15 : 1988-09-30  

## Summary

### Celex Case Id
CELEX-31987D0123, IV/31302

### Case Title
Boussois/Interpane

### Overview
The European Commission investigated an anticompetitive agreement between Boussois SA (France) and Interpane Entwicklungs- und Beratungsgesellschaft mbH & Co. KG (Germany) in the glass production industry, specifically related to coated insulating glass and double-glazing units using low-emissivity glass.

### Industry
glass production, insulation-glass manufacturing, building materials

### Oecd Nace
manufacturing (OECD sector), 23.1 (Manufacture of glass and glass products), 23.12 (Shaping and processing of flat glass)

### Companies Undertakings
Boussois SA (FR)
Interpane Entwicklungs- und Beratungsgesellschaft mbH & Co. KG (DE)

### Market
France, Germany, Benelux countries, United Kingdom, Spain, Italy (outside EU), oligopoly

### Cartel Period
NA

### Key Timeline
1984-08-01: Boussois SA and Interpane Entwicklungs- und Beratungsgesellschaft mbH & Co. KG filed application for negative clearance or exemption
1986-12-15: European Commission issued Commission Decision
1988-09-30: Exemption period ended

### Legal Framework
Article 85 (anticompetitive agreement)

### Infringement Category
license

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
medium

### Exemption
True
Applicants:
- Boussois SA
- Interpane Entwicklungs- und Beratungsgesellschaft mbH & Co. KG

### Leniency
NA

### Fines
NA

### Remedies
No decision remedies found in the provided context.

### Company Recidivism
Boussois SA: False
Interpane Entwicklungs- und Beratungsgesellschaft mbH & Co. KG: False

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
COMMISSION (Germany), European Economic Community

### Book Reference
NA

### Outcome
The Commission took no action, and the case was not appealed. The companies applied for exemption, which was granted.


*(reported: 2026-10-16 20:12:30)*

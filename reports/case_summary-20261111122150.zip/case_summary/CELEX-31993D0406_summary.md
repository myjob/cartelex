# 'IV/34.072', 'relating to a proceeding pursuant to Article 85 of the EEC Treaty against Langnese-Iglo GmbH'

**CELEX ID:** CELEX-31993D0406  
**Industry:** ice-cream  
**Cartel Period:** 1984-01-01 : 1990-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0406 | IV/34072  |

### Case Title
IV/34.072 – relating to a proceeding pursuant to Article 85 of the EEC Treaty against Langnese-Iglo GmbH

### Overview
The case involves anticompetitive agreements in the ice-cream industry in Germany, with the European Commission finding that agreements infringed Article 85(1) of the EEC Treaty. The cartel period was from 1984 to 1990, involving multiple companies including Langnese-Iglo GmbH and Schöller Lebensmittel GmbH & Co. KG.

### Industry
ice-cream

### Oecd Nace
manufacturing (OECD sector), NACE group code 10.5: Manufacture of dairy products, NACE class code 10.52: Manufacture of ice cream

### Companies Undertakings
| company                                  |
|:-----------------------------------------|
| Langnese-Iglo GmbH                       |
| Schöller Lebensmittel GmbH & Co. KG      |
| Mars GmbH                                |
| Unilever group                           |
| Südzucker AG                             |
| Jacobs Suchard                           |
| Deutsche Unilever GmbH                   |
| Oetker                                   |
| Van den Bergh Food Service GmbH & Co. KG |

### Market
Germany, oligopoly market, no turbulence

### Cartel Period
1984-01-01 : 1990-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-01-01 | L-I | subdivided supply agreements into three groups based on fixed terms and automatic renewal |
| 1985-05-07 | SLG | notified standard form supply contract to the Commission |
| 1985-09-20 | Commission's Directorate-General for Competition | informed SLG of compatibility with competition rules |
| 1990-01-01 | L-I | implemented new price list for impulse ice-cream |
| 1991-09-18 | Mars GmbH | lodged application |
| 1991-11-29 | Commission's Directorate-General for Competition | re-opened the proceeding |
| 1991-12-19 | Commission | initiated proceedings against L-I and SLG |
| 1992-03-25 | Commission | issued decision stating agreements infringed Article 85(1) |
| 1992-12-23 | Langnese-Iglo GmbH | withdrawal of block exemption |
| 1997-12-31 | Lagnese-Iglo GmbH | prohibited from concluding new agreements |

### Legal Framework
Article 85 (operative), Article 85 (all relevant), anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
high

### Exemption
Mars GmbH applied for exemption, but no exemption was granted.

### Leniency
NA

### Fines
NA

### Remedies
L-I must inform dealers with whom it has current agreements of the full wording of Articles 1 and 2, and notify them that the agreements are void; L-I must refrain from invoking its contractual rights in respect of the exclusivity of sales outlets; L-I is prohibited from concluding agreements of the kind referred to in Article 1 until after 31 December 1997; L-I is prohibited from concluding fresh agreements of this kind for a period of five years following notification of the Decision, and must be given an opportunity to apply for judicial review before that decision takes effect; the benefit of the block exemption declared by Council Regulation (EEC) No 1984/83 is withdrawn.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
| court                                               | country   | jurisdiction   |
|:----------------------------------------------------|:----------|:---------------|
| Court of Justice                                    | EU        | EU             |
| Court of First Instance of the European Communities | EU        | EU             |

### Book Reference
NA

### Outcome
The Commission issued a decision stating that the agreements infringed Article 85(1) of the EEC Treaty. Remedies included voiding agreements, prohibiting new agreements until 1997, and withdrawing the block exemption. The case involved court proceedings at the Court of Justice and the Court of First Instance of the European Communities.


*(reported: 2026-11-11 11:41:15)*

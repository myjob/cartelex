# 'IV/29.688', 'The London Grain Futures Market'

**CELEX ID:** CELEX-31987D0045  
**Industry:** grain  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0045 | IV/29688  |

### Case Title
The London Grain Futures Market

### Overview
The European Commission investigated anticompetitive practices in the London Grain Futures Market (LGFM), focusing on horizontal price fixing collusion under Article 85 of the EC Treaty. The investigation involved companies from the UK and US, operating in the grain industry.

### Industry
grain

### Oecd Nace
OECD sector: agriculture
NACE group code: 46.1:Wholesale on a fee or contract basis
NACE class code: 46.11: Agents involved in the sale of agricultural raw materials, live animals, textile raw materials and semi-finished goods

### Companies Undertakings
| companies                                          | country   |
|:---------------------------------------------------|:----------|
| London Grain Futures Market                        | GB        |
| Grain and Feed Trade Association                   | US        |
| Association of Futures Brokers and Dealers Limited | GB        |

### Market
United Kingdom
market outside EU: True

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-08-22 | redacted | submitted notification and application for negative clearance |
| 1986-12-10 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Commission required the London Grain Futures Market (LGFM) to abandon the system of fixed minimum commission rates. It also mandated changes in membership criteria and introduced an appeals procedure to ensure fairness and transparency.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
False

### Book Reference
NA

### Outcome
The Commission took a decision to require changes in membership criteria and introduced an appeals procedure to ensure fairness and transparency, without imposing fines or leniency.


*(reported: 2026-11-11 11:05:46)*

# 'IV/243, 244, 245', 'Cimbel'

**CELEX ID:** CELEX-31972D0474  
**Industry:** cement  
**Cartel Period:** 1948-06-15 : 1972-03-16  

## Summary

### Celex Case Id
CELEX-31972D0474

### Case Title
Cimbel

### Overview
This case involves a cartel of Belgian cement companies that engaged in anti-competitive practices including price fixing, quota setting, and revenue compensation mechanisms. The cartel operated from 1948 to 1972, with the European Commission taking action in 1972. Several companies had prior infringement history (recidivism). The case was addressed under Article 85(1) of the EEC Treaty.

### Industry
cement

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.5:Manufacture of cement, lime and plaster
NACE class code: 23.51: Manufacture of cement

### Companies Undertakings
| companies                                               | location          |
|:--------------------------------------------------------|:------------------|
| La Cimenterie Belge — CIMBEL S.A.                       | Brussels          |
| S.A. Belgian Cement Company C.C.B.                      | Gaurain—Ramecroix |
| S.A. Portland Cements J.vandenHeuvel                    | Hemiksem          |
| S.A. General Society of Portland Cements of the Scheldt | Antoing           |
| S.A. Quarries and Cement Factories Lemay                | Vaulx             |
| S.A. Cement Factories C.B.R. Cement Companies N.V.      | Briissel          |
| S.A. Obourg Cements                                     | Obourg            |
| S.A. Thieu Cements                                      | Thieu             |
| S.A. Liège Portland Cements                             | Haccourt          |
| S.A. Visé Cements                                       | Brussels          |

### Market
| geographical | oligopoly | turbulence |
|:-------------|:----------|:-----------|
| Belgium, Netherlands, West Germany, France | True | NA |

### Cartel Period
1948-06-15 : 1972-03-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1948-06-15 | redacted | signed cartel agreements |
| 1948-10-13 | CIMBEL | founded in accordance with Articles 14ff. of the Convention Générale Cimentière de 1948 |
| 1958-01-01 | Committee A | set base price for cement |
| 1962-10-31 | Commission | submitted agreements to the Commission |
| 1962-10-31 | redacted | registered cartel agreements with Commission |
| 1969-07-16 | Committee A | increased prices |
| 1970-07-08 | Committee A | increased prices |
| 1970-10-27 | Committee A | adjusted pricing |
| 1972-01-25 | Committee A | changed prices |
| 1972-03-16 | Committee A | adjusted pricing |
| 1972-12-22 | European Commission | issued decision addressing companies to cease violations |
| 1972-12-22 | Commission | issued decision concerning procedure under Article 85 of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| company | recidivism |
| --- | --- |
| S.A. Cimenteries C.B.R. Cement Companies N.V. | True |
| S.A. Obourg Cements | True |
| S.A. Thieu Cements | True |
| S.A. Liège Portland Cements | True |
| S.A. Visé Cements | True |
| S.A. Belgian Cement Company | True |
| S.A. Portland Cements J. van den Heuvel | True |
| S.A. General Company of Portland Cements of the Scheldt | True |
| S.A. Quarries and Cement Plants Lemay | True |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
S.L. MANSHOLT

### Courts
| court                    | country   | jurisdiction   |
|:-------------------------|:----------|:---------------|
| state courts in Brussels | Belgium   | Federal        |

### Book Reference
NA

### Outcome
Cease and desist order to stop the violations set out in Article 1, which include quota setting, price fixing, and revenue compensation mechanisms violating Article 85(1) of the Treaty.


*(reported: 2026-11-11 10:01:45)*

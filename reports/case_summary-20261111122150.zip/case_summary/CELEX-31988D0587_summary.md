# 'IV/B-2/31.424', "Hudson's' Bay-Dansk Pelsdyravlerforening"

**CELEX ID:** CELEX-31988D0587  
**Industry:** fur breeding  
**Cartel Period:** 1973 : 1987  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0587 | IV/31424  |

### Case Title
Hudson's Bay–Dansk Pelsdyravlerforening

### Overview
The case involves the Danish Fur Breeders Association (DPF) and other companies, including Hudson's Bay and Annings Ltd, for engaging in anticompetitive agreements under Article 85 of the EC Treaty. The cartel period spanned from 1973 to 1987, with the infringement categorized as horizontal restraints involving market sharing, quota cartels, and specialization agreements. The European Commission initiated proceedings in 1987 following a formal complaint by Hudson's Bay in 1985. The Commission issued its decision on 28 October 1988, imposing a fine of ECU 500,000 on the DPF. The case also involved an exemption application by the Dansk Pelsdyravlerforening.

### Industry
fur breeding

### Oecd Nace
OECD sector: agriculture
NACE group code: 14.2: Manufacture of articles of fur
NACE class code: 14.20: Manufacture of articles of fur

### Companies Undertakings
| companies                    | country   |
|:-----------------------------|:----------|
| Hudson's Bay                 | CA        |
| Annings Ltd                  | CA        |
| Dansk Pelsdyravlerforening   | DK        |

### Market
Geographical: Denmark, Finland, Norway, Sweden
Outside EU: true
Oligopoly: False
Turbulence: NA

### Cartel Period
1973 : 1987

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission of the European Communities | established first Regulation implementing Articles 85 and 86 |
| 1973-01-01 | DPF | imposed 100% obligation under Standard Pelting Control Agreement |
| 1975-04-11 | Board | introduced kit advance for members |
| 1975-04-11 | DPF | implemented 100% obligation for kit advance and Emergency Assistance Scheme |
| 1976-10-22 | DPF | enforced obligation not to organise or support sale of skins by DFA competitors |
| 1985-01-04 | HBA | filed formal complaint to Commission |
| 1985-01-04 | Hudson's Bay and Annings Ltd | submitted application for finding of infringement |
| 1985-08-27 | Dansk Pelsdyravlerforening | submitted notification and application for negative clearance |
| 1986-12-19 | Finnish Fur Sales | acquired HBA |
| 1987-03-30 | Commission of the European Communities | initiated proceedings in this case |
| 1987-04-13 | DPF | responded to statement of objections |
| 1987-06-04 | DPF | submitted proposed amendments concerning kit advances and membership conditions |
| 1987-11-26 | DPF | submitted further proposed amendments modifying regulations and agreements |
| 1988-10-28 | Commission of the European Communities | issued decision imposing fine on Danish Fur Breeders Association |
| 1988-10-28 | Commission of the European Communities | issued Commission Decision |
| 1989-01-31 | Danish Fur Breeders Association | informed members of the decision

### Legal Framework
Law articles: Article 85, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Dansk Pelsdyravlerforening

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Dansk Pelsdyravlerforening | ECU 500 000 |

### Remedies
The Commission ordered the Dansk Pelsdyravlerforening (DPF) to terminate the infringements found in Article 1 of the Decision and to refrain from taking any measure having the same object or effect as the above restrictions in the future. Additionally, the DPF was required to inform its members of this Decision by 31 January 1989 and to inform the Commission of the manner in which this had been done.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Dansk Pelsdyravlerforening | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found the Dansk Pelsdyravlerforening guilty of anticompetitive agreements under Article 85 and imposed a fine of ECU 500,000. The Commission ordered the DPF to terminate the infringements and inform its members and the Commission accordingly.


*(reported: 2026-11-11 11:14:48)*

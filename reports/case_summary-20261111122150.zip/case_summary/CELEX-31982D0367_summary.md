# 'IV/25.757', 'Hasselblad'

**CELEX ID:** CELEX-31982D0367  
**Industry:** photography  
**Cartel Period:** 1974-06-18 : 1979-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0367 | IV/25757  |

### Case Title
Hasselblad

### Overview
The European Commission investigated anticompetitive agreements involving several companies in the photography industry, specifically focusing on resale price maintenance and parallel imports. The case centered around violations of Article 85 of the EEC Treaty.

### Industry
photography

### Oecd Nace
trade (wholesaling and retailing) and hotels
NACE group code: 26.7: Manufacture of optical instruments and photographic equipment
NACE class code: 26.70: Manufacture of optical instruments and photographic equipment

### Companies Undertakings
| company                                       |
|:----------------------------------------------|
| Victor Hasselblad Aktiebolag                  |
| Hasselblad (GB) Limited                       |
| Ilford (Ireland) Limited                      |
| Telos SA                                      |
| Prolux sprl                                   |
| James Polack aps                              |
| Nordic Im- und Export Handelsgesellschaft mbH |
| Camera Care Limited                           |

### Market
Relevant market includes the United Kingdom and Belgium, with an oligopoly structure. The market is not outside the EU.

### Cartel Period
1974-06-18 : 1979-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1965-07-02 | Victor Hasselblad Aktiebolag | signed standard sole distributorship agreement |
| 1965-07-02 | Victor Hasselblad | notified the Commission of a sole distributorship agreement |
| 1973-10-05 | Commission | addressed anti-competitive behavior in dealer agreement |
| 1974-06-18 | Victor Hasselblad | exchanged price information with sole distributor Telos to prevent exports |
| 1974-12-13 | Commission | Commission Decision regarding parallel imports and competition restrictions |
| 1975-01-01 | Hasselblad (GB) | infringed Article 85(1) by influencing resale prices |
| 1975-06-03 | Commission | addressed anti-competitive clauses in dealer agreement |
| 1977-02-10 | Victor Hasselblad | informed the Commission it would comply with recommendations |
| 1977-02-15 | Victor Hasselblad | informed the Commission that it would discontinue the export ban |
| 1978-02-13 | Hasselblad (GB) | gave notice of termination for the agreement |
| 1980-10-13 | Commission | initiated proceedings under Article 85 of the EEC Treaty |
| 1981-12-02 | Commission | issued Commission Decision relating to proceeding under Article 85

### Legal Framework
Article 85 (operative article)
All relevant articles: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was sought by several applicants, including Victor Hasselblad Aktiebolag, Hasselblad (GB) Limited, Ilford (Ireland) Limited, Telos SA, Prolux sprl, Polack aps, Nordic Im- und Export Handelsgesellschaft mbH.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Victor Hasselblad | 560 000 ECU |
| Hasselblad (GB) | 165 000 ECU |
| Ilford | 10 000 ECU |
| Telos | 10 000 ECU |
| Prolux | 10 000 ECU |

### Remedies
| value                                                                                                                                                                                                                                                                                                                                                               |
|:--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Victor Hasselblad must cease the infringements and inform its sole distributors in writing within three months that exports to other Member States are not forbidden and must not be prevented or discouraged. It must also report to the Commission within four months.                                                                                            |
| Hasselblad (GB) must cease the infringements, inform dealers that cross-supplies and exports are not forbidden and that resale prices can be freely fixed; inform the public that it will grant after-sales service under the manufacturer's guarantee to all Hasselblad products without discrimination. It must also report to the Commission within four months. |
| The Commission may impose a periodic penalty payment of 1,000 ECU per day if the undertakings do not meet their obligations to bring the infringements to an end within three months.                                                                                                                                                                               |

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Victor Hasselblad Aktiebolag | True |
| Hasselblad (GB) Limited | True |
| Ilford (Ireland) Limited | True |
| Telos SA | True |
| Prolux sprl | True |
| James Polack aps | True |
| Nordic Im- und Export Handelsgesellschaft mbH | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court            | country                     | jurisdiction                |
|:-----------------|:----------------------------|:----------------------------|
| Court of Justice | European Economic Community | European Economic Community |

### Book Reference
NA

### Outcome
The Commission took action against the companies involved for violating Article 85 of the EEC Treaty. Fines were imposed, and remedies were ordered to cease the infringements and ensure compliance with competition law.


*(reported: 2026-11-11 10:39:59)*

# 'IV/30.787 and 31.488', 'Eurofix-Bauco v. Hilti'

**CELEX ID:** CELEX-31988D0138  
**Industry:** | industry                                                  |
|:----------------------------------------------------------|
| construction industry                                     |
| fastening systems industry                                |
| manufacturing of consumables for power-actuated fasteners |  
**Cartel Period:** 1981 : 1985-08-27  

## Summary

### Celex Case Id
CELEX-31988D0138

### Case Title
Eurofix-Bauco v. Hilti

### Overview
The case involved Hilti AG and several other companies in the construction industry, specifically in fastening systems, for abuse of dominance under Article 86. The cartel period was from 1981 to 1985, with Hilti applying discriminatory discount policies and refusing to supply competitors' products. The Commission found that Hilti had abused its dominant position by tying the supply of cartridge magazines to the supply of nails and applying discriminatory discount policies. A fine of six million ECU was imposed on Hilti AG, and behavioral remedies were ordered.

### Industry
construction industry, fastening systems industry, manufacturing of consumables for power-actuated fasteners

### Oecd Nace
construction; 25.9:Manufacture of other fabricated metal products; 25.94: Manufacture of fasteners and screw machine products

### Companies Undertakings
| companies                            |
|:-------------------------------------|
| Hilti AG                             |
| Hilti GB                             |
| Eurofix Limited                      |
| Bauco (UK) Ltd                       |
| Dynamit Nobel                        |
| Nouvelle Cartoucherie de Survilliers |
| Fiocchi                              |
| PASA                                 |
| Spit                                 |

### Market
Belgium, France, Ireland, Germany, Spain, UK, Denmark, Italy, Netherlands, Greece, Portugal; market outside EU; oligopolistic market

### Cartel Period
1981 : 1985-08-27

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-02-06 | Hilti | reduced discounts for customers purchasing competitors' nails |
| 1981-11-24 | Hilti AG | warned about supplying Profix (Eurofix) with cartridges |
| 1981-12-14 | Hilti AG | sent circular letter warning subsidiaries not to supply Profix (Eurofix) |
| 1982-06-17 | Hilti AG | addressed letter to Hilti Netherlands with model reply to refuse orders from Profix (Eurofix) |
| 1983-05-09 | Hilti | granted discount on cartridges only when equal quantities of fasteners were purchased |
| 1983-05-17 | Hilti GB | placed embargo on cartridge-only sales for Eurofix customer |
| 1984-03-05 | Hilti | compiled list of users of non-Hilti nail guns and outlined strategies to convert them to Hilti |
| 1985-05-10 | Hilti | initiated competitive consumables strategy targeting Firth's customers |
| 1985-06-04 | Hilti | sent letter to Commission stating marketing efforts to influence customers to use Hilti direct fastening systems and buy nails from Hilti when ordering cartridges |
| 1985-08-09 | Commission | sent statement of objections to Hilti |
| 1986-01-23 | Hilti | applied discriminatory discount policy unilaterally without consultation |
| 1987-12-22 | Commission | issued Decision relating to proceeding under Article 86 |

### Legal Framework
Article 86

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
Loyalty discounts and fidelity rebates

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Hilti AG | six million ECU |

### Remedies
Hilti AG shall forthwith bring to an end the infringements referred to in Article 1 to the extent that it has not already done so. Hilti AG shall refrain from repeating or continuing any of the acts or behaviour specified in Article 1 and shall refrain from adopting any measures having an equivalent effect. Additionally, Hilti undertakes to implement behavioral remedies including: (a) not to tie the supply of cartridge magazines to the supply of nails; (b) implementing a transparent discount policy based on quantity/value discount schedules applied uniformly and without discrimination; (c) not to refuse to supply direct fastening products to existing customers and to report any refusals; (d) waiving its rights under UK patents and copyrights related to cartridge strips; (e) providing warranty cover for both Hilti and non-Hilti consumables; (f) implementing a competition law compliance programme specific to the Hilti Group.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Hilti | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court               | country            | jurisdiction                |
|:--------------------|:-------------------|:----------------------------|
| European Commission | European Community | European Economic Community |

### Book Reference
IV/30.787 and IV/30787

### Outcome
Hilti AG was found to have abused its dominant position by applying discriminatory discount policies, refusing to supply competitors' products, and tying the supply of cartridge magazines to the supply of nails. The Commission imposed a fine of six million ECU and ordered behavioral remedies.


*(reported: 2026-11-11 11:10:41)*

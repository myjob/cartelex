# 'IV/36.010-F3', 'Amministrazione Autonoma dei Monopoli di Stato'

**CELEX ID:** CELEX-31998D0538  
**Industry:** tobacco  
**Cartel Period:** 1993-01 : 1994-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31998D0538 | IV/36010  |

### Case Title
Amministrazione Autonoma dei Monopoli di Stato

### Overview
The European Commission investigated the Italian state monopoly on tobacco products, Amministrazione Autonoma dei Monopoli di Stato (AAMS), for abuse of dominance under Article 86 of the EC Treaty. The investigation focused on AAMS's distribution practices and its refusal to allow foreign firms to use bonded warehouse traders for cigarette distribution.

### Industry
tobacco

### Oecd Nace
OECD sector: public service
NACE group code: 12.0: Manufacture of tobacco products
NACE class code: 12.00: Manufacture of tobacco products

### Companies Undertakings
| company                                            |
|:---------------------------------------------------|
| Amministrazione Autonoma dei Monopoli di Stato     |
| R. J. Reynolds Tobacco GmbH                        |
| R. J. Reynolds Tobacco Company SAE                 |
| Rothmans International BV                          |
| International Tobacco Company                      |
| British American Tobacco (Deutschland) Export GmbH |

### Market
Italy
Oligopoly: True
Turbulence: NA
Outside EU: False

### Cartel Period
1993-01 : 1994-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1942-07-17 | Italian State | enacted Law No 907 granting exclusive rights to produce manufactured tobacco |
| 1957-12-22 | Italian Government | organized services for distribution and sale of monopoly goods including cigarettes |
| 1958-10-14 | AAMS | issued decree governing management of magazzini |
| 1975-12-10 | Italian Government | liberalized importation and wholesale distribution of cigarettes |
| 1983-07-26 | Finance Ministry | laid down criteria for warehouse authorizations and movement rules for imports |
| 1993-01-01 | AAMS | policy change allowing foreign firms to use bonded warehouse traders for cigarette distribution |
| 1993-05-13 | Law No 198 | abolished state retail stores |
| 1993-11-12 | Rothmans International BV | made request for discussions on amending the distribution contract |
| 1993-12-28 | AAMS | sent new distribution contract not incorporating prior proposals |
| 1997-09-22 | AAMS | informed foreign firms of the amendment |
| 1997-10-10 | AAMS | informed Commission about changes made by circular dated 18 April 1997 |
| 1998-06-17 | Commission | issued decision relating to proceeding under Article 86 of the EC Treaty

### Legal Framework
Article 86
Infringement concept: abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Amministrazione Autonoma dei Monopoli di Stato | ECU 6 000 000 |

### Remedies
AAMS shall amend the clauses of the distribution contracts referred to in Article 2 which are still in force, in such a way as to eliminate the abuses found by this Decision to have occurred. The new distribution contracts shall be submitted to the Commission. AAMS shall refrain from continuing or repeating the behaviour referred to in Articles 2 and 3 and from all activities having an equivalent effect. For a period of three years from the date of notification of this Decision, AAMS shall forward to the Commission within two months of the end of each calendar year, a report on the preceding year describing the quantities of foreign cigarettes distributed by AAMS as well as any refusal (total or partial) to distribute such cigarettes.

### Company Recidivism
| company | recidivism |
| --- | --- |
| AAMS | True |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
True

### Book Reference
NA

### Outcome
The Commission found that AAMS had abused its dominant position by refusing to allow foreign firms to use bonded warehouse traders for cigarette distribution. AAMS was fined ECU 6,000,000 and ordered to amend its distribution contracts to eliminate the abuses. AAMS was also required to submit annual reports to the Commission for three years.


*(reported: 2026-11-11 11:56:58)*

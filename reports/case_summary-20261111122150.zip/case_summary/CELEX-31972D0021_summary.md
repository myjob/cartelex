# 'IV/26.811', 'Continental Can Company'

**CELEX ID:** CELEX-31972D0021  
**Industry:** | industry                |
|:------------------------|
| metal packaging         |
| food canning            |
| beverage manufacturing  |
| chemical industry       |
| pharmaceutical products |
| cosmetics               |
| consumer goods          |  
**Cartel Period:** 1963 : 1969  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0021 | IV/26.811 |
| CELEX-31972D0021 | IV/26811  |

### Case Title
Continental Can Company

### Overview
This case involves a cartel investigation by the European Commission against Continental Can Company Inc. and several international companies involved in metal packaging, particularly in the food canning and beverage manufacturing sectors.

### Industry
metal packaging, food canning, beverage manufacturing, chemical industry, pharmaceutical products, cosmetics, consumer goods

### Oecd Nace
manufacturing, 22.2:Manufacture of plastics products, 22.22: Manufacture of plastic packing goods

### Companies Undertakings
| companies                                            |
|:-----------------------------------------------------|
| Continental Can Company Inc.                         |
| Schmalbach-Lubeca AG                                 |
| Europemballage Corporation                           |
| Thomassen & Drijver-Verblifa N.V.                    |
| Metal Box Company Ltd.                               |
| Superbox S.p.A.                                      |
| J.J. Carnaud & Forges de Basse-Indre                 |
| International Machinery Corporation                  |
| The Metal Box Company Overseas                       |
| The Advisory Committee on Cartel and Monopoly Issues |

### Market
The relevant market is located in Germany, Netherlands, Belgium, Luxembourg, France, and Great Britain. It is characterized as an oligopoly.

### Cartel Period
1963 : 1969

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-05-30 | redacted | signed information exchange agreement among European licensees |
| 1968-06-28 | redacted | formed executive committee of international technical committee |
| 1968-09-11 | shareholders of Europemballage S.A. | decided to create a Committee of the Presidents |
| 1968-10-30 | Committee of the Presidents | decided to establish four study commissions |
| 1969-02-06 | Continental Can Company Inc. | acquired control over Schmalbach-Lubeca-Werke AG |
| 1969-06-23 | redacted | agreed on market information and statistics in the field of crown corks |
| 1970-01-06 | Committee of the Presidents | dissolved the commercial commission |
| 1970-02-16 | Continental and Thomassen & Drijver-Verblifa N.V. | signed agreement to establish Europemballage Corporation |
| 1970-02-20 | Europemballage Corporation | founded under Delaware law with specified share capital |
| 1970-04-09 | Commission | initiated proceedings against Continental Can Company Inc. and its subsidiary |
| 1971-12-09 | Commission | issued a decision |
| 1972-07-01 | Continental Can Company Inc. | submitted proposals to the Commission |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
Continental Can Company Inc. is obligated to cease the breach of Article 86 of the EEC Treaty and must submit proposals to the Commission before 1 July 1972.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
False

### Book Reference
IV/26.811

### Outcome
The Commission found a breach of Article 86 of the EEC Treaty and ordered Continental Can Company Inc. to cease the infringement and submit proposals to the Commission.


*(reported: 2026-11-11 09:54:48)*

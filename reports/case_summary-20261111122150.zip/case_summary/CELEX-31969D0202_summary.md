# 'IV/597-V.V.V.F.', 'Procedure under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31969D0202  
**Industry:** paints  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
CELEX-31969D0202

### Case Title
IV/597–V.V.V.F.

### Overview
This case involved an export cartel in the Netherlands' paints industry, where Vereniging van Vernis- en Verffabrikanten in Nederland (V.V.V.F.) and Exportgroep Verf were investigated for anticompetitive agreements under Article 85 of the EEC Treaty. The cartel operated from 1950 to 1969, with various regulatory actions by the Commission and amendments to export programs. V.V.V.F. had a prior infringement history (recidivism). No specific remedies were issued by the Commission.

### Industry
paints

### Oecd Nace
manufacturing, 20.3:Manufacture of paints, varnishes and similar coatings, printing ink and mastics, 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
| companies                                                         |
|:------------------------------------------------------------------|
| Vereniging van Vernis- en Verffabrikanten in Nederland (V.V.V.F.) |
| Exportgroep Verf                                                  |

### Market
Netherlands

### Cartel Period
1950-05-19 : 1969-06-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1950-05-19 | Vereniging van Vernis-en Verffabrikanten in Nederland (V.V.V.F.) | adopted decision and implementing provisions concerning members who export paints, varnishes and solvents |
| 1950-05-19 | export committee Exportgroep Verf | concluded export agreement for one year |
| 1962-02-06 | Commission of the European Communities | issued Regulation No.17 |
| 1962-03-13 | Commission | Regulation No.17 entered into force |
| 1962-10-31 | Exportgroep Verf | provisionally registered export programme with Commission |
| 1962-10-31 | Association of Varnish and Paint Manufacturers in the Netherlands | filed decision |
| 1967-05-01 | unknown | export program came into force |
| 1968-01-09 | V.V. V.F. | confirmed negative certificate application |
| 1968-06-08 | Exportgroep Verf | amended binding decision and export programme |
| 1968-06-08 | participating companies | amended decision and export programme |
| 1968-12-20 | Advisory Committee for Cartel and Monopoly Issues | submitted statement pursuant to Article 10 of Regulation No.17 |
| 1969-06-25 | Commission of the European Communities | issued decision concerning procedure under Article85 of the EEC Treaty

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
export cartels

### Infringement Gravity
NA

### Exemption
Exemption sought by Vereniging van Vernis- en Verffabrikanten in Nederland

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement according to the provided context.

### Company Recidivism
| companies                                              | recidivism   |
|:-------------------------------------------------------|:-------------|
| Vereniging van Vernis- en Verffabrikanten in Nederland | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
NA

### Book Reference
IV/597

### Outcome
Commission took no action but issued a decision


*(reported: 2026-10-16 19:06:41)*

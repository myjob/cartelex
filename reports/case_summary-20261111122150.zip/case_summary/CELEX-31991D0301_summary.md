# '91/301/EEC', 'relating to a proceeding under Article 85 (1) of the EEC Treaty'

**CELEX ID:** CELEX-31991D0301  
**Industry:** | industry   |
|:-----------|
| soda-ash   |
| chemical   |  
**Cartel Period:** 1990-07-01 : 1990-12-19  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0301 | IV/33016  |

### Case Title
91/301/EEC – relating to a proceeding under Article 85 (1) of the EEC Treaty

### Overview
The case involved a proceeding under Article 85(1) of the EEC Treaty concerning anticompetitive agreements in the soda-ash industry. The European Commission found infringement and issued a decision on December 19, 1990, prohibiting exclusionary rebate systems operated by Solvay and ICI.

### Industry
soda-ash, chemical

### Oecd Nace
OECD sector: mining; NACE group code: 20.5: Manufacture of other chemical products; NACE class code: 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| companies                             |
|:--------------------------------------|
| American Natural Soda Ash Corporation |
| FMC Wyoming Corporation               |
| General Chemical (Soda Ash) Partners  |
| Kerr McGee Chemical Corporation       |
| Stauffer Chemical Company             |
| Tenneco Minerals Company              |
| TG Soda Ash Inc.                      |

### Market
Relevant market: United Kingdom, Ireland, Belgium; oligopoly market; no turbulence noted.

### Cartel Period
1990-07-01 : 1990-12-19

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-12-08 | redacted | entered into membership agreement |
| 1988-12-09 | Ansac | submitted application and notification for negative clearance or exemption |
| 1988-12-09 | American Natural Soda Ash Corporation | notified arrangements to the Commission |
| 1989-07-03 | Commission | initiated proceedings |
| 1990-07-01 | most producers | raised list prices to $98 per short ton |
| 1990-09-07 | Commission | terminated review of anti-dumping measures without imposing protective measures |
| 1990-12-19 | Commission | issued decision relating to proceeding under Article 85 (1) of the EEC Treaty |
| 1990-12-19 | Commission | adopted Decision finding infringement |
| 1990-12-19 | Commission | prohibited exclusionary rebate systems operated by Solvay and ICI |

### Legal Framework
Legal framework: Article 85 (operative article); canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company |
| --- |
| American Natural Soda Ash Corporation |
| FMC Wyoming Corporation |
| General Chemical (Soda Ash) Partners |
| Kerr McGee Chemical Corporation |
| Stauffer Chemical Company |
| Tenneco Minerals Company |
| TG Soda Ash Inc. |

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist order requiring Ansac and its member companies to refrain from implementing the notified arrangements in the EEC.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country   | jurisdiction                |
|:--------------------------|:----------|:----------------------------|
| European Court of Justice | Belgium   | European Economic Community |

### Book Reference
NA

### Outcome
The Commission found infringement under Article 85(1) of the EEC Treaty and issued a decision prohibiting exclusionary rebate systems operated by Solvay and ICI. Remedies included a cease and desist order requiring Ansac and its member companies to refrain from implementing the notified arrangements in the EEC.


*(reported: 2026-11-11 11:28:44)*

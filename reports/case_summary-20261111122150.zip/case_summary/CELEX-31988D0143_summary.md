# 'IV/31.206', 'Rich Products/Jus-rol'

**CELEX ID:** CELEX-31988D0143  
**Industry:** Bakery and Food Processing  
**Cartel Period:** 1983-07-31 : 1988-07-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0143 | IV/31206  |

### Case Title
Rich Products/Jus-rol

### Overview
The European Commission investigated an anticompetitive agreement between Jus-rol Limited and Rich Products Corporation in the bakery and food processing industry. The agreement was concluded in 1983 and expired in 1988. The Commission granted an exemption under Article 85(3) of the EEC Treaty, allowing the agreement to proceed until 31 July 1993 without being declared incompatible with the common market.

### Industry
Bakery and Food Processing

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 10.7:Manufacture of bakery and farinaceous products
NACE_class_code: 10.71: Manufacture of bread; manufacture of fresh pastry goods and cakes

### Companies Undertakings
| companies                 |
|:--------------------------|
| Jus-rol Limited           |
| Rich Products Corporation |

### Market
United Kingdom
market_outside_eu: True

### Cartel Period
1983-07-31 : 1988-07-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-07-31 | parties | concluded agreement |
| 1984-04-25 | Jus-rol Limited | notified Commission of the agreement |
| 1987-12-22 | Commission | adopted decision granting exemption |
| 1988-07-31 | redacted | agreement expired |

### Legal Framework
Article 85
infringement_concept: anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
medium

### Exemption
True
| company                   |
|:--------------------------|
| Jus-rol Limited           |
| Rich Products Corporation |

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an exemption under Article 85(3) of the EEC Treaty for the agreement between Jus-rol and Rich Products, allowing it to proceed until 31 July 1993 without being declared incompatible with the common market.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court      | country            | jurisdiction   |
|:-----------|:-------------------|:---------------|
| COMMISSION | European Community | EEC            |

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) of the EEC Treaty for the agreement between Jus-rol and Rich Products, allowing it to proceed until 31 July 1993 without being declared incompatible with the common market.


*(reported: 2026-10-16 20:11:41)*

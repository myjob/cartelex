# 'IV/D-1/30.373  P & I Clubs, IGA and No IV/D-1/37.143  P & I Clubs, Pooling Agreement', 'relating to a proceeding pursuant to Articles 85 and 86 of the EC Treaty and Articles 53 and 54 of the EEA Agreement'

**CELEX ID:** CELEX-31999D0329  
**Industry:** | industry                    |
|:----------------------------|
| Marine Insurance Industry   |
| Maritime Shipping Industry  |
| Marine Reinsurance Industry |  
**Cartel Period:** 1985-02-01 : 2009-02-20  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31999D0329 | IV/30373-2 |


### Case Title
IV/D-1/30.373  P & I Clubs, IGA and No IV/D-1/37.143  P & I Clubs, Pooling Agreement

### Overview
This case concerns the International Group of P & I Clubs and their alleged anticompetitive behavior in the marine insurance industry, specifically involving horizontal price fixing collusion under Articles 85 and 86 of the EC Treaty and Articles 53 and 54 of the EEA Agreement.

### Industry
| industry                    |
|:----------------------------|
| Marine Insurance Industry   |
| Maritime Shipping Industry  |
| Marine Reinsurance Industry |


### Oecd Nace
banking and insurance (including real estate), 50.1: Sea and coastal passenger water transport, 50.10: Sea and coastal passenger water transport

### Companies Undertakings
The International Group of P & I Clubs

### Market
Geographically, the market includes UK, Bermuda, Luxembourg, Norway, USA, Japan, Sweden. The market is outside the EU, oligopolistic, and turbulence information is not available.

### Cartel Period
1997-06-02 : 2009-02-20

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-07-27 | P&I Clubs | submitted formal notification for exemption |
| 1994-12-15 | Court of Justice of the European Union | delivered judgment in Case C-250/92 |
| 1996-03-15 | Commission | asked oral question |
| 1996-03-27 | European Parliament | adopted resolution |
| 1997-06-02 | Commission | issued Statement of Objections |
| 1998-07-07 | International Group | submitted formal notification for exemption of the Pooling Agreement |
| 1998-08-14 | Commission | published notice pursuant to Article 19(3) of Regulation No 17 |
| 1998-10-21 | International Group | published notice regarding the International Group Agreement |
| 1999-02-20 | Commission | amendments to agreements entered into force |
| 1999-04-12 | Commission of the European Communities | issued Commission Decision |
| 2009-02-20 | redacted | exemption period ended |


### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |


### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption was sought and granted for the International Group of P & I Clubs.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| company     | recidivism   |
|:------------|:-------------|
| P & I Clubs | True         |


### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court               | country        | jurisdiction   |
|:--------------------|:---------------|:---------------|
| European Commission | European Union | European Union |


### Book Reference
NA

### Outcome
The Commission took no action, and the case was not pursued further.


*(reported: 2026-10-16 22:39:04)*

# 'COMP/36.653', 'Opel'

**CELEX ID:** CELEX-32001D0146  
**Industry:** NA  
**Cartel Period:** 1993-02-01 : 1996-11-27  

## Summary

### Celex Case Id
CELEX-32001D0146

### Case Title
Opel

### Overview
The European Commission investigated Opel Nederland BV and General Motors Nederland BV for anticompetitive agreements involving territorial exclusivity and parallel trade bans in the motor vehicle market. The infringement occurred between 1993 and 1996, with the Commission ordering investigations and ultimately adopting a decision in 1998. Both companies were fined EUR 43 million each.

Overview of the case

### Industry
trade (wholesaling and retailing) and hotels

Industry context, from the 'companies_industry' and 'products' facts (products covers goods and services)

### Oecd Nace
trade (wholesaling and retailing) and hotels

OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

### Companies Undertakings
| companies                   |
|:----------------------------|
| Opel Nederland BV           |
| General Motors Nederland BV |

Companies and undertakings investigated, from the 'companies_investigated' fact, with their country from the 'companies_country' fact. Preserve markdown lists if present.

### Market
Netherlands, Germany, United Kingdom, Ireland, Austria, Belgium/Luxembourg

Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

### Cartel Period
1993-02-01 : 1996-11-27

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-01-01 | redacted | introduced Dutch registration tax on passenger cars |
| 1993-09-01 | redacted | started employment at Automobielbedrijf Canton-Reiss BV |
| 1993-09-01 | redacted | export sales began in period |
| 1995-06-28 | Commission | adopted Regulation (EC) No 1475/95 on motor vehicle distribution agreements |
| 1995-08-16 | Opel Nederland BV | launched Star Wars Astra Actie programme |
| 1996-09-26 | Opel Nederland BV | adopted decision to audit export dealers and restrict export sales |
| 1996-11-27 | redacted | completed audit of remaining dealers |
| 1996-12-04 | Commission | ordered investigations under Article 14(3) of Council Regulation (EC) No 17 |
| 1997-01-31 | Opel Nederland BV | ended sales campaign period |
| 1998-01-20 | Commission | terminated the established infringement |
| 1998-01-28 | Commission | adopted decision 98/273/EC (Case IV/35.733 — VW) |

Key timeline of events, from the 'heideltime_event_agg' and 'eu_commission_decision_date' facts

### Legal Framework
Article 81

Legal framework applying to the case: the operative articles ('law_article_operative', falling back to 'law_article_all_relevant') and the canonical concept ('infringement_concept')

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

### Leniency
False

Leniency: applicants, reductions granted and applications rejected, from the 'leniency_case', 'leniency_applicants', 'leniency_granted' and 'leniency_rejected' facts. Preserve markdown lists and tables if present.

### Fines
| company | amount |
| --- | --- |
| Opel Nederland BV | EUR 43 million |
| General Motors Nederland BV | EUR 43 million |

Fines imposed, from the 'fines' fact. CRITICAL: You must exactly preserve any markdown tables from the context.

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Opel Nederland BV | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| Court of First Instance   | European Union | European Union |
| European Court of Justice | European Union | European Union |

Courts involved and their rulings, from the 'is_court_involved' and 'court_list' facts. Preserve markdown tables if present.

### Book Reference
COMP/36.653

### Outcome
Cease and desist from infringing practices; refrain from repeating or continuing the measures in question; refrain from adopting other measures with the same object or effect; pay a fine of EUR 43 million jointly and severally liable

Outcome of the case


*(reported: 2026-11-11 12:06:43)*

# 'IV/35.617 — Phoenix/GlobalOne', 'NA'

**CELEX ID:** CELEX-31996D0547  
**Industry:** telecommunications  
**Cartel Period:** 1998-01-01 : 2003-01-01  

## Summary

### Celex Case Id
CELEX-31996D0547

### Case Title
IV/35617 — Phoenix/GlobalOne

### Overview
Overview of the case:

This case involved a major antitrust investigation by the European Commission into a cartel of telecommunications companies including Deutsche Telekom AG, France Télécom, Sprint Communications Corporation, and others. The investigation focused on abuse of dominance and anticompetitive agreements in the telecommunications sector. The Commission found high gravity infringements and imposed comprehensive remedies to address market distortions.

### Industry
telecommunications

### Oecd Nace
OECD & NACE classifications:

- OECD sector: communication
- NACE group code: 61.1: Wired telecommunications activities
- NACE class code: 61.10: Wired telecommunications activities

### Companies Undertakings
| Deutsche Telekom AG (DE) |
| France Télécom (FR) |
| Sprint Communications Corporation (US) |
| Atlas |
| Phoenix entities |
| Transpac France (FR) |
| T-Data |
| GlobalOne |

### Market
Relevant market:

- Geography: France, Germany, Netherlands, United Kingdom
- Structure: Oligopoly
- Turbulence: NA
- Outside EU: True

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| 1994-12-16 | France Télécom and Deutsche Telekom | notified Atlas agreements |
| 1995-06-29 | Commission | notified Phoenix transaction |
| 1995-06-29 | Commission | submitted application for negative clearance and notification for exemption |
| 1996-01-31 | redacted | established technical information licence and access master agreement |
| 1996-01-31 | redacted | signed operating entities services agreement |
| 1996-01-31 | redacted | signed investor confidentiality agreements |
| 1996-02-16 | United States Department of Justice | signed judicial consent decree |
| 1996-03-05 | notifying parties | announced new name GlobalOne |
| 1996-07-17 | Commission | issued Commission Decision relating to proceeding under Articles 85 and 53 of the EC Treaty and EEA Agreement |
| 1998-01-01 | DT and FT | implemented non-discrimination condition for telecommunications services |
| 1998-01-01 | redacted | enforcement of non-discrimination conditions for correspondent services |

### Legal Framework
Legal framework applying to the case:

- Operative articles: Article 86
- All relevant articles: 
  - Article 85
  - Article 86
- Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted:

- Exemption case: True
- Applicants: 
  - Deutsche Telekom AG (DE)
  - France Telécom (FR)
  - Sprint Communications Corporation (US)

### Leniency
Leniency: applicants, reductions granted and applications rejected:

- Leniency case: False
- Applicants: NA
- Granted: NA
- Rejected: NA

### Fines
NA

### Remedies
Remedies and orders to terminate the infringement:

1. Non-discrimination obligations for DT and FT towards Phoenix entities and third-party competitors in terms of access to PSTN, ISDN, and other telecommunications facilities.
2. Unbundling requirement for DT and FT regarding their own services and Phoenix services under the Atlas decision.
3. Obligation for DT and FT to provide non-reserved corporate telecommunications services and packet-switched data communications services on non-discriminatory terms.
4. Requirement that all entities created pursuant to Phoenix agreements be established as distinct legal entities separate from DT and FT, and obtain financing independently.
5. Compliance obligations including detailed recordkeeping, access to business premises for inspections by the Commission, submission of unaudited accounting data every six months starting one year after commencement of exemption, and provision of oral or written explanations upon request.
6. Restrictions on disclosure of information derived from operating PSTN or providing reserved services to Phoenix entities, ensuring no market foreclosure or barriers to entry.

### Company Recidivism
| Phoenix, DT, FT, Sprint | NA |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
Outcome of the case:

The Commission issued a decision under Articles 85 and 53 of the EC Treaty and EEA Agreement, imposing significant remedies on the companies involved. These included non-discrimination obligations, unbundling requirements, and compliance measures to ensure fair competition in the telecommunications market.


*(reported: 2026-10-16 20:52:34)*

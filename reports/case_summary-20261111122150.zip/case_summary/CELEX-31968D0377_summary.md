# 'NA', 'NA'

**CELEX ID:** CELEX-31968D0377  
**Industry:** NA  
**Cartel Period:** 1967-05-29 : 1971-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31968D0377 | IV/666    |

### Case Title
NA

### Overview
This case involves a cartel of French companies in the chemical and fertilizer industry, primarily engaged in the production and sale of ammonium sulphate, synthetic ammonium sulphate, ammonium nitrate, and other nitrogen compounds. The cartel operated from 1962 to 1967, with activities centered on limiting joint sales within EEC member states and restricting trade to France and non-EEC markets only. The case was investigated by the European Commission, which took a decision after requesting information and finding no action necessary. The cartel period began with the formalization of the Nitrex Agreement in 1962 and ended when the purpose of the company was changed in 1967 to limit joint sales to French and non-EEC markets.

### Industry
Chemical and fertilizer industry, manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.17: Manufacture of synthetic rubber in primary forms

### Companies Undertakings
| companies                                                                 | location          |
|:--------------------------------------------------------------------------|:------------------|
| Comptoir français de l'azote                                              | Paris             |
| Charbonnages de France                                                    | Paris             |
| Houillères du bassin du Nord et du Pas-de-Calais                          | Douai             |
| Houillères du bassin de Lorraine                                          | Saint-Avold       |
| Houillères du bassin d'Aquitaine                                          | Albi              |
| Houillères du bassin de la Loire                                          | Saint-Étienne     |
| Société industrielle et financière de Lens (Finalens)                     | Douvrin           |
| Société des produits chimiques d'Auby                                     | Neuilly-sur-Seine |
| Grand Parish Chemical Company                                             | Paris             |
| General Fertilizer and Chemical Products Company                          | Pierrefitte       |
| Potash and Chemical Fertilizers                                           | Paris             |
| Ugine-Kuhlmann Company                                                    | Paris             |
| Ugine-Kuhlmann Chemical Factories Company                                 | Paris             |
| Courrieres-Kuhlmann Chemical Products Company                             | Paris             |
| Anonymous Company of Explosives and Chemical Products                     | Paris             |
| National Industrial Nitrogen Office (O.N.I.A.)                            | Toulouse          |
| Chemical Fertilizer and Synthetic Products Company (Azolacq)              | Paris             |
| Roche-la-Molière Chemical Products Company                                | Paris             |
| Péchiney-Saint-Gobain                                                     | Levallois-Perret  |
| Lorraine Steel Union (Sidelor)                                            | Paris             |
| Usinor                                                                    | Paris             |
| Moselle Steel Company                                                     | Paris             |
| Normandy Metallurgical Company                                            | Paris             |
| Lorraine Continuous Rolling Company                                       | Paris             |
| Wendel Company                                                            | Paris             |
| Pont-à-Mousson Foundries Company                                          | Nancy             |
| Chatillon, Commentry and Neuves-Maisons Ironworks Company                 | Paris             |
| Monchecourt Industrial Company                                            | Paris             |
| Society of steelworks and wire-drawing mills of Neuves-Maisons, Chatillon | Paris             |

### Market
France, with outside EU market involvement

### Cartel Period
1962-10-12 : 1967-07-27

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1958-06-20 | Comptoir français de l'azote | founded as public limited company |
| 1962-02-06 | Comptoir français de l'Azote (C.F.A.) | based on Council Regulation No.17 |
| 1962-07-01 | redacted | began mediating export markets for shareholders |
| 1962-10-12 | shareholders and S.P.I.E.A. | formalized Nitrex Agreement defining export market boundaries |
| 1962-10-29 | MeJ.Lassier | submitted application for negative test |
| 1967-03-15 | Comptoir frangais de l'azote and French manufacturers | indicated intention to amend agreement |
| 1967-05-29 | Comptoir français de l'Azote (C.F.A.) | confirmed application for negative test |
| 1967-07-27 | shareholders of the C.F.A. | changed the purpose of the company to limit joint sales to French and non-EEC markets |
| 1967-07-27 | Comptoir frangais de l'azote and French manufacturers | amended version came into force and ceased contested behaviours |
| 1967-10-04 | Comptoir français de l'Azote (C.F.A.) | made provisional registration of agreement |
| 1968-03-12 | Advisory Committee on Cartel and Monopoly Issues | submitted statement |

### Legal Framework
NA

### Infringement Category
Export cartels

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

| company                                                |
|:-------------------------------------------------------|
| French Nitrogen Counter                                |
| Coal Mining Company of France                          |
| Coal mines of the Nord and Pas-de-Calais basin         |
| Coal mines of the Lorraine basin                       |
| Coal mines of the Aquitaine basin                      |
| Coal mines of the Loire basin                          |
| Industrial and Financial Society of Lens               |
| Chemical Products Company of Auby                      |
| Chemical Society of Grande-Paroisse                    |
| General Society of Fertilizers and Chemical Products   |
| Potash and Chemical Fertilizers                        |
| Ugine-Kuhlmann Company                                 |
| Ugine-Kuhlmann Chemical Plant Company                  |
| Courrières-Kuhlmann Chemical Products Company          |
| Explosives and Chemical Products Ltd.                  |
| National Industrial Office of Nitrogen                 |
| Chemical Society of Fertilizers and Synthetic Products |
| Roche-la-Molière Chemical Products Company             |
| Péchiney-Saint-Gobain                                  |
| Lorraine Steel Union                                   |
| Usinor                                                 |
| Moselle Steel Company                                  |
| Normandy Metallurgical Company                         |
| Lorraine Continuous Rolling Company                    |
| Wendel Company                                         |
| Pont-à-Mousson Foundries Company                       |
| Chatillon Forge Company                                |
| Monchecourt Industrial Company                         |
| Neuves-Maisons Steelworks and Wire-Drawing Company     |

### Leniency
False

### Fines
NA

### Remedies
Cease and desist from joint sales within EEC member states; limit joint sales to France and non-EEC markets only.

### Company Recidivism
| companies                    | recidivism   |
|:-----------------------------|:-------------|
| Comptoir français de l'Azote | True         |

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
| court                    | country   | jurisdiction   |
|:-------------------------|:----------|:---------------|
| Court of Appeal of Paris | France    | France         |

### Book Reference
IV/666

### Outcome
The European Commission took a decision after requesting information and finding no action necessary. The cartel was found to be in violation of EU competition law, with remedies imposed to cease joint sales within EEC member states and limit sales to France and non-EEC markets only.


*(reported: 2026-10-16 19:07:44)*

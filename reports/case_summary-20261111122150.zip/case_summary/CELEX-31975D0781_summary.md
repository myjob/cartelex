# 'IV/256', 'Bomée——Stichting'

**CELEX ID:** CELEX-31975D0781  
**Industry:** | industry          |
|:------------------|
| perfumes          |
| toiletry articles |
| cosmetics         |  
**Cartel Period:** 1972-01-03 : 1975-08-25  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0781 | IV/256    |

### Case Title
Bomée—Stichting

### Overview
This case involved the European Commission's investigation into restrictive practices by Bomée-Stichting and Maxis BV in the cosmetics, toiletries, and perfumes industry in the Netherlands. The infringement concerned vertical restraints related to territorial exclusivity and parallel trade bans under Article 85 of the Treaty. The Commission found that the conditions imposed by Bomée-Stichting were anticompetitive and ordered an end to these practices.

### Industry
perfumes, toiletry articles, cosmetics

### Oecd Nace
trade (wholesaling and retailing) and hotels; NACE group code 20.4: Manufacture of soap and detergents, cleaning and polishing preparations, perfumes and toilet preparations; NACE class code 20.42: Manufacture of perfumes and toilet preparations

### Companies Undertakings
| companies       |
|:----------------|
| Bomée-Stichting |
| Maxis BV        |

### Market
Netherlands, oligopolistic market

### Cartel Period
1972-01-03 : 1975-08-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-01-03 | BoméeStichting | notified Commission of intent to obtain negative clearance under Article 85(1) |
| 1972-01-03 | Bomée-Stichting | made new conditions operative |
| 1972-05-05 | BoméeStichting | notified Commission of new conditions text |
| 1973-06-22 | BoméeStichting | addressed statement of objections to Commission |
| 1974-12-19 | redacted | implemented restrictive Bomée conditions |
| 1974-12-19 | BoméeStichting | amended conditions of sale with effect from date |
| 1974-12-19 | BoméeStichting | granted permission to obtain supplies from other Member States |
| 1975-07-07 | Maxis BV | applied for exemption under Article 3 of Regulation No 17 |
| 1975-07-07 | Maxis BV | lodged complaint with the Commission in respect of the Bomée conditions |
| 1975-07-08 | Bomée-Stichting | wrote to Commission about amending Clause 1(2) |
| 1975-08-25 | redacted | amended product description to clarify Bomée conditions |
| 1975-08-25 | redacted | finalized infringing clauses |
| 1975-08-25 | Bomée-Stichting | amendment to Clause 1(2) became effective |
| 1975-08-25 | Bomée-Stichting | confirmed access to supplies from other Member States |
| 1975-09-25 | Advisory Committee | delivered opinion on restrictive practices |
| 1975-11-21 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |
| 1975-11-21 | redacted | issued decision requiring end of infringement |

### Legal Framework
Article 85 (anticompetitive agreement)

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
| applicants |
| --- |
| Maxis BV |

### Leniency
NA

### Fines
NA

### Remedies
Bomée-Stichting shall bring the infringement to an end forthwith by ceasing to apply the offending clause referred to in Article 1, which includes Clauses 10 (1), (3) and (5) and Clause 11 of the 1974 Bomée conditions.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Bomée-Stichting | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
A. BORSCHETTE

### Courts
NA

### Book Reference
IV/256

### Outcome
The Commission found that Bomée-Stichting's conditions were anticompetitive under Article 85 and ordered an immediate end to the infringement by ceasing to apply the offending clauses.


*(reported: 2026-11-11 10:11:41)*

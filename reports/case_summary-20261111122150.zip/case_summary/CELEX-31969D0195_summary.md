# 'NA', 'NA'

**CELEX ID:** CELEX-31969D0195  
**Industry:** public construction  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31969D0195 | IV/22548  |

### Case Title
NA

### Overview
This case involves Christiani & Nielsen N.V. and Christiani & Nielsen A/S, both based in Denmark, who were investigated for cartel behavior in the public construction industry. The companies concluded agreements in 1931 and extended them in 1959, with a final decision by the Commission on 1969-06-18.

### Industry
public construction

### Oecd Nace
OECD sector: construction
NACE group code: 42.9:Construction of other civil engineering projects
NACE class code: 42.91: Construction of water projects

### Companies Undertakings
| companies                 |
|:--------------------------|
| Christiani & Nielsen N.V. |
| Christiani & Nielsen A/S  |

### Market
Relevant market includes Denmark, Netherlands, Germany, and France.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1931-08-25 | Christiani & Nielsen | concluded agreement |
| 1931-08-25 | Christiani & Nielsen, Copenhagen | concluded agreement with subsidiary |
| 1959-03-20 | Christiani & Nielsen | extended agreement |
| 1959-03-20 | Christiani & Nielsen, Copenhagen | extended agreement with subsidiary |
| 1963-02-22 | Christiani & Nielsen, The Hague | submitted application for negative test |
| 1968-05-07 | Christiani & Nielsen, The Hague | confirmed application for negative test |
| 1969-03-11 | Advisory Committee on Cartel and Monopoly Issues | delivered opinion on agreement |
| 1969-06-18 | Commission of the European Communities | issued decision on negative test |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies            | recidivism   |
|:---------------------|:-------------|
| Christiani & Nielsen | False        |

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action and issued a decision on the negative test.


*(reported: 2026-10-16 19:15:56)*

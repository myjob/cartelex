# 'IV/33.300', 'Baccarat'

**CELEX ID:** CELEX-31991D0213  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0213 | IV/33300  |

### Case Title
IV/33.300 – Baccarat

### Overview
The European Commission investigated Compagnie des Cristalleries Baccarat for alleged abuse of dominance and anticompetitive agreements under Articles 85 and 86 of the EC Treaty. The case involved luxury goods, specifically crystalware and gifts, manufactured in France.

### Industry
luxury goods

### Oecd Nace
trade (wholesaling and retailing) and hotels; 23.1:Manufacture of glass and glass products; 23.19: Manufacture and processing of other glass, including technical glassware

### Companies Undertakings
Compagnie des Cristalleries Baccarat (FR)

### Market
France

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 |
| 1990-02-13 | Commission | imposed periodic penalty payment on Baccarat for failure to supply requested information |
| 1990-02-13 | Commission | adopted Decision requiring information |
| 1990-04-12 | Baccarat | sent requested information |
| 1990-04-17 | Commission | information received by Commission |
| 1990-10-01 | Baccarat | submitted written reply to statement of objections |
| 1991-03-15 | Commission | issued Decision

### Legal Framework
Articles 85, 86

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Compagnie des Cristalleries Baccarat | ECU 10000 |

### Remedies
ECU 10,000 penalty payment under Article 16(2) of Regulation No 17

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed a fine of ECU 10,000 on Compagnie des Cristalleries Baccarat for abuse of dominance and anticompetitive agreements. The case was decided under Regulation No 17.


*(reported: 2026-11-11 11:26:55)*

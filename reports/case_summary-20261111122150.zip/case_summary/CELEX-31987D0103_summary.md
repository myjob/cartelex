# 'IV/31.356', 'ABI'

**CELEX ID:** CELEX-31987D0103  
**Industry:** NA  
**Cartel Period:** 1970-01-01 : 1982-03-31  

## Summary

### Celex Case Id
CELEX-31987D0103

### Case Title
ABI

### Overview
The case involves the Associazione Bancaria Italiana (ABI), a trade association in Italy, which was found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty. The infringement involved horizontal price-fixing collusion in banking services. The Commission granted exemptions under Article 85(3) for certain agreements, but imposed reporting obligations on ABI to monitor conditionality attached to the exemption periods.

### Industry
Italian bills and documents collection service, service of collecting bank cheques, foreign exchange dealings, non-resident account lire dealings, safe deposit service, safe custody service, telephone bills payment service, uniform type of lire traveller's cheque.

### Oecd Nace
banking and insurance (including real estate); 64.1:Monetary intermediation; 64.11: Central banking

### Companies Undertakings
Associazione Bancaria Italiana (IT)

### Market
Italy

### Cartel Period
1985-08-02 : 1994-10-10

### Key Timeline
1962-02-06: Council established Council Regulation No 17
1984-10-11: ABI notified agreements on banking services
1985-08-02: ABI sent statement of objections
1986-12-12: Commission of the European Communities issued Commission Decision relating to proceeding under Article 85
1986-12-12: Commission made a finding
1994-10-10: Exemption period ended

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
Trade associations

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
The Commission granted exemptions under Article 85(3) for certain agreements, but required the Associazione Bancaria Italiana (ABI) to inform it forthwith of any changes in commissions and value dates specified in the notified agreements, as per Article 3. The ABI was also required to comply with reporting obligations to monitor conditionality attached to the exemption periods.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
IV/31.356

### Outcome
The Commission granted exemptions under Article 85(3) for certain agreements, but required the Associazione Bancaria Italiana (ABI) to inform it forthwith of any changes in commissions and value dates specified in the notified agreements, as per Article 3. The ABI was also required to comply with reporting obligations to monitor conditionality attached to the exemption periods.


*(reported: 2026-10-16 20:13:03)*

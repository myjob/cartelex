# 'IV/28.980', 'Pabst & Richarz/BNIA'

**CELEX ID:** CELEX-31976D0684  
**Industry:** alcoholic beverages  
**Cartel Period:** 1974-05-29 : 1974-06-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31976D0684 | IV/28980  |

### Case Title
Pabst & Richarz/BNIA

### Overview
This case involved anticompetitive practices in the alcoholic beverages industry, specifically concerning Armagnac. The European Commission found that a prohibition on bulk deliveries of Armagnac of age grades 4 and 5, imposed by the Bureau national interprofessionnel de I'armagnac (BNIA), constituted an infringement of Article 85(1) of the Treaty. The restriction disrupted trade between Member States, particularly affecting exports to Germany, and distorted competition by artificially reducing supply and raising prices.

### Industry
alcoholic beverages

### Oecd Nace
OECD sector: manufacturing
NACE group code: 11.0:Manufacture of beverages
NACE class code: 11.01: Distilling, rectifying and blending of spirits

### Companies Undertakings
| companies                                        |
|:-------------------------------------------------|
| Pabst & Richarz KG                               |
| Bureau national interprofessionnel de I'armagnac |
| Ducouret & Cie                                   |

### Market
The relevant market involves France and Germany. The prohibition on bulk deliveries of Armagnac of age grades 4 and 5 disrupted trade between Member States by preventing new export agreements, particularly affecting exports to Germany. The measure was found to distort competition, artificially reduce supply, raise prices, and negatively impact market dynamics; this indicates significant market turbulence related to commercial policy interventions beyond necessary quality control measures.

### Cartel Period
1974-05-29 : 1974-06-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | BNIA | adopted Council Regulation No 17 |
| 1974-05-28 | BNIA | convened general meeting to consider situation as to age grades of brandies |
| 1974-05-28 | BNIA | decided to suspend deliveries of age grades 4 and 5 |
| 1974-05-29 | Bureau national interprofessionnel de l'armagnac | issued circular prohibiting deliveries of bulk Armagnac of age grades 4 and 5 |
| 1974-06-01 | BNIA | implemented restriction on dispatch of bulk Armagnac with age grade 4 or higher |
| 1974-12-09 | BNIA | issued circular 16/74 regulating qualities |
| 1975-02-13 | BNIA | revoked prohibition on deliveries |
| 1976-07-26 | BNIA | adopted decision declaring prohibition an infringement of Article 85(1) |

### Legal Framework
The operative articles are Article 85 and Article 90. The canonical concept is anticompetitive_agreement, public_undertaking.

### Infringement Category
horizontal

### Infringement Sub Category
trade associations

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
The Commission declared the prohibition on deliveries of bulk Armagnac of age grades 4 and 5 as an infringement of Article 85(1) and ordered the cessation of the infringing practice. This was accomplished by formally issuing a Decision under the Treaty, which effectively required the revocation of the circular that imposed the restriction.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
G. M. Thomson

### Courts
| court                                  | country            | jurisdiction                |
|:---------------------------------------|:-------------------|:----------------------------|
| Commission of the European Communities | European Community | European Economic Community |

### Book Reference
NA

### Outcome
The Commission declared the prohibition on deliveries of bulk Armagnac of age grades 4 and 5 as an infringement of Article 85(1) and ordered the cessation of the infringing practice. The case was decided by the Commission of the European Communities under the European Economic Community jurisdiction.


*(reported: 2026-11-11 10:15:06)*

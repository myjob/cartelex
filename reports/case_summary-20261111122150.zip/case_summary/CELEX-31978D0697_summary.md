# 'IV/28.859', 'conditions of sale'

**CELEX ID:** CELEX-31978D0697  
**Industry:** Whisky and Spirits  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0697 | IV/28859  |

### Case Title
IV/28.859 – Conditions of sale

### Overview
The European Commission investigated Wm. Teacher and Sons Ltd for anticompetitive practices under Article 85 of the EC Treaty, specifically involving vertical restraints related to territorial exclusivity and parallel trade bans in the whisky and spirits industry.

### Industry
Whisky and Spirits

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 11.0: Manufacture of beverages
NACE Class Code: 11.01: Distilling, rectifying and blending of spirits

### Companies Undertakings
Wm. Teacher and Sons Ltd

### Market
Geographical market includes United Kingdom and EEC countries; no information on market turbulence or oligopoly.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1974-04-17 | Teacher and Sons Ltd | notified conditions of sale containing prohibitions to export and resell in bond |
| 1977-06-21 | Commission | initiated proceedings in the case |
| 1977-07-12 | Commission | issued statement of objections |
| 1977-08-29 | Teacher | replied to Commission's statement of objections |
| 1978-01-17 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on the case |
| 1978-07-28 | Commission | issued decision relating to proceedings under Article 85 |
| 1978-07-28 | redacted | signed Decision |

### Legal Framework
Law Article Operative: Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought by Wm. Teacher and Sons Ltd.

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered Wm. Teacher and Sons Ltd to bring the infringement referred to in Article 1 to an end without delay, and to refrain from any further action by means of sales conditions calculated to restrict the exportation from the United Kingdom to other EEC countries.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Wm. Teacher and Sons Ltd | NA |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission ordered Wm. Teacher and Sons Ltd to cease the infringing practices related to export restrictions and resale prohibitions under Article 85.


*(reported: 2026-11-11 10:25:07)*

# 'IV/30.804', 'Nuovo CEGAM'

**CELEX ID:** CELEX-31984D0191  
**Industry:** engineering insurance  
**Cartel Period:** 1983-06-22 : 2010-12-31  

## Summary

### Celex Case Id
CELEX-31984D0191

### Case Title
Nuovo CEGAM

### Overview
This case involved a cartel in the engineering insurance sector in Italy, formed by numerous Italian and foreign insurance companies. The cartel operated from 1983 to 1993, engaging in horizontal restraints such as market sharing, quota cartels, and specialization agreements. The European Commission investigated the agreement and ultimately granted an exemption under Article 85(3) of the Treaty, allowing the cartel to continue for ten years without imposing remedies.

### Industry
engineering insurance

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 33.2:Installation of industrial machinery and equipment
NACE class code: 33.20: Installation of industrial machinery and equipment

### Companies Undertakings
| companies                                              | location   |
|:-------------------------------------------------------|:-----------|
| Nuovo Consorzio Centrale Guasti alle Macchine          | NA         |
| Assitalia Le Assicurazioni d'Italia                   | NA         |
| Milano Assicurazioni                                   | NA         |
| Compagnie riunite di assicurazione                     | NA         |
| La Fondiaria                                           | NA         |
| Italiana incendio, vita e rischi diversi               | NA         |
| La Pace  Assicurazioni e riassicurazioni               | NA         |
| RAS — L'Assicuratrice italiana                         | NA         |
| Società cattolica di assicurazione                     | NA         |
| Società reale mutua di assicurazioni                   | NA         |
| Toro Assicurazioni                                     | NA         |
| UAP Italiana                                           | NA         |
| Nationale suisse — Compagnia italiana di assicurazione | NA         |
| La Previdente                                          | NA         |
| ITAS  Istituto Trentino-Alto Adige per assicurazioni   | NA         |
| Winterthur — Compagnia italo-svizzera di assicurazioni | NA         |
| CARD  Compagnia di assicurazioni rami danni            | NA         |
| Compagnia latina di assicurazioni                      | NA         |
| Unione italiana di riassicurazione                     | NA         |
| La Vittoria riassicurazioni                            | NA         |
| Reale riassicurazioni                                  | NA         |
| La Consorziale                                         | NA         |
| Compagnie suisse de réassurances                       | NA         |
| Gerling Konzern Global                                 | NA         |
| Münchener Rückvers.-Ges.                               | NA         |

### Market
Relevant market: Italy (oligopoly)

### Cartel Period
1983-06-22 : 1993-06-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-01-01 | Italian and foreign insurance companies | formed an association to promote engineering insurance business |
| 1983-02-16 | European Commission | sent statement of objections to Nuovo CEGAM |
| 1983-04-11 | Nuovo CEGAM | replied to Commission's statement of objections and prepared to amend basic documents |
| 1983-05-18 | Association Nuovo CEGAM | approved statutes and convention at extraordinary general meeting |
| 1983-06-22 | Association Nuovo CEGAM and reinsurers | notified quota and threshold agreement |
| 1983-06-22 | Nuovo CEGAM | submitted notification under Article 4 of Regulation No 17 |
| 1983-06-22 | Nuovo CEGAM | notified basic instruments for negative clearance or exemption under Article 85(3) |
| 1984-03-30 | Commission of the European Communities | issued decision under Article 85(3) of the Treaty |
| 1993-06-21 | redacted | exemption period ended |
| 2000-12-31 | redacted | agreement extended to this date |

### Legal Framework
Article 85, infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company                                                |
|:-------------------------------------------------------|
| Assitalia Le Assicurazioni d'Italia                    |
| Milano Assicurazioni                                   |
| Compagnie riunite di assicurazione                     |
| La Fondiaria                                           |
| Italiana incendio, vita e rischi diversi               |
| La Pace — Assicurazioni e. riassicurazioni             |
| RAS — L'Assicuratrice italiana                         |
| Società cattolica di assicurazione                     |
| Società reale mutua di assicurazioni                   |
| Toro Assicurazioni                                     |
| UAP Italiana                                           |
| Nationale suisse — Compagnia italiana di assicurazione |
| La Previdente                                          |
| ITAS — Istituto Trentino-Alto Adige per assicurazioni  |
| Winterthur — Compagnia italo-svizzera di assicurazioni |
| CARD — Compagnia di assicurazioni rami danni           |
| Compagnia latina di assicurazioni                      |

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders were imposed to terminate the infringement. The Commission granted an exemption under Article 85(3) for a period of 10 years without imposing structural or behavioral remedies.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
True

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) for a period of 10 years without imposing structural or behavioral remedies.


*(reported: 2026-10-16 20:04:57)*

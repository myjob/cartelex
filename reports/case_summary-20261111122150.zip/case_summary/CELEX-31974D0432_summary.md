# 'IV/28.374', 'Advocaat Zwarte Kip'

**CELEX ID:** CELEX-31974D0432  
**Industry:** alcoholic beverages  
**Cartel Period:** 1938-02-17 : 1973-07-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31974D0432 | IV/28374  |

### Case Title
Advocaat Zwarte Kip

### Overview
This case involved anticompetitive agreements between Van Olffen VB of Hattem and Cinoco SA of Brussels concerning the trade mark 'Advocaat Zwarte Kip' in the alcoholic beverages industry. The agreements were found to restrict competition within the European Economic Community under Article 85 of the EEC Treaty.

### Industry
alcoholic beverages

### Oecd Nace
OECD sector: manufacturing
NACE group code: 46.1:Wholesale on a fee or contract basis
NACE class code: 46.17:Agents involved in the sale of food, beverages and tobacco

### Companies Undertakings
| companies               | country   |
|:------------------------|:----------|
| Van Olffen VB of Hattem | NL        |
| Cinoco SA of Brussels   | BE        |

### Market
Relevant market includes the Netherlands, Belgium, and Luxembourg. The market is not described as oligopolistic or turbulent.

### Cartel Period
1938-02-17 : 1973-07-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1938-02-17 | Van Olffen VB of Hattem and Cinoco SA of Brussels | signed agreement concerning use of trade mark 'Advocaat Zwarte Kip' |
| 1966-12-20 | Cinoco | filed original registration of trade mark 'Advocaat Zwarte Kip' |
| 1971-02-25 | Van Olffen | re-registered under Benelux arrangements as owner of all rights in trade mark 'Advocaat Zwarte Kip' |
| 1971-07-20 | Cinoco | re-registered under Benelux arrangements as owner of trade mark 'Advocaat Zwarte Kip' for Belgian and Luxembourg territory |
| 1971-08-27 | Cinoco | brought proceedings against Soenen for infringement of trade mark 'Advocaat Zwarte Kip' |
| 1973-05-24 | Tribunal de Commerce | gave judgment in favor of Cinoco on trade mark infringement |
| 1973-07-30 | Soenen | appealed the judgment to the Court of Appeal at Ghent |
| 1974-02-06 | Van Olffen VB of Hattem and Cinoco SA of Brussels | initiated proceedings pursuant to Article 3 of Regulation No 17 |
| 1974-05-29 | Commission of the European Communities | issued opinion pursuant to Article 10 of Regulation No 17 |
| 1974-07-24 | Commission of the European Communities | made decision relating to proceeding under Article 85 of the EEC Treaty |
| 1974-07-24 | Van Olffen VB of Hattem and Cinoco SA of Brussels | addressed with decision to end infringement of trade mark

### Legal Framework
Legal framework: Article 85 (operative article), EEC Treaty. Infringement concept: anticompetitive_agreement.

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True. Applicants: NA.

### Leniency
Leniency case: False. Applicants: NA. Granted: NA. Rejected: NA.

### Fines
NA

### Remedies
Cease and desist from preventing the free movement between the Netherlands, Belgium and Luxembourg of products bearing the trade mark 'Advocaat Zwarte Kip'

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Van Olffen VB of Hattem | NA |
| Cinoco SA of Brussels | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country   | jurisdiction   |
|:---------------------------------------|:----------|:---------------|
| Court of Justice of the European Union | Belgium   | European Union |
| Commercial Court of Brussels           | Belgium   | Brussels       |
| Commercial Court of Courtrai           | Belgium   | Courtrai       |

### Book Reference
NA

### Outcome
The European Commission found that the agreements between Van Olffen VB of Hattem and Cinoco SA of Brussels restricted competition in breach of Article 85 of the EEC Treaty. The Commission issued a decision to end the infringement, requiring cessation of actions preventing free movement of products bearing the trade mark 'Advocaat Zwarte Kip'.


*(reported: 2026-11-11 10:06:25)*

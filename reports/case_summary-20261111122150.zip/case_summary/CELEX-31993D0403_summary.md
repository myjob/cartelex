# 'IV/32.150', 'EBU/Eurovision System'

**CELEX ID:** CELEX-31993D0403  
**Industry:** NA  
**Cartel Period:** 1990-07-03 : 1993-02-26  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31993D0403 | IV/32150-1 |

### Case Title
IV/32.150–EBU/Eurovision System

### Overview
The European Commission investigated anticompetitive agreements among broadcasters, particularly focusing on the European Broadcasting Union (EBU) and its sub-licensing schemes. The case involved horizontal restraints in the broadcasting industry under Article 85 of the EC Treaty.

### Industry
Broadcasting industry, including feature films, television films, series, shows, games, drama, documentaries, and sports.

### Oecd Nace
OECD sector: communication
NACE group code: 59.1: Motion picture, video and television programme activities
NACE class code: 59.11: Motion picture, video and television programme production activities

### Companies Undertakings
| company                                        |
|:-----------------------------------------------|
| European Broadcasting Union                    |
| TF1                                            |
| BSkyB                                          |
| ARD                                            |
| SAT1                                           |
| TESN                                           |
| Screensport                                    |
| News International/Sky Channel                 |
| Deutsches Sportfernsehen                       |
| The European Sports Network TESN               |
| Eurosport                                      |
| Association of Commercial Television in Europe |
| OIRT                                           |

### Market
Relevant market includes Germany, France, and the United Kingdom. Market turbulence is driven by increased competition from private broadcasters, emergence of professional sports rights agencies, deregulation of television broadcasting, shift in advertising revenues, and increasing prices for sports rights due to competition.

### Cartel Period
1988-12-05 : 1998-02-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-12-05 | European Commission | initiated proceedings in the case |
| 1988-12-12 | Commission | sent first statement of objections to EBU |
| 1989-04-03 | EBU | notified relevant rules to Commission |
| 1989-04-03 | EBU | submitted application for negative clearance or exemption |
| 1990-07-03 | EBU | adopted sub-licensing scheme |
| 1990-10-05 | Commission | published notice indicating intention to grant exemption |
| 1990-12-18 | Commission | organized oral hearing with interested parties |
| 1990-12-19 | Commission | organized oral hearing with interested parties |
| 1991-06-24 | Commission | sent supplementary statement of objections |
| 1991-11-08 | EBU | submitted new scheme governing contractual access for non-members |
| 1993-02-26 | EBU | submitted final version of sub-licensing scheme |
| 1993-02-26 | EBU | submitted amended scheme of rules governing contractual access for non-members |
| 1993-06-11 | Commission | issued Commission Decision |

### Legal Framework
Legal framework: Article 85 (operative), Article 90 (relevant). Infringement concept: anticompetitive_agreement, public_undertaking.

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption was sought and granted to the European Broadcasting Union.

### Leniency
NA

### Fines
NA

### Remedies
The EBU must inform the Commission of any amendments and additions to the rules notified, of all arbitration procedures concerning disputes under the access scheme, and of all decisions regarding applications for membership by third parties.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                             | country       | jurisdiction   |
|:----------------------------------|:--------------|:---------------|
| Court of Justice                  | nan           | nan            |
| Court of Appeal                   | national      | competent      |
| International Chamber of Commerce | international | arbitration    |

### Book Reference
NA

### Outcome
The European Commission granted an exemption to the EBU under specific conditions, allowing it to continue its sub-licensing scheme while ensuring compliance with EU competition law.


*(reported: 2026-10-16 20:23:58)*

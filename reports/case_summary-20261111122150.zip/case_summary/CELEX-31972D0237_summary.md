# 'IV/17.545, 6.964, 26.858, 26.890, 18.673, 17.448', 'Davidson Rubber Co.'

**CELEX ID:** CELEX-31972D0237  
**Industry:** vehicle interior components  
**Cartel Period:** 1959-01-01 : 1979-06-26  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0237 | IV/6964   |

### Case Title
Davidson Rubber Co.

### Overview
This case involved anticompetitive agreements in the vehicle interior components industry, specifically relating to patent and know-how license agreements. The agreements were found to be in violation of Article 85 of the Treaty, which prohibits certain agreements that may affect trade between Member States and that have as their object or effect the prevention, restriction or distortion of competition within the common market.

### Industry
vehicle interior components

### Oecd Nace
OECD sector: manufacturing
NACE group code: 31.0:Manufacture of furniture
NACE class code: 31.09: Manufacture of other furniture

### Companies Undertakings
| companies                         |
|:----------------------------------|
| Davidson Rubber Company           |
| Gebr. Happich GmbH                |
| Gallino S.p.A.                    |
| Maglum S.A.                       |
| C.I.M.                            |
| Stampaggio Resine Speciali S.p.A. |

| companies_investigated            | country   |
|:----------------------------------|:----------|
| Davidson Rubber Company           | US        |
| Gebr. Happich GmbH                | DE        |
| Gallino S.p.A.                    | IT        |
| Maglum S.A.                       | CL        |
| C.I.M.                            | IT        |
| Stampaggio Resine Speciali S.p.A. | IT        |

### Market
Relevant market includes USA, Germany, Italy, and France. The market is characterized as an oligopoly.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-06-05 | Davidson Rubber Company | concluded patent-and-know-how licence agreement |
| 1959-06-05 | Davidson Rubber Co. | concluded patent and know-how license agreement with Gebr. Happich GmbH |
| 1962-03-13 | unknown | agreements amended in accordance with Commission's suggestions |
| 1965-04-07 | Happich and Maglum | repealed clause prohibiting exports |
| 1965-12-14 | Maglum | concluded patent and know-how license agreement |
| 1970-10-01 | parties | lifted obligation not to challenge patent validity |
| 1971-02-12 | unknown | contract filed with Commission |
| 1971-05-06 | Happich | lifted export ban in agreement with Gallino |
| 1971-05-06 | Commission | repealed export prohibition clause |
| 1971-05-06 | unknown | amended and became effective |
| 1972-01-20 | Advisory Committee on Cartel and Monopoly Issues | submitted opinion pursuant to Article10 of Regulation No.17 |

### Legal Framework
Legal framework applying to the case: the operative article is Article 85 and the canonical concept is anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission did not issue direct cease and desist orders or structural remedies (e.g., divestitures). Instead, the remedy involved behavioral changes to existing agreements to bring them into compliance with Article 85(3) of the Treaty. Specifically, contractual clauses were amended such as removing obligations not to challenge patent validity (effective 1 October 1970), eliminating export bans between parties (e.g., Happich-Maglum on 7 April 1965; Happich-Gallino on 6 May 1971), and ensuring agreements meet the conditions under Article 85(3).

### Company Recidivism
| company                 | recidivism   |
|:------------------------|:-------------|
| Davidson Rubber Company | False        |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
S.L. Mansholt

### Courts
NA

### Book Reference
IV/6964

### Outcome
The Commission took a decision to address the anticompetitive agreements, focusing on behavioral remedies rather than structural ones. The agreements were amended to comply with Article 85(3) of the Treaty.


*(reported: 2026-10-16 19:13:36)*

# 'NA', 'NA'

**CELEX ID:** CELEX-31977D0327  
**Industry:** NA  
**Cartel Period:** 1974-01 : 1974-04-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31977D0327 | IV/28841  |

### Case Title
NA

### Overview
This case involves a group of oil companies in the Netherlands found to have engaged in abuse of dominance and anticompetitive agreements during the oil crisis of 1973-1974. The companies were investigated for their conduct related to the supply of motor spirit, particularly during periods of scarcity and economic instability.

### Industry
The industry context involves the refining and distribution of petroleum products, specifically premium and standard grade motor spirit.

### Oecd Nace
OECD sector: manufacturing
NACE group code: 19.2: Manufacture of refined petroleum products
NACE class code: 19.20: Manufacture of refined petroleum products

### Companies Undertakings
| companies                                      |
|:-----------------------------------------------|
| Benzine en Petroleum Handelmaatschappij BV     |
| British Petroleum Raffinaderij Nederland NV    |
| British Petroleum Maatschappij Nederland BV    |
| ABG oil companies operating in the Netherlands |
| Esso Nederland BV                              |
| Shell Nederland Raffinaderij BV                |
| Shell Nederland Verkoopmaatschappij BV         |
| Shell Nederland BV                             |
| Mobiloil BV                                    |
| Chevron Petroleum Maatschappij (Nederland) BV  |
| Texaco Olie Maatschappij NV                    |
| Gulfoil (Nederland) BV                         |
| Gulf Oil Raffinaderij BV                       |
| Gulf Oil (Nederland) BV                        |
| Fina Nederland BV                              |
| Total Nederland NV                             |
| Petrofina                                      |
| Compagnie frangaise des pétroles               |
| Mobil Oil BV                                   |
| Aardolie Belangen Gemeenschap BV               |
| Avia Nederland CV                              |
| Olie Contact Commissie (OCC)                   |
| Rijksbureau voor Aardolie Produkten (RBAP)     |

### Market
The relevant market is the Netherlands, characterized by an oligopoly structure and significant turbulence due to the oil crisis beginning in November 1973. The crisis caused a sudden reduction in oil supply, leading to scarcity, economic instability, and the emergence of dominant positions for large oil firms.

### Cartel Period
1974-01 : 1974-04-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-12-10 | Compagnie frangaise de pétroles and Total Nederland NV | commenced work on Vlissingen refinery |
| 1973-11-01 | BP | reduced deliveries to ABG by 74% during crisis period |
| 1973-11-13 | ABG | received supplies of motor spirit |
| 1973-11-30 | ABG | continued receiving supplies of motor spirit |
| 1974-01-01 | BP | agreement entered into force |
| 1974-01-02 | Gulf | received telex from ABG requesting deliveries and delivered insufficient quantity |
| 1974-01-02 | ABG | requested Gulf and other oil companies to supply motor spirit |
| 1974-01-12 | OCC members | established a petrol pool for supply difficulties |
| 1974-02-28 | Dutch authorities | issued decree on maximum prices for motor spirit |
| 1974-04-01 | ABG | ended supply period |
| 1976-12-10 | Advisory Committee on Restrictive Practices | delivered opinion |
| 1977-04-19 | Commission of the European Communities | issued decision |

### Legal Framework
Legal framework applying to the case:

Operative articles: Article 86
All relevant articles: 
| law_article   |
|:--------------|
| Article 85    |
| Article 86    |
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUel

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision in the case, finding that the companies engaged in abuse of dominance and anticompetitive agreements. The case was part of the EU's enforcement actions during the oil crisis period.


*(reported: 2026-11-11 10:17:18)*

# 'IV/26612', 'MAN/SAVIEM'

**CELEX ID:** CELEX-31972D0088  
**Industry:** truck manufacturing  
**Cartel Period:** 1970-01-01 : 1972-01-17  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0088 | IV/26612  |

### Case Title
MAN/SAVIEM

### Overview
This case involves the European Commission's decision concerning two companies, MAN and SAVIEM, who entered into an agreement restricting competition in the truck manufacturing industry. The agreement was registered under Regulation No.17 and later reviewed by the Commission.

### Industry
truck manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 29.1:Manufacture of motor vehicles
NACE class code: 29.10: Manufacture of motor vehicles

### Companies Undertakings
| companies                                                            | country   |
|:---------------------------------------------------------------------|:----------|
| Maschinenfabrik Augsburg-Nürnberg AG                                 | DE        |
| Société Anonyme de Véhicules Industriels et d'Equipements Mécaniques | FR        |

### Market
Germany, France
Market outside EU: false
Market oligopoly: False
Market turbulence: NA

### Cartel Period
1968-02-21 : 1968-03-11

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-02-21 | MAN and SAVIEM | concluded agreement restricting competition |
| 1968-03-11 | Maschinenfabrik Augsburg-Nürnberg AG and Société Anonyme de Véhicules Industriels et d'Equipements Mécaniques | registered cooperation agreement under Regulation No.17 |
| 1969-06-14 | European Communities | published essential content of application in Official Journal |
| 1972-01-17 | Commission of the European Communities | issued decision concerning procedure under Article85 |
| 1974-12-31 | Maschinenfabrik Augsburg-Nürnberg AG and Société Anonyme de Véhicules Industriels et d'Equipements Mécaniques | submitted report to Commission on cooperation measures and market shares

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Commission ordered the companies to report every three years on specialization and cooperation measures, impacts, market shares, and to disclose all agreements entered into among themselves or with third-party automobile manufacturers that affect competitive behavior.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision but did not take any action.


*(reported: 2026-10-16 19:23:08)*

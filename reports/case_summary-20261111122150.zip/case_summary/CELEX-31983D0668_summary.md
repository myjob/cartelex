# '83/668/EEC', 'Extra alloy'

**CELEX ID:** CELEX-31983D0668  
**Industry:** commercial vehicle manufacturing  
**Cartel Period:** 1976-11-04 : 1987-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0668 | IV/29329  |

### Case Title
83/668/EEC – Extra alloy

### Overview
The European Commission investigated an anticompetitive agreement between Volkswagenwerk AG and Maschinenfabrik Augsburg-Nürnberg AG in the commercial vehicle manufacturing industry. The agreement was found to infringe Article 85 of the EEC Treaty, with a medium gravity infringement. The Commission granted an exemption from Article 85(1) subject to notification obligations.

### Industry
commercial vehicle manufacturing

### Oecd Nace
manufacturing
29.1:Manufacture of motor vehicles
29.10: Manufacture of motor vehicles

### Companies Undertakings
| companies                            |
|:-------------------------------------|
| Volkswagenwerk AG                    |
| Maschinenfabrik Augsburg-Nürnberg AG |

### Market
market_oligopoly: True
market_geographical: NA
market_outside_eu: no
market_turbulence: NA

### Cartel Period
1976-11-04 : 1987-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-10-14 | VW and MAN | signed preliminary memorandum of understanding |
| 1977-08-25 | VW and MAN | signed Cooperation Agreement concerning commercial vehicles |
| 1982-11-29 | Volkswagenwerk AG and Maschinenfabrik Augsburg-Nürnberg AG | amended cooperation agreement |
| 1983-12-05 | Commission of the European Communities | issued decision on the agreements |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
| company                              |
|:-------------------------------------|
| Volkswagenwerk AG                    |
| Maschinenfabrik Augsburg-Nürnberg AG |

### Leniency
NA

### Fines
NA

### Remedies
The Commission granted an exemption from Article 85(1) subject to notification obligations. Parties must inform the Commission immediately upon any substantial amendment or addition being made to the notified Agreements, and if Volkswagenwerk AG enters into agreements with importers in the common market who distribute both the joint range and MAN's commercial vehicles.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption from Article 85(1) subject to notification obligations.


*(reported: 2026-10-16 19:44:45)*

# 'NA', 'NA'

**CELEX ID:** CELEX-32000D0117  
**Industry:** NA  
**Cartel Period:** 1958 : 1994  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0117 | IV/33884  |

### Case Title
NA

### Overview
This case involves a cartel in the Netherlands operating in the electrotechnical fittings and cable industry, with companies such as FEG, NAVEG, TU, and others. The cartel operated from 1958 to 1994, engaging in anticompetitive agreements including fixed pricing, exclusive dealing arrangements, and loss-leader pricing. The European Commission investigated and imposed fines on FEG and TU.

### Industry
Electrotechnical fittings, wire and cable, PVC tubes, cable support systems, PLC switches, relays, solenoid switches, protective circuit switches, lighting, electricity cables, trunking, distribution boxes, industrial switching equipment, junction boxes, safety systems, telephony, light sources, brackets, emergency lighting, fans.

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 27.3: Manufacture of wiring and wiring devices
NACE class code: 27.32: Manufacture of other electronic and electric wires and wiring devices

### Companies Undertakings
| company                 |
|:------------------------|
| FEG                     |
| NAVEG                   |
| UNETO                   |
| TU                      |
| CEF                     |
| CEF UK                  |
| Draka Kabel             |
| Van Geel Systems        |
| Gira                    |
| Bernard BV              |
| Brinkman & Germeraad BV |
| Conelgro BV             |
| Schiefelbusch           |
| Schotman Elektro        |
| Wolff                   |
| Alcoo BV                |
| Bolderheij BV           |
| Cammaert BV             |
| Van Egmond BV           |
| Elauma BV               |
| Eltema BV               |
| Electro Metaal BV       |
| Elgro BV                |
| Den Hollander BV        |
| Kasdorp                 |
| Oscar Keip BV           |
| De Koning               |
| Polimex                 |
| Rolff BV                |
| Schuurman BV            |
| Smelt BV                |
| Vibo                    |
| Waagmeester BV          |

### Market
Netherlands, oligopoly market, no turbulence

### Cartel Period
1958 : 1994

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1958-01-24 | boards of FEG, NAVEG and BOGETA | agreed to continue arrangement under gentleman's agreement |
| 1972-11-23 | Commission | adopted decision Centrale Verwarming |
| 1978-01-25 | Commission | adopted decision Centraal Bureau voor de Rijwielhandel |
| 1978-08-02 | FEG | issued binding decision on publications prohibiting loss-leader pricing |
| 1984-11-02 | FEG | adopted binding decision on fixed prices |
| 1986-03-11 | FEG | established collective exclusive dealing arrangement with TU |
| 1986-03-11 | FEG board and NAVEG board | entered into agreement |
| 1986-04-28 | NAVEG | advised members to supply only to FEG members |
| 1994-02-25 | FEG | ended collective exclusive dealing arrangement |
| 1996-07-03 | Commission | issued objections to FEG and seven members |
| 1997-11-19 | Commission | held hearing |
| 1998-12-30 | Commission | published Commission Regulation (EC) No 2842/98 |

### Legal Framework
Article 81 (operative), Article 81 (all relevant)
Infringement concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| FEG | EUR 4,4 million |
| TU | EUR 2,15 million |

### Remedies
The FEG shall forthwith bring the infringements referred to in Articles 1 and 2 to an end, if it has not already done so. TU shall immediately bring the infringements referred to in Article 3 to an end, if it has not already done so.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                   | country        | jurisdiction   |
|:------------------------|:---------------|:---------------|
| Court of Justice        | European Union | European Union |
| Court of First Instance | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission imposed fines on FEG and TU, and ordered the cessation of anticompetitive practices. The case was decided by the European Court of Justice and the Court of First Instance.


*(reported: 2026-11-11 12:03:48)*

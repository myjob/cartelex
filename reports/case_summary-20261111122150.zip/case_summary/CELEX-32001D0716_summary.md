# 'COMP.D.2 37.444 — SAS Maersk Air and Case COMP.D.2 37.386 — Sun-Air versus SAS and Maersk Air', 'relating to proceedings pursuant to Article 81 of the EC Treaty and Article 53 of the Agreement on the European Economic Area'

**CELEX ID:** CELEX-32001D0716  
**Industry:** airline  
**Cartel Period:** 1998-09-05 : 1999-03-28  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32001D0716 | IV/37444  |

### Case Title
COMP.D.2 37.444 — SAS Maersk Air and Case COMP.D.2 37.386 — Sun-Air versus SAS and Maersk Air

### Overview
The case involves SAS and Maersk Air, which were found to have engaged in anticompetitive agreements under Article 81 of the EC Treaty. The infringement concerned horizontal restraints related to market sharing, quota cartels, and specialization agreements in the airline industry.

### Industry
airline

### Oecd Nace
OECD sector: transport
NACE group code: 51.1: Passenger air transport
NACE class code: 51.10: Passenger air transport

### Companies Undertakings
| company        |
|:---------------|
| SAS            |
| Maersk Air A/S |

Countries:
- SAS: SE
- Maersk Air A/S: DK

### Market
Denmark, oligopolistic market

### Cartel Period
1998-09-05 : 1999-03-28

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1998-09-05 | SAS and Maersk Air | agreed to cease operations on Copenhagen-Stockholm route |
| 1998-10-08 | SAS and Maersk Air | signed cooperation agreement |
| 1999-03-27 | Maersk Air | withdrew from Copenhagen-Stockholm route |
| 1999-03-28 | SAS and Maersk Air | finalized agreement on cessation of BLL-FRA flights |
| 1999-03-28 | Maersk Air | ceased CPH-STO flights |
| 1999-03-28 | SAS | ceased operations between Copenhagen and Venice at end of March/beginning of April 1999 |
| 1999-03-28 | Maersk Air | withdrew from Copenhagen-Stockholm route |
| 2000-06-09 | Commission | ordered inspections into Maersk Air's withdrawal from Copenhagen-Stockholm route |
| 2000-06-15 | Commission | conducted inspection |
| 2000-06-22 | Maersk Air | voluntarily submitted additional information |
| 2001-01-31 | Commission | initiated proceedings and sent statement of objections to SAS and Maersk Air |
| 2001-07-18 | Commission | issued decision

### Legal Framework
Legal framework: Article 81 (operative), Article 85 (relevant)
Canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought by:
- SAS
- Maersk Air

### Leniency
| company | amount |
| --- | --- |
| Maersk Air | 10% |
| SAS | 25% |

### Fines
| company | amount |
| --- | --- |
| SAS | EUR 39 375 000 |
| Maersk Air A/S | EUR 13 125 000 |

### Remedies
The Commission required the undertakings concerned to bring the infringement to an end, as provided under Article 4(1) of Regulation (EEC) No 3975/87.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that SAS and Maersk Air had engaged in anticompetitive agreements under Article 81 of the EC Treaty. Fines were imposed, with leniency reductions granted to both companies. The infringement was brought to an end through Commission remedies.


*(reported: 2026-11-10 19:45:20)*

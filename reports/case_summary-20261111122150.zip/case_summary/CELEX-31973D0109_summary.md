# 'IV/26918', 'European sugar industry'

**CELEX ID:** CELEX-31973D0109  
**Industry:** | industry   |
|:-----------|
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |
| sugar      |  
**Cartel Period:** 1968-05-30 : 1969-09-11  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31973D0109 | IV/26918  |

### Case Title
European sugar industry

### Overview
The European Commission investigated anticompetitive practices in the sugar industry, focusing on vertical restraints and abuse of dominance. The case involved multiple companies from Belgium, France, Germany, and Italy operating in the sugar sector.

### Industry
sugar

### Oecd Nace
OECD: manufacturing
NACE group code: 10.8:Manufacture of other food products
NACE class code: 10.81: Manufacture of sugar

### Companies Undertakings
| company                                                          |
|:-----------------------------------------------------------------|
| Raffinerie Tirlemontoise SA                                      |
| Centrale Suiker Maatschappij NV                                  |
| Cooperatieve Vereniging Suiker UA                                |
| Westdeutsche Zuckervertriebsgesellschaft mbH & Co KG             |
| Pfeifer & Langen                                                 |
| Südzucker Verkaufs-GmbH                                          |
| Süddeutsche Zucker AG                                            |
| Zuckerfabrik Franken                                             |
| Sucre-Union SA                                                   |
| Société des Raffineries and Sucreries Say                        |
| Société F. Béghin SA                                             |
| Générale Sucrière SA                                             |
| Société Nouvelle de Raffinerie Lebaudy-Sommier SA                |
| Groupement d'Interèt Economique Lebaudy-SUC                      |
| Sucres & Denrees SA                                              |
| Eridania Zuccherifici Nazionali SpA                              |
| Società Generale di Zuccherifici (Société Générale de Sucreries) |
| Cavarzere-Produzioni Industriali                                 |
| Società Italiana per I'Industria degli Zuccheri SpA              |
| Romana Zucchero SpA                                              |
| Zuccherificio del Volano SpA                                     |
| Agricola Industriale Emiliana (AIE) SpA                          |
| Zuccherificio di Sermide SpA                                     |
| SADAM SpA                                                        |

### Market
Relevant market: Germany, France, Belgium, Italy; Oligopoly structure; No turbulence mentioned

### Cartel Period
1968-05-30 : 1969-09-11

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-05-30 | CEFS (Comité Européen des Fabricants de Sucre) | held meeting to apportion sugar quantities between surplus and human consumption markets |
| 1968-06-30 | EEC | ended national market organization system for sugar production and distribution |
| 1968-07-01 | sugar manufacturers of Schleswig-Holstein and a part of Lower Saxony | formed sales organizations for sugar manufacturing |
| 1969-07-29 | French and Belgian producers, Eridania | discussed measures to prevent low-price sales |
| 1969-09-11 | Eridania | coordinated formation of importers' group in Genoa meeting |
| 1969-09-11 | undertakings exporting or importing sugar | established principles for sugar deliveries |
| 1970-09-22 | members of the importers' and suppliers' groups | reaffirmed respective obligations to overcome difficulties |
| 1972-05-31 | Commission | introduced official procedure under Article 3 of Regulation No 17 |
| 1972-12-05 | Consultative Committee | provided opinion on agreements and dominant positions |
| 1973-01-01 | Say and Béghin | merged |
| 1973-01-02 | Commission | issued Commission Decision relating to proceedings under Articles 85 and 86 of the EEC Treaty

### Legal Framework
Legal framework applying to the case: operative articles 'Article 85' and 'Article 86'; canonical concept 'abuse_of_dominance, anticompetitive_agreement'

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans; Discounts and Rebates

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Raffinerie Tirlemontoise | 1 500 000 |
| Sucres & Denrées | 1 000 000 |
| Société des Raffineries et Sucreries Say | 500 000 |
| Südzucker Verkauf GmbH | 200 000 |
| Société F. Beghin SA | 700 000 |
| Generale Sucrière SA | 400 000 |
| Eridania Zuccherifici Nazionali SpA | 1 000 000 |
| Società Italiana per l'Industria degli Zuccheri SpA | 300 000 |
| Cavarzere-Produzioni Industriali | 200 000 |
| Agricola Industriale Emiliana (AIE) SpA | 100 000 |
| Zuccherificio del Volano SpA | 100 000 |
| SADAM SpA | 100 000 |
| Cooperative Vereniging Suiker Unie UA | 800 000 |
| Centrale Suiker Maatschappij NV | 600 000 |
| Pfeifer and Langen | 800 000 |
| Süddeutsche Zucker AG | 700 000 |

### Remedies
to put an end immediately to the infringements

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/26, IV/26918

### Outcome
The Commission issued a decision under Articles 85 and 86 of the EEC Treaty, fining multiple sugar companies for anticompetitive practices and ordering immediate termination of the infringements.


*(reported: 2026-11-11 10:02:54)*

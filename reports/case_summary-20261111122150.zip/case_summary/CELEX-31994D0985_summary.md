# 'IV/33.218', 'Far Eastern Freight Conference'

**CELEX ID:** CELEX-31994D0985  
**Industry:** | industry                        |
|:--------------------------------|
| Maritime Shipping               |
| Inland Transport/Haulage        |
| Multimodal Transport Operations |  
**Cartel Period:** 1990 : 1994-05-28  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0985 | IV/33218  |

### Case Title
Far Eastern Freight Conference

### Overview
The case involves the Far Eastern Freight Conference (FEFC), a cartel of maritime shipping companies that engaged in anticompetitive practices, specifically Resale Price Maintenance (RPM). The cartel operated from 1990 until May 28, 1994, when Croatia Line ceased to be a member. The European Commission investigated and found the infringement to be of high gravity.

### Industry
Maritime Shipping, Inland Transport/Haulage, Multimodal Transport Operations

### Oecd Nace
OECD sector: transport
NACE group code: 50.2: Sea and coastal freight water transport
NACE class code: 50.20: Sea and coastal freight water transport

### Companies Undertakings
| company                                             |
|:----------------------------------------------------|
| Compagnie Générale Maritime                         |
| Hapag-Lloyd Aktiengesellschaft                      |
| Croatia Line                                        |
| Kawasaki Kisen Kaisha Limited                       |
| Lloyd Triestino di Navigazione SpA                  |
| AP Moller-Maersk Line                               |
| Malaysian International Shipping Corporation Berhad |
| Mitsui OSK Lines Ltd                                |
| Nedlloyd Lijnen BV                                  |
| Neptune Orient Lines Ltd                            |
| Nippon Yusen Kabushiki Kaisha                       |
| Orient Overseas Container Line                      |
| P & O Containers Ltd                                |
| Wilh. Wilhelmsen Limited                            |

### Market
The market is oligopolistic and outside the EU, covering countries including the UK, Ireland, Norway, Sweden, Finland, Denmark, Germany, Netherlands, Belgium, France, Iceland, Poland, Malaysia, Singapore, Thailand, Hong Kong, Japan, Taiwan, Republic of Korea, Democratic People's Republic of Korea, People's Republic of China, Macau, Indonesia, Democratic Kampuchea, Vietnam, Laos, Myanmar, Brunei, Philippines, Europe, and Morocco.

### Cartel Period
1990 : 1994-05-28

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-01-01 | Far Eastern Freight Conference | introduced NT90 tariff document |
| 1994-01-31 | Lloyd Triestino | ceased to be member of FEFC |
| 1994-05-28 | Croatia Line | ceased to be member of FEFC |
| 1994-08-12 | FEFC | wrote to the Commission with preliminary views on the Report |
| 1994-11-21 | Commission | informed about cessation of membership |
| 1994-11-23 | Advisory Committee | was consulted |
| 1994-12-21 | Commission | issued decision |

### Legal Framework
Legal framework applying to the case: the operative article is Article 85, and the canonical concept is anticompetitive agreement.

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True, but no applicants listed.

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Compagnie Générale Maritime | ECU 10000 |
| Hapag-Lloyd Aktiengesellschaft | ECU 10000 |
| Croatia Line | ECU 10000 |
| Kawasaki Kisen Kaisha Limited | ECU 10000 |
| Lloyd Triestino di Navigazione SpA | ECU 10000 |
| AP Moller-Maersk Line | ECU 10000 |
| Malaysian International Shipping Corporation Berhad | ECU 10000 |
| Mitsui OSK Lines Ltd | ECU 10000 |
| Nedlloyd Lijnen BV | ECU 10000 |
| Neptune Orient Lines Ltd | ECU 10000 |
| Nippon Yusen Kabushiki Kaisha | ECU 10000 |
| Orient Overseas Container Line | ECU 10000 |
| P & O Containers Ltd | ECU 10000 |

### Remedies
Cease and desist from the infringement; refrain from any agreement or concerted practice having the same or a similar object or effect to the infringing agreement.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
True

### Book Reference
NA

### Outcome
The European Commission found the companies guilty of an anticompetitive agreement under Article 85, imposed fines of ECU 10,000 on each company, and ordered them to cease and desist from the infringement.


*(reported: 2026-11-11 11:50:43)*

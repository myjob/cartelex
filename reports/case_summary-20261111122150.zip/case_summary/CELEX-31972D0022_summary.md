# 'NA', 'NA'

**CELEX ID:** CELEX-31972D0022  
**Industry:** cement trading  
**Cartel Period:** 1962-10 : 1970-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0022 | IV/324    |

### Case Title
NA

### Overview
This case involves the European Commission's decision against a cartel in the cement trading industry in the Netherlands, involving companies such as Vereeniging van Cementhandelaren, HIBIN, N.C.A., C.C.N., and V.C.H. The cartel operated from October 1962 to December 1970, engaging in restrictive practices under Article 85(1) of the Treaty.

### Industry
cement trading

### Oecd Nace
OECD sector: construction
NACE group code: 23.5: Manufacture of cement, lime and plaster
NACE class code: 23.51: Manufacture of cement

### Companies Undertakings
| companies                        |
|:---------------------------------|
| Vereeniging van Cementhandelaren |
| HIBIN                            |
| N.C.A.                           |
| C.C.N.                           |
| V.C.H.                           |

### Market
Relevant market includes the Netherlands, Belgium, West Germany, and France. The market is characterized as an oligopoly with no turbulence noted.

### Cartel Period
1962-10 : 1970-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1928-04-04 | V.C.H. | was established |
| 1962-10-30 | V.C.H. | registered agreement on Form B |
| 1966-03-16 | V.C.H. | replaced 'Reglement Geschillen' with 'Arbitrage Reglement' and 'Reglement voor Disciplinaire Rechtspraak' |
| 1967-09-30 | V.C.H. | terminated the V.C.H. contract |
| 1967-09-30 | redacted | voluntarily relinquished V.C.H. contract |
| 1968-05-16 | V.C.H. | replaced old agreements with new 'Algemene Bepalingen en Prijsvoorschriften' |
| 1968-12-24 | redacted | issued circular No. 48 relating to re-setting of V.C.H. prices |
| 1969-01-01 | redacted | compared V.C.H. member prices with manufacturer selling prices for Portland cement delivery |
| 1969-01-01 | redacted | price sheets I-VI came into force |
| 1969-01-13 | redacted | issued circular No. 1 continuing connection between V.C.H. and C.C.N. prices |
| 1970-12-31 | redacted | terminated agreement |
| 1971-12-16 | Commission | issued decision concerning procedure under Article 85 |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was sought by Vereeniging van Cementhandelaren.

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the 'Vereeniging van Cementhandelaren' to immediately cease the violation identified in Article 1, effectively issuing a cease and desist order. This represents a behavioral remedy to stop the restrictive practices that violate Article 85(1) of the Treaty.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Vereeniging van Cementhandelaren | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/324

### Outcome
The Commission found the cartel practices to be in violation of EU competition law and ordered an immediate cessation of the restrictive practices.


*(reported: 2026-11-11 09:55:07)*

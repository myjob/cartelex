# 'IV/29.236', 'Sopelem-Vickers'

**CELEX ID:** CELEX-31981D1066  
**Industry:** microscopy  
**Cartel Period:** 1981-02-27 : 1991-02-26  

## Summary

### Celex Case Id
CELEX-31981D1066 / IV/29236-2

### Case Title
Sopelem-Vickers

### Overview
The European Commission investigated anticompetitive agreements between Sopelem SA (France), Vickers Ltd (United Kingdom), and Microscopes Nachet SA (France) in the microscopy industry. The companies engaged in horizontal restraints through agreements on standards, which were found to be contrary to Article 85 of the EC Treaty. The Commission granted exemptions under Article 85(3) for a 10-year period, with renewal in 1991.

### Industry
microscopy

### Oecd Nace
manufacturing (OECD sector: manufacturing; NACE group code: 26.7; NACE class code: 26.70)

### Companies Undertakings
Société d'optique, précision, électronique et mécanique (Sopelem) SA, Paris (FR)
Vickers Ltd, London (GB)
Microscopes Nachet SA, Paris (FR)

### Market
France, United Kingdom
Market is not oligopolistic
No information on market turbulence

### Cartel Period
1981-02-27 : 1991-02-26

### Key Timeline
1975-04-17: Sopelem, Vickers, Nachet concluded technical cooperation agreement
1980-10-27: Sopelem, Vickers, Nachet filed application for renewal of exemption
1981-02-26: European Commission exemption period ended
1981-02-27: Agreement period began
1981-09-03: European Commission published summary of Agreement in Official Journal
1981-10-13: Advisory Committee on Restrictive Practices and Dominant Positions delivered opinion on Agreement
1981-11-26: Commission renewed exemption under Article 85(3)
1991-02-26: Commission renewed Decision 78/251/EEC for a 10-year period
1991-02-26: Agreement period ended

### Legal Framework
Article 85 (operative article), Article 85 (all relevant articles)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
agreements on standards

### Infringement Gravity
low

### Exemption
Exemption sought and granted under Article 85(3)
Applicants:
- Sopelem
- Vickers
- Nachet

### Leniency
NA

### Fines
NA

### Remedies
No decision remedies found

### Company Recidivism
Sopelem, Vickers, Nachet: True

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission granted exemptions under Article 85(3) for a 10-year period, with renewal in 1991. No fines or remedies were imposed.


*(reported: 2026-10-16 21:59:24)*

# 'COMP/E-1/37.919 (ex 37.391)', 'Bank charges for exchanging euro-zone currencies'

**CELEX ID:** CELEX-32003D0025  
**Industry:** banking  
**Cartel Period:** 1997-10-15 : 2001-12-31  

## Summary

### Celex Case Id
CELEX-32003D0025

### Case Title
Bank charges for exchanging euro-zone currencies

### Overview
This case involves a cartel of German banks that engaged in horizontal price fixing collusion regarding currency exchange services during the transition period when the euro was introduced. The banks agreed to fix exchange rates and commission structures for exchanging in-currency banknotes, foreign euro-zone currencies, and currency exchange services. The infringement occurred from 1997 to 2001, with the Commission taking action through statements of objections in 2000. Fines were imposed on all five banks involved, ranging from EUR 2.8 million to EUR 28 million. The case was decided by the Court of Justice of the European Union and resulted in remedies requiring the banks to end the infringement and refrain from similar practices.

### Industry
banking

### Oecd Nace
banking and insurance (including real estate), 64.9:Other financial service activities, except insurance and pension funding, 64.99: Other financial service activities, except insurance and pension funding n.e.c.

### Companies Undertakings
| companies                           |
|:------------------------------------|
| Commerzbank AG                      |
| Dresdner Bank AG                    |
| Bayerische Hypo- und Vereinsbank AG |
| Deutsche VerkehrsBank AG            |
| Vereins- und Westbank AG            |

### Market
Relevant market: Germany, Netherlands; oligopoly; turbulence due to Bundesbank's free service leading to rush of consumers to Landeszentralbanks; rumors of German commercial banks planning to offer free cash-exchange transactions; technological adaptation challenges and IT complications in transitioning from margins to commissions; lack of clarity from the Bundesbank regarding policies causing general dissatisfaction; differences in approaches between central banks and commercial banks; impact on profit margins post-euro introduction with a 40% decrease in profits for some banks.

### Cartel Period
1997-10-15 : 2001-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1997-10-15 | Commerzbank AG, Dresdner Bank AG, Deutsche VerkehrsBank AG, Bayerische Hypo- und Vereinsbank AG and Vereins- und Westbank AG | concluded agreement infringing Article 81(1) of the EC Treaty |
| 1999-01-01 | redacted | euro introduced as single currency in euro zone |
| 1999-01-01 | Commerzbank AG, Dresdner Bank AG, Deutsche VerkehrsBank AG, Bayerische Hypo- und Vereinsbank AG and Vereins- und Westbank AG | agreement commenced for transitional period |
| 1999-01-01 | Commerzbank AG, Dresdner Bank AG, Deutsche VerkehrsBank AG, Bayerische Hypo- und Vereinsbank AG and Vereins- und Westbank AG | participated in an agreement to fix exchange rates and commission structures |
| 1999-01-01 | Deutsche Verkehrsbank AG | engaged in price fixing |
| 1999-01-01 | Banks | agreed on common charging structure for exchange of in-currencies during transitional period |
| 2000-08-03 | Commission | sent statement of objections to banks |
| 2000-08-10 | Commission | sent statement of objections to banks |
| 2001-12-31 | Commerzbank AG, Dresdner Bank AG, Deutsche VerkehrsBank AG, Bayerische Hypo- und Vereinsbank AG and Vereins- und Westbank AG | agreement ended for transitional period |
| 2001-12-31 | redacted | ended agreement and refrained from similar agreements |
| 2002-01-01 | redacted | began period of free-of-charge conversion of euro-zone currencies into euros |
| 2002-07-01 | redacted | transitional period for euro-zone currency exchange ends |

### Legal Framework
Article 81, Article 85

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
False

### Leniency
True

### Fines
| company | amount |
| --- | --- |
| Commerzbank AG | EUR 28 million |
| Dresdner Bank AG | EUR 28 million |
| Bayerische Hypo- und Vereinsbank AG | EUR 28 million |
| Deutsche VerkehrsBank AG | EUR 14 million |
| Vereins- und Westbank AG | EUR 2.8 million |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                                  | country   | jurisdiction   |
|:---------------------------------------|:----------|:---------------|
| Court of Justice of the European Union | Germany   | European Union |

### Book Reference
COMP/E

### Outcome
The undertakings must put an end to the infringement and refrain from any agreements or concerted practices which may have the same or similar object or effect as the infringement.


*(reported: 2026-11-11 12:15:39)*

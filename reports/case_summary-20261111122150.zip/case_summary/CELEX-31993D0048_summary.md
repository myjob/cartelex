# 'IV/33.031', 'Fiat/Hitachi'

**CELEX ID:** CELEX-31993D0048  
**Industry:** | industry                                     |
|:---------------------------------------------|
| Earthmoving machinery market                 |
| Hydraulic excavator subsector                |
| Construction machinery market                |
| Automotive and engineering components market |  
**Cartel Period:** 1992-06-12 : 2001-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0048 | IV/33031  |

### Case Title
Fiat/Hitachi

### Overview
The European Commission investigated a joint venture between Fiat Geotech Tecnologie per la Terra SpA (Italy) and Hitachi Construction Machinery Ltd (Japan) in the earthmoving machinery market, specifically in the hydraulic excavator subsector. The venture was found to involve anticompetitive agreements under Article 85 of the EC Treaty.

### Industry
Earthmoving machinery market
Hydraulic excavator subsector
Construction machinery market
Automotive and engineering components market

### Oecd Nace
OECD sector: construction
NACE group code: 28.9: Manufacture of other special-purpose machinery
NACE class code: 28.99: Manufacture of other special-purpose machinery n.e.c.

### Companies Undertakings
| companies                                |
|:-----------------------------------------|
| Fiat Geotech Tecnologie per la Terra SpA |
| Hitachi Construction Machinery Ltd       |

| companies_investigated                   | country   |
|:-----------------------------------------|:----------|
| Fiat Geotech Tecnologie per la Terra SpA | IT        |
| Hitachi Construction Machinery Ltd       | JP        |

### Market
Western Europe
Oligopoly market
NA

### Cartel Period
1988-12-23 : 1992-12-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-12-23 | Fiat-Hitachi Excavators SpA | created joint venture agreement |
| 1992-12-21 | Commission of the European Communities | issued decision on joint venture |
| 2001-12-31 | redacted | end of applicability period for joint venture agreement |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
medium

### Exemption
Exemption sought or granted:

| company                                  |
|:-----------------------------------------|
| Fiat Geotech Tecnologie per la Terra SpA |
| Hitachi Construction Machinery Ltd       |

### Leniency
NA

### Fines
NA

### Remedies
No decision remedies found.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission requested information, took no action, and issued a decision on the joint venture. No remedies were imposed.


*(reported: 2026-10-16 20:34:42)*

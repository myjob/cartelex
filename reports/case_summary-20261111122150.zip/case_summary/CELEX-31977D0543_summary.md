# 'IV/27.093', 'De LavalStork'

**CELEX ID:** CELEX-31977D0543  
**Industry:** | industry   |
|:-----------|
| turbine    |
| compressor |  
**Cartel Period:** 1971-01-01 : 1977-07-01  

## Summary

### Celex Case Id
CELEX-31977D0543

### Case Title
De LavalStork

### Overview
This case involved a joint venture cartel in the turbine and compressor industry, investigated by the European Commission under Article 85 for anticompetitive agreements. The companies involved were De Laval Turbine International Incorporated, Koninklijke Machinefabriek Stork BV, Stork Roterende Werktuigen BV, and De Laval-Stork VOF. The cartel period was from 1969 to 1986. The Commission granted exemption for the joint venture under Article 85 of the EEC Treaty, with no fines or remedies imposed.

### Industry
turbine, compressor

### Oecd Nace
manufacturing, 25.30: Manufacture of steam generators, except central heating hot water boilers

### Companies Undertakings
| company                                     |
|:--------------------------------------------|
| De Laval Turbine International Incorporated |
| Koninklijke Machinefabriek Stork BV         |
| Stork Roterende Werktuigen BV               |
| De Laval-Stork VOF                          |

### Market
Netherlands, Germany, oligopolistic

### Cartel Period
1969-06-02 : 1986-09-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-09-01 | De Laval International, KMS and Stork | entered into a joint venture agreement |
| 1973-03-02 | De Laval International, KMS and Stork | notified the joint venture agreement to the Commission |
| 1973-03-02 | Stork Roterende Werktuigen BV | requested exemption under Article 85 of EEC Treaty |
| 1973-03-02 | De Laval | notified agreement to Commission applying for exemption under Article 85 (3) |
| 1976-12-11 | European Communities | published summary of notification in Official Journal |
| 1977-07-25 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |
| 1986-09-01 | redacted | exemption period for joint venture ends |
| 1986-09-01 | redacted | provisions become inapplicable |

### Legal Framework
Article 85, anticompetitive agreement

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
| court                                  | country     | jurisdiction                |
|:---------------------------------------|:------------|:----------------------------|
| Commission of the European Communities | Netherlands | European Economic Community |

### Book Reference
IV/27.093

### Outcome
The Commission took no action but issued a decision.


*(reported: 2026-10-16 21:56:40)*

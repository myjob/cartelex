# 'IV/417', 'BPICA'

**CELEX ID:** CELEX-31977D0722  
**Industry:** NA  
**Cartel Period:** 1962-03-13 : 1982-05-17  

## Summary

### Celex Case Id
CELEX-31977D0722 (IV/181, IV/417-1)

### Case Title
BPICA

### Overview
The European Commission investigated the International Permanent Bureau of Motor Manufacturers (BPICA) for anticompetitive agreements under Article 85 of the EC Treaty. The case involved a cartel among automotive manufacturers from multiple EU and non-EU countries, engaging in horizontal restraints such as market sharing, quota cartels, and specialization agreements.

### Industry
Manufacturing of motor vehicles (NACE 29.10) and related products including concrete mixers, mobile crushing and screening plants, cranes, excavators, dumpers, spreaders, bitumen heaters, grit spreaders, vehicles for emptying and cleaning sewers, refuse collection vehicles, sprayers, road sweepers, snow ploughs, ambulances, formula racing cars, and sports cars.

### Oecd Nace
OECD: manufacturing; NACE Group Code: 29.1; NACE Class Code: 29.10

### Companies Undertakings
International Permanent Bureau of Motor Manufacturers (BPICA) - Paris, France
Verband der Automobilindustrie e.V. (VDA) - Frankfurt/Main 17, Germany
Fachverband der Fahrzeugindustrie Österreichs - Wien 1, Austria
Fédération Belge des Industries de l'Automobile et du Cycle (FEBIAC) - Bruxelles, Belgium
Sammenslutningen af Automobil-Fabrikanter og Importorer - Hellerup, Denmark
Agrupación Nacional de Fabricantes de Automoviles y Camiones (ANFAC) - Madrid 3, Spain
Motor Vehicle Manufacturers Association of the United States, Inc. (MVMA) - Detroit, Michigan 48202, United States
Chambre Syndicale des Constructeurs d'Automobiles (CSCA) - Paris, France
MOGURT, Société Hongroise pour le Commerce d'Automobile - Budapest VI, Hungary
Associazione nazionale fra industrie automobilistiche (ANFIA) - Torino, Italy
Japan Automobile Manufacturers Association (JAMA) - Tokyo 100, Japan
Automobilimportorenes Forening - Oslo 1, Norway
Nederlandse Vereniging de Rijwiel- en AutomobielIndustrie (RAI) - Amsterdam 1010, Netherlands
The Society of Motor Manufacturers & Traders Ltd (SMMT) - London SW1X 7DS, United Kingdom
Sveriges Bilindustri- och Bilgrossistforening - Stockholm, Sweden
Chambre Syndicale Suisse de l'Automobile et branches annexes - Genève 4, Switzerland
MOTOKOV - Praha 3, Czechoslovakia
V.O. AVTOEXPORT - Moscow G—19, USSR
Biro Proizvodaja Motornih Vozila - Beograd, Yugoslavia
Polmo - Warszawa, Poland
Autotuojat r.y. - Helsinki 10, Finland

### Market
The market spans multiple EU countries including the United Kingdom, Sweden, Switzerland, Czechoslovakia, USSR, Yugoslavia, Poland, Finland, Federal Republic of Germany, Austria, Belgium, Denmark, Spain, United States, France, Hungary, Italy, Japan, Norway, Netherlands, and non-EU nations.

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| Event | Date |
| --- | --- |
| BPICA formed in accordance with French Law of 1 July 1901 | 1901-07-01 |
| Additional provisions added to regulations regarding display of specialized vehicles at international exhibitions | 1960-11-21 |
| Regulation No 17 became effective | 1962-02-06 |
| Regulation No 17 entered into force | 1962-03-13 |
| Regulation declared inapplicable for the period | 1962-03-13 |
| Mr. P. Lemaigre submitted application for negative clearance and notification | 1962-10-29 |
| BPICA adopted regulations concerning display of motor vehicles at international exhibitions | 1976-05-17 |
| BPICA amended regulations to comply with Article 85(3) | 1976-05-17 |
| Summary of notification published in Official Journal | 1977-03-23 |
| Advisory Committee delivered opinion under Article 10 of Regulation No 17 | 1977-07-13 |
| Commission issued decision relating to proceeding under Article 85 | 1977-11-07 |
| Decision ceased to be effective | 1982-05-17 |

### Legal Framework
Article 85 (operative article), with the canonical concept being 'anticompetitive_agreement'.

### Infringement Category
Horizontal restraints

### Infringement Sub Category
Market sharing, quota cartels, and specialization agreements

### Infringement Gravity
High

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
BPICA - True

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/181 (landmark case for Trade associations)

### Outcome
The European Commission found that BPICA engaged in anticompetitive agreements under Article 85 of the EC Treaty, resulting in a high gravity infringement. The case involved horizontal restraints such as market sharing, quota cartels, and specialization agreements. The Commission requested information, took no action, and issued a decision. The case is considered a landmark for Trade associations.


*(reported: 2026-10-16 22:07:13)*

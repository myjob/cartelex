# 'IV/27.591', 'London Cocoa Terminal Market Association Limited'

**CELEX ID:** CELEX-31985D0564  
**Industry:** cocoa trading  
**Cartel Period:** 1985-12-13 : 1985-12-13  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0564 | IV/27591  |

### Case Title
London Cocoa Terminal Market Association Limited

### Overview
The European Commission investigated the London Cocoa Terminal Market Association Limited (LCTMA) for an anticompetitive agreement under Article 85 of the EEC Treaty. The case involved vertical restraints, specifically Resale Price Maintenance (RPM). LCTMA submitted notifications and applications for negative clearance, and the Commission issued a decision based on the association's amendments to its rules that removed appreciable restrictions on competition.

### Industry
cocoa trading

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 01.1: Growing of non-perennial crops
NACE class code: 01.14: Growing of sugar cane

### Companies Undertakings
London Cocoa Terminal Market Association Limited, GB

### Market
United Kingdom

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | London Cocoa Terminal Market Association Limited | established first Regulation implementing Articles 85 and 86 of the Treaty |
| 1973-06-29 | London Cocoa Terminal Market Association Limited | submitted notification and application for negative clearance |
| 1985-05-20 | London Cocoa Terminal Market Association Limited | last notified rules and regulations |
| 1985-05-20 | London Cocoa Terminal Market Association Limited | submitted application for negative clearance |
| 1985-12-13 | London Cocoa Terminal Market Association Limited | decision addressed to association |
| 1985-12-13 | Commission of the European Communities | issued decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM)

### Infringement Gravity
medium

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The Commission issued a negative clearance pursuant to Article 2 of Regulation No 17, based on the LCTMA's amendments to its rules that removed any appreciable restrictions on competition. The infringement was resolved through voluntary compliance without further cease-and-desist orders or structural remedies.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court           | country              | jurisdiction   |
|:----------------|:---------------------|:---------------|
| ordinary courts | United Kingdom       | English law    |
| Commission      | European Communities | EEC            |

### Book Reference
NA

### Outcome
The infringement was resolved through voluntary compliance without further cease-and-desist orders or structural remedies.


*(reported: 2026-10-16 19:32:53)*

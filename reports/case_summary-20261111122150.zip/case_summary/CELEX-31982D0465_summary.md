# 'IV/AF 511', 'National Panasonic (France) SA'

**CELEX ID:** CELEX-31982D0465  
**Industry:** consumer electronics  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0465 | IV/511    |

### Case Title
National Panasonic (France) SA

### Overview
The European Commission investigated National Panasonic (France) SA and National Panasonic (UK) Ltd for anticompetitive agreements under Article 85 of the EC Treaty, specifically involving vertical restraints in the form of Resale Price Maintenance (RPM). The case was initiated following a Council Regulation No 17 that entered into force in 1962. The Commission conducted investigations and requested information from the companies involved.

### Industry
consumer electronics

### Oecd Nace
manufacturing
26.4:Manufacture of consumer electronics
26.40: Manufacture of consumer electronics

### Companies Undertakings
| companies                      |
|:-------------------------------|
| National Panasonic (France) SA |
| National Panasonic (UK) Ltd    |

### Market
France

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council of the European Union | Council Regulation No 17 entered into force |
| 1979-06-27 | Commission | conducted investigation at National Panasonic (UK) Ltd |
| 1979-08-24 | National Panasonic (UK) Ltd | appealed to the Court of Justice against the Decision ordering an investigation |
| 1980-06-26 | Court of Justice of the European Communities | dismissed the appeal |
| 1981-05-25 | Commission | addressed request for information to marketing subsidiaries and distributor |
| 1981-06-15 | National Panasonic (France) SA | responded to Commission's request for information |
| 1981-06-15 | NPF | replied to request for information by registered letter |
| 1981-12-11 | Commission of the European Communities | issued Commission Decision |
| 1981-12-11 | Commission | formally decided and signed decision |
| 1982-06-21 | Commission of the European Communities | amended Commission Decision |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| National Panasonic (France) SA | 5 000 ECU |

### Remedies
A fine of 5000 ECU was imposed on National Panasonic (France) SA under Article 15(1)(b) of Regulation No 17.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| National Panasonic (France) SA | False |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                        | country        | jurisdiction   |
|:---------------------------------------------|:---------------|:---------------|
| Court of Justice of the European Communities | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission imposed a fine of 5000 ECU on National Panasonic (France) SA for anticompetitive agreements under Article 85. The case involved vertical restraints in the form of Resale Price Maintenance (RPM). The Court of Justice dismissed an appeal by National Panasonic (UK) Ltd, and the Commission formally decided and signed the decision in December 1981.


*(reported: 2026-11-11 10:40:45)*

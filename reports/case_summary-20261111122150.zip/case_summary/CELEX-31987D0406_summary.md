# 'IV/31.507', 'Tipp-Ex (standard form contract)'

**CELEX ID:** CELEX-31987D0406  
**Industry:** | industry                                 |
|:-----------------------------------------|
| Pharmaceuticals, Cosmetics and Chemicals |
| General Trade                            |  
**Cartel Period:** 1979-08 : 1984-03  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0406 | IV/31192  |

### Case Title
Tipp-Ex (standard form contract)

### Overview
The European Commission investigated an anticompetitive agreement involving Tipp-Ex Vertrieb GmbH & Co KG and several other companies in the pharmaceuticals, cosmetics, and chemicals industry. The case centered on vertical restraints related to territorial exclusivity and parallel trade bans.

### Industry
Pharmaceuticals, Cosmetics and Chemicals, General Trade

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 17.2:Manufacture of articles of paper and paperboard
NACE Class Code: 17.23: Manufacture of paper stationery

### Companies Undertakings
| company                         | country   |
|:--------------------------------|:----------|
| Tipp-Ex Vertrieb GmbH & Co KG   | DE        |
| Beiersdorf AG                   | DE        |
| Burotex SA                      | CH        |
| Esveha-Rijam BV                 | NL        |
| Tipp-Ex (Leslie McLean) Limited | GB        |
| ISA France Sarl                 | FR        |
| VIHO BV                         | NL        |
| Stadler GmbH & Co KG            | CH        |
| BDF tesa SA                     | FR        |

### Market
Geographical scope includes Federal Republic of Germany, France, Belgium, Netherlands, United Kingdom. Market is outside the EU.

### Cartel Period
1979-08 : 1984-03

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1979-04-11 | Tipp-Ex | terminated business relationship with ISA France |
| 1981-12-31 | redacted | agreements terminated |
| 1982-01-04 | Beiersdorf | took over exclusive distribution of Tipp-Ex products in France |
| 1982-01-04 | Beiersdorf | began supporting market-partitioning measures |
| 1983-10-01 | Tipp-Ex | concluded contract with authorized dealers |
| 1984-03-02 | BDF tesa | temporarily discontinued business relations with ISA France |
| 1984-03-30 | ISA France | filed complaint initiating proceedings |
| 1985-03-07 | Tipp-Ex | submitted application for negative clearance |
| 1986-04-10 | Commission | initiated proceedings in the case |
| 1986-06-02 | Beiersdorf | answered Statement of Objections |
| 1986-09-11 | Tipp-Ex | reapplied for negative clearance |
| 1987-07-10 | Commission | issued Commission Decision |

### Legal Framework
Legal framework: Article 85 (operative article), with the canonical concept of anticompetitive_agreement.

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought by Tipp-Ex Vertrieb GmbH & Co KG

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Tipp-Ex Vertrieb GmbH & Co KG | 400 000 ECU |
| Beiersdorf AG | 10 000 ECU |

### Remedies
The Commission ordered Tipp-Ex Vertrieb GmbH & Co KG and its exclusive distributors in France, Belgium, the United Kingdom, and the Netherlands to bring the infringements to an end and refrain from taking any measures that have the same object or effect.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Tipp-Ex Vertrieb GmbH & Co KG | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
Courts involved in the case, although specific rulings are not detailed in the facts provided.

### Book Reference
NA

### Outcome
The Commission issued a decision finding anticompetitive agreements and imposed fines on Tipp-Ex Vertrieb GmbH & Co KG and Beiersdorf AG. Remedies were ordered to end the infringements.


*(reported: 2026-11-11 11:07:38)*

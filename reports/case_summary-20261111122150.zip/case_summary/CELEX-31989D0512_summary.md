# 'NA', 'NA'

**CELEX ID:** CELEX-31989D0512  
**Industry:** NA  
**Cartel Period:** 1987-01-26 : 1988-10-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0512 | IV/31499  |

### Case Title
NA

### Overview
The European Commission investigated anticompetitive agreements among Dutch banking associations and undertakings, finding violations of Article 85 of the EC Treaty. The infringement involved horizontal price-fixing collusion in various banking-related goods and services including gift vouchers, securities trading, foreign banknotes, traveller's cheques, payment transfers, letters of credit, guarantees, and collection services.

### Industry
banking and insurance (including real estate)

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 64.1:Monetary intermediation
NACE class code: 64.11: Central banking

### Companies Undertakings
| companies                                           |
|:----------------------------------------------------|
| Nederlandse Bankiersvereniging                      |
| Vereniging van Deviezenbanken                       |
| Stichting Bevordering Chequeverkeer                 |
| Vereniging van Bemiddelaars in Onderhandse Leningen |
| College van Overleg der Gezamenlijke Banken         |
| Vereniging voor de Effectenhandel                   |
| Vereniging van Wisselmakelaars                      |
| Coöperatieve Centrale Raiffeisen-Boerenleenbank BA  |
| Nederlandse Spaarbankbond                           |
| Postbank NV                                         |

### Market
Netherlands
Oligopoly market
NA

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-03-19 | Nederlandse Bankiersvereniging | notified Commission of regulations and decisions |
| 1985-10-22 | Nederlandse Bankiersvereniging | notified Commission of regulations and decisions |
| 1986-11-27 | Nederlandse Bankiersvereniging | notified Commission of regulations and decisions |
| 1987-01-26 | Commission | initiated proceedings in the case |
| 1987-02-05 | Commission | sent statement of objections to associations of undertakings |
| 1987-11-25 | redacted | hearing held on matters to which Commission took objection |
| 1988-01-01 | the parties concerned | withdrew most of the abovementioned provisions |
| 1988-10-01 | the parties concerned | withdrew all remaining provisions |
| 1989-01-16 | the parties concerned | withdrew the regulation on foreign exchange transactions |
| 1989-04-12 | Commission | communicated modified regulation concerning foreign exchange quotations committee |
| 1989-07-19 | Commission | adopted Decision |
| 1998-05-09 | redacted | exemption period ended |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought and granted
| company                                           |
|:--------------------------------------------------|
| Nederlandse Bankiersvereniging                    |
| Vereniging van Deviezenbanken                     |
| Vereniging van Wisselmakelaars                    |
| Coöperative Centrale Raiffeisen-Boerenleenbank BA |
| Nederlandse Spaarbankbond                         |
| Postbank NV                                       |

### Leniency
NA

### Fines
NA

### Remedies
The parties concerned were required to withdraw or amend several regulations, decisions, circulars, and agreements related to minimum commissions, value dating, telex/postage charges, and gifts/bonuses in order to terminate the infringement.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took action against the anticompetitive agreements, requiring withdrawal or amendment of several regulations and agreements related to minimum commissions, value dating, telex/postage charges, and gifts/bonuses. An exemption was granted for the case.


*(reported: 2026-10-16 20:15:38)*

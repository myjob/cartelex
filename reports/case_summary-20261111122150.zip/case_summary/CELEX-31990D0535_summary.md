# 'IV/32.681', 'Cekacan'

**CELEX ID:** CELEX-31990D0535  
**Industry:** | industry                            |
|:------------------------------------|
| foodstuffs packaging                |
| paperboard and paperboard packaging |
| machinery for packaging             |
| glass packaging                     |
| metal packaging                     |
| plastic packaging                   |  
**Cartel Period:** 1982-01-01 : 1999-04-26  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0535 | IV/32681  |

### Case Title
Cekacan

### Overview
The European Commission investigated an anticompetitive agreement between Akerlund & Rausing and Europa Carton Aktiengesellschaft, which was concluded in 1987 and entered into force in 1988. The agreement involved a joint venture in the packaging industry, specifically in paperboard and paperboard packaging. The Commission granted an exemption under Article 85(3) of the Treaty for a period of 10 years (from 27 April 1989 to 26 April 1999), conditional on behavioral commitments such as the operation of Ceka Europe, customer sharing upon termination, and ECA regaining exclusive rights in Germany under the 1982 agreement if cooperation ends.

### Industry
foodstuffs packaging, paperboard and paperboard packaging, machinery for packaging, glass packaging, metal packaging, plastic packaging

### Oecd Nace
manufacturing, 17.2:Manufacture of articles of paper and paperboard, 17.21: Manufacture of corrugated paper and paperboard and of containers of paper and paperboard

### Companies Undertakings
| company                          |
|:---------------------------------|
| Akerlund & Rausing               |
| Europa Carton Aktiengesellschaft |

### Market
| country     |
|:------------|
| Germany     |
| Netherlands |
| Belgium     |
| Luxembourg  |
| France      |
| Italy       |
| Greece      |
| Spain       |
| Portugal    |
| Austria     |
| Switzerland |

### Cartel Period
1987-02-17 : 1994-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-02-17 | Akerlund & Rausing and Europa Carton Aktiengesellschaft | agreement concluded |
| 1987-03-01 | parties | agreement entered into force |
| 1988-03-28 | Akerlund & Rausing | made notification concerning cooperation agreement |
| 1989-04-27 | Commission | exemption granted for the amended agreement |
| 1990-03-01 | parties | contract prolonged for indefinite period |
| 1990-10-15 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 |
| 1999-04-26 | redacted | end of exemption period |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
medium

### Exemption
True

Applicants: Akerlund & Rausing

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an exemption under Article 85(3) of the Treaty for a period of 10 years (from 27 April 1989 to 26 April 1999), conditional on behavioral commitments such as the operation of Ceka Europe, customer sharing upon termination, and ECA regaining exclusive rights in Germany under the 1982 agreement if cooperation ends.

### Company Recidivism
| companies                                            | recidivism   |
|:-----------------------------------------------------|:-------------|
| Akerlund & Rausing, Europa Carton Aktiengesellschaft | True         |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) of the Treaty for a period of 10 years (from 27 April 1989 to 26 April 1999), conditional on behavioral commitments such as the operation of Ceka Europe, customer sharing upon termination, and ECA regaining exclusive rights in Germany under the 1982 agreement if cooperation ends.


*(reported: 2026-10-16 20:30:36)*

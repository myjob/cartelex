# 'IV/24.510', 'GERO-fabriek'

**CELEX ID:** CELEX-31977D0066  
**Industry:** manufacturing  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31977D0066 | IV/24510  |

### Case Title
GERO-fabriek

### Overview
This case involves the European Commission's decision regarding GERO-fabriek NV, a company in the manufacturing sector. The company was found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty, specifically involving vertical restraints such as territorial exclusivity, resale price maintenance, and exclusive dealing.

### Industry
manufacturing

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 25.7: Manufacture of cutlery, tools and general hardware
NACE Class Code: 25.71: Manufacture of cutlery

### Companies Undertakings
GERO-fabriek NV (NL)

### Market
The relevant market includes the Netherlands, Belgium, Luxembourg, Surinam, and the Netherlands Antilles. The market is outside the EU.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-08-08 | GERO-fabriek | filed notification for negative clearance under Article 85(1) |
| 1973-08-24 | NV GEROfabriek | deleted clause 27 from terms of sale |
| 1976-12-22 | Commission | adopted decision finding infringement and ordering cessation of infringements |

### Legal Framework
Article 85 (operative article)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans; Resale Price Maintenance (RPM); Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
GERO-fabriek NV sought exemption.

### Leniency
NA

### Fines
NA

### Remedies
GERO-fabriek shall end forthwith the infringements referred to in Article I unless it has already done so of its own accord. It shall also inform all its retailers and wholesalers of the contents of this Decision.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
R. VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that GERO-fabriek NV had engaged in anticompetitive agreements under Article 85 and ordered the cessation of these infringements.


*(reported: 2026-11-11 10:15:59)*

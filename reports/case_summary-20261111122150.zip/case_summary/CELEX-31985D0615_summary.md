# 'IV/30.373', 'P&I clubs'

**CELEX ID:** CELEX-31985D0615  
**Industry:** NA  
**Cartel Period:** 1981-06-18 : 1985-02-20  

## Summary

### Celex Case Id
CELEX-31985D0615

### Case Title
IV/30.373 – P&I clubs

### Overview
This case involved a group of P&I clubs (Protection and Indemnity clubs) from multiple countries who were found to have engaged in anticompetitive practices under Article 85 of the EEC Treaty. The clubs had entered into an International Group Agreement (IGA), which was later found to contain horizontal restraints such as price fixing collusion, market sharing, quota cartels, and specialization agreements. The Commission opened proceedings against the IGA clauses, and after negotiations, the clubs were granted an exemption under Article 85(3) of the Treaty with conditions including behavioral remedies.

### Industry
insurance services, mutual insurance, protection and indemnity insurance, marine insurance, third-party liability insurance, contractual liability insurance, freight services, claims-handling services

### Oecd Nace
OECD sector: banking and insurance (including real estate); NACE group code: 65.1: Insurance; NACE class code: 65.11: Life insurance

### Companies Undertakings
| companies                                                                                |
|:-----------------------------------------------------------------------------------------|
| The Britannia Steamship Insurance Association Limited                                    |
| The London Steamship Owners' Mutual Insurance Association Limited                        |
| The Newcastle Protection and Indemnity Association                                       |
| The North of England Protecting and Indemnity Association Limited                        |
| The Standard Steamship Owners' Protection and Indemnity Association Limited              |
| The Standard Steamship Owners' Protection and Indemnity Association (Bermuda) Limited    |
| The Steamship Mutual Underwriting Association Limited                                    |
| Sveriges Angfartys Assurans Forening                                                     |
| The Shipowners' Mutual Protection and Indemnity Association (Luxembourg)                 |
| The Steamship Mutual Underwriting Association (Bermuda) Limited                          |
| The Sunderland Steamship Protecting and Indemnity Association                            |
| The United Kingdom Mutual Steamship Assurance Association (Bermuda) Limited              |
| The West of England Shipowners' Mutual Protection and Indemnity Association (Luxembourg) |
| Assuranceforeningen Gard (Gjensidig)                                                     |
| Assuranceforeningen Skuld (Gjensidig)                                                    |
| The Japan Shipowners' Mutual Protection and Indemnity Association                        |
| The Liverpool and London Steamship Protection and Indemnity Association Limited          |

### Market
Relevant market: United Kingdom, Sweden, Luxembourg, Norway, Japan; outside EU; oligopoly market

### Cartel Period
1981-12-08 : 1985-12-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-06-18 | 17 protection and indemnity clubs | made notification concerning International Group Agreement |
| 1981-12-08 | redacted | IGA came into force |
| 1983-02-18 | Commission | opened proceedings against IGA clauses |
| 1983-02-24 | Commission | sent statement of objections to applicants |
| 1984-07-12 | Commission | dispatched statement of objections |
| 1984-07-12 | Commission | sent statement of objections regarding IGA infringement |
| 1984-07-27 | P&I clubs | notified text of modified IGA requesting negative clearance or exemption under Article 85 (3) |
| 1984-07-27 | 17 protection and indemnity clubs | made further notification concerning International Group Agreement |
| 1984-09-27 | P&I clubs | informed Commission of willingness to modify IGA to settle procedures under Article 85 (3) |
| 1984-09-27 | clubs | issued letter |
| 1985-02-20 | 17 protection and indemnity clubs | made final notification concerning International Group Agreement |
| 1985-02-20 | International Group Agreement parties | notified agreement |
| 1985-02-20 | clubs | modified IGA came into force |
| 1985-12-16 | Commission | issued decision relating to proceeding under Article 85 of the Treaty |
| 1995-02-20 | International Group Agreement parties | exemption period ended |

### Legal Framework
Article 85, anticompetitive agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company                                                                                  |
|:-----------------------------------------------------------------------------------------|
| The Britannia Steamship Insurance Association Limited                                    |
| The London Steamship Owners' Mutual Insurance Association Limited                        |
| The Newcastle Protection and Indemnity Association                                       |
| The North of England Protecting and Indemnity Association Limited                        |
| The Standard Steamship Owners' Protection and Indemnity Association Limited              |
| The Standard Steamship Owners' Protection and Indemnity Association (Bermuda) Limited    |
| The Steamship Mutual Underwriting Association Limited                                    |
| Sveriges Angfartys Assurans Forening                                                     |
| The Shipowners' Mutual Protection and Indemnity Association (Luxembourg)                 |
| The Steamship Mutual Underwriting Association (Bermuda) Limited                          |
| The Sunderland Steamship Protecting and Indemnity Association                            |
| The United Kingdom Mutual Steamship Assurance Association (Bermuda) Limited              |
| The West of England Shipowners' Mutual Protection and Indemnity Association (Luxembourg) |
| Assuranceforeningen Gard (Gjensidig)                                                     |
| Assuranceforeningen Skuld (Gjensidig)                                                    |
| The Japan Shipowners' Mutual Protection and Indemnity Association                        |

### Leniency
False

### Fines
NA

### Remedies
The Commission did not issue any cease and desist orders, divestitures, or other formal enforcement orders. Instead, the Commission accepted an exemption under Article 85(3) of the EEC Treaty on condition that the clubs adopted behavioral remedies such as annual notifications and modified procedures for club transfers, including a pre-30 September procedure, and changes to expert committee composition.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission accepted an exemption under Article 85(3) of the EEC Treaty on condition that the clubs adopted behavioral remedies such as annual notifications and modified procedures for club transfers, including a pre-30 September procedure, and changes to expert committee composition.


*(reported: 2026-10-16 19:59:27)*

# 'IV/32.034', 'Computerland'

**CELEX ID:** CELEX-31987D0407  
**Industry:** microcomputer products  
**Cartel Period:** 1987-07-10 : 1997-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0407 | IV/32034  |

### Case Title
Computerland

### Overview
The European Commission investigated Computerland Europe SA for anticompetitive agreements under Article 85 of the EC Treaty. The case involved a cartel period from 1986-09-18 to 1997-12-31, with key events including the submission of a notification in 1986 and the Commission's decision in 1987. An exemption was granted under Article 85(3) for 10 years, valid until 31 December 1997, with specific remedies and reporting obligations.

### Industry
microcomputer products

### Oecd Nace
trade (wholesaling and retailing) and hotels

26.2:Manufacture of computers and peripheral equipment

26.20: Manufacture of computers and peripheral equipment

### Companies Undertakings
Computerland Europe SA

### Market
| country        |
|:---------------|
| France         |
| Spain          |
| United Kingdom |
| Italy          |
| Luxembourg     |
| Ireland        |

market_outside_eu: True

market_oligopoly: False

market_turbulence: NA

### Cartel Period
1986-09-18 : 1997-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-09-18 | Computerland Europe SA | submitted notification and application for negative clearance |
| 1987-07-13 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |
| 1992-12-31 | CLE | submitted overview of franchise system to Commission |
| 1997-12-31 | redacted | Decision became invalid |

### Legal Framework
Article 85

anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
license

### Infringement Gravity
medium

### Exemption
True

Computerland Europe SA

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an exemption under Article 85(3) with a 10-year term (valid until 31 December 1997), requiring CLE to communicate substantial changes in the franchise system, and at the halfway point, inform the Commission of the number of outlets per Member State and overall market share. Furthermore, any provision more restrictive than the standard form must be adapted to align with it.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
True

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) with a 10-year term (valid until 31 December 1997), requiring CLE to communicate substantial changes in the franchise system, and at the halfway point, inform the Commission of the number of outlets per Member State and overall market share. Furthermore, any provision more restrictive than the standard form must be adapted to align with it.


*(reported: 2026-10-16 20:23:38)*

# 'IV/428 — VBBB/VBVB', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31982D0123  
**Industry:** book trade  
**Cartel Period:** 1949-01-21 : 1958-07-02  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0123 | IV/428    |

### Case Title
IV/428 — VBBB/VBVB

### Overview
This case involved anticompetitive agreements in the book trade between Belgium and the Netherlands, infringing Article 85 of the EEC Treaty. The agreements were found to constitute vertical restraints including Exclusive Dealing and Resale Price Maintenance.

### Industry
book trade

### Oecd Nace
trade (wholesaling and retailing) and hotels; OECD sector: trade (wholesaling and retailing); NACE group code: 58.1: Publishing of books, periodicals and other publishing activities; NACE class code: 58.11: Book publishing

### Companies Undertakings
| company                                                     |
|:------------------------------------------------------------|
| Vereeniging ter Bevordering van de Belangen des Boekhandels |
| Vereeniging ter Bevordering van het Vlaamsche Boekwezen     |
| Maxis BV                                                    |
| GB-INNO-BM                                                  |

### Market
Belgium, Netherlands; oligopoly market

### Cartel Period
1949-01-21 : 1958-07-02

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1949-01-21 | associations of undertakings concerned | concluded agreement infringing Article 85 |
| 1949-01-21 | Vereeniging ter Bevordering van de Belangen des Boekhandels | signed agreement |
| 1949-01-21 | VBBB and VBvB | signed agreement concerning trade in books between Belgium and the Netherlands |
| 1958-07-02 | associations of undertakings concerned | amended agreement infringing Article 85 |
| 1958-07-02 | Vereeniging ter Bevordering van het Viaamsche Boekwezen | amended agreement |
| 1958-07-02 | VBBB and VBvB | amended main provisions of the agreement |
| 1962-02-06 | Commission of the European Communities | established Council Regulation No 17 |
| 1962-10-30 | Vereeniging ter Bevordering van de Belangen des Boekhandels | notified Commission pursuant to Regulation No 17 |
| 1962-10-30 | Vereeniging ter Bevordering van de Belangen des Boekhandels | filed notification under Article 5 of Regulation No 17 |
| 1962-11-03 | Vereeniging ter Bevordering van het Viaamsche Boekwezen | notified Commission pursuant to Regulation No 17 |
| 1962-11-03 | Vereeniging ter Bevordering van het Vlamsche Boekwezen | filed notification under Article 5 of Regulation No 17 |
| 1980-02-15 | associations | sent proposals to replace collective resale price maintenance system |
| 1981-11-25 | Commission of the European Communities | issued Commission Decision

### Legal Framework
Article 85; infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
Exemption sought by Vereeniging ter Bevordering van de Belangen des Boekhandels and Vereeniging ter Bevordering van het Vlaamsche Boekwezen

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the associations of undertakings to bring the infringement to an end forthwith, and to inform their members and affiliates in writing of this decision and the ending of the restrictions, setting out practical effects on trade, while also submitting a proposal for such notice to the Commission within four months.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court                        | country     | jurisdiction             |
|:-----------------------------|:------------|:-------------------------|
| Amsterdam District Court     | Netherlands | District Court           |
| Amsterdam Court of Appeal    | Netherlands | Regional Court of Appeal |
| Dutch High Court             | Netherlands | High Court               |
| Commercial Court of Brussels | Belgium     | Commercial Court         |

### Book Reference
IV/428

### Outcome
Commission Decision issued on 1981-11-25; the infringement was found to be in breach of Article 85 of the EEC Treaty, and remedies were imposed to end the anticompetitive practices.


*(reported: 2026-11-11 10:37:12)*

# 'IV/30.809-John Deere', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31985D0079  
**Industry:** agricultural machinery  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0079 | IV/30809  |

### Case Title
IV/30.809–John Deere, relating to a proceeding under Article 85 of the EEC Treaty

### Overview
This case concerns an anticompetitive agreement involving vertical restraints in the agricultural machinery sector. The European Commission found that Deere and Company, along with several national dealers, engaged in practices restricting parallel trade and territorial exclusivity, which violated Article 85 of the EEC Treaty.

### Industry
agricultural machinery

### Oecd Nace
OECD: manufacturing
NACE group code: 28.3: Manufacture of agricultural and forestry machinery
NACE class code: 28.30: Manufacture of agricultural and forestry machinery

### Companies Undertakings
| company                                   |
|:------------------------------------------|
| Deere and Company                         |
| NV Cofabel                                |
| NV Louis Nagel & Co.                      |
| Dansk Oversoisk Motor Industri A/S (DOMI) |
| John Deere Vertrieb Deutschland           |
| John Deere Italiana                       |
| John Deere SA                             |
| John Deere Ltd                            |

### Market
| country        |
|:---------------|
| Belgium        |
| Netherlands    |
| Denmark        |
| Italy          |
| Ireland        |
| Luxembourg     |
| Greece         |
| Germany        |
| United Kingdom |

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1967-10-03 | Nagel | signed dealer agreement containing export restrictions |
| 1975-10-15 | Deere | began seeking to persuade dealers to accept an export ban as a concerted practice |
| 1982-09-03 | National Farmers Union | filed complaint with the Commission |
| 1982-11-12 | Deere | applied for negative clearance under Article 13 |
| 1983-08-08 | redacted | initiated proceedings in the case |
| 1983-08-12 | Commission | sent Statement of Objections to Deere and national dealers |
| 1983-10-12 | Cofabel, Domi and Nagel | replied to the Statement of Objections |
| 1983-10-18 | Deere | replied to the Statement of Objections |
| 1984-03-21 | Commission | submitted quotations from its file to Deere |
| 1984-04-27 | Deere | commented on quotations through its lawyers |
| 1984-12-14 | Commission of the European Communities | issued Commission Decision

### Legal Framework
Article 85 (operative)
Article 85 (all relevant)
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Deere and Company | 2 000 000 ECU (DM 4 465720) |

### Remedies
The undertakings concerned must bring the infringement referred to in Article I to an end immediately and shall refrain from taking any measure having the same object or effect.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Deere and Company | True |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court      | country            | jurisdiction   |
|:-----------|:-------------------|:---------------|
| Commission | European Community | EEC            |

### Book Reference
NA

### Outcome
The Commission found that Deere and Company, along with several national dealers, engaged in anticompetitive practices violating Article 85 of the EEC Treaty. A fine of 2,000,000 ECU was imposed on Deere and Company, and the infringement was ordered to be terminated immediately.


*(reported: 2026-11-11 10:55:41)*

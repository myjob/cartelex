# 'C.37.519', 'Methionine'

**CELEX ID:** CELEX-32003D0674  
**Industry:** | industry                |
|:------------------------|
| Chemical industry       |
| Pharmaceutical industry |
| Agricultural chemicals  |
| Feed additives          |  
**Cartel Period:** 1990-01-01 : 1994-11-29  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32003D0674 | IV/37519  |

### Case Title
C.37.519 – Methionine

### Overview
This case involves a cartel in the methionine market, where companies colluded to fix prices and engage in anticompetitive practices. The European Commission investigated and imposed significant fines on the participating companies.

### Industry
Chemical industry, Pharmaceutical industry, Agricultural chemicals, Feed additives

### Oecd Nace
OECD sector: manufacturing
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.14: Manufacture of other organic basic chemicals

### Companies Undertakings
| companies                   |
|:----------------------------|
| Aventis SA                  |
| Aventis Animal Nutrition SA |
| Degussa AG                  |
| Nippon Soda Company Ltd     |

### Market
EEA, with market outside EU. Market is oligopolistic and turbulent due to price declines, competition from Novus, risk of product flowing back into European markets, market sluggishness, currency devaluation, and varying prices among national markets.

### Cartel Period
1990-01-01 : 1994-11-29

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-01-01 | Rhône-Poulenc, Degussa, Nippon Soda | agreed on first price increase |
| 1990-06-10 | Rhône-Poulenc and Degussa | discussed falling prices |
| 1990-11-07 | cartel members | agreed to increase methionine prices |
| 1991-04-01 | Rhône-Poulenc, Degussa, Nippon Soda | agreed on second price increase |
| 1992-03-15 | redacted | held meeting reviewing price levels and prospects for increasing prices |
| 1993-02-02 | redacted | held meeting discussing Russian imports and price trends |
| 1994-06-04 | Degussa | made announcement of Europe-wide price rise to DEM 5,50 |
| 1994-06-16 | Rhône-Poulenc | increased prices for methionine by 10% |
| 1999-02-04 | redacted | continued cartel activities through meeting |
| 1999-05-26 | Aventis | submitted decisive evidence on methionine cartel to Commission |
| 2001-10-01 | Commission | decided to open a proceeding in the methionine case |
| 2002-07-02 | Commission | issued Commission Decision relating to the methionine case |

### Legal Framework
Article 81 (operative article), Article 81 (all relevant articles)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought or granted:
| company |
| --- |
| Aventis SA/AAN |
| Nippon Soda Company Ltd |

### Leniency
| company |
| --- |
| Aventis SA |
| Nippon Soda Company Ltd |
| Degussa AG |

Leniency granted:
| company | amount |
| --- | --- |
| Aventis SA/AAN | 100% |
| Degussa AG | 25% |
| Nippon Soda Company Ltd | 50% |

Leniency rejected: NA

### Fines
| company | amount |
| --- | --- |
| Degussa AG | EUR 118 125 000 |
| Nippon Soda Company Ltd | EUR 9 000 000 |
| Aventis SA/AAN | EUR 0 |

### Remedies
The undertakings named in Article 1 shall forthwith bring the said infringement to an end, if they have not already done so. They shall henceforward refrain in relation to their activities in methionine from any agreements or concerted practices that may have the same or a similar object or effect as the infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                   | country        | jurisdiction              |
|:------------------------|:---------------|:--------------------------|
| Court of Justice        | European Union | European Court of Justice |
| Court of First Instance | European Union | European Union            |

### Book Reference
NA

### Outcome
The Commission decided to open a proceeding in the methionine case and issued a Commission Decision. Fines were imposed on Degussa AG and Nippon Soda Company Ltd, while Aventis SA/AAN received full leniency relief. Remedies were ordered to end the infringement.


*(reported: 2026-11-11 12:18:31)*

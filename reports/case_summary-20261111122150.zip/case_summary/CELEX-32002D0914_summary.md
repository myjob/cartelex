# 'COMP/29.373', 'Visa International — Multilateral Interchange Fee'

**CELEX ID:** CELEX-32002D0914  
**Industry:** NA  
**Cartel Period:** 2002-12-31 : 2007-12-31  

## Summary

### Celex Case Id
CELEX-32002D0914 / COMP/29.373

### Case Title
Visa International — Multilateral Interchange Fee

### Overview
This case involved a cartel investigation into the multilateral interchange fee (MIF) charged by Visa International and related entities. The Commission found that certain practices were anticompetitive under Article 81 of the EC Treaty. The case was resolved with an exemption granted for specific conditions, including cost studies and reporting obligations.

### Industry
Payment cards, cheques, cash; banking and insurance (including real estate)

### Oecd Nace
OECD sector: banking and insurance (including real estate); NACE group code: 66.1: Activities auxiliary to financial services, except insurance and pension funding; NACE class code: 66.11: Administration of financial markets

### Companies Undertakings
- Visa International Service Association European Union Region (EU)
- EuroCommerce (EU)
- Visa International (US)
- Visa EU Board (EU)
- Europay International (EU)
- MasterCard International (US)
- Ibanco Ltd (GB)

### Market
European Union Member States, Iceland, Liechtenstein, Norway, Turkey, Israel, Cyprus, Malta, Switzerland; outside EU: True; oligopoly: True

### Cartel Period
1997-05-23 : 2007-12-31

### Key Timeline
| Date | Event |
| --- | --- |
| 1962-02-06 | European Community adopted Regulation No 17 implementing Articles 85 and 86 of the Treaty |
| 1977-01-31 | Visa International submitted application for negative clearance and notification with a view to an exemption |
| 1977-01-31 | Ibanco Ltd notified rules and regulations to the Commission applying for negative clearance |
| 1997-05-23 | EuroCommerce lodged a complaint concerning the Visa International payment card scheme |
| 2000-09-29 | Commission issued supplementary statement of objections |
| 2000-09-29 | Commission sent Supplementary Statement of Objections to Visa |
| 2001-02-06 | Commission held oral hearing |
| 2001-06-27 | The Executive Committee of the Visa EU Board approved a proposal for a modified MIF scheme |
| 2001-06-27 | Visa EU Board approved concrete proposal for modified MIF |
| 2001-08-09 | Commission issued a decision clearing certain provisions under Article 81(1) |
| 2001-08-09 | Commission stated decision regarding Visa cards |
| 2001-08-09 | Commission issued decision on payment card schemes |
| 2001-08-09 | Commission issued decision in the Visa case |
| 2001-08-11 | Commission published notice in Official Journal describing proposed modified MIF scheme |
| 2001-08-11 | Visa proposed separate intraregional MIF rate for mail order/telephone order transactions |
| 2001-08-11 | Commission published 19(3) notice |
| 2001-09-07 | Commission sent Article 6 letter rejecting complaint by EuroCommerce |
| 2001-09-07 | EuroCommerce sent email relating to complaint against MIF in Visa scheme |
| 2001-10-29 | EuroCommerce submitted reply to Article 6 letter |
| 2001-10-29 | EuroCommerce opposed any exemption for proposed modified MIF scheme of Visa |
| 2002-03-22 | Commission invited complainant to comment on further modification |
| 2002-07-24 | Commission of the European Communities issued decision in case COMP/29.373 — Visa International — Multilateral Interchange Fee |
| 2002-07-24 | Decision issued |
| 2002-09-04 | Visa Board adopted measures for implementing the modified MIF scheme |
| 2003-04-30 | Visa board adopted measures necessary to secure implementation of MO/TO transaction intra-regional interchange fee |
| 2007-12-31 | Exemption ended |
| 2007-12-31 | Exemption ends for Visa intra-regional interchange fees for MO/TO transactions

### Legal Framework
Article 81 (operative), EC Treaty; canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought by Visa

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared the provisions of Article 81(1) of the EC Treaty and Article 53(1) of the EEA Agreement inapplicable to the Visa intra-regional interchange fee for MO/TO transactions until 31 December 2007, subject to conditions including adoption of necessary measures by the Visa board, submission of cost studies, compliance with specific cost categories, reporting obligations for amendments, and limitation of MIF levels according to cost determinations.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
True

### Book Reference
COMP/29.373, not a landmark case in the book, infringement type: Bundling and tying

### Outcome
The Commission declared the provisions of Article 81(1) of the EC Treaty and Article 53(1) of the EEA Agreement inapplicable to the Visa intra-regional interchange fee for MO/TO transactions until 31 December 2007, subject to conditions.


*(reported: 2026-10-16 22:38:46)*

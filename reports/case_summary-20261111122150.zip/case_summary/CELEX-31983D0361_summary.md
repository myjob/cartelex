# 'IV/30.174', 'Vimpoltu'

**CELEX ID:** CELEX-31983D0361  
**Industry:** Agricultural machinery trade  
**Cartel Period:** 1980-05-27 : 1980-09-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0361 | IV/30174  |

### Case Title
Vimpoltu

### Overview
The European Commission investigated anticompetitive agreements in the agricultural machinery trade, specifically focusing on vertical restraints imposed by Vimpoltu and Cebeco. The case involved a cartel period from 1980-05-27 to 1980-09-01, with the Commission adopting a final decision on 1983-07-13.

### Industry
Agricultural machinery trade

### Oecd Nace
trade (wholesaling and retailing) and hotels
28.3:Manufacture of agricultural and forestry machinery
28.30: Manufacture of agricultural and forestry machinery

### Companies Undertakings
| companies                                                                              |
|:---------------------------------------------------------------------------------------|
| Vereniging van Importeurs van en Groothandelaren in Land- en Tuinbouwmachines Vimpoltu |
| Cebeco Handelsraad                                                                     |

### Market
Netherlands
Oligopolistic market

### Cartel Period
1980-05-27 : 1980-09-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-05-27 | Vimpoltu | adopted decision laying down maximum discounts, standard delivery and payment terms and rules on sales promotions and exchange of price information |
| 1980-09-01 | importers | published and exchanged new price lists |
| 1983-07-13 | Commission | adopted final decision |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Vimpoltu sought exemption which was denied.

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist order requiring Vimpoltu to stop applying the decision and refrain from future actions with the same object or effect, inform its members within one month of notification, inform the Commission of how this is done, and refuse exemption under Article 85(3) of the EEC Treaty.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Vimpoltu | NA |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Frans AndriesSEN

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission adopted a final decision on 1983-07-13, imposing a cease and desist order on Vimpoltu. The case was not a landmark in any book, and no exemption was granted.


*(reported: 2026-11-11 10:44:57)*

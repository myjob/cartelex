# 'AF/IV/372', 'Case AF/IV/372'

**CELEX ID:** CELEX-31979D0253  
**Industry:** manufacturing  
**Cartel Period:** 1962-02-01 : 1979-01-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31979D0253 | IV/372    |

### Case Title
AF/IV/372

### Overview
This case involves the European Commission's investigation into an anticompetitive agreement in the manufacturing sector, specifically related to natural gas extraction. The investigation targeted Fides, a company based in Milan, Italy, for price fixing collusion under Article 85 of the EC Treaty.

### Industry
manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 06.2: Extraction of natural gas
NACE class code: 06.20: Extraction of natural gas

### Companies Undertakings
| companies                     | location   |
|:------------------------------|:-----------|
| Fides, Unione Fiduciaria, Spa | Milan      |

### Market
Italy

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | redacted | adopted Council Regulation No 17 |
| 1962-02-21 | Commission | published Council Regulation No 17 granting powers to impose fines and penalty payments |
| 1977-06-13 | Mr. Vouel | ordered investigation at various firms |
| 1978-06-09 | Fides | refused to submit to the investigation |
| 1979-01-31 | Commission | adopted decision requiring Fides to submit to investigations |
| 1979-01-31 | redacted | issued Commission Decision in Case AF/IV/372 |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
The Commission imposed fines under Article 15(1)(c) and periodic penalty payments under Article 16(1)(d).

### Remedies
The Commission issued a decision ordering Fides to submit to investigations, including allowing access to premises and producing required books and papers.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
| court                                        | country    | jurisdiction   |
|:---------------------------------------------|:-----------|:---------------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission ordered Fides to submit to investigations and imposed fines and penalty payments under Articles 15(1)(c) and 16(1)(d).


*(reported: 2026-10-16 19:00:21)*

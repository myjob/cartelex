# '71/258/EWG', 'Extra alloy'

**CELEX ID:** CELEX-31971D0258  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31971D0258 | IV/399-3  |

### Case Title
71/258/EWG – Extra alloy

### Overview
The European Commission initiated a general investigation into the brewing industry in October 1969. In May 1970, the Commission sent an information request in the form of a questionnaire to breweries. A decision was issued by the Commission on 18 June 1971.

### Industry
beer, other alcoholic drinks, non-alcoholic drinks

### Oecd Nace
manufacturing; 11.05: Manufacture of beer

### Companies Undertakings
Union des Brasseries — Société Anonyme (BE)

### Market
NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1969-10-09 | Commission | initiated general investigation into brewing industry |
| 1970-05-14 | Commission | sent information request in form of questionnaire to breweries |
| 1971-06-18 | Commission | issued decision |

### Legal Framework
The Commission may impose monetary penalties ranging from one hundred to five thousand billing units and compulsory fines from fifty to one thousand billing units for each day of delay in providing information requested under Article11 paragraph5.

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Commission may impose monetary penalties ranging from one hundred to five thousand billing units and compulsory fines from fifty to one thousand billing units for each day of delay in providing information requested under Article11 paragraph5.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
| court                                        | country   | jurisdiction   |
|:---------------------------------------------|:----------|:---------------|
| Court of Justice of the European Communities | Belgium   | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision following an investigation into the brewing industry and information requests to breweries. The case involved penalties for non-compliance with information requests under Article 11 paragraph 5.


*(reported: 2026-11-11 09:53:14)*

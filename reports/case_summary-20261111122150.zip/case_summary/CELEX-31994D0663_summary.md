# 'IV/34.600', 'Night Services'

**CELEX ID:** CELEX-31994D0663  
**Industry:** NA  
**Cartel Period:** 1995-01-01 : 2002-12-31  

## Summary

### Celex Case Id
CELEX-31994D0663

### Case Title
Night Services

### Overview
This case concerns anti-competitive agreements in the night rail passenger transport sector involving European Night Services Ltd (ENS) and several railway undertakings from the UK, France, Germany, Netherlands, and Belgium. The Commission investigated potential infringements of Article 85 of the EC Treaty and Article 53 of the EEA Agreement related to abuse of dominance and anticompetitive agreements. An exemption was initially granted but later declared inapplicable to ENS agreements from January 29, 1993, to December 31, 2002, with conditions for fair access by new entrants.

### Industry
passenger transport services, combined transport of goods, rail transport for motor vehicles, overnight passenger trains, rail tickets, specialized rolling stock, cleaning services, sleeper services, terminal operations, on-board personnel services, daily servicing, daily maintenance, safety checks, emergency repairs on rolling stock, passenger-handling services, reservation systems, marketing services.

### Oecd Nace
OECD: transport; NACE: 49.10 Passenger rail transport, interurban

### Companies Undertakings
| company                                       |
|:----------------------------------------------|
| European Night Services Ltd                   |
| British Rail                                  |
| Deutsche Bundesbahn                           |
| NV Nederlandse Spoorwegen                     |
| Société nationale des chemins de fer frangais |
| Société nationale des chemins de fer belges   |
| European Passenger Services                   |
| German Rail UK Ltd                            |
| Transmanche Night Travel Ltd                  |
| Deutsche Bahn AG                              |
| Société nationale des chemins de fer frangais |
| Société nationale des chemins de fer belges   |

### Market
Relevant market includes United Kingdom, France, Germany, Netherlands, Belgium; outside the EU; oligopoly.

### Cartel Period
1992-06-30 : 2002-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-06-30 | ENS | concluded operating agreements with railways and SNCB |
| 1993-01-29 | European Night Services Ltd, British Rail, Deutsche Bundesbahn, NV Nederlandse Spoorwegen, Société nationale des chemins de fer frangais, Société nationale des chemins de fer belges | filed application seeking declaration on applicability of Article 2 of Regulation (EEC) No 1017/68 |
| 1993-01-29 | redacted | submitted application for exemption under Article 5 of Regulation (EEC) No 1017/68 |
| 1993-01-29 | Commission | granted exemption decision |
| 1993-01-29 | redacted | declared exemption inapplicable to ENS agreements |
| 1993-08-23 | Commission of the European Communities | expressed serious doubts within the meaning of Article 12(3) of Regulation (EEC) No 1017/68 |
| 1994-05-10 | redacted | EPS became railway undertaking and replaced BR as supplier of international passenger services; BR's holding in ENS transferred to EPS |
| 1994-09-21 | Commission of the European Communities | issued Commission Decision relating to a proceeding pursuant to Article 85 of the EC Treaty and Article 53 of the EEA Agreement |
| 2002-12-31 | redacted | exemption period ends |

### Legal Framework
Article 85, Article 86

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The Commission declared inapplicable Article 85(1) of the EC Treaty and Article 53(1) of the EEA Agreement to the agreements relating to ENS from 29 January 1993 to 31 December 2002, subject to conditions ensuring new entrants can obtain necessary rail services under the same technical and financial terms as ENS.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court      | country              | jurisdiction           |
|:-----------|:---------------------|:-----------------------|
| COMMISSION | European Communities | European Economic Area |

### Book Reference
NA

### Outcome
The Commission declared inapplicable Article 85(1) of the EC Treaty and Article 53(1) of the EEA Agreement to the agreements relating to ENS from 29 January 1993 to 31 December 2002, subject to conditions ensuring new entrants can obtain necessary rail services under the same technical and financial terms as ENS.


*(reported: 2026-10-16 20:47:39)*

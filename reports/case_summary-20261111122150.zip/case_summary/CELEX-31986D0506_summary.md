# 'IV/31.143', 'Peugeot'

**CELEX ID:** CELEX-31986D0506  
**Industry:** automotive  
**Cartel Period:** 1982 : 1985-06-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31986D0506 | IV/31143  |

### Case Title
Peugeot

### Overview
The European Commission investigated Peugeot's restrictive distribution practices, which included selective distribution and territorial exclusivity measures that restricted the purchase of Right Hand Drive (RHD) cars. The investigation spanned from 1982 to 1985, with the Commission issuing statements of objections and requesting information. Peugeot provided incorrect responses, leading to a decision imposing a fine.

### Industry
automotive

### Oecd Nace
manufacturing (OECD sector), 29.1:Manufacture of motor vehicles (NACE group code), 29.10: Manufacture of motor vehicles (NACE class code)

### Companies Undertakings
| company                                             |
|:----------------------------------------------------|
| Automobiles Peugeot SA                              |
| Peugeot Talbot Belgique SA                          |
| Peugeot Talbot Nederland NV                         |
| Talbot Motor Company Limited                        |
| Peugeot Automobile Deutschland GmbH                 |
| Société de Distribution et d'Exportation Automobile |
| Peugeot-Talbot Belgique                             |
| Peugeot-Talbot Nederland                            |

### Market
Market geography includes France, Belgium, Grand Duchy of Luxembourg, Netherlands, Federal Republic of Germany, United Kingdom, Denmark, Italy, and Ireland. Market turbulence was caused by dealer network mergers, economic difficulties leading to 100 dealers exiting the market, and parallel imports into the UK due to differing economic policies among Member States.

### Cartel Period
1982 : 1985-06-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-01-30 | Peugeot | notified Commission of standard form agreement for distribution in France and imports into other Member States |
| 1971-05-07 | Peugeot | forwarded standard form distribution agreements for Benelux, Germany, and Italy to Commission |
| 1972-02-28 | Commission | sent Peugeot statement of objections in Cases No IV/14.056 and No IV/12.428 |
| 1982-05-01 | Peugeot | began implementing distribution practices restricting purchase of RHD cars |
| 1982-09-09 | Commission | sent first letter requesting information on vehicle pricing |
| 1982-10-06 | Peugeot | furnished incorrect reply to Commission's request for information |
| 1983-01-28 | Commission | sent second letter referencing the first letter |
| 1983-03-17 | Peugeot | responded to Commission's inquiries with incorrect pricing information |
| 1984-10-01 | Peugeot | initiated proceedings under Regulation No 17 |
| 1985-06-30 | Peugeot | ended distribution practices restricting purchase of RHD cars |
| 1985-12-24 | Commission | communicated to the Commission about amending distribution agreements |
| 1986-09-25 | Commission of the European Communities | issued decision on restrictive practices |

### Legal Framework
Article 85, infringement concept: anticompetitive agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution;Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought by Automobiles Peugeot SA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Automobiles Peugeot SA | 4 000 ECU or 27 413 FF |

### Remedies
A fine of 4000 ECU was imposed on Automobiles Peugeot SA pursuant to Article 15(1)(b) of Regulation No 17 for furnishing incorrect information in response to Commission requests.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
Courts were involved in the case, though specific rulings are not detailed.

### Book Reference
NA

### Outcome
The Commission imposed a fine of 4000 ECU on Automobiles Peugeot SA for providing incorrect information during the investigation. The case was concluded with a decision issued by the Commission in 1986.


*(reported: 2026-11-11 11:03:17)*

# 'IV/581', 'Cement regulation for the Netherlands — 1971'

**CELEX ID:** CELEX-31972D0468  
**Industry:** cement  
**Cartel Period:** 1956-07-06 : 1970-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0468 | IV/581    |

### Case Title
Cement regulation for the Netherlands — 1971

### Overview
This case concerns a cartel involving cement producers in the Netherlands, Belgium, and Germany. The cartel operated from 1956 to 1970, engaging in price fixing collusion. The European Commission took action against the cartel, leading to a decision in 1972.

### Industry
cement

### Oecd Nace
OECD & NACE classifications:
- OECD sector: manufacturing
- NACE group code: 23.5: Manufacture of cement, lime and plaster
- NACE class code: 23.51: Manufacture of cement

### Companies Undertakings
| companies                                                  | location                                   |
|:-----------------------------------------------------------|:-------------------------------------------|
| First Dutch Cement Industry (ENCI) N.V.                    | Maastricht, Netherlands                    |
| Cement Plant IJmuiden (CEMIJ) N.V.                         | IJmuiden, Netherlands                      |
| Cement Plant Rozenburg N.V.                                | Rozenburg, Netherlands                     |
| Dutch Cement Trading Company N.V.                          | The Hague, Netherlands                     |
| La Cimenterie Belge, CIMBEL S.A.                           | Brussels, Belgium                          |
| S.A. Cimenteries C.B.R.                                    | Brussels, Belgium                          |
| S.A. Ciments d'Obourg                                      | Obourg, Belgium                            |
| S.A. Ciments de Thieu                                      | Thieu, Belgium                             |
| S.A. Ciments Portland Liegeois                             | Haccourt, Belgium                          |
| S.A. Ciments de Visé                                       | Brussels, Belgium                          |
| S.A. Compagnie des Ciments Belges                          | Gaurain‑Ramecroix, Belgium                 |
| S.A. Ciments Portland J. Van den Heuvel                    | Hemiksem, Belgium                          |
| S.A. Sté Générale des Ciments Portland de l'Escaut         | Antoing, Belgium                           |
| S.A. Carrières et Cimenteries Lemay                        | Vaulx, Belgium                             |
| Alsen'sche Portland‑Cement‑Fabriken KG                     | Hamburg, Germany                           |
| Anneliese Portland‑Cement‑ and Water‑Lime Works AG         | Ennigerloh, Germany                        |
| Bonner Zementwerk AG                                       | Oberkassel, Germany                        |
| Breitenburger Portland‑Cement‑Factory                      | Hamburg, Germany                           |
| Burania Portland‑Cement and Lime Works Operating‑Ltd.      | Büren, Germany                             |
| Dyckerhoff Cement Works AG                                 | Wiesbaden, Germany                         |
| Elsa Cement and Lime Works AG                              | Neubeckum, Germany                         |
| Evers Portland‑Cement and Lime Works Operating‑Ltd.        | Büren, Germany                             |
| Felsenfest Westphalian Portland‑Cement and Lime Works GmbH | Erwitte, Germany                           |
| Germania Cement Works AG                                   | Misburg, Germany                           |
| West German Portland‑Cement and Lime Works Gebr. Gröne     | Ennigerloh, Germany                        |
| Hannoversche Portland‑Cement Factory AG                    | Misburg, Germany                           |
| Portland‑Cement Works Hellbach Feldmann & Co.              | Beckum, Germany                            |
| Portland‑Cement Works Heidelberg AG                        | Heidelberg, Germany                        |
| Hemmoor Cement AG                                          | Hemmoor, Germany                           |
| Holsteinic Portland‑Cement Factory GmbH                    | Hamburg, Germany                           |
| Ilse Building Materials Distribution‑Ltd.                  | Paderborn, Germany                         |
| W. Kalthöner Portland‑Cement and Lime Works                | Ennigerloh, Germany                        |
| Klöckner‑Werke AG                                          | HüttenBremen, Bremen, Germany              |
| Westfälische Portland‑Zementwerke Kohle&Co.                | Geseke, Germany                            |
| C.Mersmann Zement‑ und Kalkwerke GmbH                      | Beckum, Germany                            |
| HermannMilke KG                                            | Soest, Germany                             |
| Montanzement Vertriebs‑GmbH                                | Düsseldorf, Germany                        |
| HoeschAG, Hüttenwerke                                      | Dortmund, Germany                          |
| Klöckner‑Werke AG                                          | Georgsmarienwerke, Osnabrück, Germany      |
| Fried.Krupp HüttenwerkeAG                                  | Rheinhausen, Germany                       |
| Hüttenwerke OberhausenAG                                   | Oberhausen, Germany                        |
| Rheinstahl HüttenwerkeAG                                   | WerkSchalkerVerein, Gelsenkirchen, Germany |
| August‑Thyssen‑HittenAG                                    | Duisburg, Germany                          |
| NordcementAG                                               | Hannover, Germany                          |
| Portland‑Zementwerke Nordstern JosefSpenner                | Erwitte, Germany                           |
| PhoenixZementwerke KrogbeumkerKG                           | Beckum, Germany                            |
| E.Schwenk Cement and Stone Works Ltd.                      | Ulm/Donau, Germany                         |
| Teutonia Misburg Portland Cement Plant                     | Misburg, Germany                           |
| Tubag Trass Cement and Stone Works Ltd.                    | Kruft, Germany                             |
| Portland Cement Works Westfalen Schonlau &Co. Ltd.         | Geseke, Germany                            |
| Portland Cement Plant Wittekind Hugo Miebach Sons          | Erwitte, Germany                           |

### Market
Relevant market:
- Geography: Germany, Netherlands, Belgium
- Structure: Oligopoly
- Turbulence: Declining demand leading to price competition, seasonal fluctuations in demand, price inelasticity of cement demand, capital-intensive production affecting capacity adjustments, market supply uncertainties

### Cartel Period
1956-07-06 : 1970-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1956-07-06 | Eerste Nederlandse Cement Industrie (ENCI) N.V., Cementfabriek IJmuiden (Cemij) N.V., La Cimenterie Beige (CIMBEL) S.A., De Nederlandse Cement-Handelmaatschappij N.V. (N.C.H.) | contract concluded |
| 1962-10-31 | N.C.A. parties | registered N.C.A. agreement |
| 1962-10-31 | Commission | registered Noordwijks-Cement-Accoord |
| 1964-01-01 | N.C.A. members | imposed Supplementary Conditions granting sales discounts |
| 1964-01-01 | C.C.N. | removed requirement for manufacturers to appear on list of concrete product makers |
| 1966-01-03 | Commission | issued communication regarding agreements |
| 1966-01-03 | Commission | informed companies involved in the N.C.A. |
| 1966-03-29 | representatives of the parties | stated willingness to delete agreements except quota and pricing systems |
| 1967-03-15 | European Court of Justice | set aside the Commission’s communication |
| 1967-06-15 | representative of the N.C.A. parties | amended request for exemption of N.C.A. contract |
| 1970-12-31 | N.C.A. members | terminated N.C.A. in its current form |
| 1972-12-18 | European Commission | issued decision concerning cement regulation |

### Legal Framework
Legal framework applying to the case:
- Operative articles: NA
- Canonical concept: NA

### Infringement Category
Price fixing collusion

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted:
- Exemption case: True
- Applicants:
  | company |
  | --- |
  | First Dutch Cement Industry (ENCI) N.V., Maastricht, Netherlands |
  | Cement Plant IJmuiden (CEMIJ) N.V., IJmuiden, Netherlands |
  | Cement Plant Rozenburg N.V., Rozenburg, Netherlands |
  | La Cimenterie Belge, CIMBEL S.A., Brussels, Belgium |
  | S.A. Cimenteries C.B.R., Cement Companies N.V., Brussels — S.A. Ciments d'Obourg, Obourg, Belgium |
  | S.A. Ciments de Thieu, Thieu, Belgium |
  | S.A. Ciments Portland Liegeois, Haccourt, Belgium |
  | S.A. Ciments de Visé, Brussels, Belgium |
  | S.A. Compagnie des Ciments Belges, Gaurain-Ramecroix, Belgium |
  | S.A. Ciments Portland J. Van den Heuvel, Hemiksem, Belgium |
  | S.A. Sté Générale des Ciments Portland de l'Escaut, Antoing, Belgium |
  | S.A. Carrières et Cimenteries Lemay, Vaulx, Belgium |
  | Dutch Cement Trading Company N.V., The Hague, Netherlands |
  | Alsen'sche Portland-Cement-Fabriken KG, Hamburg, Germany |
  | Anneliese Portland-Cement and Water-Lime Works AG, Ennigerloh, Germany |
  | Bonner Zementwerk AG, Oberkassel, Germany |
  | Breitenburger Portland-Cement-Factory, Hamburg, Germany |
  | Burania Portland-Cement and Lime Works Operating-Ltd., Büren, Germany |
  | Dyckerhoff Cement Works AG, Wiesbaden, Germany |
  | Elsa Cement and Lime Works AG, Neubeckum, Germany |
  | Evers Portland-Cement and Lime Works Operating-Ltd., Büren, Germany |
  | Felsenfest Westphalian Portland-Cement and Lime Works GmbH, Erwitte, Germany |
  | Germania Cement Works AG, Misburg, Germany |
  | West German Portland-Cement and Lime Works Gebr. Gröne, Ennigerloh, Germany |
  | Hannoversche Portland-Cement Factory AG, Misburg, Germany |
  | Portland-Cement Works Hellbach Feldmann & Co., Beckum, Germany |
  | Portland-Cement Works Heidelberg AG, Heidelberg, Germany |
  | Hemmoor Cement AG, Hemmoor, Germany |
  | Holsteinic Portland-Cement Factory GmbH, Hamburg, Germany |
  | Ilse Building Materials Distribution-Ltd., Paderborn, Germany |
  | W. Kalthöner Portland-Cement and Lime Works, Ennigerloh, Germany |
  | Klöckner-Werke AG, HüttenBremen, Bremen, Germany |
  | Westfälische Portland-Zementwerke Kohle&Co., Geseke, Germany |
  | C.Mersmann Zement- und Kalkwerke GmbH, Beckum, Germany |
  | HermannMilke KG, Soest, Germany |
  | Montanzement Vertriebs-GmbH, Düsseldorf, Germany |
  | HoeschAG, Hüttenwerke, Dortmund, Germany |
  | Klöckner-Werke AG, Georgsmarienwerke, Osnabrück, Germany |
  | Fried.Krupp HüttenwerkeAG, Rheinhausen, Germany |
  | Hüttenwerke OberhausenAG, Oberhausen, Germany |
  | Rheinstahl HüttenwerkeAG, WerkSchalkerVerein, Gelsenkirchen, Germany |
  | August-Thyssen-HittenAG, Duisburg, Germany |
  | NordcementAG, Hannover, Germany |
  | Portland-Zementwerke Nordstern JosefSpenner, Erwitte, Germany |
  | PhoenixZementwerke KrogbeumkerKG, Beckum, Germany |
  | E.Schwenk Cement and Stone Works Ltd., Ulm/Donau, Germany |
  | Teutonia Misburg Portland Cement Plant, Misburg, Germany |
  | Tubag Trass Cement and Stone Works Ltd., Kruft, Germany |
  | Portland Cement Works Westfalen Schonlau &Co. Ltd., Geseke, Germany |
  | Portland Cement Plant Wittekind Hugo Miebach Sons, Erwitte, Germany |

### Leniency
Leniency:
- Leniency case: False
- Applicants: NA
- Granted reductions: NA
- Rejected applications: NA

### Fines
NA

### Remedies
Remedies and orders to terminate the infringement:
- The parties are obliged to remedy the violation identified in Article 1. This includes abandoning all competition restrictions previously practiced under the N.C.A., lifting collective exclusivity agreements, removing uniform pricing requirements and resale bans.
- Specifically, they must implement a relaxed quota system with independent pricing, end mutual commitment obligations regarding cement plant construction, and ensure compliance through a monitoring commission.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| First Dutch Cement Industry (ENCI) N.V., Cement Plant IJmuiden (CEMIJ) N.V., Cement Plant Rozenburg N.V., La Cimenterie Belge, CIMBEL S.A., Dutch Cement Trading Company N.V., Alsen'sche Portland-Cement-Fabriken KG, Anneliese Portland-Cement and Water-Lime Works AG, Bonner Zementwerk AG, Breitenburger Portland-Cement Factory, Burania Portland-Cement and Lime Works Operating-Ltd., Dyckerhoff Cement Works AG, Elsa Cement and Lime Works AG, Evers Portland-Cement and Lime Works Operating-Ltd., Felsenfest Westphalian Portland-Cement and Lime Works GmbH, Germania Cement Works AG, West German Portland-Cement and Lime Works Gebr. Gröne, Hannoversche Portland-Cement Factory AG, Portland-Cement Works Hellbach Feldmann & Co., Portland-Cement Works Heidelberg AG, Hemmoor Cement AG, Holsteinic Portland-Cement Factory GmbH, Ilse Building Materials Distribution-Ltd., W. Kalthöner Portland-Cement and Lime Works, Klöckner-Werke AG, Westfälische Portland-Zementwerke Kohle&Co., C.Mersmann Zement- und Kalkwerke GmbH, HermannMilke KG, Montanzement Vertriebs-GmbH, HoeschAG, Klöckner-Werke AG, Fried.Krupp HüttenwerkeAG, Hüttenwerke OberhausenAG, Rheinstahl HüttenwerkeAG, August-Thyssen-HittenAG, NordcementAG, Portland-Zementwerke Nordstern JosefSpenner, PhoenixZementwerke KrogbeumkerKG, E.Schwenk Cement and Stone Works Ltd., Teutonia Misburg Portland Cement Plant, Tubag Trass Cement and Stone Works Ltd., Portland Cement Works Westfalen Schonlau &Co. Ltd., Portland Cement Plant Wittekind Hugo Miebach Sons | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country    | jurisdiction              |
|:--------------------------|:-----------|:--------------------------|
| European Court of Justice | Luxembourg | European Court of Justice |

### Book Reference
IV/581

### Outcome
NA


*(reported: 2026-11-11 10:01:23)*

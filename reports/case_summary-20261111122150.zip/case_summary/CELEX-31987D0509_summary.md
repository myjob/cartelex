# 'IV/31.739', 'Internationale Dentalschau'

**CELEX ID:** CELEX-31987D0509  
**Industry:** dental  
**Cartel Period:** 2000-12-01 : 2016-05-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0509 | IV/31739  |

### Case Title
Internationale Dentalschau

### Overview
The European Commission investigated the Verband der Deutschen Dental-Industrie eV (VDDI) for anticompetitive agreements related to the Internationale Dentalschau, a trade fair for dental articles and equipment. The infringement involved horizontal restraints under Article 85 of the EC Treaty, specifically market sharing, quota cartels, and specialization agreements.

### Industry
dental

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.5:Manufacture of medical and dental instruments and supplies
NACE class code: 32.50: Manufacture of medical and dental instruments and supplies

### Companies Undertakings
Verband der Deutschen Dental-Industrie eV (DE)

### Market
Federal Republic of Germany

### Cartel Period
1962-02-06 : 2000-12-29

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | redacted | adopted Regulation No 17 implementing Articles 85 and 86 |
| 1985-12-30 | Commission | declared inapplicability of Article 85(1) for specified period |
| 1985-12-30 | Verband der Deutschen Dental-Industrie VDDI | notified Commission of special participation conditions |
| 1987-09-18 | Commission of the European Communities | issued Commission Decision on proceeding under Article 85 |
| 1987-09-18 | Peter SUTHERLAND | signed decision on behalf of the Commission |
| 2000-12-29 | redacted | exemption period ended |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
Exemption sought and granted for the VDDI's special participation conditions in the Internationale Dentalschau.

### Leniency
NA

### Fines
NA

### Remedies
1. The Verband der Deutschen Dental-Industrie shall inform the Commission immediately of any change in or addition to the 'special participation conditions' relating to the Internationale Dentalschau.
2. The Verband der Deutschen Dental-Industrie shall send the Commission immediately a copy of any arbitration award refusing an exhibitor's application for participation.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the VDDI's participation conditions in the Internationale Dentalschau constituted an anticompetitive agreement under Article 85. However, an exemption was granted for a specified period, and remedies were imposed to ensure transparency and compliance with the decision.


*(reported: 2026-10-16 20:19:37)*

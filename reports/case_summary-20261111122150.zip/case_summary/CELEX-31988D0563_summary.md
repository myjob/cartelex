# 'IV/31.498', 'Delta Chemie/DDD'

**CELEX ID:** CELEX-31988D0563  
**Industry:** NA  
**Cartel Period:** 1984-01-01 : 2004-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0563 | IV/31498  |

### Case Title
IV/31.498 – Delta Chemie/DDD

### Overview
The European Commission investigated an anticompetitive agreement between Delta Chemie (Germany) and DDD Limited (UK) concerning the exclusive distribution of stain removal products. The agreement, signed in 1985, was notified to the Commission and led to a decision under Article 85 in 1988.

### Industry
manufacturing

### Oecd Nace
OECD: manufacturing
NACE Group Code: 20.4: Manufacture of soap and detergents, cleaning and polishing preparations, perfumes and toilet preparations
NACE Class Code: 20.42: Manufacture of perfumes and toilet preparations

### Companies Undertakings
| companies    |
|:-------------|
| Delta Chemie |
| DDD Limited  |

### Market
Relevant market includes the United Kingdom, Ireland, and Greece.

### Cartel Period
1984-01-01 : 2004-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-01-15 | DDD Limited and Delta Chemie | signed agreement for exclusive distribution of stain removal products |
| 1985-03-14 | DDD Limited and Delta Chemie | applied for negative clearance or exemption under Article 85 (3) |
| 1985-03-14 | DDD Limited and Delta Chemie | notified agreement |
| 1988-10-13 | The Commission of the European Communities | issued decision on the proceeding under Article 85 |
| 2004-12-31 | Commission | agreement expired |

### Legal Framework
Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
Exemption sought by DDD Limited under Article 85(3), but not granted.

### Leniency
NA

### Fines
NA

### Remedies
The Commission imposed behavioral remedies, including an obligation for DDD to inform the Commission of all refusals of requests for authorization made pursuant to Article 13 of the agreement. Additionally, DC is required to refer inquiries to DDD in principle, unless the purchaser prefers dealing directly with DC. Furthermore, the licensor undertakes not to appoint any other person as distributor or licensee within the licensed territory for a limited period of ten years from the date of signature, if DDD also manufactures the products. This 10-year restriction is tied to ensuring that DDD has sufficient time to establish itself in the market and benefit from the know-how transferred.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court      | country   | jurisdiction                |
|:-----------|:----------|:----------------------------|
| COMMISSION | Germany   | European Economic Community |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85, imposing behavioral remedies on DDD Limited to prevent further anticompetitive behavior. The agreement expired in 2004.


*(reported: 2026-10-16 20:15:17)*

# 'IV/223', 'Transocean Marine Paint Association'

**CELEX ID:** CELEX-31988D0635  
**Industry:** marine paint  
**Cartel Period:** 1959-01-01 : 1998-12-01  

## Summary

### Celex Case Id
CELEX-31988D0635

### Case Title
Transocean Marine Paint Association

### Overview
The case involves a horizontal cartel in the marine paint industry, operating from 1959 to 1986. The Transocean Marine Paint Association was involved in market sharing, quota cartels, and specialization agreements. The Commission granted exemptions under Article 85(3) which were extended until 1986, and further applications for extension were made and approved in 1988.

### Industry
marine paint

### Oecd Nace
OECD & NACE classifications:
- OECD sector: manufacturing
- NACE group code: 20.3: Manufacture of paints, varnishes and similar coatings, printing ink and mastics
- NACE class code: 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
| companies                                   |
|:--------------------------------------------|
| Transocean Marine Paint Association         |
| F.A.C. van der Linden GmbH & Co.            |
| Copalin SA                                  |
| Veneziani Zonca Vernici SpA                 |
| Transocean Ibérica SA                       |
| Fábrica de Tintas Marilina SA               |
| Pacific Products Inc.                       |
| Healing Industries Pty Ltd                  |
| Asian Paints (SP) Ltd.                      |
| YCee Marine Supplies Ltd.                   |
| Toa Paint Co. Ltd                           |
| Healing Industries Ltd                      |
| Epiglass (S) Pte. Ltd                       |
| Vapocure Taiwan Ltd                         |
| A.P.C. Industries Co. Ltd                   |
| Copalin Paint Factory                       |
| Pars-Pamchal Chemical Co.                   |
| Durmus Yasar & Sons                         |
| Colorin SA                                  |
| Tecno-Quimica SA                            |
| Industria de Pinturas Adolfo Stierling Ltda |
| Technoquímica SA                            |
| Kossan Chemical Industries                  |
| National Paints Factories Co.               |
| Neo-Shine Varnishes                         |

### Market
| geography              |
|:-----------------------|
| Germany                |
| Philippines            |
| Italy                  |
| Turkey                 |
| Iran                   |
| Greece                 |
| Japan                  |
| New Zealand            |
| Hong Kong              |
| Argentina              |
| Chile                  |
| Peru                   |
| Egypt                  |
| Australia              |
| Fiji                   |
| Brazil                 |
| Singapore              |
| Spain                  |
| Taiwan                 |
| Portugal               |
| Malaysia               |
| United Arab Emirates   |
| India                  |

market outside EU: True
market oligopoly: True

### Cartel Period
1959-01-01 : 1986-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-01-01 | redacted | agreement established |
| 1962-02-06 | Council | adopted Regulation No 17 implementing Articles 85 and 86 |
| 1972-12-31 | Commission | exemption under Article 85(3) expired |
| 1978-12-31 | Commission | exemption extended until end of year 1978 |
| 1986-12-31 | Commission | exemption extended until end of year 1986 |
| 1988-01-07 | Transocean Marine Paint Association | filed application for further extension |
| 1988-12-02 | Commission | issued Decision extending exemption |
| 1998-12-31 | redacted | exemption period ends |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
No specific infringement findings or remedies are mentioned in the provided context.

### Company Recidivism
| companies                           | recidivism   |
|:------------------------------------|:-------------|
| Transocean Marine Paint Association | NA           |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/223

### Outcome
NA


*(reported: 2026-10-16 21:54:29)*

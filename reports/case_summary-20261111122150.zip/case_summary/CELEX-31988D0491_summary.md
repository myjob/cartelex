# 'NA', 'NA'

**CELEX ID:** CELEX-31988D0491  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0491 | IV/31379  |

### Case Title
NA

### Overview
This case involves a cartel in the Dutch flower trade sector, where the European Commission found violations of Article 85 of the EEC Treaty due to anticompetitive agreements. The infringement was categorized as vertical restraints, specifically Exclusive Dealing and Market Foreclosure, and Territorial Exclusivity or Parallel Trade Bans.

### Industry
cut flowers, plant arrangements, dried flowers, dried flower arrangements, indoor plants, garden plants

### Oecd Nace
trade (wholesaling and retailing) and hotels; 01.2:Growing of perennial crops; 01.21: Growing of grapes

### Companies Undertakings
| company                                                        |
|:---------------------------------------------------------------|
| Coöperatieve Vereniging De Verenigde Bloemenveilingen Aalsmeer |
| Florimex BV                                                    |
| Brug Bloemen BV                                                |
| Florimex Verwaltungs-GmbH                                      |
| VBN                                                            |
| Bedrijfschap voor Groothandel in Bloemkwekerijprodukten        |

### Market
Netherlands

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-05-13 | VBA | formed through amalgamation of existing firms of auctioneers |
| 1982-09-08 | Florimex BV | applied to the Commission for a finding of infringement of Articles 85 and 86 |
| 1982-12-15 | Van der Burg Bloemen BV | applied to the Commission for a finding that the VBA had infringed Articles 85 and 86 of the EEC Treaty |
| 1984-11-05 | VBA | applied to the Commission for negative clearance or exemption from prohibition |
| 1984-11-05 | VBA | notified rules to Commission |
| 1984-11-05 | De Verenigde Bloemenveilingen Aalsmeer | filed notification pursuant to Article 4 of Regulation No 17 |
| 1986-06-12 | Commission | initiated proceedings in the case |
| 1988-03-08 | Commission and VBA | held intensive discussions on new rules |
| 1988-04-12 | VBA | informed Commission of intent to implement non-compliant rules |
| 1988-05-01 | VBA | entered into force non-compliant rules |
| 1988-05-01 | De Verenigde Bloemenveilingen Aalsmeer | introduced new rules governing business activities of flower traders |
| 1988-07-26 | Commission | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The VBA shall take no measures having the same purpose or effect as the infringements referred to in Article 1.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                            | country     | jurisdiction                |
|:---------------------------------|:------------|:----------------------------|
| Court of Justice                 | Netherlands | European Union              |
| Arrondissementsrechtbank Haarlem | Netherlands | Netherlands                 |
| Commission                       | Netherlands | European Economic Community |

### Book Reference
NA

### Outcome
The Commission found infringement under Article 85, and ordered the VBA to take no measures having the same purpose or effect as the infringements.


*(reported: 2026-11-11 11:12:33)*

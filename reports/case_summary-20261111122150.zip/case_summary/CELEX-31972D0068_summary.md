# 'IV/595', 'Nederlandse Cement‑Handelmaatschappij N.V.'

**CELEX ID:** CELEX-31972D0068  
**Industry:** NA  
**Cartel Period:** 1948-04-01 : 1967-09-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0068 | IV/595    |

### Case Title
Nederlandse Cement‑Handelmaatschappij N.V.

### Overview
This case involves a cartel of Dutch and German cement manufacturers, primarily centered around the Nederlandse Cement-Handelmaatschappij N.V. (N.C.H.), which engaged in price fixing collusion in the Dutch cement market from 1948 to 1967. The cartel operated under various agreements and pricing mechanisms, including base price increases and Franco-Destination pricing for truck deliveries.

### Industry
Cement industry, specifically Portland cement, iron Portland cement, blast furnace cement, trass cement, sulphate slag cement, alumina hot-melt cement clinker, white cement, and alumina enamel cement.

### Oecd Nace
OECD sector: manufacturing; NACE group code: 23.5: Manufacture of cement, lime and plaster; NACE class code: 23.51: Manufacture of cement

### Companies Undertakings
| companies                                                  | location   |
|:-----------------------------------------------------------|:-----------|
| Dutch Cement Trading Company N.V.                          | NA         |
| Alsen's Portland Cement Factories Ltd.                     | NA         |
| Anneliese Portland Cement and Water Lime Works Inc.        | NA         |
| Beckum Portland Cement Plant Bomke & Bleckmann Ltd.        | NA         |
| Bonner Portland Cement Plant Inc.                          | NA         |
| Breitenburg Portland Cement Factory                        | NA         |
| Burania Portland Cement and Lime Works Operating GmbH      | NA         |
| Dyckerhoff Cement Works Inc.                               | NA         |
| Elsa Cement and Lime Works Inc.                            | NA         |
| Evers Portland Cement and Lime Works Operating GmbH        | NA         |
| Felsenfest Westphalian Portland Cement and Lime Works GmbH | NA         |
| Fortuna Portland Cement Works GmbH                         | NA         |
| Germania Cement Works Inc.                                 | NA         |
| Hanover Portland Cement Factory Inc.                       | NA         |
| Portland Cement Works Heidelberg AG                        | NA         |
| Portland Cement Works Hellbach Feldmann & Co.              | NA         |
| Portland Cement Factory Hemmoor                            | NA         |
| Hoesch AG Steelworks                                       | NA         |
| Holstein Portland-Cement-Factory Ltd.                      | NA         |
| Zementwerk, Friedrich-Wilhelm Mohn                         | NA         |
| Bonner Portland Cement Works Ltd                           | NA         |
| Dyckerhoff Cement Works Ltd                                | NA         |
| Portland Cement Works Heidelberg Ltd                       | NA         |
| E. Schwenk Cement Works Ltd                                | NA         |
| Tubag Trass Cement and Stone Works Ltd                     | NA         |
| West German Lime and Portland Cement Works AG              | NA         |
| Hoesch AG, Hüttenwerke                                     | NA         |
| Klöckner-Werke AG, Georgsmarienwerke                       | NA         |
| Fried. Krupp Hüttenwerke AG                                | NA         |
| Hüttenwerk Oberhausen AG                                   | NA         |
| Rheinstahl Hüttenwerke AG                                  | NA         |
| Werk Schalker Verein                                       | NA         |
| Werk Friedrich-Wilhelms-Hütte AG                           | NA         |
| August-Thyssen-Hütte AG                                    | NA         |
| Nordcement AG                                              | NA         |
| Teutonia Misburger Portland Cement Plant                   | NA         |
| Anneliese Portland Cement and Water Lime Works AG          | NA         |
| Beckum Portland Cement Works Bomke and Bleckmann           | NA         |
| Elsa Cement and Lime Works AG                              | NA         |
| Fortuna Portland-Cement Works Ltd.                         | NA         |
| Germania Cement Works AG — Plant Ennigerloh =              | NA         |
| Portland-Cement Works Hellbach Feldmann & Co.              | NA         |
| Cement Works Ilse Friedrich-Wilhelm Mohn                   | NA         |
| C. Mersmann Portland-Cement Works                          | NA         |
| Hermann Milke KG                                           | NA         |
| Portland-Cement and Lime Works Nord Ruhr & Co.             | NA         |
| Portland-Cement Works Nordstern Josef Spenner              | NA         |
| Phoenix                                                    | NA         |
| Krogbeumker Cement Works KG                                | NA         |
| West German Portland Cement and Lime Works Brothers        | NA         |
| Westphalian Portland Cement Works Coal and Co.             | NA         |
| Portland Cement Works Wittekind Hugo Miebach Sons          | NA         |
| Alsen'sche Portland-Cement Factories KG                    | NA         |
| Breitenburger Portland-Cement Factory                      | NA         |
| Portland Cement Factory Hemmoor                            | NA         |
| Holsteinische Portland-Cement Factory GmbH                 | NA         |
| Klöckner-Werke AG, Bremen Works                            | NA         |
| Klöckner-Werke AG, Georgsmarien-Works                      | NA         |
| Friedrich Krupp Steelworks AG                              | NA         |
| C.Mersmann Portland Cement Works                           | NA         |
| Hermann Milke KG                                           | NA         |
| Nordcement AG                                              | NA         |
| Portland Cement and Lime Works NordRuhr & Co.              | NA         |
| Portland Cement Works Nordstern Josef Spenner              | NA         |
| Steelworks Oberhausen AG                                   | NA         |
| Phoenix Cement Works Krogbeumker KG                        | NA         |
| Rheinstahl HittenWorks AG                                  | NA         |
| Teutonia Misburg Portland Cement Works                     | NA         |
| August-Thyssen Smelter AG                                  | NA         |
| Tubag Trass Cement and Stone Works AG                      | NA         |
| E. Schwenk Cement Works GmbH                               | NA         |
| West-German Lime and Portland Cement Works AG              | NA         |
| West-German Portland Cement and Lime Works Gebr. Gröne     | NA         |
| Westphalian Portland Cement Works Coal & Co.               | NA         |
| Portland Cement Works Wittekind, Hugo Miebach Sons KG      | NA         |
| Montanzement-VertriebsGmbH                                 | NA         |

### Market
The relevant market is the Dutch cement market, with geographical scope including Belgium, Netherlands, and Luxembourg. The market was characterized as an oligopoly with high turbulence due to strikes in 1961 and 1964, emergence of Westphalian up-feeders, cartelization of distribution channels, fluctuating delivery quantities, and secret direct deliveries by members.

### Cartel Period
1948-04-01 : 1967-09-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1922-10-04 | N.C.H. | was founded as a public limited company |
| 1948-04-01 | N.C.H. | increased base price by 5 hfl./t |
| 1951-04-01 | N.C.H. | increased base price by 4.50 hfl./t |
| 1955-01-01 | N.C.H. | entered into representation agreement |
| 1962-02-06 | Commission | issued Council Regulation No.17 |
| 1962-10-31 | N.C.H. | made agreements on Form B at the Commission |
| 1962-10-31 | N.C.H. | registered contract with the Commission on Form B |
| 1964-01-01 | N.C.H. | began applying Franco-Destination prices for truck deliveries |
| 1967-09-30 | manufacturers involved in the Dutch cement market | ended V.C.H.–Contract |
| 1969-01-01 | N.C.H. | passed on competition discounts to participating companies |
| 1971-01-01 | manufacturers involved in the Dutch cement market | implemented Cementregeling voor Nederland1971 (C.R.N.) |
| 1971-12-23 | redacted | issued legal decision concerning proceeding under Article85 of the EEC Treaty |

### Legal Framework
The case was brought under the European Economic Community (EEC) Treaty, specifically Article 85(1), which prohibits agreements between undertakings that may affect trade between Member States and that have as their object or effect the prevention, restriction or distortion of competition within the common market.

### Infringement Category
Price fixing collusion

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was sought and granted for the case, as indicated by the 'exemption_case' fact.

### Leniency
NA

### Fines
NA

### Remedies
Cease and desist from the violation of Article 85(1) as determined by the Commission.

### Company Recidivism
N.C.H. - NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/595

### Outcome
NA


*(reported: 2026-11-11 09:57:11)*

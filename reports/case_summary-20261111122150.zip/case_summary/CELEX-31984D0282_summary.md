# 'IV/30.658', 'Polisti1/Arbois'

**CELEX ID:** CELEX-31984D0282  
**Industry:** NA  
**Cartel Period:** 1978 : 1983  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31984D0282 | IV/30658  |

### Case Title
Polisti1/Arbois

### Overview
This case involved an anticompetitive agreement in the toy industry, specifically a vertical restraint involving exclusive distribution agreements between companies in France and Italy. The agreements were found to restrict competition under Article 85 of the EC Treaty.

### Industry
toy cars, motor cycles, toys

### Oecd Nace
manufacturing (OECD), 32.4:Manufacture of games and toys (NACE)

### Companies Undertakings
| companies                     |
|:------------------------------|
| Polistil SpA                  |
| Arbois-Modelud                |
| CEJI-Compagnie du Jouet group |
| Joustra                       |
| CEJI-Interlude                |
| Jouef                         |

### Market
| country   |
|:----------|
| France    |
| Italy     |

### Cartel Period
1978 : 1983

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-01-18 | Polistil and Arbois | signed exclusive distribution agreement |
| 1979-01-01 | Polistil and Arbois | exclusive distribution agreement came into effect |
| 1979-09-11 | Arbois | complained of parallel imports |
| 1979-10-23 | Arbois | wrote to Polistil claiming proof of direct supply by Italian wholesaler Repetto Angelo and called for action to stop this wholesaler from operating in the French market |
| 1980-05-23 | Arbois | wrote to Polistil reporting on Timky's irregular imports |
| 1980-06-18 | Arbois | requested checks on Italian wholesalers to stop large-scale imports |
| 1981-12-16 | Commission | received copy of exclusive distribution agreement during inspection visit |
| 1982-03-05 | Commission | received copy of exclusive distribution agreement during inspection visit |
| 1982-04-30 | Arbois | sent letter proposing abrogation of Article 14 with retroactive effect |
| 1982-05-18 | Polistil and Arbois | notified exclusive distribution agreement to Commission for negative clearance or exemption under Article 85(3) |
| 1983-05-19 | Commission | decided to open proceedings in the case |
| 1983-12-31 | Polistil and Arbois | exclusive distribution agreement expired |
| 1984-05-16 | Commission | issued Commission Decision relating to proceeding under Article 85 |
| 1984-05-16 | Commission | adopted decision imposing fines on undertakings |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
| company |
| --- |
| Polistil SpA |
| Arbois-Modelud |

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Polistil | 30 000 ECU |
| Arbois | 30 000 ECU |

### Remedies
Imposition of a fine of 30,000 ECU on Polistil and Arbois; declaration that Article 14(1) of the contract was null and void retroactively from April 30, 1982.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
True

### Book Reference
NA

### Outcome
The Commission found the exclusive distribution agreements to be anticompetitive under Article 85. Fines of 30,000 ECU were imposed on Polistil and Arbois, and Article 14(1) of the agreement was declared null and void retroactively from April 30, 1982.


*(reported: 2026-11-11 10:50:54)*

# 'IV/M.802', 'Non-opposition to a notified concentration'

**CELEX ID:** CELEX-31996M0802  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
NA

### Case Title
IV/M.802 – Non-opposition to a notified concentration

### Overview
The European Commission decided not to oppose a notified concentration involving Telecom Eireann, declaring it compatible with the common market.

### Industry
NA

### Oecd Nace
OECD: communication

### Companies Undertakings
| companies_investigated   | country   |
|:-------------------------|:----------|
| Telecom Eireann          | IE        |

### Market
NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1996-12-18 | Commission | decided not to oppose notified concentration and declared it compatible with the common market |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
False

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission decided not to oppose the notified concentration and declared it compatible with the common market.


*(reported: 2026-11-11 11:54:52)*

# 'IV/33.100', 'Assurpol'

**CELEX ID:** CELEX-31992D0096  
**Industry:** NA  
**Cartel Period:** 1998-02-01 : 2019-03-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31992D0096 | IV/33100  |

### Case Title
Assurpol

### Overview
This case involves a cartel in the insurance sector, specifically focusing on anti-competitive agreements under Article 85 of the EC Treaty. The infringement is categorized as horizontal price fixing collusion.

### Industry
banking and insurance (including real estate)

### Oecd Nace
OECD: banking and insurance (including real estate), NACE Group Code: 06.2, NACE Class Code: 06.20

### Companies Undertakings
| companies                                              | location   |
|:-------------------------------------------------------|:-----------|
| EIG Assurpol                                           | NA         |
| ABEILLE-ASSURANCES                                     | NA         |
| ACTE IARD                                              | NA         |
| ALLIANZ FRANCE SA                                      | NA         |
| RIUNIONE ADRIATICA DI SICURTA RASSA                    | IT        |
| ASSURANCES DU CREDIT MUTUAL IARD (ACM-IARD)            | FR        |
| AGF                                                    | FR        |
| ASSURANcES MUTUELLES DE L'INDRE (AmI)                  | FR        |
| ASSURANCES MUTUELLES DE SEINE-ET-MARNE                 | FR        |
| CAISSE GENÉRALE D'ASSURANCES MUTUeLLES (cGA)           | FR        |
| CAISSE INDUSTRIELLE D'ASSURANCES MUTUELLES             | FR        |
| CIAM                                                   | FR        |
| LANGUEDOC                                              | FR        |
| RHIN ET MOSELLE ASSURANCES FRANCAISES                  | FR        |
| CAISSE MUTUELLE D'ASSURANCES ET DE PRÉvOYANCE          | FR        |
| CMA                                                    | FR        |
| CHUBB COMPAGNIE D'ASSURANCES EUROPEENNE SA             | FR        |
| COMMERCIAL UNION IARD                                  | FR        |
| CAMAT                                                  | FR        |
| Caisse d'assurances maritimes, aériennes et terrestres | FR        |
| LA CONCORDE                                            | FR        |
| LE CONTINENT                                           | FR        |
| DROUOT ASSURANCES (AXA ASSURANCES)                     | FR        |
| MUTUELLE PARISIENNE DE GARANTIE MPG                    | FR        |
| MUTUELLES UNIES (AXA ASSURANCES)                       | FR        |
| PRESENCE ASSURANCES (AXA ASSURANCES)                   | FR        |
| PATERNELLE RD (AXA ASSURANCES)                         | FR        |
| PRÉVOYANCE MUTUELLE MACL (AXA ASSURANCES)              | FR        |
| ELVIA SUISSSE D'ASSURANCES, ZURICH                     | CH        |
| LA FRANCE                                              | FR        |
| GAN Incendie-Accidents Tour GAN                        | FR        |
| GENERAL ACCIDENT                                       | FR        |
| GROUPE AZUR ASSURANCE MUTUELLE                         | FR        |
| GFA                                                    | FR        |
| HANNOVER INTERNATIONAL — HIF                           | DE        |
| LLOYD CONTINENTAL                                      | FR        |
| LA LUTECE                                              | FR        |
| MUTUELLE D'ASSURANCE DES PROFESSIONS ALIMENTAIRES      | FR        |
| La Prévoyante Accidents                                | FR        |
| MUTUELLE GENERALE D'ASSURANCES (MGA)                   | FR        |
| MUTUELLES DU MANS ASSURANCES                           | FR        |
| MUTUELLE DE POITIERS                                   | FR        |
| MUTUELLES DES PROVINCES DE FRANCE — MPF                | FR        |
| MUTUELLES REGIONALES D'ASSURANCES (MRA)                | FR        |
| NATIONALE SUISSE FRANCE                                | CH        |
| LA NORMANDIE                                           | FR        |
| PFA                                                    | FR        |
| SOCIETE LILLOISE D'ASSURANCES ET DE REASSURANCES       | FR        |
| SIS ASSURANCE                                          | FR        |
| UAP                                                    | FR        |
| UNION ET PHENIX ESPAGNOL                               | ES        |
| VIA ASSURANCES NORD ET MONDE                           | FR        |
| WINTERTHURTour Winterthur                              | CH        |
| ZURICH ASSURANCE                                       | CH        |
| ABRI (ZURICH INTERNATIONAL FRANCE)                     | CH        |
| ABEILLE REASSURANCES                                   | FR        |
| BAYERISCHE RUCK                                        | DE        |
| CAISSE CENTRALE DE REASSURANCE (cCR)                   | FR        |
| COREPA                                                 | FR        |
| CIE SUISSE DE REASSURANCES                             | CH        |
| CIE TRANSCONTINENTALE DE REASSURANCE                   | FR        |
| EISEN UND STAHL-RUCKVERSICHERUNGS-AG                   | DE        |
| HANNOVER RUCKVERSICHERUNGS-AG                          | DE        |
| KOLNISCHE RUCK                                         | DE        |
| MUNCHENER RUCK                                         | DE        |
| MUTUELLE CENTRALE DE REASSURANCES                      | FR        |
| SAFR                                                   | FR        |
| SOCIETE COMMERCIALE DE REASSURANCE                     | FR        |
| SOREMA                                                 | FR        |

### Market
France

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1989-02-17 | Assurpol | concluded co-reinsurance agreement |
| 1989-02-17 | Assurpol | submitted notification concerning co-reinsurance agreements |
| 1990-12-21 | EIG Assurpol | approved co-reinsurance agreement |
| 1990-12-21 | Assurpol | approved amended instruments at general meeting |
| 1991-02-06 | EIG Assurpol | communicated co-reinsurance agreement to Commission |
| 1991-02-06 | Assurpol | transmitted amended instruments to Commission |
| 1992-01-14 | Commission | issued Decision on proceeding under Article 85 |

### Legal Framework
Article 85, infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
medium

### Exemption
Exemption sought by EIG Assurpol

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
| court                     | country        | jurisdiction                |
|:--------------------------|:---------------|:----------------------------|
| European Court of Justice | European Union | European Economic Community |

### Book Reference
NA

### Outcome
The Commission took a decision under Article 85, and the case was referred to the European Court of Justice. An exemption was sought by EIG Assurpol.


*(reported: 2026-10-16 22:10:51)*

# 'COMP/36.264', 'Mercedes-Benz'

**CELEX ID:** CELEX-32002D0758_01  
**Industry:** NA  
**Cartel Period:** 1985-09-12 : 1999-06-10  

## Summary

### Celex Case Id
NA

### Case Title
COMP/36.264 – Mercedes-Benz

### Overview
The European Commission investigated DaimlerChrysler AG and other Mercedes-Benz entities for anticompetitive agreements involving vertical restraints such as territorial exclusivity and resale price maintenance in the luxury car market.

### Industry
Mercedes passenger cars, luxury cars, sports cars, multipurpose vehicles, off-road vehicles, small cars, medium cars, upper-medium cars, executive cars

### Oecd Nace
manufacturing (29.1: Manufacture of motor vehicles)

### Companies Undertakings
| companies                                                                                 |
|:------------------------------------------------------------------------------------------|
| DaimlerChrysler AG                                                                        |
| Daimler-Benz AG                                                                           |
| Mercedes-Benz AG                                                                          |
| MBBel (Mercedes-Benz Belgium SA/NV)                                                       |
| MBE (Mercedes-Benz Espan˜a SA)                                                            |
| Mercedes-Benz agents in Germany                                                           |
| Belgian dealers                                                                           |
| Spanish dealers                                                                           |
| Belgian Association of Mercedes-Benz Dealers (Amicale des Concessionnaires Mercedes-Benz) |

### Market
Germany, Belgium, Austria, Denmark, Finland, France, Ireland, Italy, Luxembourg, Netherlands, Portugal, Sweden

### Cartel Period
1985-09-12 : 1999-06-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-09-12 | Mercedes-Benz | began infringement restricting competition |
| 1996-10-01 | Mercedes-Benz | infringement of Article 81 began |
| 1996-12-04 | Commission | issued decision ordering investigations |
| 1999-03-30 | Commission | initiated proceedings under Article 81 of the EC Treaty |
| 1999-03-31 | Commission | sent statement of objections to DaimlerChrysler AG |
| 1999-06-10 | Mercedes-Benz | ended period of infringing price-setting measures |
| 1999-06-10 | Mercedes-Benz | ended directives against exports |
| 1999-06-10 | DaimlerChrysler AG | terminated agreements restricting discount granting and ended internal competition restrictions |
| 1999-06-10 | DaimlerChrysler AG | sent circular to distribution partners ending some infringements |
| 2001-10-10 | Commission | adopted decision in Mercedes-Benz case

### Legal Framework
Article 81, Article 85

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans; Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| DaimlerChrysler AG | EUR 9,8 million |
| DaimlerChrysler AG | EUR 47,025 million |

### Remedies
Cease and desist orders to withdraw circular No 52/85 of 12 September 1985 instructing German agents to require a 15% deposit from Komm-Kunden; remove rules prohibiting sales to leasing companies for stock from German agency agreements and Spanish dealer agreements; inform German agents by memo of withdrawal of the 6 August 1996 memo

### Company Recidivism
| companies | recidivism |
| --- | --- |
| DaimlerChrysler AG | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission adopted a decision finding that DaimlerChrysler AG and other entities engaged in anticompetitive agreements under Articles 81 and 85 of the EC Treaty. Fines were imposed, and cease and desist orders were issued to terminate the infringements.


*(reported: 2026-11-11 12:12:58)*

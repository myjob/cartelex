# 'IV/E-1/35.860-B', 'seamless steel tubes'

**CELEX ID:** CELEX-32003D0382  
**Industry:** steel pipes and tubes  
**Cartel Period:** 1990 : 1994-03-31  

## Summary

### Celex Case Id
CELEX-32003D0382

### Case Title
seamless steel tubes

### Overview
This case involved a cartel among several international steel companies, including Mannesmannröhren-Werke AG, Vallourec SA, British Steel Limited, Dalmine SpA, NKK Corporation, Sumitomo Metal Industries Limited, Nippon Steel Corporation, and Kawasaki Steel Corporation. The cartel operated in the seamless steel tubes market from 1990 to 1994, engaging in horizontal restraints such as market sharing, quota cartels, and specialization agreements. The European Commission investigated and imposed significant fines on the companies involved, with leniency granted to Vallourec SA and Dalmine SpA. The case was landmark in the reference book IV/E-1/35.860-B.

### Industry
steel pipes and tubes

### Oecd Nace
manufacturing, 24.2:Manufacture of tubes, pipes, hollow profiles and related fittings, of steel, 24.20: Manufacture of tubes, pipes, hollow profiles and related fittings, of steel

### Companies Undertakings
| company                           |
|:----------------------------------|
| Mannesmannröhren-Werke AG         |
| Vallourec SA                      |
| British Steel Limited             |
| Dalmine SpA                       |
| NKK Corporation                   |
| Sumitomo Metal Industries Limited |
| Nippon Steel Corporation          |
| Kawasaki Steel Corporation        |

### Market
Relevant market includes China, Europe, Middle East, Far East, USA/Canada, South America. Market is outside the EU and is an oligopoly with turbulence due to restructuring of the European industry, rise of Latin American producers, growing importance of welded OCTG, collapse in demand from 1982 onwards, structural overcapacity in the sector

### Cartel Period
1990 : 1994-03-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-07-24 | Vallourec | discussed respecting UK market with BS |
| 1991-07-24 | British Steel Limited | entered into infringement involving contracts for supplies of plain end OCTG pipes and tubes |
| 1991-12-04 | Dalmine SpA | entered into infringement involving contracts for supplies of plain end OCTG pipes and tubes |
| 1993-08-09 | Mannesmannröhren-Werke AG | entered into infringement involving contracts for supplies of plain end OCTG pipes and tubes |
| 1994-03-31 | Vallourec | renewed plain ends supply contracts with Dalmine and MRW |
| 1994-12-01 | Commission | initiated investigation into Europe-Japan club meetings |
| 1996-09-17 | Vallourec | made written statement regarding fundamentals of Europe-Japan club |
| 1997-04-24 | Commission | infringement period concluded |
| 1997-06-03 | Commission | authorized takeover of Vallourec by MRW and amalgamation of seamless pipe and tube production |
| 1997-10-06 | Commission | sent decision to undertakings |
| 1998-06-24 | Commission | rejected appeal |
| 1999-12-08 | THE COMMISSION OF THE EUROPEAN COMMUNITIES | issued Commission Decision |

### Legal Framework
Article 81, Article 85

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
False

### Leniency
| company      | amount   |
|:-------------|:---------|
| Vallourec SA | 40%      |
| Dalmine SpA  | 20%      |

### Fines
| company | amount |
| --- | --- |
| Vallourec SA | EUR 8100 000 |
| British Steel Limited | EUR 12 600 000 |
| Dalmine SpA | EUR 10 800 000 |
| Sumitomo Metal Industries Limited | EUR 13 500 000 |
| Nippon Steel Corporation | EUR 13 500 000 |
| Kawasaki Steel Corporation | EUR 13500 000 |
| NKK Corporation | EUR 13 500 000 |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | European Union |

### Book Reference
IV/E-1/35.860-B

### Outcome
The Commission ordered all firms to immediately terminate the abovementioned infringements and to refrain in future from repeating the acts or behaviour specified in Articles 1 and 2, and from adopting any measures having equivalent effect.


*(reported: 2026-11-11 12:16:47)*

# 'IV/30.665', 'Villroy & Boch'

**CELEX ID:** CELEX-31985D0616  
**Industry:** ceramic tableware and ornaments (fine ceramics)  
**Cartel Period:** 1962-02-01 : 1985-12-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0616 | IV/30665  |

### Case Title
Villroy & Boch

### Overview
The European Commission investigated Villeroy & Boch KG and Villeroy & Boch Sarl for anticompetitive agreements under Article 85 of the EEC Treaty. The case involved vertical restraints in the form of selective distribution agreements within the ceramic tableware industry.

### Industry
ceramic tableware and ornaments (fine ceramics)

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.4: Manufacture of other porcelain and ceramic products
NACE class code: 23.42: Manufacture of ceramic sanitary fixtures

### Companies Undertakings
| companies            |
|:---------------------|
| Villeroy & Boch KG   |
| Villeroy & Boch Sarl |

| companies_investigated   | country   |
|:-------------------------|:----------|
| Villeroy & Boch KG       | DE        |
| Villeroy & Boch Sarl     | DE        |

### Market
Relevant market includes Germany, Belgium, Netherlands, Luxembourg, and France. The market is not described as oligopolistic or turbulent.

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-05-25 | Villeroy & Boch KG and Villeroy & Boch Sarl | submitted application for negative clearance of distribution agreements |
| 1985-12-16 | Commission of the European Communities | issued decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Legal framework: Article 85 (operative article), with relevant provisions from Regulation No 17. Infringement concept: anticompetitive_agreement.

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
NA

### Exemption
Exemption was sought and granted under Article 2 of Regulation No 17, indicating that the agreements are compatible with the common market.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate an infringement. The Commission granted negative clearance under Article 2 of Regulation No 17, indicating that the agreements are compatible with the common market and do not require corrective actions such as cease and desist orders, divestitures, or behavioral changes.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
The case involved the European Commission, and no court rulings are specified in the context.

### Book Reference
NA

### Outcome
The Commission granted negative clearance under Article 2 of Regulation No 17, indicating that the agreements were compatible with the common market and did not require corrective actions.


*(reported: 2026-10-16 20:02:05)*

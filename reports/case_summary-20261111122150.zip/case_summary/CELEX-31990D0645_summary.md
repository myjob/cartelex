# 'IV/32.877', 'Bayer Dental'

**CELEX ID:** CELEX-31990D0645  
**Industry:** Dental and Medical Products  
**Cartel Period:** 1988-03 : 1989-02  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0645 | IV/32877  |

### Case Title
Bayer Dental

### Overview
The case involves the European Commission's decision regarding anticompetitive agreements in the dental and medical products industry. The investigation focused on vertical restraints related to territorial exclusivity and parallel trade bans under Article 85 of the EEC Treaty.

### Industry
Dental and Medical Products

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 32.5: Manufacture of medical and dental instruments and supplies
NACE Class Code: 32.50: Manufacture of medical and dental instruments and supplies

### Companies Undertakings
| companies    |
|:-------------|
| Bayer AG     |
| Bayer Dental |
| Bayerwerk    |

### Market
Geographical: Germany, European Community
Outside EU: False
Oligopoly: NA
Turbulence: NA

### Cartel Period
1988-03 : 1989-02

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-03-01 | Bayer AG | submitted price list No 32 including Article XIV in General Conditions of Sale and Delivery |
| 1988-09-15 | Bayer AG | received request for information from Commission regarding Article XIV |
| 1988-10-27 | Bayer AG | responded to Commission's request for information |
| 1989-03-06 | Commission | initiated proceedings in the case upon its own initiative |
| 1989-05-18 | Bayer AG | engaged in talks with Commission |
| 1989-06-19 | Bayer AG | presented sample packages and explained practice at hearing |
| 1990-01-11 | Court of Justice | issued judgment in Case 277/87 (Sandoz) on competition law implications |
| 1990-07-01 | Bayer AG | amended Article XV in price list, permitting exports and excluding liability for defects of title |
| 1990-11-28 | Commission | adopted decision finding Article XIV infringed Article 85(1) of the EEC Treaty |
| 1990-11-28 | Commission | adopted Commission Decision |

### Legal Framework
Law Article Operative: Article 85
Law Article All Relevant: Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True
Applicants: NA

### Leniency
False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Bayer AG | NA |

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court            | country            | jurisdiction   |
|:-----------------|:-------------------|:---------------|
| Court of Justice | Germany            | EEC            |
| Commission       | European Community | EEC            |

### Book Reference
NA

### Outcome
The Commission adopted a decision finding Article XIV infringed Article 85(1) of the EEC Treaty. The case resulted in a finding of infringement but no specific fines or remedies are detailed in the context.


*(reported: 2026-11-11 11:24:39)*

# 'IV/30.070', 'National Panasonic'

**CELEX ID:** CELEX-31982D0853  
**Industry:** NA  
**Cartel Period:** 1976-09-08 : 1978-05-02  

## Summary

### Celex Case Id
CELEX-31982D0853

### Case Title
National Panasonic

### Overview
This case involved National Panasonic (UK) Ltd and other companies accused of engaging in vertical restraints, specifically territorial exclusivity and parallel trade bans, which violated Article 85(1) of the Treaty establishing the European Economic Community. The cartel period was from 1976 to 1978. The Commission initiated investigations in 1979, and a decision was made on 1982-12-07, fining National Panasonic (UK) Ltd 450,000 ECU. Remedies included an antitrust compliance programme.

### Industry
consumer electronic equipment, home appliances, communication measuring and business equipment, semiconductors, tubes and lighting equipment, industrial equipment, batteries, video equipment, audio equipment, hi-fi equipment, amplifiers, tuners, cassette decks, record players, loudspeakers.

### Oecd Nace
manufacturing, 26.40: Manufacture of consumer electronics

### Companies Undertakings
| company                                    |
|:-------------------------------------------|
| National Panasonic (UK) Ltd                |
| Audiotronics Holdings Ltd                  |
| Matsushita Electric Industrial Company Ltd |
| Matsushita Electric Trading Company Ltd    |

### Market
| country        |
|:---------------|
| France         |
| Germany        |
| Netherlands    |
| Belgium        |
| United Kingdom |

### Cartel Period
1976-09-08 : 1978-05-02

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-09-08 | redacted | reached agreement not to export trade quantities of Technics and National products to Europe |
| 1976-09-08 | managing director of Audiotronics | sent internal memorandum to export department agreeing not to export trade quantities of Technics and National products to Europe |
| 1976-09-20 | Audiotronics | replied to enquiry from Euro Electric stating inability to export Technics equipment due to manufacturer’s agency agreement |
| 1978-01-16 | import/export manager of NPUK | requested that dealers be kept under surveillance for possible exporting to Europe |
| 1978-01-18 | import/export manager of NPUK | issued memorandum setting out rules to prevent exports by dealers from taking place |
| 1978-05-02 | Managing Director of Audiotronics | wrote to Managing Director of NPUK apologizing for incidents with dealers and stating firm instructions to cease re-exporting Technics products |
| 1978-05-03 | Managing Director of NPUK | acknowledged letter from Audiotronics accepting apologies and expressing satisfaction with assurances |
| 1978-05-11 | NPUK | issued internal memorandum setting out instructions to find dealers selling goods at discounted prices and stating that Audiotronics is to be kept under surveillance |
| 1978-05-11 | import/export manager of NPUK | mentioned dealers to be kept under surveillance |
| 1978-06-27 | NPUK management | recorded that prevention of pirate accounts, discounting and re-export was still continuing |
| 1979-06-22 | Commission | initiated investigations at premises of National Panasonic (UK) Ltd |
| 1982-12-07 | National Panasonic (UK) Ltd | was found guilty of infringing Article 85(1) of the Treaty establishing the European Economic Community and was fined 450 000 ECU |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| National Panasonic (UK) Ltd | 450 000 ECU |

### Remedies
A fine of 450,000 ECU was imposed on National Panasonic (UK) Ltd. Additionally, behavioral remedies were mandated through the implementation of a comprehensive antitrust compliance programme by MET, including a code of conduct, guarantees for consumer service throughout the Community, and audits of legal practices in the EEC, all aimed at preventing further infringements.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| National Panasonic (UK) Ltd | NA |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court            | country        | jurisdiction          |
|:-----------------|:---------------|:----------------------|
| Court of Justice | European Union | European Court System |
| European Court   | Belgium        | European Union        |

### Book Reference
NA

### Outcome
National Panasonic (UK) Ltd was found guilty of infringing Article 85(1) of the Treaty establishing the European Economic Community and was fined 450 000 ECU. Behavioral remedies were mandated through a comprehensive antitrust compliance programme.


*(reported: 2026-11-11 10:42:33)*

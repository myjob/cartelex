# 'IV/29.955', 'Carbon Gas Technologie'

**CELEX ID:** CELEX-31983D0669  
**Industry:** | industry                      |
|:------------------------------|
| energy sector                 |
| industrial plant construction |
| chemical process technology   |
| refining                      |  
**Cartel Period:** 1979-05-29 : 1989-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0669 | IV/29955  |

### Case Title
Carbon Gas Technologie

### Overview
This case involves the European Commission's decision regarding an anticompetitive agreement in the energy sector, specifically within the context of coal gasification and liquefaction technologies. The companies involved were investigated for their participation in a joint venture that was found to be in violation of Article 85 of the EC Treaty.

### Industry
energy sector, industrial plant construction, chemical process technology, refining

### Oecd Nace
mining, 05.1:Mining of hard coal, 05.10: Mining of hard coal

### Companies Undertakings
| companies                                      |
|:-----------------------------------------------|
| Deutsche BP Aktiengesellschaft                 |
| Deutsche Babcock Aktiengesellschaft            |
| Deutsche Babcock-Beteiligungs GmbH             |
| Projektierung Chemische Verfahrenstechnik GmbH |
| Carbon Gas Technologie GmbH                    |

### Market
European Community, oligopoly market

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1979-05-29 | Deutsche BP | concluded agreement |
| 1979-10-09 | Deutsche BP Aktiengesellschaft | submitted application for negative clearance |
| 1983-12-08 | Commission of the European Communities | issued decision |
| 1989-12-31 | redacted | period of validity of exemption limited to this date |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
True

| company                                        |
|:-----------------------------------------------|
| Deutsche BP Aktiengesellschaft                 |
| Carbon Gas Technologie GmbH                    |
| Deutsche Babcock Aktiengesellschaft            |
| Deutsche Babcock-Beteiligungs GmbH             |
| Projektierung Chemische Verfahrenstechnik GmbH |

### Leniency
False

### Fines
NA

### Remedies
No specific cease and desist orders or structural remedies (e.g., divestitures) were explicitly listed for termination of the infringement. The Commission imposed conditions such as submission of licensing agreements to the Commission for examination, and penalties are specified for breach of commitments relating to know-how.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action but issued a decision regarding the anticompetitive agreement. An exemption was sought and granted, with conditions imposed on licensing agreements.


*(reported: 2026-10-16 19:51:45)*

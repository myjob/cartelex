# 'IV/33.473', 'Scottish Nuclear, Nuclear Energy Agreement'

**CELEX ID:** CELEX-31991D0329  
**Industry:** Electricity industry  
**Cartel Period:** 1990-03-31 : 2005-03-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0329 | IV/33473  |

### Case Title
Scottish Nuclear, Nuclear Energy Agreement

### Overview
The European Commission investigated an anticompetitive agreement between Scottish Nuclear Limited, Scottish Power plc, and Scottish Hydro-Electric plc in the UK electricity industry. The agreement was notified to the Commission and found to constitute a vertical restraint under Article 85 of the EEC Treaty.

### Industry
Electricity industry

### Oecd Nace
OECD sector: electricity and gas
NACE group code: 35.1: Electric power generation, transmission and distribution
NACE class code: 35.11: Production of electricity

### Companies Undertakings
| companies                   |
|:----------------------------|
| Scottish Nuclear Limited    |
| Scottish Power plc          |
| Scottish Hydro-Electric plc |

### Market
UK
Market outside EU: True
Market oligopoly: False
Market turbulence: NA

### Cartel Period
1990-02-27 : 2005-03-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-02-27 | Scottish Nuclear Limited | notified the Commission about an agreement |
| 1990-02-27 | redacted | entered into force nuclear energy agreement |
| 1990-03-31 | redacted | conclusion of old electricity supply arrangement in Scotland |
| 1991-04-30 | Commission | adopted decision |
| 2005-03-31 | redacted | agreement expires |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
medium

### Exemption
True
Exemption applicants:
| company                     |
|:----------------------------|
| Scottish Nuclear Limited    |
| Scottish Power plc          |
| Scottish Hydro-Electric plc |

### Leniency
False
Leniency applicants: NA
Leniency granted: NA
Leniency rejected: NA

### Fines
NA

### Remedies
No specific remedies or orders for termination of infringement were imposed by the Commission; instead, the agreement was granted exemption under Article 85(3) of the EEC Treaty.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted exemption under Article 85(3) of the EEC Treaty, finding that the agreement's potential benefits for technical and economic progress outweighed its anticompetitive effects.


*(reported: 2026-10-16 20:40:05)*

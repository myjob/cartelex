# 'IV/10.498, 11.546, 12.992, 17.394, 17.395, 17.971, 18.772, 18.888 and ex3.213—Omega', 'Extra alloy'

**CELEX ID:** CELEX-31970D0488  
**Industry:** watch manufacturing/distribution  
**Cartel Period:** 1967-08-01 : 1967-10-02  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31970D0488 | IV/10498  |

### Case Title
IV/10498, 11.546, 12.992, 17.394, 17.395, 17.971, 18.772, 18.888 and ex3.213—Omega

### Overview
This case involves Omega Louis Brandt et Frères S.A. and several other companies in the watch manufacturing/distribution industry who were found to have engaged in restrictive trade practices through exclusive distribution agreements within the European Economic Community (EEC). The agreements restricted exports outside the Common Market and prevented resale between contract dealers, violating Article 85(3) of the EEC Treaty. The Commission took action against these practices, leading to a decision that required the companies to cease and desist from such restrictions.

### Industry
watch manufacturing/distribution

### Oecd Nace
manufacturing
32.1:Manufacture of jewellery, bijouterie and related articles
32.12: Manufacture of jewellery and related articles

### Companies Undertakings
| companies                         | location          |
|:----------------------------------|:------------------|
| Omega Louis Brandt et Frères S.A. | Biel              |
| Maison Brandt Frères S.A.         | Paris             |
| S.p.A. De Marchi Fratelli         | Turin             |
| Ultimo Watch S.A.                 | Brussels          |
| Uhren-Handelsgesellschaft mbH     | Frankfurt am Main |
| A. Kinsbergen N.V.                | Amsterdam         |

### Market
| country     |
|:------------|
| Switzerland |
| France      |
| Italy       |
| Belgium     |
| Germany     |
| Netherlands |

### Cartel Period
1963-01-31 : 1972-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission of the European Communities | adopted Regulation No.17 |
| 1962-03-13 | redacted | prohibition of Article 85 paragraph 1 does not apply to earlier versions of agreements |
| 1963-01-31 | Omega Louis Brandt et Frères S.A. | registered exclusive distribution agreements |
| 1963-01-31 | Commission | applied Article 85(3) of the EEC Treaty to exclusive distribution agreements |
| 1967-03-22 | Omega general representatives | informed Commission on exclusive distribution agreements |
| 1967-08-01 | Omega general representatives | lifted export ban for delivery orders to contract dealers in other EEC Member States |
| 1967-08-01 | Omega | lifted absolute export ban on Omega watches |
| 1967-10-02 | Omega general representatives | allowed to supply contract dealers within the Common Market outside their own contract area |
| 1969-08-18 | Kinsbergen | removed obligation to supply only appointed dealers and stopped committing not to supply to department stores |
| 1969-08-18 | UltimoWatch | removed obligation to supply only appointed dealers |
| 1969-08-18 | Omega contract dealers in the Netherlands | no longer required to obtain watches exclusively from general representatives |
| 1970-10-28 | Commission of the European Communities | issued decision |
| 1972-12-31 | redacted | regulation No.67/67/EEC expires, ending applicability of exclusive distribution agreement terms |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts.

| company                       |
|:------------------------------|
| S.A. Maison Brandt Frères     |
| S.p.A. De Marchi Fratelli     |
| S.A. Ultimo Watch             |
| Uhren-Handelsgesellschaft mbH |
| A. Kinsbergen N.V.            |

### Leniency
Leniency: applicants, reductions granted and applications rejected, from the 'leniency_case', 'leniency_applicants', 'leniency_granted' and 'leniency_rejected' facts.

False

### Fines
NA

### Remedies
Cease and desist from restricting exports outside the Common Market; allow Omega contract dealers in France, Belgium, Luxembourg, and the Netherlands to source watches from any EEC general representative or dealer; remove prohibitions on resale between contract dealers; eliminate restrictions preventing general representatives from supplying department stores.

### Company Recidivism
| company                           | recidivism   |
|:----------------------------------|:-------------|
| Omega Louis Brandt et Frères S.A. | NA           |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 19:14:32)*

# 'IV/29.971', 'GEMA statutes'

**CELEX ID:** CELEX-31982D0204  
**Industry:** NA  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
CELEX-31982D0204 / IV/29971

### Case Title
GEMA statutes

### Overview
This case concerns the European Commission's decision on the statutes of GEMA (Gesellschaft für musikalische Auffihrungs- und mechanische Vervielfaltigungsrechte), a German collecting society for musical rights. The Commission found that GEMA's statutes were incompatible with EU competition law, particularly in relation to abuse of dominance and anticompetitive agreements under Articles 85 and 86 of the EC Treaty.

### Industry
Musical works, broadcasting services, sound recordings, performances, advertisements

### Oecd Nace
OECD sector: public service; NACE group code: 90.0: Creative, arts and entertainment activities; NACE class code: 90.02: Support activities to performing arts

### Companies Undertakings
Gesellschaft für musikalische Auffihrungs- und mechanische Vervielfaltigungsrechte (GEMA) - DE

### Market
Germany

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| Date | Event |
| --- | --- |
| 1962-02-06 | Council established Council Regulation No 17 |
| 1971-06-02 | Commission pointed to conflict of interests between users and authors |
| 1971-06-20 | Commission recognized need for joint copyright protection by collecting societies |
| 1974-02-12 | Advocate-General Mayras pointed out conflict of interests and need for collecting societies to protect copyright holders |
| 1974-03-27 | Court of Justice of the European Communities ruled on unfairness in collecting societies' statutes and determined how such statutes must balance interests |
| 1979-11-09 | GEMA filed application for negative clearance of amendment to statutes |
| 1981-03-05 | Commission published summary of notification in Official Journal |
| 1981-11-10 | Advisory Committee delivered opinion on restrictive practices |
| 1981-12-04 | Commission issued decision on GEMA's statutes |
| 1981-12-04 | Unknown adopted decision

### Legal Framework
Operative articles: Article 85, Article 86. All relevant articles: Article 102, Article 85, Article 86. Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Gesellschaft für musikalische Auffihrungs- und mechanische Vervielfältigungsrechte (GEMA)

### Leniency
NA

### Fines
NA

### Remedies
None

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| Court | Country | Jurisdiction |
| --- | --- | --- |
| Court of Justice of the European Union | European Union | European Union |
| arbitration tribunal | Germany | Germany |

### Book Reference
NA

### Outcome
The Commission found that GEMA's statutes were incompatible with EU competition law, particularly in relation to abuse of dominance and anticompetitive agreements. No fines or remedies were imposed, but the Commission issued a decision on the matter.


*(reported: 2026-10-16 19:52:05)*

# 'IV/A-22491', 'Maison Jallatte S.A.—Hans Voss KG, Maison Jallatte S.A.—S.A.Ets.Vandeputte'

**CELEX ID:** CELEX-31966D0005  
**Industry:** protective equipment  
**Cartel Period:** 1965-12-01 : 1965-12-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31966D0005 | IV/22491  |

### Case Title
Maison Jallatte S.A.—Hans Voss KG, Maison Jallatte S.A.—S.A.Ets.Vandeputte

### Overview
This case involves a cartel agreement among Maison Jallatte S.A., Hans Voss KG, and S.A. Ets. Vandeputte concerning the exclusive import and distribution of protective boots in Germany and Belgium. The agreements were concluded in 1962, and the European Commission issued a decision in December 1965.

### Industry
protective equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 15.2: Manufacture of footwear
NACE class code: 15.20: Manufacture of footwear

### Companies Undertakings
| companies            |
|:---------------------|
| Maison Jallatte S.A. |
| Hans Voss KG         |
| S.A. Ets. Vandeputte |

### Market
Relevant market includes Germany and Belgium, with no indication of market outside the EU or oligopoly structure.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-26 | MaisonJallatteS.A. and HansVossKG | concluded agreement |
| 1962-10-26 | Maison Jallatte | concluded agreement with Hans Voss for exclusive import and distribution of safety boots in Germany |
| 1962-12-05 | MaisonJallatteS.A. and S.A.EtsVandeputte | concluded agreement |
| 1962-12-05 | Maison Jallatte | concluded agreement with S.A.EtsVandeputte for exclusive representation and distribution of protective boots in Belgium |
| 1963-02-19 | MaisonJallatteS.A. | filed request pursuant to Article4 paragraph(1) of Regulation No.17 |
| 1964-07-29 | MaisonJallatteS.A. | provided explanations in letter |
| 1965-12-17 | Commission of the European Economic Community | issued decision about procedure pursuant to Article85 of the treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies            | recidivism   |
|:---------------------|:-------------|
| Maison Jallatte S.A. | False        |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
False

### Book Reference
NA

### Outcome
The European Commission issued a decision in December 1965, concluding that the agreements constituted an infringement of Article 85 of the Treaty. No leniency or exemption applications were made, and no action was taken beyond issuing the decision.


*(reported: 2026-10-16 19:15:42)*

# 'IV/24055—Kodak', 'European delivery and payment conditions for Kodak products and services'

**CELEX ID:** CELEX-31970D0332  
**Industry:** photographic and chemical products  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31970D0332 | IV/24055  |

### Case Title
IV/24055—Kodak

### Overview
The European Commission investigated Kodak companies for potential infringement of Article 85 of the Treaty, concerning restrictive practices in the photographic and chemical products industry. The investigation focused on uniform business conditions adopted by subsidiaries across multiple EU countries.

### Industry
photographic and chemical products

### Oecd Nace
OECD sector: manufacturing
NACE group code: 74.2:Photographic activities
NACE class code: 74.20: Photographic activities

### Companies Undertakings
| companies                          |
|:-----------------------------------|
| Kodak‑Pathé, Paris, France         |
| Kodak AG, Stuttgart, Germany       |
| Kodak S.A., Brussels, Belgium      |
| Kodak S.p.A., Milan, Italy         |
| Kodak N.V., The Hague, Netherlands |

### Market
Market geographical: France, Germany, Belgium, Italy, Netherlands
Market outside EU: false
Market oligopoly: NA
Market turbulence: NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Kodak companies | adopted Council Regulation No.17 |
| 1963-05-06 | Mr. Jean-Marot | submitted application for negative test |
| 1963-06-01 | Kodak companies | introduced general terms and conditions for direct customers |
| 1968-04-02 | Kodak companies | supplemented application for negative test |
| 1970-01-01 | Eastman Kodak | instructed subsidiaries to apply uniform business conditions |
| 1970-06-11 | Kodak companies | submitted statement to advisory committee |
| 1970-06-30 | Commission of the European Communities | issued decision on proceeding under Article85 |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No remedies or orders were issued by the Commission. The Commission determined not to intervene under Article 85(1) of the Treaty, issuing a negative certificate.

### Company Recidivism
| companies                                                                                                                                                | recidivism   |
|:---------------------------------------------------------------------------------------------------------------------------------------------------------|:-------------|
| Kodak‑Pathé, Paris, France, Kodak AG, Stuttgart, Germany, KodakS.A., Brussels, Belgium, KodakS.p.A., Milan, Italy, and KodakN.V., The Hague, Netherlands | True         |

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission determined not to intervene under Article 85(1) of the Treaty, issuing a negative certificate.


*(reported: 2026-10-16 19:16:56)*

# 'IV/34.503', 'Ferry operators — Currency surcharges'

**CELEX ID:** CELEX-31997D0084  
**Industry:** freight transport by roll-on roll-off ferry  
**Cartel Period:** 1992-10-02 : 1992-11-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31997D0084 | IV/34503  |

### Case Title
Ferry operators — Currency surcharges

### Overview
This case involves a cartel among ferry operators in the UK, France, Belgium and The Netherlands, where companies engaged in concerted practices to implement currency surcharges on freight services. The cartel period was from October 2, 1992 to November 1, 1992. The European Commission found that these actions constituted an anticompetitive agreement under Article 85 of the EC Treaty.

### Industry
freight transport by roll-on roll-off ferry

### Oecd Nace
OECD sector: transport
NACE group code: 50.2: Sea and coastal freight water transport
NACE class code: 50.20: Sea and coastal freight water transport

### Companies Undertakings
| company              |
|:---------------------|
| P&O European Ferries |
| Stena Line UK        |
| Sea France           |
| Brittany Ferries     |
| North Sea Ferries    |

### Market
Relevant market includes the United Kingdom, France, Belgium and The Netherlands. The market is described as oligopolistic and outside the EU.

### Cartel Period
1992-10-02 : 1992-11-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-10-02 | P&OEF, Sealink, SNAT | began concerted practice |
| 1992-10-19 | P&OEF | issued letter announcing currency surcharge |
| 1992-11-01 | Stena Sealink | implemented surcharges on freight paid in sterling on Anglo-French routes |
| 1992-11-01 | P&OEF, Brittany Ferries | exchanged letters regarding currency surcharge implementation |
| 1992-11-01 | Brittany Ferries | implemented currency surcharge effective from 1 November 1992 |
| 1992-11-01 | P&OEF | announced currency surcharge effective |
| 1992-11-01 | North Sea Ferries | implemented currency surcharge |
| 1992-11-01 | ferry operators | introduced identical currency surcharges |
| 1992-11-01 | SSL | applied surcharge |
| 1993-04-06 | P&OEF | carried out simultaneous investigations without warning |
| 1994-09-12 | Commission | opened a proceeding in this case |
| 1996-10-30 | Commission | issued Commission Decision |

### Legal Framework
Legal framework applying to the case: Article 85 (operative article) and Article 85 (all relevant articles). The canonical concept is anticompetitive_agreement.

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| P&O European Ferries | ECU 400 000 |
| Stena Line UK (Stena Sealink) | ECU 100000 |
| Sea France (SNAT) | ECU 60 000 |
| Brittany Ferries | ECU 60 000 |
| North Sea Ferries | ECU 25 000 |

### Remedies
The Commission imposed fines on P&O European Ferries (ECU 400,000), Stena Line UK (Stena Sealink) (ECU 100,000), Sea France (SNAT) (ECU 60,000), Brittany Ferries (ECU 60,000), and North Sea Ferries (ECU 25,000). No structural or behavioral remedies were imposed.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found that the companies engaged in an anticompetitive agreement under Article 85 of the EC Treaty. Fines were imposed on all five companies involved, with no structural or behavioral remedies.


*(reported: 2026-11-11 11:55:33)*

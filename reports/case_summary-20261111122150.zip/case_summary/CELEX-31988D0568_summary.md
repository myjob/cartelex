# 'IV/32.437/8', 'Eurotunnel'

**CELEX ID:** CELEX-31988D0568  
**Industry:** | industry           |
|:-------------------|
| Construction       |
| Civil engineering  |
| Consulting         |
| Project management |
| Engineering        |  
**Cartel Period:** 1986-05-01 : 1993-05-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0568 | IV/32437  |

### Case Title
Eurotunnel

### Overview
The European Commission investigated potential anticompetitive agreements related to the construction of the Channel Tunnel (Eurotunnel) project. The investigation focused on the construction and maitre d'oeuvre contracts entered into by Channel Tunnel Group Ltd and France Manche SA, with other companies involved in the project.

### Industry
Construction
Civil engineering
Consulting
Project management
Engineering

### Oecd Nace
construction
30.2:Manufacture of railway locomotives and rolling stock
30.20: Manufacture of railway locomotives and rolling stock

### Companies Undertakings
| companies                                  |
|:-------------------------------------------|
| Channel Tunnel Group Ltd                   |
| France Manche SA                           |
| W.S. Atkins and Partners                   |
| Société d'Études Techniques et Economiques |
| Transmanche Link                           |
| Transmanche Construction                   |
| Translink                                  |
| SETEC                                      |

### Market
Relevant market: United Kingdom, France
Market is not an oligopoly
Market turbulence: NA

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-02-12 | UK and French governments | signed Treaty providing for the Tunnel |
| 1986-03-14 | UK and French governments | entered into 5-year concession agreement with CTG and FM |
| 1986-08-13 | Channel Tunnel Group Ltd and France Manche SA acting on behalf of Eurotunnel | entered into construction contract and maitre d'oeuvre contract |
| 1986-08-13 | CTG and FM | signed construction contract and maitre d'oeuvre contract |
| 1987-09-30 | Channel Tunnel Group Ltd | submitted notification and application for negative clearance |
| 1987-09-30 | Commission | registered requests for negative clearance or exemption |
| 1987-11-05 | Channel Tunnel Group Ltd | amended construction contract |
| 1988-10-24 | Commission | issued decision on construction and maitre d'oeuvre contracts |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
low

### Exemption
| company                  |
|:-------------------------|
| Channel Tunnel Group Ltd |
| France Manche SA         |

### Leniency
NA

### Fines
NA

### Remedies
No remedies or orders issued, as the Commission found no grounds for action under Article 85(1) of the EEC Treaty.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found no grounds for action under Article 85(1) of the EEC Treaty and took no action.


*(reported: 2026-10-16 20:27:48)*

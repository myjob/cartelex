# 'IV/27.000', 'IFTRA rules for producers of virgin aluminium'

**CELEX ID:** CELEX-31975D0497  
**Industry:** | industry                               |
|:---------------------------------------|
| Primary Aluminium Production           |
| Aluminium Processing and Manufacturing |
| Automotive Industry                    |
| Construction Industry                  |
| Packaging Industry                     |  
**Cartel Period:** 1972-04-27 : 1975-02-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0497 | IV/27000  |

### Case Title
IFTRA rules for producers of virgin aluminium

### Overview
This case involved a cartel in the primary aluminium production industry, where companies engaged in anticompetitive agreements under the IFTRA rules for producers of virgin aluminium. The infringement was found to be in breach of Article 85(1) of the EEC Treaty.

### Industry
Primary Aluminium Production, Aluminium Processing and Manufacturing, Automotive Industry, Construction Industry, Packaging Industry

### Oecd Nace
manufacturing; 24.4:Manufacture of basic precious and other non-ferrous metals; 24.42: Aluminium production

### Companies Undertakings
| companies                                      | location                                          |
|:-----------------------------------------------|:--------------------------------------------------|
| Alusuisse Deutschland GmbH                     | Konstanz, Federal Republic of Germany             |
| Gebrüder Giulini GmbH                          | Ludwigshafen (Rhein), Federal Republic of Germany |
| Kaiser-Preussag Aluminium GmbH & Co            | Voerde (Niederrhein), Federal Republic of Germany |
| Metallgesellschaft AG                          | Frankfurt (Main), Federal Republic of Germany     |
| VAW                                            | Berlin                                            |
| Péchiney-Ugine Kuhlmann S.A.                   | Paris, France                                     |
| Holland-Aluminium N.V.                         | Den Haag, the Netherlands                         |
| The British Aluminium Company Limited          | London, England                                   |
| Empresa Nacional del Aluminio S.A.             | Madrid, Spain                                     |
| Ardal og Sunndal Verk (AsV)                    | Oslo, Norway                                      |
| Elkem — Spigerverket A/S                       | Oslo, Norway                                      |
| Norsk Hydro A/S                                | Karmoy, Oslo, Norway                              |
| Vereinigte Metallwerke Ranshofen-Berndorf A.G. | Braunau am Inn/Ranshofen, Austria                 |
| Schweizerische Aluminium AG.                   | Zürich, Switzerland                               |
| Granges Essem AB                               | Vasteras, Sweden                                  |

### Market
The relevant market includes Germany, France, Netherlands, United Kingdom, Belgium, Luxembourg, Denmark, Ireland, Austria, Greece, Iceland, Norway, Portugal, Spain, Sweden, and Switzerland. The market is characterized as an oligopoly.

### Cartel Period
1972-04-27 : 1975-02-18

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-04-27 | redacted | signed IFTRA agreement for producers of virgin aluminium |
| 1972-04-28 | redacted | submitted notification under Article 4(1) of Regulation No 17/62 |
| 1975-02-18 | signatories | terminated the agreement |
| 1975-02-24 | signatories | informed the Commission of termination and requested closure of proceedings |
| 1975-07-15 | Commission | issued Decision on IFTRA rules for producers of virgin aluminium |
| 1975-07-15 | redacted | signed decision |

### Legal Framework
Article 85; Article 86; abuse_of_dominance, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales; price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the termination of the infringement by ceasing application and enforcement of the IFTRA rules, particularly groups A and B, which were found to be in breach of Article 85(1) of the EEC Treaty.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                | country   | jurisdiction   |
|:---------------------|:----------|:---------------|
| court of arbitration |           |                |

### Book Reference
NA

### Outcome
The Commission ordered the termination of the infringement by ceasing application and enforcement of the IFTRA rules, particularly groups A and B, which were found to be in breach of Article 85(1) of the EEC Treaty.


*(reported: 2026-11-11 10:10:24)*

# 'COMP/ 38.370', 'O2 UK Limited / T-Mobile UK Limited (‘UK Network Sharing Agreement’)'

**CELEX ID:** CELEX-32003D0570  
**Industry:** NA  
**Cartel Period:** 2001-09-20 : 2007-06-30  

## Summary

### Celex Case Id
CELEX-32003D0570

### Case Title
COMP/ 38.370 – O2 UK Limited / T-Mobile UK Limited (‘UK Network Sharing Agreement’)

### Overview
The case involves O2 UK Limited and T-Mobile UK Limited, two major UK mobile network operators, who entered into a network sharing agreement concerning infrastructure sharing and national roaming. The agreement was notified to the European Commission in 2002, leading to an investigation under Articles 81 and 82 of the EC Treaty. The Commission granted an exemption under Article 81(3) subject to conditions including time limits and restrictions on information exchange.

### Industry
wireless telecommunications activities

### Oecd Nace
OECD sector: communication, NACE group code: 61.2:Wireless telecommunications activities, NACE class code: 61.20: Wireless telecommunications activities

### Companies Undertakings
| company             |
|:--------------------|
| O2 UK Limited       |
| T-Mobile UK Limited |

### Market
Relevant market: United Kingdom, oligopolistic structure

### Cartel Period
2001-09-20 : 2007-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 2001-09-20 | O2 UK and T-Mobile UK | signed agreement concerning infrastructure sharing and national roaming |
| 2001-12-31 | redacted | granted IBA Option period beginning |
| 2002-01-01 | Member States | enabled the introduction of UMTS services on their territory |
| 2002-02-06 | O2 UK and T-Mobile UK | notified Commission of the Agreement |
| 2002-02-06 | European Commission | declared inapplicability of Articles 81(1) and 53(1) to national roaming within the residual area of the Initial Build Area |
| 2002-04-09 | O2 UK Limited and T-Mobile UK Limited | amended agreement concerning site sharing and information exchange |
| 2002-05-31 | redacted | granted DA Option periods beginning |
| 2002-05-31 | Parties | exercised option for site sharing |
| 2003-03-06 | O2 UK and T-Mobile UK | informed the Commission that they had agreed to further subdivide the IBA |
| 2003-04-30 | Commission of the European Communities | issued decision in case COMP/ 38.370 |
| 2004-01-30 | redacted | ended IBA Option period |
| 2008-12-31 | European Commission | ended inapplicability of Articles 81(1) and 53(1) for national roaming within the Divided Area |

### Legal Framework
Article 81, Article 82

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
NA

### Exemption
| company             |
|:--------------------|
| O2 UK Limited       |
| T-Mobile UK Limited |

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 81(3) of the Treaty/Article 53(3) of the EEA Agreement subject to conditions including: (i) the exemption lapses by 31 December 2007 for the IBA and 31 December 2008 for the DA; (ii) the Parties must notify the Commission of any change in ownership; (iii) the use of safeguard measures prohibiting exchange of pricing information, product development plans and launch plans; (iv) compliance with the requirement that site sharing and roaming must be limited to specified time frames.


*(reported: 2026-10-16 22:30:35)*

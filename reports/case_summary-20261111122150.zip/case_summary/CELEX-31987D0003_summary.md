# 'IV/31.055', 'ENI/Montedison'

**CELEX ID:** CELEX-31987D0003  
**Industry:** NA  
**Cartel Period:** 1981-01-01 : 1998-10-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0003 | IV/31055  |

### Case Title
IV/31.055 – ENI/Montedison

### Overview
The case concerns anticompetitive agreements between Ente Nazionale Idrocarburi (ENI) and Montedison SpA in the Italian petrochemical market, involving horizontal restraints such as market sharing, quota cartels, and specialization agreements. The agreements were found to violate Article 85 of the EEC Treaty.

### Industry
Petrochemicals

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE Class Code: 20.14: Manufacture of other organic basic chemicals

### Companies Undertakings
| companies                  |
|:---------------------------|
| Ente Nazionale Idrocarburi |
| Montedison SpA             |

### Market
Italy, oligopoly market

### Cartel Period
1983-03-17 : 1998-10-18

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1982-12-31 | ENI and Montedison | signed agreements |
| 1983-03-17 | ENI and Montedison | entered into agreements concerning energy and petrochemicals |
| 1983-09-27 | Montedison | transferred assets to ENI |
| 1983-09-27 | Ente Nazionale Idrocarburi and Montedison SpA | entered into agreement |
| 1983-09-27 | ENI and Montedison | implemented further agreements related to supply, plant operations, and licensing |
| 1983-10-19 | ENI and Montedison | submitted application for negative clearance and notification for exemption |
| 1986-10-19 | ENI | submitted initial report |
| 1986-10-19 | ENI and Montedison | submitted report on production and sales covering period from 1986-10-19 to 1989-10-18 |
| 1986-12-04 | Commission of the European Communities | issued Commission Decision in proceedings under Article 85 of the EEC Treaty |
| 1989-10-18 | ENI | reporting period ended |
| 1989-10-18 | ENI and Montedison | submitted report on production and sales covering subsequent reporting period |
| 1998-03-17 | Ente Nazionale Idrocarburi | implemented agreement |

### Legal Framework
Article 85 (operative article)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
| company    |
|:-----------|
| ENI        |
| Montedison |

### Leniency
NA

### Fines
NA

### Remedies
No specific cease and desist orders or termination remedies are explicitly issued by the Commission in this decision; instead, the Commission granted an exemption with conditions.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption with conditions to ENI and Montedison, recognizing their conduct as part of a broader agreement but allowing them to continue operating under certain terms.


*(reported: 2026-10-16 20:09:21)*

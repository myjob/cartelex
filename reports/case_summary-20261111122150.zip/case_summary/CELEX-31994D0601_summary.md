# 'NA', 'NA'

**CELEX ID:** CELEX-31994D0601  
**Industry:** Paper & Packaging  
**Cartel Period:** 1986 : 1988-09-30  

## Summary

### Celex Case Id
CELEX-31994D0601 / IV/31.128

### Case Title
NA

### Overview
Cartel involving companies in the paper and packaging industry, specifically cartonboard, paperboard, solid bleached sulphate board (SBS), greyboard, and chipboard (WLC). The cartel operated between 1986 and 1988, engaging in price fixing collusion, market sharing, quota cartels, and exchange of information on prices and sales. The Commission took a decision under Article 85 of the EC Treaty, imposing significant fines on the participating companies.

### Industry
Paper & Packaging

### Oecd Nace
OECD Sector: manufacturing; NACE Group Code: 17.1:Manufacture of pulp, paper and paperboard; NACE Class Code: 17.12: Manufacture of paper and paperboard

### Companies Undertakings
| Buchmann GmbH (DE) |
| Cascades SA (CA) |
| Enso-Gutzeit Oy (FI) |
| Europa Carton AG (DE) |
| Finnboard (FI) |
| Fiskeby Board AB (SE) |
| Gruber & Weber GmbH & Co KG (AT) |
| Kartonfabriek 'de Eendracht' NV (trading as BPB de Eendracht) (NL) |
| NV Koninklijke KNP BT NV (NL) |
| Laakmann Karton GmbH & Co KG (DE) |
| Mayr-Melnhof Karton Gesellschaft mbH (AT) |
| Mo Och Domsjö AB (MoDo) (SE) |
| Papeteries de Lancey SA (FR) |
| Rena Kartonfabrik A/S (DK) |
| Sarrió SpA (ES) |
| SCA Holding Ltd (formerly Reed Paper & Board (UK) Ltd) (GB) |
| Stora Kopparbergs Bergslags AB (SE) |
| Enso Española SA (formerly Tampella Española SA) (ES) |
| Moritz J. Weig GmbH & Co KG (DE) |

### Market
Relevant market: Germany, France, United Kingdom, Belgium, Netherlands, Italy, Denmark, Austria, Switzerland, Portugal; oligopoly market

### Cartel Period
1986 : 1988-09-30

### Key Timeline
| 1986-11-10 | redacted | held meeting |
| 1986-11-10 | redacted | discussed collusive pricing initiatives |
| 1987-01-15 | Feldmühle | exchanged detailed information on pricing, order backlog and downtime |
| 1987-03-01 | Cascades | notified price increase for GC grades |
| 1988-03-01 | producers (Aussedat-Rey, Béghin, Cascades) | implemented floor prices for UC, GC 1 and GC 2 grades |
| 1988-09-30 | cartonboard producers | ended price initiative increasing GC, GD, and SBS grades |
| 1989-04-01 | redacted | price increases for GC grades became effective |
| 1990-01-11 | Iggesund | sent out price increase letter for packaging grades |
| 1990-01-25 | Cascades | announced price increase |
| 1990-04-01 | redacted | price increases took effect |
| 1990-11-22 | British Printing Industries Federation | filed complaint alleging price-fixing |
| 1994-07-13 | Commission | issued Commission Decision relating to a proceeding under Article 85 of the EC Treaty |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
False

### Fines
| Buchmann GmbH | ECU 2 200 000 |
| Cascades SA | ECU 16 200 000 |
| Enso-Gutzeit Oy | ECU 3 250 000 |
| Europa Carton AG | ECU 2 000 000 |
| Finnboard — the Finnish Board Mills Association | ECU 20 000 000 |
| Fiskeby Board AB | ECU 1 000 000 |
| Gruber & Weber GmbH & Co KG | ECU 1 000 000 |
| Kartonfabriek 'de Eendracht' NV (trading as 'BPB de Eendracht') | ECU 1 750 000 |
| NV Koninklijke KNP BT NV | ECU 300 000 |
| Laakmann Karton GmbH & Co KG | ECU 2 200 000 |
| Mayr-Melnhof Karton Gesellschaft mbH | ECU 21 000 000 |
| Mo Och Domsjö AB | ECU 22 750 000 |
| Papeteries de Lancey SA | ECU 1 500 000 |
| Rena Kartonfabrik A/S | ECU 200 000 |
| Sarrió SpA | ECU 15 500 000 |
| SCA Holding Ltd | ECU 2 200 000 |
| Stora Kopparbergs Bergslags AB | ECU 11 250 000 |
| Enso Española SA | ECU 1 750 000 |
| Moritz J. Weig GmbH & Co KG | ECU 3 000 000 |

### Remedies
The Commission ordered undertakings to bring the infringement to an end and to refrain from any agreement or concerted practice that may have the same or similar object or effect, including exchanges of commercial information on production, sales, order backlog, machine utilization rates, selling prices, costs, or marketing plans; they must also abstain from meetings or discussions related to such information that could lead to coordinated behavior.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| Commission | European Union | EC Treaty |

### Book Reference
IV/31.128

### Outcome
The Commission ordered undertakings to bring the infringement to an end and to refrain from any agreement or concerted practice that may have the same or similar object or effect, including exchanges of commercial information on production, sales, order backlog, machine utilization rates, selling prices, costs, or marketing plans; they must also abstain from meetings or discussions related to such information that could lead to coordinated behavior.


*(reported: 2026-11-11 11:46:37)*

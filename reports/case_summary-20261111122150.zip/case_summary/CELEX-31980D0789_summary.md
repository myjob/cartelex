# 'IV/26.528', 'The Distillers Co. Ltd — Victuallers'

**CELEX ID:** CELEX-31980D0789  
**Industry:** distillery/whisky  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0789 | IV/26528  |

### Case Title
The Distillers Co. Ltd — Victuallers

### Overview
This case concerns the European Commission's investigation into anticompetitive agreements among UK whisky distillers, specifically focusing on vertical restraints such as territorial exclusivity and parallel trade bans. The Commission found no infringement under Article 85(1) of the Treaty.

### Industry
distillery/whisky

### Oecd Nace
OECD Sector: manufacturing
NACE Group Code: 11.0: Manufacture of beverages
NACE Class Code: 11.04: Manufacture of other non-distilled fermented beverages

### Companies Undertakings
| companies                            | location          |
|:-------------------------------------|:------------------|
| The Distillers Company Ltd           | NA                |
| Ainslie & Heilbron (Distillers) Ltd  | Glasgow           |
| Baird-Taylor Ltd                     | Glasgow           |
| John Begg Ltd                        | Glasgow           |
| Benmore Distilleries Ltd             | Glasgow           |
| J. S. A. Bertram & Co. Ltd           | Edinburgh         |
| John Bisset & Co. Ltd                | Edinburgh         |
| James Buchanan & Co. Ltd             | London            |
| Bulloch Lade & Co. Ltd               | Glasgow           |
| Geo. Cowie & Son Ltd                 | Duftown           |
| John Crabbie & Co. Ltd               | Edinburgh         |
| Craighall Bonding Co. Ltd            | Glasgow           |
| A. & A. Crawford Ltd                 | Edinburgh         |
| Daniel Crawford & Co. Ltd            | Glasgow           |
| The Distillers Agency Ltd            | South Queensferry |
| Peter Dawson Ltd                     | Glasgow           |
| John Dewar & Sons Ltd                | Perth             |
| A. Ferguson & Co. Ltd                | Edinburgh         |
| Donald Fisher Ltd                    | Edinburgh         |
| John Gillon & Co. Ltd                | Glasgow           |
| Wm. Greer & Co. Ltd                  | Glasgow           |
| John Haig & Co. Ltd                  | Fife              |
| J. & W. Hardie Ltd                   | Edinburgh         |
| J. & R. Harvey & Co. Ltd             | Glasgow           |
| John Hopkins & Co. Ltd               | Glasgow           |
| Low Robertson & Co. Ltd              | Edinburgh         |
| W. P. Lowrie & Co. Ltd               | Glasgow           |
| Macdonald Greenlees Ltd              | Edinburgh         |
| Macleay Duff (Distillers) Ltd        | Glasgow           |
| D. & J. McCallum Ltd                 | Edinburgh         |
| John McEwan & Co. Ltd                | Edinburgh         |
| Mitchell Bros. Ltd                   | Glasgow           |
| Jas. Munro & Son Ltd                 | Edinburgh         |
| John Robertson & Son Ltd             | Edinburgh         |
| Wm. Sanderson & Son Ltd              | Edinburgh         |
| Slater, Rodger & Co. Ltd             | Glasgow           |
| J. & G. Stewart Ltd                  | Edinburgh         |
| R. H. Thomson & Co. (Distillers) Ltd | Edinburgh         |
| John Walker & Sons Ltd               | London            |
| James Watson & Co. Ltd               | Dundee            |
| White Horse Distillers Ltd           | Glasgow           |
| Wright & Greig Ltd                   | Glasgow           |

### Market
Relevant market includes Glasgow, Edinburgh, London, Perth, and Duftown in the UK. The market is outside the EU.

### Cartel Period
1967-09-04 : 1980-07-22

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1967-09-04 | The Distillers Co. Ltd | filed notification of standard agreement |
| 1971-02-02 | Commission | published essential content of notification |
| 1971-02-02 | redacted | published essential content of standard agreement in Official Journal |
| 1975-07-16 | Advisory Committee | provided opinion on restrictive practices |
| 1980-03-15 | Commission | published second essential content of notification |
| 1980-03-15 | redacted | published standard agreement to enable observations from third parties |
| 1980-05-20 | Advisory Committee | provided second opinion on restrictive practices |
| 1980-07-22 | Commission | issued decision under Article 85 of EEC Treaty |
| 1980-07-22 | Commission | adopted this decision |

### Legal Framework
Law Article Operative: Article 85
Law Article All Relevant: Article 85
Infringement Concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
low

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
No remedies were issued, as the Commission found no infringement under Article 85(1) of the Treaty.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found no infringement under Article 85(1) of the Treaty, and no remedies or fines were imposed.


*(reported: 2026-10-16 19:22:19)*

# 'IV/4.204', 'Velcro/Aplix'

**CELEX ID:** CELEX-31985D0410  
**Industry:** fastener industry  
**Cartel Period:** 1958 : 1977-12-15  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0410 | IV/4204   |

### Case Title
Velcro/Aplix

### Overview
This case involved two French companies, Velcro SA and Aplix SA, which entered into a licensing agreement in 1958 that restricted competition in the fastener market. The agreement included exclusivity, export bans, and non-compete obligations, leading to an infringement of Article 85(1) of the EC Treaty. The Commission found the agreement to be anticompetitive with high gravity.

### Industry
fastener industry

### Oecd Nace
manufacturing
NACE group code: 25.9
NACE class code: 25.94

### Companies Undertakings
| companies   |
|:------------|
| Velcro SA   |
| Aplix SA    |

### Market
France, Federal Republic of Germany, Japan, Switzerland, Netherlands

### Cartel Period
1958 : 1977-12-15

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1958-10-14 | Velcro and Aplix | signed initial agreement |
| 1958-11-17 | Aplix and Velcro | extended the term of the licensing agreement |
| 1963-01-30 | Aplix | notified licensing agreement to Commission |
| 1972-05-29 | Aplix and Velcro | signed supplementary agreement |
| 1973-12-10 | Aplix and Velcro | signed supplementary agreement for intervention in French action |
| 1977-12-15 | Aplix and Velcro | restricted competition in fastener market |
| 1977-12-15 | Commission | found infringement of Article 85(1) |
| 1984-06-26 | Aplix and Velcro | Commission initiated proceedings in case |
| 1985-07-12 | Commission | adopted decision on infringement |
| 1989-08-11 | Aplix | patent expiry date claimed to extend territorial exclusivity |

### Legal Framework
Article 85
infringement concept: anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
high

### Exemption
| company |
| --- |
| Velcro SA |
| Aplix SA |

### Leniency
NA

### Fines
NA

### Remedies
The Commission required the undertakings Velcro SA and Aplix SA to bring the infringements of Article 85(1) to an end by ceasing to operate under the infringing clauses, including exclusivity, export bans, and non-compete obligations, as listed in Article 1 of the Decision. No structural or specific commitments for divestiture were ordered.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Velcro SA | NA |
| Aplix SA | NA |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                            | country                | jurisdiction                |
|:-------------------------------------------------|:-----------------------|:----------------------------|
| Paris Regional Court                             | France                 | Tribunal de Grande Instance |
| Dutch court                                      | Netherlands            | Netherlands                 |
| High Court of Justice, Chancery Division, London | United Kingdom         | England and Wales           |
| French and Dutch courts                          | France and Netherlands | Not specified               |

### Book Reference
NA

### Outcome
The Commission found infringement of Article 85(1) and required the companies to cease operating under the infringing clauses. No structural remedies or divestiture were ordered.


*(reported: 2026-11-11 10:58:10)*

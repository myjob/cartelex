# 'IV/29.725', 'Wood pulp'

**CELEX ID:** CELEX-31985D0202  
**Industry:** Pulp and Paper  
**Cartel Period:** 1973-07-02 : 1980  

## Summary

### Celex Case Id
CELEX-31985D0202

### Case Title
Wood pulp

### Overview
This case involves a cartel in the wood pulp industry, where companies engaged in anticompetitive practices including exchange of information on prices and sales. The infringement occurred between 1973 and 1980, with the Commission taking action in 1984. Companies from multiple countries were involved, including those from the EU and outside the EU. Fines were imposed, and undertakings were provided to cease such practices.

### Industry
Pulp and Paper

### Oecd Nace
OECD: manufacturing; NACE: 17.1: Manufacture of pulp, paper and paperboard; 17.11: Manufacture of pulp

### Companies Undertakings
| companies                                                          | location   |
|:-------------------------------------------------------------------|:-----------|
| British Columbia Forest Products Ltd                               | NA         |
| Canfor Corporation                                                 | NA         |
| MacMillan Bloedel Ltd                                              | NA         |
| St Anne-Nackawick Pulp and Paper Co. Ltd                           | NA         |
| Weldwood of Canada Ltd                                             | NA         |
| Westar Timber Ltd                                                  | NA         |
| Bowater Incorporated                                               | NA         |
| Chesapeake Corporation                                             | NA         |
| Crown Zellerbach                                                   | NA         |
| Federal Paper Board Company, Incorporated                          | NA         |
| Georgia-Pacific Corporation                                        | NA         |
| International Pulp Sales Company                                   | NA         |
| ITT Rayonier Incorporated                                          | NA         |
| The Mead Corporation                                               | NA         |
| Scott Paper Company                                                | NA         |
| Weyerhaeuser Company                                               | NA         |
| Pulp, Paper and Paperboard Export Association of the United States | US         |
| A. Ahlstrom Oy                                                     | Finland    |
| Enso-Gutzeit Oy                                                    | Finland    |
| Joutseno-Pulp Oy                                                   | Finland    |
| Kaukas AB Oy                                                       | Finland    |
| Kemi Oy                                                            | Finland    |
| Metsa-Botnia AB Oy                                                 | Finland    |
| Metsaliton Teollisus Oy                                            | Finland    |
| Oulu Oy                                                            | Finland    |
| Wilh. Schauman AB Oy                                               | Finland    |
| Sunila Oy                                                          | Finland    |
| Veitsiluoto Oy                                                     | Finland    |
| Finncell                                                           | Finland    |
| Billerud AB                                                        | Sweden     |
| Iggesunds Bruk AB                                                  | Sweden     |
| Kopparfors AB                                                      | Sweden     |
| Korsnas-Marma AB                                                   | Sweden     |
| MoDoCell AB                                                        | Sweden     |
| Norrlands Skogsagares Cellulosa AB                                 | Sweden     |
| Södra Skogsagarna AB                                               | Sweden     |
| Stora Kopparbergs Bergslags AB                                     | Sweden     |
| Svenska Cellulosa AB                                               | Sweden     |
| Uddeholms AB                                                       | Sweden     |
| Svenska Cellulosa – Och Papperbruks Foreningen                     | Sweden     |
| Borregaard A/S                                                     | Norway     |
| Portucel – Empresa de celulose e papel de Portugal EP              | Portugal   |
| Empresa nacional de celulosas SA                                   | Spain      |

### Market
Relevant market: Belgium, Federal Republic of Germany, France, Netherlands, United Kingdom, Portugal; oligopoly structure

### Cartel Period
1973-07-02 : 1980

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-07-02 | GEC, Swedish Pulp and Paper Association, Sodra | discussed price increase for bleached pulp and exchanged information on production capacities, stocks, and customer reactions |
| 1973-09-27 | participants | discussed market situation and production capacities |
| 1974-01-08 | MacMillan | considered holding a mini-reunion to harmonize viewpoints on price increase |
| 1974-01-24 | Scandinavian pulp producers | discussed prices at general meeting |
| 1974-01-29 | Canfor | noted discussion on surcharges and second quarter prices |
| 1974-09-12 | Rayonier | reported price moves from Stockholm meeting |
| 1974-09-13 | Rayonier | communicated outcomes of previous day's Stockholm meeting |
| 1974-09-24 | participants | discussed market and price situation |
| 1974-10-02 | SCA | entered data for pricing |
| 1974-10-03 | Sodra Stora | entered data for pricing |
| 1975-05-27 | MoDoCell | announced undertaking |
| 1975-05-28 | Crown Zellerbach Federal Paper | announced undertaking |
| 1975-11-19 | Finncell | set policy for internationally uniform price level for pulp |
| 1984-07-20 | enterprises | gave and complied with undertaking sent to Commission |
| 1984-12-19 | redacted | Commission Decision was made regarding restrictive practices in wood pulp industry |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| addressee 1 | 100 000 ECU |
| addressee 2 | 125 000 ECU |
| addressee 3 | 150 000 ECU |
| addressee 4 | 200 000 ECU |
| addressee 5 | 50 000 ECU |
| addressee 6 | 150 000 ECU |
| addressee 7 | 500 000 ECU |
| addressee 8 | 50 000 ECU |
| addressee 9 | 50 000 ECU |
| addressee 10 | 100 000 ECU |
| addressee 11 | 150 000 ECU |
| addressee 12 | 250 000 ECU |
| addressee 14 | 50 000 ECU |
| addressee 15 | 50 000 ECU |
| addressee 16 | 50 000 ECU |
| addressee 17 | 50 000 ECU |
| addressee 18 | 50 000 ECU |
| addressee 19 | 200 000 ECU |
| addressee 20 | 50 000 ECU |
| addressee 21 | 100 000 ECU |
| addressee 22 | 50 000 ECU |
| addressee 23 | 100 000 ECU |
| addressee 25 | 100 000 ECU |
| addressee 26 | 100 000 ECU |
| addressee 28 | 150 000 ECU |
| addressee 29 | 100 000 ECU |
| addressee 30 | 50 000 ECU |
| addressee 31 | 50 000 ECU |
| addressee 32 | 50 000 ECU |
| addressee 33 | 50 000 ECU |
| addressee 34 | 150 000 ECU |
| addressee 35 | 150 000 ECU |
| addressee 36 | 200 000 ECU |
| addressee 37 | 150 000 ECU |
| addressee 38 | 150 000 ECU |
| addressee 40 | 50 000 ECU |

### Remedies
Cease and desist from concertation on prices and exchange of confidential information; refrain from any measure having the same object or effect; provide undertakings to future behavior.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court   | country   | jurisdiction            |
|:--------|:----------|:------------------------|
| SCA     | Sweden    | Stockholm County Courts |
| BCFP    | Sweden    | Stockholm County Courts |

### Book Reference
NA

### Outcome
Commission Decision taken, fines imposed, undertakings provided to cease and desist from concertation on prices and exchange of confidential information.


*(reported: 2026-11-11 10:56:34)*

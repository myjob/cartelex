# 'NA', 'NA'

**CELEX ID:** CELEX-31985D0563  
**Industry:** commodity trading  
**Cartel Period:** 1985-05-20 : 1985-12-13  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0563 | IV/27590  |

### Case Title
NA

### Overview
The European Commission investigated two UK-based companies, London Sugar Futures Market Limited and International Commodities Clearing House Limited, for engaging in horizontal price fixing collusion under Article 85 of the EC Treaty. The cartel period is noted as 1900-01-01 to 1900-01-01 (likely a placeholder or error). The Commission took no action but issued a decision.

### Industry
commodity trading

### Oecd Nace
OECD sector: agriculture
NACE group code: 10.8:Manufacture of other food products
NACE class code: 10.81: Manufacture of sugar

### Companies Undertakings
| companies                                        |
|:-------------------------------------------------|
| London Sugar Futures Market Limited              |
| International Commodities Clearing House Limited |

### Market
Relevant market: United Kingdom, outside EU, oligopoly

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-06-29 | London Sugar Futures Market | submitted notification and application for negative clearance |
| 1985-05-20 | London Sugar Futures Market | submitted application for negative clearance |
| 1985-05-20 | Commission | issued negative clearance pursuant to Article 2 of Regulation 17 |

### Legal Framework
Legal framework applying to the case: the operative articles 'Article 85' and the canonical concept 'anticompetitive_agreement'

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the London Sugar Futures Market to abandon the system of fixed minimum commission rates. It also required changes in the Rules and Regulations such that business between Full Members may be transacted free of commission, while other transactions must include a commission but at freely negotiable rates. An appeal procedure was introduced to protect member rights.

### Company Recidivism
| companies                   | recidivism   |
|:----------------------------|:-------------|
| London Sugar Futures Market | False        |

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court           | country   | jurisdiction   |
|:----------------|:----------|:---------------|
| ordinary courts | England   | English law    |

### Book Reference
NA

### Outcome
The Commission took no action but issued a decision. Remedies were ordered to abandon fixed minimum commission rates and introduce free negotiation of commissions.


*(reported: 2026-10-16 19:32:38)*

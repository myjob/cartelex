# 'NA', 'closed agreement among manufacturers of synthetic nitrogen fertilizers regarding joint sales in the version applicable from 1 July1967, to be implemented on the basis of Article85 paragraph1 of the Treaty establishing the European Economic Community'

**CELEX ID:** CELEX-31968D0375  
**Industry:** | industry                     |
|:-----------------------------|
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |
| nitrogen fertilizer industry |  
**Cartel Period:** 1967-04-24 : 1967-07-01  

## Summary

### Celex Case Id
CELEX-31968D0375

### Case Title
closed agreement among manufacturers of synthetic nitrogen fertilizers regarding joint sales in the version applicable from 1 July1967, to be implemented on the basis of Article85 paragraph1 of the Treaty establishing the European Economic Community

### Overview
This case involves a cartel among manufacturers of synthetic nitrogen fertilizers in Belgium, which was found to be incompatible with Article 85 of the Treaty establishing the European Economic Community. The cartel period lasted from 1962 to 1967, and the agreement included practices such as loyalty premiums and storage loss compensations. The Commission took a decision and ordered the cessation of these practices and required amendments to the agreement.

### Industry
nitrogen fertilizer industry

### Oecd Nace
manufacturing, 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms, 20.15: Manufacture of fertilisers and nitrogen compounds

### Companies Undertakings
| companies                                     | location         |
|:----------------------------------------------|:-----------------|
| Belgian Nitrogen Counter                      | Brussels         |
| Synthetic Ammonia and Derivatives, S.A.       | Brussels         |
| Cockerill-Ougrée-Providence, S.A.             | Seraing          |
| Hainaut-Sambre Metallurgical Company, S.A.    | Couillet         |
| S.A. of the Coke Ovens of Zeebrügge           | Brussels         |
| Thy-Marcinelle and Monceau Forges, S.A.       | Marcinelle       |
| Marly Cokeries, S.A.                          | Brussels         |
| Espérance-Longdoz Metallurgical Company, S.A. | Liège            |
| Anderlues Coal Mines, S.A.                    | Anderlues        |
| Central Carbonisation, S.A.                   | Brussels         |
| S.A. of the Borinage Coal Mines               | Cuesmes          |
| Clabecq Forges, S.A.                          | Clabecq          |
| Gustave Boël Factories, S.A.                  | Brissel          |
| Brabant Cokeries, S.A.                        | Brissel          |
| André Dumont N.V., S.A.                       | Brissel          |
| S.A. of the Bois-du-Luc Coal Mines            | Houdeng-Aimeries |
| Zolder N.V., S.A.                             | Zolder           |
| Hensies-Pommeroeul Coal Mines, S.A.           | Brussels         |
| Limburg-Meuse, S.A.                           | Brussels         |

### Market
Belgium, outside EU

### Cartel Period
1962-03-13 : 1967-04-24

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1940-09-12 | Comptoir belge del'azote Cobelaz | founded cooperative and signed agreement transferring exclusive rights for joint sales of nitrogen fertilizers |
| 1962-03-13 | redacted | agreement became effective |
| 1962-10-30 | Belgian manufacturers of coking ammonium sulfate | submitted application for negative test |
| 1964-05-22 | Belgian manufacturers of coking ammonium sulfate | confirmed application for negative test |
| 1966-10-14 | Commission | communicated points of complaint regarding incompatibility with Article 85 of the Treaty |
| 1967-04-06 | Cobelaz | terminated contested provisions by resolution of members’ general meeting |
| 1967-04-24 | Cobelaz | confirmed to the Commission that amended agreement will terminate loyalty premium and stock-holding compensation |
| 1967-05-18 | Commission of the European Communities | published essential content of negative certificate application |
| 1967-07-01 | parties to the agreement | amended agreement and ceased contested provisions |
| 1967-07-01 | Cobelaz | applied general sales conditions without export/import restrictions |
| 1967-07-01 | members | incorporated clause restricting joint sales to Belgian and non-EEC markets |
| 1967-07-01 | Cobelaz | terminated contested provisions in agreement and general sales conditions applicable in Belgium

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
Belgian Federation of Nitrogen Producers, Belgian Nitrogen Counter, Synthetic ammonia and derivatives, Belgian Nitrogen and Marly Chemical Products Company, Carbo-chemical Company, Public limited company for the manufacture of nitrogen fertilizers, Company of the Ugine-Kuhlmann chemical factories, U.C.B. Chemical Union Chemische Bedrijven

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/507

### Outcome
The Commission ordered the cessation of restrictive practices such as loyalty premiums and storage loss compensations. It also required that the agreement be amended to allow members free export rights within the EEC, remove uniform pricing that distorted competition, and ensure no indirect restrictions on trade between Member States.


*(reported: 2026-10-16 19:03:10)*

# 'IV/29.246', 'Penneys'

**CELEX ID:** CELEX-31978D0193  
**Industry:** retail trade  
**Cartel Period:** 1974-04-04 : 1976-12-31  

## Summary

### Celex Case Id
CELEX-31978D0193

### Case Title
Penneys

### Overview
This case involved an investigation into anticompetitive practices in the retail trade sector, focusing on horizontal restraints. The European Commission examined settlement agreements between J.C. Penney Company, Inc., and Associated British Foods (ABF) group, ultimately concluding that no infringement occurred under Article 85(1) of the EEC Treaty. The Commission granted negative clearance, indicating that the practices did not constitute a violation of EU competition law.

### Industry
retail trade

### Oecd Nace
trade (wholesaling and retailing) and hotels

### Companies Undertakings
| companies                               | location   |
|:----------------------------------------|:-----------|
| J.C. Penney Company, Inc.               | NA         |
| J.C. Penney Purchasing Corporation      | NA         |
| Associated British Foods Limited        | NA         |
| Fine Fare Limited                       | NA         |
| Penneys Limited                         | NA         |
| Penneys (NI) Limited                    | NA         |
| The Penneys Primark Quinnsworth Limited | NA         |
| Bee Line Products Limited               | NA         |
| Power Supermarkets Limited              | NA         |
| Primark Limited                         | NA         |

### Market
EEC

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-02-26 | J.C. Penney Company, Inc. and J.C. Penney Purchasing Corporation | entered into settlement agreement with Associated British Foods Limited, Fine Fare Limited, Penneys Limited, Penneys (NI) Limited, The Penneys Primark Quinnsworth Limited, Bee Line Products Limited and Power Supermarkets Limited |
| 1976-02-26 | Penney America and the ABF Group | entered into notified agreement to settle pending litigations |
| 1976-02-26 | J.C. Penney Company, Inc. | concluded settlement agreement with Associated British Foods Limited and others |
| 1976-05-31 | J.C. Penney Company, Inc. | filed application for negative clearance |
| 1976-08-27 | Penney America and the ABF Group | agreement became effective |
| 1977-01-10 | Penney America | licensed the ABF Group to use the mark 'Penneys' in Ireland |
| 1977-01-29 | Penney America | reported sales volume of 8,354 million USD |
| 1977-03-29 | redacted | summary of application published in Official Journal of the European Communities |
| 1977-09-28 | Advisory Committee | delivered opinion on restrictive practices and dominant positions |
| 1977-12-23 | Commission | issued decision at Brussels |
| 1977-12-23 | redacted | issued commission decision |

### Legal Framework
Article 85

### Infringement Category
horizontal

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
| court                           | country            | jurisdiction      |
|:--------------------------------|:-------------------|:------------------|
| Supreme Court                   | Ireland            | Ireland           |
| High Court of England and Wales | England            | England and Wales |
| COMMISSION                      | European Community | EEC               |
| High Court of Justice           | England            | England and Wales |

### Book Reference
NA

### Outcome
The Commission concluded there was no infringement under Article 85(1) of the EEC Treaty and granted negative clearance.


*(reported: 2026-10-16 19:44:02)*

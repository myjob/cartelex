# 'IV/34.456', 'Stichting Baksteen'

**CELEX ID:** CELEX-31994D0296  
**Industry:** brick industry  
**Cartel Period:** 1991-08-19 : 1997-09-30  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0296 | IV/34456  |

### Case Title
Stichting Baksteen

### Overview
The European Commission investigated an anticompetitive agreement among Dutch brick manufacturers, involving exchange of information on prices and sales during a structural crisis in the brick industry. The cartel period was from August 25, 1992 to September 30, 1997.

### Industry
brick industry

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.3:Manufacture of clay building materials
NACE class code: 23.32: Manufacture of bricks, tiles and construction products, in baked clay

### Companies Undertakings
| companies                                    |
|:---------------------------------------------|
| Rodruza BV                                   |
| Teewen BV                                    |
| Boral Nedusa Baksteen BV                     |
| Koramic Baksteengroep BV                     |
| De Jong van Lekkerkerk Holding BV (Desimpel) |
| Steenfabriek Huissenswaard BV                |
| Steenfabriek De Rijswaard BV                 |
| L. J. Duijs Steenfabrieken BV                |
| Daas Baksteen BV                             |
| C. R. H. Kleiwaren Beheer BV                 |
| Steenfabriek Zennewijnen BV                  |
| Steenfabriek De Waalwaard BV                 |
| Hagens Steenfabrieken BV                     |
| Baksteen Helden BV                           |
| Smeijers & Voortman BV                       |
| Steenindustrie Strating BV                   |
| Stichting Baksteen                           |

### Market
Relevant market: Netherlands, Germany, Belgium, United Kingdom
Market structure: oligopoly
Market turbulence: considerable overcapacity, steadily mounting stockpiles, falling demand, declining consumption of bricks relative to other building materials, low price elasticity of demand, structural drop in demand, deteriorating financial performance, no lasting improvement in medium term

### Cartel Period
1992-08-25 : 1997-09-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-08-19 | Stichting Baksteen | notified Commission of agreements between Dutch brick manufacturers |
| 1992-01-28 | Commission | initiated proceedings in this case |
| 1992-08-25 | Stichting Baksteen and Dutch brick producers | concluded agreement |
| 1992-09-10 | redacted | made further notification under Article 4 of Regulation No 17 |
| 1992-10-01 | 16 firms | began contributing to compensation fund |
| 1993-02-06 | Commission | published notice summarizing notification |
| 1994-04-29 | Commission | issued Commission Decision

### Legal Framework
Legal framework applying to the case: the operative articles ('Article 85') and the canonical concept ('anticompetitive_agreement')

### Infringement Category
horizontal

### Infringement Sub Category
structural crisis cartels; exchange of information on prices and sales

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared the agreement inapplicable under Article 85(3) for the period from 10 September 1992 to 30 September 1997, and required undertakings to refrain from divulging individual data on outputs and deliveries of bricks. It also imposed structural remedies including permanent closure of 217 million bricks worth of production capacity, prohibition against bringing on stream new capacity during the financing period, and obligations on future purchasers not to use dismantled plant to increase production capacity within a 500 km radius.

### Company Recidivism
| companies          | recidivism   |
|:-------------------|:-------------|
| Stichting Baksteen | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
NA

### Outcome
The Commission declared the agreement inapplicable under Article 85(3) for the period from 10 September 1992 to 30 September 1997, and required undertakings to refrain from divulging individual data on outputs and deliveries of bricks. It also imposed structural remedies including permanent closure of 217 million bricks worth of production capacity, prohibition against bringing on stream new capacity during the financing period, and obligations on future purchasers not to use dismantled plant to increase production capacity within a 500 km radius.


*(reported: 2026-10-16 20:45:50)*

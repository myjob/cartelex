# 'IV/31.572 and 32.571', 'Building and construction industry in the Netherlands'

**CELEX ID:** CELEX-31992D0204  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
CELEX-31992D0204

### Case Title
IV/31.572 and 32.571 – Building and construction industry in the Netherlands

### Overview
This case involved a cartel in the Dutch construction industry, where multiple organizations engaged in horizontal anticompetitive practices such as price fixing collusion, bid-rigging, and exchange of information on prices and sales. The European Commission found that these practices violated Article 85 of the EC Treaty. Fines were imposed on numerous companies involved in the cartel, with significant penalties ranging from ECU 38,250 to ECU 4,792,500. The case was landmark in the book reference IV/31571.

### Industry
residential buildings, non-residential buildings, roads, bridges, viaducts, tunnels, dams, locks, sewerage systems, parks, road marking, demolition services, water-engineering works.

### Oecd Nace
OECD sector: construction; NACE group code: 41.2; NACE class code: 41.20

### Companies Undertakings
| companies                                                                       | location       |
|:--------------------------------------------------------------------------------|:---------------|
| Vereniging van Samenwerkende Prijsregelende Organisaties in de Bouwnijverheid   | Amersfoort     |
| Samenwerkende Patroons Verenigingen in de Bouwbedrijven Noord-Holland-Noord     | Alkmaar        |
| Utrechtse Aannemers Vereniging                                                  | Utrecht        |
| Vereniging Wegenbouw Aannemers Combinatie Nederland                             | Zeist          |
| Zuid Nederlandse Aannemers Vereniging                                           | Heeze          |
| Gooise Aannemers Vereniging                                                     | Huizen         |
| 's-Gravenhaagse Aannemersvereniging                                             | 's-Gravenhage  |
| Leidse Aannemersvereniging                                                      | Leiden         |
| Vereniging Markeer Aannemers Combinatie                                         | Zeist          |
| Nederlandse Aannemers- en Patroonsbond voor de Bouwbedrijven (NAPB Dordrecht)   | Dordrecht      |
| Noordhollandse Aannemers Vereniging voor Waterbouwkundige Werken                | Amsterdam      |
| Oostnederlandse-Vereniging-Aanbestedings-Regeling                               | Ambt-Delden    |
| Provinciale Vereniging van Bouwbedrijven in Groningen en Drenthe                | Groningen      |
| Rotterdamse Aannemersvereniging                                                 | Rotterdam      |
| Aannemersvereniging 'de Rijnstreek'                                             | Rotterdam      |
| Stichting Aanbestedingsregeling van de Samenwerkende Bouwbedrijven in Friesland | Leeuwarden     |
| Samenwerkende Prijsregelende Vereniging Nijmegen en Omstreken                   | Nijmegen       |
| Amsterdamse Aannemers Vereniging                                                | Amsterdam-Zuid |
| Algemene Aannemersvereniging voor Waterbouwkundige Werken                       | Utrecht        |
| Aannemersvereniging van Boorondernemers en Buizenleggers                        | Soest          |
| Aannemersvereniging Velsen, Beverwijk en Omstreken                              | Velsen Zuid    |
| Aannemersvereniging Haarlem-Bollenstreek                                        | Heemstede      |
| Aannemersvereniging Veluwe en Zuidelijke IJsselmeerpolders                      | Apeldoorn      |
| Combinatie van Aannemers in het Noorden                                         | Leeuwarden     |
| Vereniging Centrale Prijsregeling Kabelwerken                                   | Leeuwarden     |
| Delftse Aannemers Vereniging                                                    | Rotterdam      |
| Economisch Nationaal Verbond van Aannemers van Sloopwerken                      | Utrecht        |
| Aannemersvereniging 'Gouda en Omstreken'                                        | Rotterdam      |
| Gelderse Aannemers Vereniging inzake Aanbestedingen                             | Arnhem         |
| Vereniging Nederlandse Aannemers Combinatie                                     | Leiden         |

### Market
Netherlands, oligopoly

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-12-10 | Vereniging van Samenwerkende Prijsregelende Organisaties in de Bouwnijverheid | adopted statutes |
| 1980-06-03 | SPO General Assembly | adopted the Code of Honour |
| 1986-06-02 | SPO | established Uniform Aanbestedingsreglement |
| 1986-10-09 | SPO | adopted Uniforme Prijsregelende Reglementen |
| 1987-04-01 | SPO | implemented UPR rules |
| 1988-06-23 | SPO | amended UPR rules |
| 1988-08-01 | SPO | suspended price tendering rules for subcontracting |
| 1988-11-14 | SPO | responded to formal requests for information |
| 1989-07-26 | municipality of Rotterdam | lodged complaint relating to rules and regulations |
| 1989-11-07 | Commission | decision to initiate proceedings was taken |
| 1990-06-12 | SPO | made statements at hearing regarding contract values |
| 1992-02-05 | Commission of the European Communities | Commission Decision was issued |

### Legal Framework
Article 85, anticompetitive agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; bid-rigging and tender fixing; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
Exemption sought by Vereniging van Samenwerkende Prijsregelende Organisaties in de Bouwnijverheid, Amersfoort

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Aannemersvereniging 'Gouda en Omstreken' | ECU 249 750 |
| Gelderse Aannemers Vereniging inzake Aanbestedingen | ECU 996 750 |
| Gooise Aannemers Vereniging | ECU 270 000 |
| 's-Gravenhaagse Aannemersvereniging | ECU 1 188 000 |
| Leidse Aannemersvereniging | ECU 317 250 |
| Vereniging Markeer Aannemers Combinatie | ECU 38 250 |
| Nederlandse Aannemers- en Patroonsbond voor de Bouwbedrijven (NAPB Dordrecht) | ECU 324 000 |
| Noordhollandse Aannemers Vereniging voor Waterbouwkundige Werken | ECU 238 500 |
| Oostnederlandse-Vereniging-Aanbestedings-Regeling | ECU 1 116 000 |
| Provinciale Vereniging van Bouwbedrijven in Groningen en Drenthe | ECU 474750 |
| Rotterdamse Aannemersvereniging | ECU 2 103 750 |
| Aannemersvereniging 'de Rijnstreek' | ECU 96 750 |
| Stichting Aanbestedingsregeling van de Samenwerkende Bouwbedrijven in Friesland | ECU 384 750 |
| Samenwerkende Prijsregelende Vereniging Nijmegen en Omstreken | ECU 200 250 |
| Amsterdamse Aannemers Vereniging | ECU 1 451 250 |
| Algemene Aannemersvereniging voor Waterbouwkundige Werken | ECU 436 500 |
| Aannemersvereniging van Boorondernemers en Buizenleggers | ECU 436 500 |
| Aannemersvereniging Velsen, Beverwijk en Omstreken | ECU 202 500 |
| Aannemers Vereniging Haarlem-Bollenstreek | ECU 337 500 |
| Aannemersvereniging Veluwe en Zuidelijke IJsselmeerpolders | ECU 445 500 |
| Combinatie van Aannemers in het Noorden | ECU 198 000 |
| Vereniging Centrale Prijsregeling Kabelwerken | ECU 180 000 |
| Delftse Aannemers Vereniging | ECU 162 000 |
| Economisch Nationaal Verbond van Aannemers van Sloopwerken | ECU 184 500 |
| Samenwerkende Patroons Verenigingen in de Bouwbedrijven Noord-Holland-Noord | ECU 670 500 |
| Utrechtse Aannemers Vereniging | ECU 1 055 250 |
| Vereniging Wegenbouw Aannemers Combinatie Nederland | ECU 4 792 500 |
| Zuid Nederlandse Aannemers Vereniging | ECU 3 948 750 |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                              | country   | jurisdiction   |
|:---------------------------------------------------|:----------|:---------------|
| Stichting Berechtingsinstituut Erecode Bouwbedrijf |           |                |

### Book Reference
IV/31571

### Outcome
The Commission required the SPO and its member organizations to bring the infringements to an end immediately, prohibited any actions with the same purpose or effect, and mandated that they inform member undertakings and other participants in writing of the decision and its consequences, including the right to withdraw from the rules and regulations.


*(reported: 2026-11-11 11:34:41)*

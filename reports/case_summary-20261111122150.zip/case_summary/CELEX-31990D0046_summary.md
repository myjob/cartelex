# 'IV/32.006', 'Alcatel Espace/ANT Nachrichtentechnik'

**CELEX ID:** CELEX-31990D0046  
**Industry:** satellite and space equipment manufacturing  
**Cartel Period:** 1986-02-11 : 1996-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0046 | IV/32006  |

### Case Title
Alcatel Espace/ANT Nachrichtentechnik

### Overview
The European Commission investigated an anticompetitive agreement between Alcatel Espace SA and ANT Nachrichtentechnik GmbH in the satellite and space equipment manufacturing industry. The agreement, signed on 1986-02-11 and notified on 1986-07-28, was found to involve horizontal restraints including market sharing, quota cartels, and specialization agreements. The Commission granted exemption under Article 85(3) of the EEC Treaty with conditions, but did not impose penalties or corrective measures.

### Industry
satellite and space equipment manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.3:Manufacture of communication equipment
NACE class code: 26.30: Manufacture of communication equipment

### Companies Undertakings
| companies                   |
|:----------------------------|
| Alcatel Espace SA           |
| ANT Nachrichtentechnik GmbH |

Countries:
- Alcatel Espace SA: FR
- ANT Nachrichtentechnik GmbH: DE

### Market
Geographical scope: France, Germany
Outside EU: False
Oligopoly: False
Turbulence: NA

### Cartel Period
1986-02-11 : 1990-01-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-02-11 | Alcatel Espace SA and ANT Nachrichtentechnik GmbH | signed agreement |
| 1986-07-28 | Alcatel Espace SA and ANT Nachrichtentechnik GmbH | notified agreement |
| 1990-01-12 | Commission | issued decision on agreement |
| 1996-12-31 | Commission | decision expires |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
low

### Exemption
Exemption sought: True
Applicants:
- Alcatel Espace SA
- ANT Nachrichtentechnik GmbH

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
No remedies or termination orders are specified in the document. The Decision grants exemption to the agreement under Article 85(3) of the EEC Treaty with conditions, but does not impose any penalties or corrective measures.

### Company Recidivism
| companies                                      | recidivism   |
|:-----------------------------------------------|:-------------|
| Alcatel Espace SA, ANT Nachrichtentechnik GmbH | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission granted exemption to the anticompetitive agreement under Article 85(3) of the EEC Treaty with conditions, but did not impose penalties or corrective measures.


*(reported: 2026-10-16 20:22:29)*

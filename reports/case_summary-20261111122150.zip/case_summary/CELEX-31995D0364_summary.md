# '95/364/EC', 'COMMISSION DECISION of 28 June 1995 relating to a proceeding pursuant to Article 90 (3) of the Treaty'

**CELEX ID:** CELEX-31995D0364  
**Industry:** air transport  
**Cartel Period:** NA  

## Summary

### Celex Case Id
95/364/EC

### Case Title
COMMISSION DECISION of 28 June 1995 relating to a proceeding pursuant to Article 90 (3) of the Treaty

### Overview
The European Commission investigated an abuse of dominance case involving Belgian air transport authorities and companies, finding that certain measures were incompatible with EU competition law.

### Industry
air transport

### Oecd Nace
OECD: transport; NACE: 51.10 Passenger air transport

### Companies Undertakings
| companies                                                                  |
|:---------------------------------------------------------------------------|
| British Midland                                                            |
| Belgian authorities                                                        |
| Belgian airways authority (Régie des Voies Aériennes/Regie der Luchtwegen) |
| Sabena                                                                     |
| Sobelair                                                                   |
| British Airways                                                            |
| Kingdom of Belgium                                                         |

### Market
Belgium

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-10-05 | Airways Authority | granted exclusive rights under Royal Decree |
| 1985-10-03 | Court of Justice | delivered judgment on dominant position in Telemarketing case |
| 1988-05-04 | Court | handed down judgment in Case 30/87, Bodson v. Pompes funèbres |
| 1989-04-11 | redacted | referenced in judgment concerning unfair competition in maritime transport |
| 1989-12-22 | Belgian authorities | introduced system of discounts on landing fees |
| 1989-12-22 | State | implemented Royal Decree establishing landing fee discounts for Brussels National Airport |
| 1989-12-22 | Airways Authority | implemented discount system for landing fees |
| 1989-12-22 | redacted | issued Royal Decree authorizing airport fees and establishing discount system |
| 1991-12-10 | redacted | referenced in judgment defining relevant market for port facilities |
| 1993-02-08 | British Midland | lodged complaint concerning system of discounts on landing fees at Brussels National Airport |
| 1994-05-17 | redacted | referenced in judgment concerning piloting services at the Port of Genoa |
| 1995-05-04 | Belgian State and Swissair | concluded agreement acquiring holding in Sabena |
| 1995-06-28 | Commission | adopted decision regarding the incompatible measure |

### Legal Framework
| law_article |
| --- |
| Article 86 |
| Article 90 |

### Infringement Category
abuse_of_dominance, public_undertaking

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Belgian Government shall bring to an end the infringement and inform the Commission of the measures taken within two months.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court   | country        | jurisdiction   |
|:--------|:---------------|:---------------|
| Court   | European Union | European Union |
| Court   | Belgium        | European Union |

### Book Reference
NA

### Outcome
The Commission found that the measures were incompatible with EU competition law and ordered the Belgian Government to end the infringement.


*(reported: 2026-11-10 19:22:30)*

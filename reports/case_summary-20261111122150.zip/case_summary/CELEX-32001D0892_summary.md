# 'COMP/C-1/36.915', 'Deutsche Post AG — Interception of cross-border mail'

**CELEX ID:** CELEX-32001D0892  
**Industry:** | industry           |
|:-------------------|
| Financial Services |
| Clothing/Retail    |
| Postal Services    |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
CELEX-32001D0892

### Case Title
Deutsche Post AG — Interception of cross-border mail

### Overview
The case involved allegations that Deutsche Post AG, a dominant player in the postal services market, intercepted cross-border mail, thereby violating EU competition law. The Commission investigated and found that Deutsche Post AG had engaged in discriminatory practices, leading to a decision imposing a fine and ordering cessation of the infringing behavior.

### Industry
Financial Services, Clothing/Retail, Postal Services

### Oecd Nace
public service, 53.2:Other postal and courier activities, 53.20: Other postal and courier activities

### Companies Undertakings
| company                             | country   |
|:------------------------------------|:----------|
| Deutsche Post AG                    | DE        |
| British Post Office                 | GB        |
| Ideas Direct Ltd                    | GB        |
| Fidelity Investments Services Ltd   | US        |
| Multiple Zones                      | US        |
| Gant                                | US        |
| Pyramid Sportswear AB               | SE        |
| Extensis Corporation                | US        |
| Direct Group International Ltd      | GB        |
| Fidelity Investments Management Ltd | US        |
| Fidelity Investments Services GmbH  | DE        |
| Plantijn Groep BV                   | NL        |

### Market
Germany

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council of the European Union | Council Regulation No 17 entered into force |
| 1996-09-16 | DPAG | notified BPO of interception of mailing from Gant |
| 1996-09-25 | BPO | requested DPAG to release mailing immediately |
| 1996-10-04 | DPAG | released mailing held back by DPAG |
| 1996-10-31 | Pyramid Sportswear GmbH | complained about delay and claimed reimbursement for lost advertising campaign and goodwill |
| 1996-11-04 | Ideas Direct Ltd | intercepted mailing |
| 1998-02-04 | DPAG | filed complaint against BPO |
| 1998-02-04 | BPO | lodged complaint against Deutsche Post |
| 1998-11-27 | DPAG | claimed surcharges from BPO for 19 mailings from Ideas Direct |
| 2000-05-25 | DPAG | issued Statement of Objections |
| 2000-10-17 | BPO and DPAG | reached a settlement |
| 2001-07-25 | Commission | issued Commission Decision |

### Legal Framework
Article 82, Article 86

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Deutsche Post AG | EUR 1 000 |

### Remedies
Deutsche Post AG shall immediately bring to an end the infringement referred to in Article 1 and shall refrain in the future from repeating any act or conduct described in Article 1. In addition, a fine of EUR 1 000 is imposed on Deutsche Post AG.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Deutsche Post AG | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                  | country        | jurisdiction   |
|:-----------------------|:---------------|:---------------|
| Court of Justice       | European Union | EU Law         |
| Hamburg Regional Court | Germany        | German         |
| German courts          | Germany        | German         |

### Book Reference
COMP/C-1/36.915

### Outcome
Deutsche Post AG was found to have committed an abuse of dominance by intercepting cross-border mail, resulting in a fine of EUR 1 000 and an order to cease the infringing conduct.


*(reported: 2026-11-11 12:10:07)*

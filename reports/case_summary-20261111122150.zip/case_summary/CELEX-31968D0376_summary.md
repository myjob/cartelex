# 'IV/23077', 'Rieckermann/AEG‑Elotherm'

**CELEX ID:** CELEX-31968D0376  
**Industry:** Manufacturing and distribution of inductive heating, melting, and hardening systems  
**Cartel Period:** 1953-01-01 : 1953-06-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31968D0376 | IV/23077  |

### Case Title
Rieckermann/AEG‑Elotherm

### Overview
The European Commission investigated an exclusive distribution agreement between Johs. Rieckermann Kommanditgesellschaft and AEGElotherm Gesellschaft mit beschränkter Haftung, concluded in 1953. The case involved an exemption request by Johs. Rieckermann Kommanditgesellschaft. No infringement was found, and no remedies were issued.

### Industry
Manufacturing and distribution of inductive heating, melting, and hardening systems

### Oecd Nace
OECD sector: manufacturing
NACE group code: 08.9:Mining and quarrying n.e.c.
NACE class code: 08.93: Extraction of salt

### Companies Undertakings
| companies                                         |
|:--------------------------------------------------|
| Johs. Rieckermann Kommanditgesellschaft           |
| AEGElotherm Gesellschaft mit beschränkter Haftung |

### Market
Relevant market includes Japan and Korea. The market is outside the EU.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1953-06-16 | Johs. Rieckermann Kommanditgesellschaft and AEGElotherm Gesellschaft mit beschränkter Haftung | concluded exclusive distribution agreement |
| 1968-11-06 | Commission of the European Communities | issued decision about procedure according to Article5 of the contract |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
Exemption sought by Johs. Rieckermann Kommanditgesellschaft was considered in the case.

### Leniency
NA

### Fines
NA

### Remedies
No remedies or orders were issued since the Commission determined that the exclusive distribution agreement does not restrict or distort competition within the Common Market, and thus no infringement occurred.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
NA

### Book Reference
NA

### Outcome
The Commission determined that the exclusive distribution agreement did not restrict or distort competition within the Common Market, and thus no infringement occurred.


*(reported: 2026-10-16 19:16:24)*

# 'IV/30.307', 'Fire insurance (D)'

**CELEX ID:** CELEX-31985D0075  
**Industry:** NA  
**Cartel Period:** 1981 : 1982  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31985D0075 | IV/30307-2 |

### Case Title
IV/30.307 Fire insurance (D)

### Overview
The European Commission investigated anti-competitive practices in the German fire insurance sector, specifically involving price-fixing collusion by two major insurance associations, Verband der Sachversicherer eV and Gesamtverband der Deutschen Versicherungswirtschaft eV. The associations issued recommendations on premium increases that were found to be in violation of Article 85 of the EEC Treaty.

### Industry
industrial fire insurance, consequential loss insurance

### Oecd Nace
banking and insurance (including real estate); 65.1:Insurance; 65.12: Non-life insurance

### Companies Undertakings
| company                                                |
|:-------------------------------------------------------|
| Verband der Sachversicherer eV                         |
| Gesamtverband der Deutschen Versicherungswirtschaft eV |

Countries:
- Verband der Sachversicherer eV: DE
- Gesamtverband der Deutschen Versicherungswirtschaft eV: DE

### Market
Germany; oligopolistic market; fluctuating loss ratios, cyclical volatility in premiums, economic instability due to high interest rates affecting investment income, and competitive pressures leading to anti-competitive premium recommendations.

### Cartel Period
1981 : 1982

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Council Regulation No 17 |
| 1980-02-27 | Commission officials | met with VdS representatives in Cologne |
| 1980-05-21 | VdS | wrote to Federal Supervisory Office for Insurance and Federal Cartel Office notifying them of a planned non-binding recommendation |
| 1981-01-01 | German specialized reinsurers | uniformly introduced premium calculation clause in reinsurance treaties |
| 1982-06-25 | VdS | notified new tariff to members |
| 1982-09-23 | VdS | notified recommendation on premium increases |
| 1982-09-23 | Verband der Sachversicherer eV | filed application for negative clearance or exemption |
| 1982-09-23 | VdS | notified tariff to Commission with recommendation |
| 1983-09-09 | Commission | decided to initiate proceedings |
| 1984-12-05 | Commission | adopted decision |
| 1984-12-05 | Commission | issued Commission Decision

### Legal Framework
Article 85; operative article: Article 85; canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Verband der Sachversicherer eV sought exemption, but it was not granted.

### Leniency
NA

### Fines
NA

### Remedies
The Commission refused to grant negative clearance or exemption under Articles 2 and 4 of Regulation No 17 or under Article 85(3) of the EEC Treaty for the recommendation issued by VdS, thus ordering that the anti-competitive recommendations be ceased.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Verband der Sachversicherer eV | False |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriesen

### Courts
| court                     | country                     | jurisdiction                |
|:--------------------------|:----------------------------|:----------------------------|
| European Court of Justice | Federal Republic of Germany | European Economic Community |

### Book Reference
NA

### Outcome
The Commission found the anti-competitive recommendations by the insurance associations to be in violation of EU law and ordered that they cease such practices. No exemption or negative clearance was granted.


*(reported: 2026-11-11 10:54:24)*

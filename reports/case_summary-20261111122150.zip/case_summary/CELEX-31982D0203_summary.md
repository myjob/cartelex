# 'TV/30.188', 'Moet et Chandon (London) Ltd'

**CELEX ID:** CELEX-31982D0203  
**Industry:** | industry                  |
|:--------------------------|
| Champagne/Wine Production |
| Cognac Production         |
| Cosmetics                 |  
**Cartel Period:** 1980-01-01 : 1981-10-21  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0203 | IV/30188  |

### Case Title
Moet et Chandon (London) Ltd

### Overview
The case involved a cartel in the champagne and cognac industry where companies including Moet et Chandon (London) Ltd, Moet-Hennessy, and Champagne Moet et Chandon implemented terms of sale restricting resale and introduced export bans that infringed Article 85(1) of the EC Treaty. The Commission initiated proceedings after a complaint from Central Wine Buyers (South Leicester) Ltd, and the infringement was ceased by October 21, 1981. Moet-Hennessy was fined 1,100,000 ECU and ordered to refrain from applying export bans intended to hinder exports from the UK to other Member States.

### Industry
Champagne/Wine Production, Cognac Production, Cosmetics

### Oecd Nace
manufacturing, 11.0:Manufacture of beverages, 11.02: Manufacture of wine from grape

### Companies Undertakings
| companies                                 |
|:------------------------------------------|
| Moet et Chandon (London) Ltd              |
| Moet-Hennessy                             |
| Champagne Moet et Chandon                 |
| Central Wine Buyers (South Leicester) Ltd |

| companies_investigated                    | country   |
|:------------------------------------------|:----------|
| Moet et Chandon (London) Ltd              | GB        |
| Moet-Hennessy                             | FR        |
| Champagne Moet et Chandon                 | FR        |
| Central Wine Buyers (South Leicester) Ltd | GB        |

### Market
United Kingdom, France

### Cartel Period
1980-01-01 : 1981-10-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-01-01 | MC | implemented terms of sale restricting resale to United Kingdom |
| 1980-01-01 | Moet et Chandon (London) Ltd | applied terms of sale infringing Article 85(1) |
| 1980-01-01 | Champagne Moët et Chandon and Moët-Hennessy | introduced export ban |
| 1980-01-01 | Moet-Hennessy | constituted infringement of Article 85(1) and applied export ban |
| 1980-09-15 | Central Wine Buyers (South Leicester) Ltd | submitted application to Commission |
| 1980-09-15 | Central Wine Buyers (C.W.B.) | lodged a complaint with the Commission regarding the terms of sale |
| 1981-04-13 | Commission | initiated proceedings in case |
| 1981-10-21 | Moet et Chandon (London) Ltd | ceased applying terms of sale infringing Article 85(1) |
| 1981-10-21 | Champagne Moët et Chandon and Moët-Hennessy | withdrew export ban |
| 1981-10-21 | Moet-Hennessy | ceased applying export ban intended to hinder exports from UK to other Member States |
| 1981-10-21 | Moet-Hennessy | sent a circular letter to all clients withdrawing the terms of sale |
| 1981-10-23 | Moet-Hennessy | informed the Commission in a letter that the terms of sale had been withdrawn |
| 1981-11-27 | Commission | adopted decision on infringement |
| 1981-11-27 | Commission of the European Communities | issued Decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Moet-Hennessy | 1 100 000 ECU |

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Moet-Hennessy | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court            | country        | jurisdiction                |
|:-----------------|:---------------|:----------------------------|
| Court of Justice | European Union | European Economic Community |

### Book Reference
NA

### Outcome
Commission adopted decision on infringement; Moet-Hennessy fined 1,100,000 ECU and ordered to refrain from applying export bans.


*(reported: 2026-11-11 10:38:08)*

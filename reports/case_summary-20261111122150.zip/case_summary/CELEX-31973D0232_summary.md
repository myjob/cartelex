# NA

**CELEX ID:** CELEX-31973D0232  
**Industry:** gas water-heaters and bathheaters  
**Cartel Period:** 1965-12-29 : 1970-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31973D0232 | IV/25963  |

### Case Title
NA

### Overview
The European Commission investigated an anticompetitive agreement among Belgian companies involved in the production and sale of gas water-heaters and bath-heaters. The agreement, concluded in December 1965, regulated sales on the Belgian market and was terminated in December 1970. The Commission found the agreement to be contrary to Article 85 of the Treaty and refused an exception request.

### Industry
gas water-heaters and bathheaters

### Oecd Nace
OECD sector: manufacturing
NACE group code: 27.5:Manufacture of domestic appliances
NACE class code: 27.52: Manufacture of non-electric domestic appliances

### Companies Undertakings
| companies                                                 | location   |
|:----------------------------------------------------------|:-----------|
| SPRL Le Renova                                            | Forest     |
| SA Contigea                                               | Brussels   |
| SNCR Joski et Fils                                        | Ghent      |
| SA Etablissements Guillaume Prist                         | Antwerp    |
| SAB Chaffoteaux et Maury                                  | Brussels   |
| Union des fabricants belges de chauffeau et chauffe-bains | NA         |

### Market
Belgium
market_oligopoly: True
market_outside_eu: False

### Cartel Period
1965-12-29 : 1970-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1965-12-29 | SPRL Le Renova, SA Contigea, SNCR Joski et Fils, SA Etablissements Guillaume Prist, SAB Chaffoteaux et Maury | concluded agreement regulating sale on Belgian market |
| 1965-12-29 | member undertakings | concluded Agreement regulating sale of gas water-heaters and bath-heaters |
| 1966-01-03 | redacted | submitted notification of Agreement to Commission |
| 1966-01-11 | undertakings party to the Agreement | abolished criterion regarding shop and saleroom sizes |
| 1970-12-31 | member undertakings | terminated the Agreement and dissolved the Union |
| 1970-12-31 | SPRL Le Renova, SA Contigea, SNCR Joski et Fils, SA Etablissements Guillaume Prist, SAB Chaffoteaux et Maury | agreement ended |
| 1972-03-03 | Commission | notified its objections to the Union and member undertakings |
| 1972-03-17 | Union | informed the Commission and made replies to objections while requesting additional time for examination |
| 1972-11-22 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on Agreement |
| 1973-07-03 | redacted | finalized proceedings under Article 85 of the Treaty |
| 1973-07-03 | The Commission | refused exception request for agreement

### Legal Framework
Article 85
infringement_concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific orders or remedies were issued by the Commission to terminate the infringement; the Agreement was terminated voluntarily by the member undertakings on 31 December 1970.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| SPRL Le Renova, Forest | NA |
| SA Contigea, Brussels | NA |
| SNCR Joski et Fils, Ghent | NA |
| SA Etablissements Guillaume Prist, Antwerp | NA |
| SAB Chaffoteaux et Maury, Brussels | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
François-Xavier ORTOL

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found the agreement to be contrary to Article 85 of the Treaty and refused an exception request. The cartel was terminated voluntarily by the member undertakings in December 1970.


*(reported: 2026-11-11 10:03:49)*

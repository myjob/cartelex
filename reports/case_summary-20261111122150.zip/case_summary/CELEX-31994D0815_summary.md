# 'IV/33.126 and 33.322', 'Cement'

**CELEX ID:** CELEX-31994D0815  
**Industry:** cement  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0815 | IV/33126  |

### Case Title
IV/33.126 and 33.322 – Cement

### Overview
This case involves a horizontal cartel in the cement industry, with companies from multiple EU countries engaging in anticompetitive practices including market sharing, quota cartels, price fixing collusion, and exchange of information on prices and sales. The infringement was found to be of high gravity, and fines were imposed on numerous companies involved. Leniency applicants are listed, and the case resulted in a decision by the Commission ordering an end to the infringements.

### Industry
cement

### Oecd Nace
OECD & NACE classifications: manufacturing, 23.51: Manufacture of cement

### Companies Undertakings
| companies                                |
|:-----------------------------------------|
| Cembureau                                |
| Holderbank                               |
| Blue Circle                              |
| Oficemen                                 |
| Asland                                   |
| Uniland                                  |
| Hispacement                              |
| SFIC                                     |
| Lafarge                                  |
| Ciments Français                         |
| BDZ                                      |
| Heidelberger                             |
| Dyckerhoff                               |
| CBR                                      |
| Aker                                     |
| EUROC                                    |
| Aalborg                                  |
| Irish Cement                             |
| Italcementi                              |
| Unicem                                   |
| Cementir                                 |
| FIC                                      |
| Association of the Greek Cement Industry |
| VNC                                      |
| ATIC                                     |
| BCA                                      |
| Blue Circle Industries Plc               |
| Rugby Group Plc                          |
| Castle                                   |
| Ciments Luxembourgeois                   |
| Cimpor                                   |
| SECIL                                    |
| Buzzi                                    |
| ENCI                                     |
| Heracles                                 |
| Halkis                                   |
| Titan                                    |
| Cedest                                   |
| Vicat                                    |
| Alsen                                    |
| Nordcement                               |
| Hornos Ibéricos                          |
| Valenciana                               |
| DADA                                     |
| Cementos del Mar                         |
| Cementos del Norte                       |
| Cementos Cosmos                          |

### Market
Relevant market: geography (France, Belgium-Luxembourg, Netherlands, Germany, Italy, United Kingdom, Ireland, Denmark, Greece, Portugal, Spain), structure (oligopoly), turbulence (Price differences between markets ranging from 10% to over 100%, indicating volatility and instability. Exports from countries like Greece, Spain, and Italy threatening domestic markets. Reactions by European industries to protect markets show inter-European trade tensions and competitiveness issues. Capacity adjustments, import pressures, and rising demand levels in various nations suggest economic shifts and instability. Oligopolistic structures exacerbate market dynamics through retaliatory measures and competitive concerns. The presence of 'hot spots' such as specific export routes (UK, France, Spain) signals ongoing disputes and fluctuations.)

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1950-12-20 | Belgian Government | implemented price control system for cement prices |
| 1957-01-01 | associates (Arbed, Ciments Frangais, Cedest, Wülfrather, Heidelberger and Dyckerhoff) | agreed to set up joint cement transport company 'Saarlandische SiloTransport GmbH' |
| 1981-07-01 | Lafarge Coppée S.A., Titan Cement Company S.A., Heracles General Cement Company, Halkis Cement Company S.A., Société de Ciments Frangais S.A., Blue Circle Industries Plc | participated in concerted practice |
| 1982-05-06 | Italcementi-Fabbriche Riunite Cemento S.p.A., Dyckerhoff AG, Lafarge Coppée S.A., Société de Ciment Français S.A., S.A. Cimenteries CBR | participated in concerted practice |
| 1983-01-14 | Cimbureau and its members | reached an agreement on non-transhipment to domestic markets |
| 1983-01-14 | Commission | found infringement in non-transhipping principle |
| 1984-03-19 | Cembureau and its members | confirmed the content of the agreement |
| 1986-06-09 | Commission | established agreement relating to setting-up of Interciment S.A. |
| 1986-09-09 | Head Delegates | set up Joint Trading Company and allocated shareholdings |
| 1988-05-26 | Italcementi-Fabbriche Riunite Cemento S.p.A., Dyckerhoff AG, Lafarge Coppée S.A., Société de Ciment Français S.A., S.A. Cimenteries CBR, Compañia Valenciana de Cementos Portland S.A. | ended participation in concerted practice |
| 1991-11-12 | Commission | initiated proceedings in cement cases and adopted statement of objections |
| 1994-11-30 | Commission | decision issued |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements; price fixing collusion; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

### Leniency
| company         |
|:----------------|
| Buzzi           |
| Oficemen        |
| Asland          |
| Hispacement     |
| Hornos Ibéricos |
| Uniland         |
| Valenciana      |
| Atic            |
| Cimpor          |
| Secil           |
| Holderbank      |
| Aker            |
| EUROC           |

### Fines
| company | amount |
| --- | --- |
| Halkis Cement Company S.A. | ECU 100000 |
| Heracles General Cement Company | ECU 5331000 |
| Titan Cement Company S.A. | ECU 40000 |
| Irish Cement Ltd | ECU 40000 |
| Fratelli Buzzi S.p.A. | ECU 100000 |
| Cementir-Cementerie del Tirreno S.p.A. | ECU 3841000 |
| Italcementi-Fabbriche Riunite Cemento S.p.A. | ECU 12296000 |
| Unicem S.p.A. | ECU 15652000 |
| S.A. des Ciments Luxembourgeois | ECU 1850000 |
| Vereniging Nederlandse CementIndustrie | ECU 100000 |
| Eerste Nederlandse Cement-Industrie N.V. | ECU 7196000 |
| ATIC-Associaçao Tecnica da Industria do Cimento | ECU 4008000 |
| Cimpor-Cimentos de Portugal S.A. | ECU 70000 |
| SECIL-Companhia Geral de Cal e Cimento S.A. | ECU 5337000 |
| British Cement Association | ECU 102000 |
| Blue Circle Industries Plc | ECU 1784000 |
| Castle Cement Ltd | ECU 1971000 |
| The Rugby Group Plc | ECU 1312000 |
| Cembureau-The European Cement Association | ECU 100000 |
| Holderbank Financière Glaris S.A. | ECU 5331000 |
| Aker a.s. | ECU 40000 |
| EUROC AB | ECU 40000 |
| Bundesverband der Deutschen Zementindustrie | ECU 100000 |
| Alsen-Breitenberg Zement- und Kalkwerke GmbH | ECU 3841000 |
| Dyckerhoff AG | ECU 12296000 |
| Heidelberger Zement AG | ECU 15652000 |
| Nordcement AG | ECU 1850000 |
| Fedération de I'Industrie Cimentière a.s.b.l. | ECU 100000 |
| S.A. Cimenteries CBR | ECU 7196000 |
| Aalborg Portland A/S | ECU 4008000 |
| Agrupación de Fabricantes de Cementos de España-Oficemen | ECU 70000 |
| Asland S.A. | ECU 5337000 |
| Hispacement S.A. | ECU 102000 |
| Hornos Ibéricos Alba S.A. | ECU 1784000 |
| Corporación Uniland S.A. | ECU 1971000 |
| Compañia Valenciana de Cementos Portland S.A. | ECU 1312000 |
| Syndicat Frangais de 1'Industrie Cimentière | ECU 100000 |
| Cedest S.A. | ECU 2522000 |
| Société des Ciments Frangais S.A. | ECU 24716000 |
| Lafarge Coppée S.A. | ECU 22872000 |
| Vicat S.A. | ECU 8272000 |
| Association of the Greek Cement Industry | ECU 100000 |
| Italcementi-Fabbriche Riunite Cemento S.p.A. | ECU 1088000 |
| Dyckerhoff AG | ECU 988000 |
| Lafarge Coppée S.A. | ECU 1028000 |
| Société des Ciments Frangais S.A. | ECU 1052000 |
| S.A. Cimenteries CBR | EECU 836000 |
| Compañia Valenciana de Cementos Portland S.A. | ECU 554000 |

### Remedies
NA

### Company Recidivism
| company | recidivism |
| --- | --- |
| Cembureau | True |
| Buzzi | True |
| Vicat | True |
| Lafarge | True |
| Ciments Frangais | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                   | country        | jurisdiction   |
|:------------------------|:---------------|:---------------|
| Court of Justice        | European Union | European Union |
| Court of First Instance | European Union | European Union |
| Commission              | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission ordered undertakings to forthwith bring the infringements referred to in Articles 1 to 7 to an end and henceforth refrain from any agreement or concerted practice which may have the same or similar object, including exchanges of confidential commercial information that monitors the performance of such agreements.


*(reported: 2026-11-11 11:48:48)*

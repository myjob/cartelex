# 'IV/31.043', 'Tetra Pak I (BTG licence)'

**CELEX ID:** CELEX-31988D0501  
**Industry:** NA  
**Cartel Period:** 1981 : 1988  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31988D0501 | IV/31.043  |
| CELEX-31988D0501 | IV/31043-1 |

### Case Title
Tetra Pak I (BTG licence)

### Overview
The case involved companies such as Tetra Pak Rausing SA, Elopak Group, BTG, and others, operating in the manufacturing sector producing milk cartons, aseptic milk cartons, fresh milk cartons, plastic bottles, glass bottles, plastic bags, fruit juice cartons, wine cartons, UHT milk cartons, gable-top cartons, and sterilized milk cartons. The case concerned abuse of dominance under Article 86 and anticompetitive agreements under Article 85, with a high gravity infringement. The relevant market was in the European Union, specifically Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Netherlands, Portugal, Spain, and United Kingdom, with an oligopolistic structure.

### Industry
- milk cartons
- aseptic milk cartons
- fresh milk cartons
- plastic bottles
- glass bottles
- plastic bags
- fruit juice cartons
- wine cartons
- UHT milk cartons
- gable-top cartons
- sterilized milk cartons

### Oecd Nace
manufacturing, 22.2:Manufacture of plastics products, 22.22: Manufacture of plastic packing goods

### Companies Undertakings
| companies                 | country   |
|:--------------------------|:----------|
| Tetra Pak Rausing SA      | SE        |
| Elopak Group              | SE        |
| BTG                       | GB        |
| Liquipak Group            | DE        |
| Novus Corp                | US        |
| Tetra Pak Italiana SpA    | IT        |
| Pak Center Limited        | GB        |
| Liquipak International BV | NL        |
| PLK                       | PL        |
| Allpak Group              | US        |
| Purepak                   | US        |

### Market
The relevant market was in the European Union, specifically Belgium, Denmark, France, Germany, Greece, Ireland, Italy, Netherlands, Portugal, Spain, and United Kingdom. The market structure is oligopolistic.

### Cartel Period
1981 : 1988

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-08-27 | NRDC and Novus Corp. | entered into licence agreement containing exclusivity provisions |
| 1983-09-27 | Elopak Group | filed application to Commission |
| 1986-06-23 | Elopak Group | filed application to Commission |
| 1986-06-26 | Elopak Group | filed application to Commission |
| 1986-10-03 | BTG | raised no objections to transfer of licence to Tetra |
| 1987-02-24 | Commission | initiated proceedings in case |
| 1987-03-03 | Commission | issued statement of objections |
| 1987-11-26 | Tetra | announced abandonment of exclusivity claims |
| 1988-04-22 | BTG | announced entry into negotiations for non-exclusive licences |
| 1988-07-26 | Commission | issued Commission Decision |
| 1988-07-26 | Commission | issued decision addressing Tetra Pak Rausing SA |
| 1988-08-27 | Tetra | no further exclusivity to be negotiated |

### Legal Framework
Article 86, Article 85

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought by Tetra Pak Rausing SA

### Leniency
NA

### Fines
NA

### Remedies
Tetra ceased exclusive licensing and committed to not reasserting exclusivity. BTG agreed to negotiate non-exclusive licences with both Tetra and Elopak.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Commission of the European Communities | European Union | European Union |

### Book Reference
IV/31.043, IV/31.043, Excessive pricing, discriminatory sales conditions, and prohibition to resale

### Outcome
NA


*(reported: 2026-11-11 11:12:59)*

# 'IV/31.846', 'Enichem/ICI'

**CELEX ID:** CELEX-31988D0087  
**Industry:** chemicals  
**Cartel Period:** 1986-02-12 : 1991-03-25  

## Summary

### Celex Case Id
CELEX-31988D0087

### Case Title
Enichem/ICI

### Overview
The case involves a cartel formed by Enichem SpA, Imperial Chemical Industries plc, and European Vinyls Corporation in the PVC compounds and related products market. The cartel operated from 1986 to 1991, with activities including agreements on vinyl chloride monomer and polyvinylchloride sectors. The European Commission investigated the case under Article 85 of the EEC Treaty, leading to a decision issued on December 22, 1987. An exemption was granted for five years, subject to specific remedies and reporting obligations.

### Industry
chemicals

### Oecd Nace
OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

- OECD sector: manufacturing
- NACE group code: 22.2:Manufacture of plastics products
- NACE class code: 22.21: Manufacture of plastic plates, sheets, tubes and profiles

### Companies Undertakings
| company                          |
|:---------------------------------|
| Enichem SpA                      |
| Imperial Chemical Industries plc |
| European Vinyls Corporation      |

### Market
Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

- Geography: Italy, United Kingdom, Ireland
- Outside EU: True
- Oligopoly: True
- Turbulence: NA

### Cartel Period
1986-10-01 : 1991-03-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-02-12 | Enichem SpA and Imperial Chemical Industries plc | signed agreements concerning vinyl chloride monomer and polyvinylchloride sectors |
| 1986-03-26 | Enichem and ICI | submitted application for negative clearance and notification for exemption |
| 1986-10-01 | Enichem and ICI | began operations of EVC |
| 1987-03-26 | Enichem, ICI and EVC | began reporting period for annual compliance report |
| 1987-12-22 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |
| 1988-03-25 | Enichem, ICI and EVC | ended reporting period for annual compliance report |
| 1991-03-25 | unknown | exemption period ends |

### Legal Framework
Article 85

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

| company                          |
|:---------------------------------|
| Enichem SpA                      |
| Imperial Chemical Industries plc |

### Leniency
NA

### Fines
NA

### Remedies
1. Advance notification to Commission about initiatives or scope changes affecting products; 2. Annual submission of detailed reports on rationalization plans, capacity closures, production/distribution changes, sales figures, output consumption; 3. Cease and desist from maintaining any direct or indirect interests in competing producers or distributors in the relevant sectors; 4. Structural dependency of EVC on parents (no asset transfer); 5. Temporary nature of exemption lasting five years with option for dissolution

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
IV/31.846

### Outcome
NA


*(reported: 2026-10-16 20:20:10)*

# 'IV/1.576', 'Zanussi'

**CELEX ID:** CELEX-31978D0922  
**Industry:** domestic electrical appliances  
**Cartel Period:** 1977-05-01 : 1978-10-23  

## Summary

### Celex Case Id
CELEX-31978D0922

### Case Title
Zanussi

### Overview
The case involved Industrie A. Zanussi SpA, an Italian company engaged in the manufacture of domestic electrical appliances, including refrigerators, cookers, dishwashers, washing machines, and television sets. The Commission investigated exclusive dealing practices related to guarantee terms that restricted intra-Community trade. The infringement occurred from 1962 to 1978, with the Commission ultimately declaring no cause to intervene pursuant to Article 85(1) of the EEC Treaty after Zanussi revised its guarantee scheme to comply with Community competition rules.

### Industry
domestic electrical appliances

### Oecd Nace
manufacturing, 27.5:Manufacture of domestic appliances, 27.52: Manufacture of non-electric domestic appliances

### Companies Undertakings
Industrie A. Zanussi SpA (IT)

### Market
Italy, France, Belgium, United Kingdom, Germany, Denmark, Netherlands

### Cartel Period
1962-03-13 : 1978-10-23

### Key Timeline
1962-02-06: Commission issued Council Regulation No 17
1963-01-28: Commission received notification concerning exclusive dealing agreement
1963-03-13: Zanussi implemented guarantee conditions not compliant with Article 85 (3)
1963-07-25: Commission heard undertakings concerned in accordance with Article 19 (1) of Regulation No 17
1977-01-01: IAZ Netherlands took over importation of Zanussi appliances
1977-05-25: Advisory Committee delivered opinion on restrictive practices
1977-10-11: Zanussi notified Commission of new guarantee terms
1977-12-29: Commission published summary of notification in Official Journal
1978-02-14: Commission issued decision on restrictive practices
1978-02-15: Commission declared no cause to intervene pursuant to Article 85 (1)
1978-02-15: Zanussi began providing guarantee service to purchasers in the Community
1978-10-23: Commission published Commission Decision (78/922/EEC)

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Commission declared inapplicable the prohibition contained in Article 85(1) of the EEC Treaty to the supply contracts containing the terms of guarantee formerly operated by the Zanussi Group for the period 13 March 1962 to 14 February 1978. This decision effectively allowed Zanussi to continue with its revised guarantee scheme, which eliminated restrictions on intra-Community trade and ensured compliance with Community competition rules, thus serving as a behavioral remedy.

### Company Recidivism
Industrie A. Zanussi SpA: True

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
NA

### Book Reference
IV/1576

### Outcome
The Commission declared inapplicable the prohibition contained in Article 85(1) of the EEC Treaty to the supply contracts containing the terms of guarantee formerly operated by the Zanussi Group for the period 13 March 1962 to 14 February 1978. This decision effectively allowed Zanussi to continue with its revised guarantee scheme, which eliminated restrictions on intra-Community trade and ensured compliance with Community competition rules, thus serving as a behavioral remedy.


*(reported: 2026-10-16 19:09:32)*

# 'IV/36.748', 'REIMS II'

**CELEX ID:** CELEX-31999D0695  
**Industry:** postal services  
**Cartel Period:** 1995-06-02 : 2001-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0695 | IV/36748  |

### Case Title
REIMS II

### Overview
The case involved a cartel among postal operators in the EU from 1995 to 2001, focusing on horizontal price-fixing collusion in cross-border mail services. The agreement was implemented with terminal dues reaching up to 55% of domestic dues. The Commission took no action but requested information. Exemption was sought and granted by all investigated companies.

### Industry
postal services

### Oecd Nace
public service, 53.1:Postal activities under universal service obligation, 53.10: Postal activities under universal service obligation

### Companies Undertakings
| companies                                  | location   |
|:-------------------------------------------|:-----------|
| Austrian Post                              | NA         |
| La Poste/De Post                           | NA         |
| Post Danmark                               | NA         |
| Finland Post                               | NA         |
| La Poste                                   | NA         |
| Deutsche Post                              | NA         |
| Hellenic Post ELTA                         | NA         |
| Iceland Post                               | NA         |
| An Post                                    | NA         |
| Poste Italiane                             | NA         |
| Entreprise des Postes & Télécommunications | NA         |
| Norway Post                                | NA         |
| CTT Correios de Portugal                   | NA         |
| Correos y Telégrafos                       | NA         |
| Sweden Post                                | NA         |
| The Post Office                            | NA         |

### Market
| country        |
|:---------------|
| Austria        |
| Belgium        |
| Denmark        |
| Finland        |
| France         |
| Germany        |
| Greece         |
| Iceland        |
| Ireland        |
| Italy          |
| Luxembourg     |
| Norway         |
| Portugal       |
| Spain          |
| Sweden         |
| United Kingdom |

### Cartel Period
1995-06-02 : 2001-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1995-06-02 | 14 PPOs | entered into an Agreement for the Remuneration of Mandatory Deliveries of CrossBorder Mails |
| 1995-12-13 | 16 PPOs | resigned in an amended form |
| 1997-10-31 | unknown | notified agreement to Commission |
| 1998-09-28 | unknown | notified first supplementary agreement |
| 1998-12-01 | Commission | published notice in Official Journal proposing positive view of Agreement |
| 1999-04-01 | parties | implemented agreement with terminal dues reaching maximum of 55% of domestic dues |
| 2000-02-10 | Member States | introduced appropriate accounting systems under the Postal Directive |
| 2001-01-01 | Italian PPO | increased terminal dues to final level under REIMS II Agreement |
| 2001-12-31 | parties | exemption duration expired |
| 2001-12-31 | Commission | re-examined the appropriateness of proposed final increase in terminal dues |

### Legal Framework
Article 81, Article 82, Article 86

### Infringement Category
horizontal restraints

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
medium

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
Introduce a transparent cost-accounting system; provide annual reports on tariffs, costs, and cross-border traffic flows; grant effective Level 3 access to each other; relax domestic conditions where rules bar other parties from access to domestic rates or use best efforts to remove such rules if set by the state.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
NA

### Commissioner
Karel Van Miert

### Courts
| court                   | country        | jurisdiction       |
|:------------------------|:---------------|:-------------------|
| Court of First Instance | European Union | European Community |

### Book Reference
NA

### Outcome
The Commission took no action but requested information. The case involved a cartel period from 1995 to 2001 with horizontal price-fixing collusion in cross-border mail services. Remedies included introducing transparent cost-accounting systems, annual reporting on tariffs and traffic flows, granting effective Level 3 access, and relaxing domestic conditions.


*(reported: 2026-10-16 22:21:52)*

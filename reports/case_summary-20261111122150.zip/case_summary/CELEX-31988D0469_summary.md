# 'IV/31.902', 'IVECO/FORD'

**CELEX ID:** CELEX-31988D0469  
**Industry:** NA  
**Cartel Period:** 1986-04-15 : 1995-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0469 | IV/31902  |

### Case Title
IVECO/FORD

### Overview
The European Commission investigated anticompetitive agreements between The Ford Motor Company Limited (US) and Iveco Industrial Vehicles Corporation BV (IT), along with Iveco-Ford Truck Limited (IT), concerning a joint venture for the production and sale of heavy vehicles. The cartel period lasted from 1986-04-15 to 1995-12-31.

### Industry
manufacturing

### Oecd Nace
OECD sector: manufacturing, NACE group code: 28.1:Manufacture of general-purpose machinery

### Companies Undertakings
| companies                                |
|:-----------------------------------------|
| The Ford Motor Company Limited           |
| Iveco Industrial Vehicles Corporation BV |
| Iveco-Ford Truck Limited                 |

### Market
Relevant market includes the United Kingdom and the European Community, with an outside EU presence. The market is described as oligopolistic.

### Cartel Period
1986-04-15 : 1995-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-04-15 | The Ford Motor Company Limited and Iveco Industrial Vehicles Corporation BV | entered into agreement |
| 1986-04-15 | Ford UK and Iveco | concluded Omnibus Agreement establishing joint venture for production and sale of heavy vehicles |
| 1986-06-24 | Ford Motor Company Ltd and Iveco Industrial Vehicles Corporation BV | notified joint arrangement relating to heavy vehicles |
| 1986-06-24 | redacted | exemption notified retroactively effective |
| 1988-07-20 | Peter SUTHERLAND Member of the Commission | adopted decision |
| 1992-12-31 | Ford UK | required transfer of shares in JV to Iveco |
| 1995-12-31 | redacted | expiration of no-competition clause and trademark licensing agreements |
| 1995-12-31 | redacted | exemption period ended |

### Legal Framework
Article 85 (operative article), with the canonical concept being anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
medium

### Exemption
Exemption was sought and notified retroactively effective.

### Leniency
NA

### Fines
None

### Remedies
None

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission adopted a decision in 1988, finding anticompetitive agreements in the joint venture. An exemption was notified retroactively effective, and the case concluded with the expiration of the no-competition clause and trademark licensing agreements in 1995.


*(reported: 2026-10-16 20:21:35)*

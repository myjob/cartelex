# NA

**CELEX ID:** CELEX-31975D0077  
**Industry:** preserved mushrooms  
**Cartel Period:** 1973-01-08 : 1975-01-08  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0077 | IV/27039  |

### Case Title
NA

### Overview
This case involves a cartel agreement among producers of preserved mushrooms in France and Taiwan, which was found to violate Article 85 of the Treaty on the Functioning of the European Union (TFEU). The agreement included market sharing, price fixing, and quota cartels, leading to significant fines and remedies ordered by the Commission.

### Industry
preserved mushrooms, tinned mushrooms, preserved vegetables, freeze dried products, foods for children

### Oecd Nace
agriculture; 10.3:Processing and preserving of fruit and vegetables; 10.39: Other processing and preserving of fruit and vegetables

### Companies Undertakings
| companies                                         |
|:--------------------------------------------------|
| Blanchaud SA                                      |
| Euroconserves                                     |
| Champifrance                                      |
| Faval SA                                          |
| Champex-Centre                                    |
| Taiwan Mushroom Packers United Export Corporation |

### Market
The relevant market includes France and Germany. The market is characterized as an oligopoly with significant turbulence due to imports from non-member countries, particularly China, fluctuating exchange rates, and large import volumes causing stockpiling in France.

### Cartel Period
1973-01-08 : 1975-01-08

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-01-08 | French and Taiwanese producers | concluded agreement on market sharing and price fixing |
| 1973-05-01 | MFMP and TMPUEC | adjusted selling prices upward by 3% |
| 1974-04-29 | Commission of the European Communities | initiated proceedings under Regulation No 17 |
| 1974-06-10 | Commission | sent statement of objections to relevant French undertakings and TMPUEC |
| 1974-08-08 | Commission | issued Regulation No 2107/74 addressing market disturbances |
| 1975-01-08 | redacted | terminated the agreement of 8 January 1973 |
| 1975-01-08 | redacted | document published or finalized |

### Legal Framework
Article 85; Article 86

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Blanchaud SA | 32 000 units of account, that is 177 734 French francs |
| Euroconserves | 32 000 units of account, that is 177 734 French francs |
| Champifrance | 26 000 units of account, that is 144 408 French francs |
| Faval SA | 2 000 units of account, that is 11 108 French francs |
| Champex-Centre | 8 000 units of account, that is 44 433 French francs |

### Remedies
The undertakings referred to in Article I shall terminate the agreement of 8 January 1973.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
François-Xavier Ortoli

### Courts
False

### Book Reference
NA

### Outcome
The Commission found the agreement to be in violation of EU competition law, imposed fines on the involved companies, and ordered the termination of the cartel agreement.


*(reported: 2026-11-11 10:08:27)*

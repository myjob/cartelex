# 'IV/337', 'Supexie'

**CELEX ID:** CELEX-31971D0022  
**Industry:** fertilizers  
**Cartel Period:** 1969-04-15 : 1970-12-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31971D0022 | IV/337    |

### Case Title
Supexie

### Overview
The European Commission investigated Supexie and several other companies for involvement in an export cartel in the fertilizer industry. The cartel operated from 1962 to 1970, with key amendments and meetings recorded in the timeline.

### Industry
fertilizers

### Oecd Nace
OECD sector: agriculture
NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms
NACE class code: 20.15: Manufacture of fertilisers and nitrogen compounds

### Companies Undertakings
| companies                      |
|:-------------------------------|
| Supexie, Paris                 |
| Péchiney Saint-Gobain, Paris   |
| Ugine-Kuhlmann, Paris          |
| West Fertilizer Company, Paris |
| Linet Establishments, Paris    |

### Market
non-EEC countries
market outside EU: true

### Cartel Period
1962-03-13 : 1970-02-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-30 | participating companies | notified agreement |
| 1969-04-15 | Supexie members | held extraordinary general meeting to waive provisions |
| 1969-04-15 | participating companies | amended agreement |
| 1970-02-12 | Supexie members | held extraordinary general meeting to alter corporate purpose and export mandates |
| 1970-02-12 | participating companies | amended agreement |
| 1970-12-23 | Commission | issued decision concerning the agreement |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False
Exemption applicants: Supexie

### Leniency
False
Leniency granted: NA

### Fines
NA

### Remedies
The Commission ordered Supexie to amend its mandate and restrict sales activities exclusively to countries outside the Common Market through behavioral commitments made on 15 April 1969 and 12 February 1970.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Franco M. MALFATTI

### Courts
NA

### Book Reference
IV/337
Case is in book: IV/337
Case is landmark in book: False
Infringement type in book: Export cartels

### Outcome
The Commission issued a decision concerning the agreement, ordering Supexie to amend its mandate and restrict sales activities exclusively to countries outside the Common Market.


*(reported: 2026-10-16 18:59:51)*

# 'IV/34.073, IV/34.395 and IV/35.436', 'Van den Bergh Foods Limited'

**CELEX ID:** CELEX-31998D0531  
**Industry:** | industry                |
|:------------------------|
| Ice cream manufacturing |
| Dairy products          |
| Confectionery           |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31998D0531 | IV/34.395 |

### Case Title
Van den Bergh Foods Limited

### Overview
The European Commission investigated Van den Bergh Foods Limited, Masterfoods Limited, and Valley Ice Cream (Ireland) Limited for alleged abuse of dominance and anticompetitive agreements under Articles 85 and 86 of the EC Treaty. The case involved vertical restraints, specifically Exclusive Dealing / Market Foreclosure.

### Industry
Ice cream manufacturing, Dairy products, Confectionery

### Oecd Nace
manufacturing, 10.5:Manufacture of dairy products, 10.52: Manufacture of ice cream

### Companies Undertakings
| companies                          |
|:-----------------------------------|
| Van den Bergh Foods Limited        |
| Masterfoods Limited                |
| Valley Ice Cream (Ireland) Limited |

### Market
Ireland, oligopoly market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-07-29 | European Commission | initiated proceedings in case IV/34.073, IV/34.395 and IV/35.436 |
| 1993-07-29 | Commission | provisionally concluded that HB infringed Articles 85 and 86 |
| 1994-11-29 | HB | presented paper entitled 'Sales of cabinets in situ' to the Commission |
| 1995-03-08 | HB | notified proposals to the Commission |
| 1995-03-09 | Van den Bergh Foods Ltd | lodged application for negative clearance/exemption |
| 1995-08-15 | Commission | published decision refusing exemption application |
| 1995-08-15 | Commission | announced intention to take a favourable view towards HB’s distribution arrangements |
| 1997-01-22 | Commission | sent a new Statement of Objections to HB |
| 1997-04-24 | HB | submitted written response to the new Statement of Objections |
| 1997-06-11 | HB | put forward arguments at an oral hearing |
| 1998-03-11 | Van den Bergh Foods Limited | entered into freezer-cabinet agreements with retailers subject to exclusivity conditions |
| 1998-03-11 | European Commission | issued decision finding infringement of Article 85(1) and Article 86 of the EC Treaty

### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |

Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Exemption was sought but refused.

### Leniency
NA

### Fines
NA

### Remedies
Van den Bergh Foods Limited is required immediately to cease the infringements set out in Articles 1 and 3 of this Decision, and to refrain from taking any measure having the same object or effect. Furthermore, Van den Bergh Foods Limited is required, within three months of notification of this Decision, to inform retailers with whom it currently has freezer-cabinet agreements constituting infringements of Article 85(1) of the EC Treaty as described in Articles 1 and 3, and to notify them that the exclusivity provisions in question are void. Additionally, Van den Bergh Foods Limited is required to inform those parties that its inducement to enter into the agreements constitutes an abuse of its dominant position contrary to Article 86.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Van den Bergh Foods Limited | True |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                        | country   | jurisdiction   |
|:---------------------------------------------|:----------|:---------------|
| Irish High Court                             | Ireland   | national       |
| Irish Supreme Court                          | Ireland   | national       |
| Court of Justice of the European Communities | Belgium   | European Union |

### Book Reference
IV/34.395, landmark case in IV/34.073 and IV/34.395; infringement type: Bundling and tying

### Outcome
The European Commission found infringement of Articles 85(1) and 86 of the EC Treaty. Van den Bergh Foods Limited was ordered to cease the infringements, inform retailers about the voidness of exclusivity provisions, and acknowledge that its actions constituted an abuse of dominant position.


*(reported: 2026-11-10 19:31:38)*

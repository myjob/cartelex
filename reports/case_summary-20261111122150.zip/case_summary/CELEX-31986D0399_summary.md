# 'IV/31.371', 'Roofing felt'

**CELEX ID:** CELEX-31986D0399  
**Industry:** NA  
**Cartel Period:** 1978-01-01 : 1984-04-09  

## Summary

### Celex Case Id
CELEX-31986D0399

### Case Title
Roofing felt

### Overview
This case involved a cartel of roofing felt manufacturers in Belgium that operated from 1978 to 1984. The cartel engaged in price fixing collusion, market sharing, and other anticompetitive practices. The European Commission investigated the cartel and imposed significant fines on the participating companies.

### Industry
NA

### Oecd Nace
manufacturing, 20.3:Manufacture of paints, varnishes and similar coatings, printing ink and mastics, 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
| company                                    |
|:-------------------------------------------|
| Compagnie Générale des Asphaltes SA        |
| Antwerps Teer- en Asphaltbedrijf NV        |
| De Boer & Co NV                            |
| Kempisch Asphaltbedrijf NV                 |
| Limburgse Asfaltfabrieken PvBA             |
| Lummerzheim & Co NV                        |
| Vlaams Asfaltbedrijf Huyghe & Co PvBA      |
| Société Coopérative des Asphalteurs Belges |
| International Roofing Company SA           |
| Al-Asfalt NV                               |

### Market
Belgium, oligopoly market

### Cartel Period
1978-01-01 : 1984-04-09

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-01-01 | Belasco members and undertakings | agreement came into effect |
| 1978-05-15 | members, UPM, IR | coordinated reduction of discounts |
| 1978-10-30 | IR, UPM, AA | concluded agreement limiting and coordinating discounts |
| 1984-04-09 | Commission | conducted first on-the-spot investigation into cartel operations |
| 1984-04-09 | Commission | investigated Belasco's offices |
| 1985-06-14 | Commission | initiated proceedings in case |
| 1986-07-10 | redacted | issued Commission Decision |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements; agreements on standards; marketing and advertising agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Antwerps Teer- en Asfaltbedrijf NV | 420 000 ECU |
| Compagnie Genérale des Asphaltes SA | 150 000 ECU |
| Lummerzheim & Co NV | 200 000 ECU |
| Limburgse Asfaltfabrieken PvbA | 30 000 ECU |
| Kempisch Asphaltbedrijf NV | 75 000 ECU |
| De Boer & Co NV | 75 000 ECU |
| Vlaams Asfaltbedrijf Huyghe & Co PvbA | 50 000 ECU |
| Société Coopérative des Asphalteurs Belges | 15 000 ECU |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
| court               | country        | jurisdiction               |
|:--------------------|:---------------|:---------------------------|
| Court               | European Union | Case 8/72 Cementbandelaren |
| European Commission | European Union | EEC                        |

### Book Reference
IV/31.371

### Outcome
Cease the infringements forthwith and refrain from entering into any agreement or engaging in any concerted practice or measure likely to have a similar effect.


*(reported: 2026-11-11 11:02:23)*

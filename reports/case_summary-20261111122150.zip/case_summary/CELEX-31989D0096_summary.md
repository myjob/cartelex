# 'IV/0.093, EMO', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31989D0096  
**Industry:** metal-working machine tools  
**Cartel Period:** 1989-01-01 : 2003-12-31  

## Summary

### Celex Case Id
CELEX-31989D0096

### Case Title
IV/0.093, EMO

### Overview
This case involves a proceeding under Article 85 of the EEC Treaty concerning anticompetitive agreements related to machine tool exhibitions (EMOs). The European Commission took action against companies involved in organizing these exhibitions, which were found to restrict competition. The cartel period spans from December 20, 1988, to December 31, 2003. The infringement was categorized as horizontal restraints related to licensing with a high degree of gravity. Exemptions were sought and granted by the Commission for certain companies involved in the EMOs.

### Industry
metal-working machine tools

### Oecd Nace
manufacturing, 28.4:Manufacture of metal forming machinery and machine tools, 28.49: Manufacture of other machine tools

### Companies Undertakings
| companies                                                                                 | location   |
|:------------------------------------------------------------------------------------------|:-----------|
| European Committee for Cooperation of Machine Tool Industries (Cecimo)                    | NA         |
| Fachverband der Maschinen- und Stahlbauindustrie Osterreichs                              | NA         |
| Syndicat des Constructeurs Belges de Machines-Outils pour le Travail des Métaux (Sycomom) | NA         |
| Verein Schweizerischer Maschinen-Industrieller (VSM)                                      | NA         |
| Verein Deutscher Werkzeugmaschinenfabriken eV (VDW)                                       | NA         |
| Foreningen af Danske Vaerktojsmaskinfabrikanter                                           | NA         |
| Asociación Española de Fabricantes de Máquinas-Herramientas                               | NA         |
| Syndicat de la machine-outil, de l'assemblage et de la production associée (Symap)        | NA         |
| The Machine Tool Trades Association (MTTA)                                                | NA         |
| Unione Costruttori Italiani Macchine Utensili (Ucimu)                                     | NA         |
| Mekaniske Verksteders Landsforening                                                       | NA         |
| Vereniging voor de Metaal- en de Elektrotechnische Industrie (FME)                        | NA         |
| Centro de Cooperaçāo dos Industriais de Máquinas-Ferramientas (Cimaf)                     | NA         |
| Föreningen Svenska Verktygmaskintillverkare                                               | NA         |

### Market
| country        |
|:---------------|
| Austria        |
| Belgium        |
| Switzerland    |
| Germany        |
| Denmark        |
| Spain          |
| France         |
| United Kingdom |
| Italy          |
| Netherlands    |
| Portugal       |
| Sweden         |

market_outside_eu: True

### Cartel Period
1988-12-20 : 2003-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-09-20 | Cecimo | submitted notification concerning decisions to organize machine tool exhibitions EMOs |
| 1986-04-16 | Cecimo's Secretary-General | submitted application for renewal of Commission Decision |
| 1986-04-16 | Cecimo | applied for renewal of exemption |
| 1988-12-20 | Commission of the European Communities | adopted Commission Decision relating to a proceeding under Article 85 |
| 1988-12-31 | redacted | submitted application for renewal of Decision 79/37/EEC |
| 1989-01-01 | redacted | entered into force |
| 2003-12-31 | redacted | expired |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal restraints

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders issued by the Commission to terminate infringements are mentioned in the provided context.

### Company Recidivism
| companies   | recidivism   |
|:------------|:-------------|
| Cecimo      | False        |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                   | country   | jurisdiction                                                   |
|:------------------------|:----------|:---------------------------------------------------------------|
| court of first instance |           | place where the EMO's administrative headquarters are situated |

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 22:08:44)*

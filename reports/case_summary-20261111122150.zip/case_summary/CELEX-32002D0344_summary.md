# '2002/344/EC', 'lack of exhaustive and independent scrutiny of the scales of charges and technical conditions applied by La Poste to mail preparation firms for access to its reserved services'

**CELEX ID:** CELEX-32002D0344  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32002D0344 | IV/37133  |

### Case Title
2002/344/EC – lack of exhaustive and independent scrutiny of the scales of charges and technical conditions applied by La Poste to mail preparation firms for access to its reserved services

### Overview
The European Commission investigated La Poste, a public postal undertaking in France, for alleged abuse of dominance in the provision of mail preparation services. The case centered on the lack of exhaustive and independent scrutiny of the scales of charges and technical conditions applied by La Poste to mail preparation firms for access to its reserved services.

### Industry
Mail preparation services, desktop publishing services, laser printing services, parcelling services, franking services, sorting services, management of orders, storage services, enveloping services, making up of parcels, direct mail services, business correspondence production, computerised data handling.

### Oecd Nace
OECD sector: public service; NACE group code: 53.2: Other postal and courier activities; NACE class code: 53.20: Other postal and courier activities

### Companies Undertakings
| companies                                                            |
|:---------------------------------------------------------------------|
| La Poste                                                             |
| Syndicat national des entreprises de logistique de publicité directe |
| Datapost                                                             |
| Mikros                                                               |
| Dynapost                                                             |

### Market
France

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-07-09 | Government | enacted law establishing La Poste as public institution |
| 1990-12-29 | La Poste | approved service obligations under decree |
| 1991-01-01 | La Poste | established as autonomous entity |
| 1991-12-13 | Court | ruled on conflict of interest in competition law, determining that such a conflict constitutes an abuse |
| 1993-12-01 | Minister for Economic Affairs and Finance | assumed responsibility for framing government policy in postal and telecommunications sectors |
| 1998-02-25 | complainant | lodged complaint with French Competition Board against La Poste |
| 1998-06-30 | Syndicat national des entreprises de logistique de publicité directe | lodged complaint against the French State concerning La Poste’s mail preparation activities |
| 1998-09-25 | Commission | sent copy of complaint to French authorities |
| 1998-10-26 | Commission | sent copy of complaint to La Poste |
| 1998-12-18 | French authorities | responded to complaint |
| 1999-10-27 | European Commission | pointed out conflict of interest in monitoring function and policy direction |
| 2000-02-04 | French authorities | submitted comments disputing points in the letter of formal notice and described minister's role in supervising La Poste |
| 2000-02-16 | La Poste | replied to Commission’s questions and attached a consultant study on relations with mail preparation firms |
| 2001-07-17 | French authorities | sent draft decree to Commission for information |

### Legal Framework
Law articles: Article 82, Article 86; Canonical concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance, member_states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
France shall inform the Commission, within two months of being notified of this Decision, of the measures it has taken to put an end to the infringements identified in Article 1.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                                  | country   | jurisdiction               |
|:---------------------------------------|:----------|:---------------------------|
| Court of Justice of the European Union | France    | EU Law and Competition Law |

### Book Reference
NA

### Outcome
The Commission found that La Poste, as a public undertaking, engaged in an abuse of dominance by failing to provide exhaustive and independent scrutiny of charges and technical conditions applied to mail preparation firms. The case was decided under Articles 82 and 86 of the EC Treaty, with remedies requiring France to inform the Commission of measures taken to end the infringements.


*(reported: 2026-11-11 12:11:41)*

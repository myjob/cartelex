# 'IV/28.851', 'General Motors Continental'

**CELEX ID:** CELEX-31975D0075  
**Industry:** automotive  
**Cartel Period:** 1972-09-01 : 1974-03-15  

## Summary

### Celex Case Id
CELEX-31975D0075

### Case Title
General Motors Continental

### Overview
General Motors Continental NV was investigated by the European Commission for abuse of dominance under Article 86. The company was found to have engaged in excessive pricing and discriminatory sales conditions, particularly regarding inspection practices and charges for certificates of conformity and typeshields. The infringement occurred between 1972-09-01 and 1974-03-15. A fine of 5,000,000 Belgian francs (equivalent to 100,000 units of account) was imposed to terminate the infringement.

### Industry
automotive

### Oecd Nace
manufacturing (NACE 29.10)

### Companies Undertakings
General Motors Continental NV

### Market
Belgium

### Cartel Period
1972-09-01 : 1974-03-15

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-09-01 | GMC | received applications for inspecting parallel imports of GMC vehicles |
| 1973-03-15 | GMC | began charging higher inspection fees and applied unfair prices for Opel vehicles |
| 1973-07-31 | GMC | continued infringement of Article 86 regarding inspection practices |
| 1973-08-01 | GMC | implemented new inspection charge scale distinguishing between American and European vehicles |
| 1974-03-15 | GMC | began charging excessive prices for certificates of conformity and typeshields |
| 1974-07-26 | Commission | took proceedings against General Motors Continental NV |
| 1974-12-19 | General Motors Continental NV | was issued a decision by the Commission |

### Legal Framework
Article 86, abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| General Motors Continental NV | 5000000 Belgian francs |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
François-Xavier Ortoli

### Courts
NA

### Book Reference
IV/28.851

### Outcome
A fine of 100,000 units of account (equivalent to 5,000,000 Belgian francs) was imposed on General Motors Continental NV to terminate the infringement.


*(reported: 2026-11-11 10:07:54)*

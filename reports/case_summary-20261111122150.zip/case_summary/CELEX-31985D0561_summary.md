# 'IV/30.017', "Breeders' rights: roses"

**CELEX ID:** CELEX-31985D0561  
**Industry:** ornamental flowers  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0561 | IV/30017  |

### Case Title
IV/30.017 – Breeders’ rights: roses

### Overview
This case concerns anticompetitive agreements in the ornamental flowers industry, specifically involving licensing practices related to rose breeding rights. The European Commission found that certain provisions of licensing agreements were infringements of Article 85(1) of the EEC Treaty and refused an application for exemption under Article 85(3).

### Industry
ornamental flowers

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.2: Growing of perennial crops
NACE class code: 01.29: Growing of other perennial crops

### Companies Undertakings
| companies                         |
|:----------------------------------|
| SNC Meilland & Cie                |
| Universal Plant Sarl              |
| Universal Rose Selection-France   |
| Universal Rose Selection-Meilland |

### Market
Relevant market includes France, Germany, Netherlands, United States, Israel, Hungary, Morocco, Sweden, Denmark, Italy, Switzerland, Japan, and Latin America. The market is oligopolistic and outside the EU.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-09-30 | Richardier | concluded exclusive licensing agreement with Meilland for commercial exploitation of Selection Meilland varieties |
| 1968-09-30 | URS-Meilland and URS-F (Richardier) | signed basic licensing agreement containing clause on mutations |
| 1971-10-28 | Universal Rose Selection-France (Mr Francisque Richardier) and you | signed licensing agreement No 1442-2 |
| 1971-10-28 | Meilland | concluded agreement with Mr. Royon obliging him to surrender mutations discovered |
| 1971-10-28 | URS-F Richardier | concluded cut flower sub-licensing agreement with Mr R. Royon |
| 1972-10-30 | URS-Meilland | amended clause on mutations in basic licensing agreement |
| 1973-12-10 | Mr. Royon | signed application for plant breeders' certificate |
| 1974-04-10 | Meilland | sent letter to Mr. Royon referencing his rights over mutation Pitica |
| 1980-01-31 | Mr. Royon | lodged complaint with the Commission |
| 1983-12-09 | Commission | opened procedure in response to Mr. Royon's complaint |
| 1985-04-27 | Meilland | notified amended cut flower standard form agreement |
| 1985-12-13 | Commission | refused application for exemption under EEC Treaty |

### Legal Framework
Legal framework: Article 85 (operative) and Article 85 (all relevant)
Canonical concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
| company |
| --- |
| SNC Meilland & Cie |
| Universal Plant Sarl |

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared certain provisions of the licensing agreement as infringements of Article 85(1) of the EEC Treaty, refused an application for exemption under Article 85(3), and implied that the infringing practices must cease.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
The Commission need not take action as the Articles are hereby declared inapplicable.

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
The case involved the European Commission, which opened a procedure in response to a complaint and ultimately made a decision refusing an exemption application. No court rulings beyond the Commission's decision are mentioned.

### Book Reference
NA

### Outcome
The Commission declared certain provisions of the licensing agreement as infringements of Article 85(1) of the EEC Treaty, refused an application for exemption under Article 85(3), and implied that the infringing practices must cease.


*(reported: 2026-11-11 10:58:57)*

# 'IV/B-2/34.179', 'Stichting Certificatie Kraanverhuurbedrijf and the Federatie van Nederlandse Kraanverhuurbedrijven'

**CELEX ID:** CELEX-31994D0272  
**Industry:** crane-hire business  
**Cartel Period:** 1991-01-01 : 1993-11-04  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31994D0272 | IV/34179-1 |

### Case Title
Stichting Certificatie Kraanverhuurbedrijf and the Federatie van Nederlandse Kraanverhuurbedrijven

### Overview
This case involved a cartel in the crane-hire business in the Netherlands, Belgium, and Germany. The cartel was found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty, specifically involving horizontal restraints such as market sharing, quota cartels, and specialization agreements. The infringement occurred between 1991 and 1993.

### Industry
crane-hire business

### Oecd Nace
OECD sector: construction
NACE group code: 77.3:Renting and leasing of other machinery, equipment and tangible goods
NACE class code: 77.32: Renting and leasing of construction and civil engineering machinery and equipment

### Companies Undertakings
| companies                                       |
|:------------------------------------------------|
| Stichting Certificatie Kraanverhuurbedrijf      |
| Federatie van Nederlandse Kraanverhuurbedrijven |

### Market
The relevant market was oligopolistic in the Netherlands, Belgium, and Germany.

### Cartel Period
1991-01-01 : 1993-11-04

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-01-01 | SCK bodies | implemented hiring ban on non-affiliated crane firms |
| 1992-01-13 | M. W. C. M. van Marwijk and 10 other firms | submitted complaint |
| 1992-02-06 | Federatie van Nederlandse Kraanverhuurbedrijven | notified statutes and internal rules |
| 1992-07-09 | Amsterdam Court of Appeal | issued judgment |
| 1992-07-09 | Amsterdam Court of Appeal | overturned previous judgment in interlocutory proceedings |
| 1993-07-06 | President of the Utrecht District Court | ruled to suspend the ban on hire of cranes from non-affiliated firms |
| 1993-07-12 | FNK and SCK | proposed amendment to the ban on hiring extra cranes |
| 1993-08-02 | Commission | proposed amendment to Article 7 |
| 1993-10-28 | Amsterdam Court of Appeal | rejected appeal |
| 1994-04-13 | Commission | issued decision |
| 1994-04-13 | Commission | issued decision withdrawing immunity from fines |
| 1994-11-04 | FNK and SCK | distributed statement withdrawing inhuurverbod |

### Legal Framework
Article 85 (operative article), with the canonical concept of anticompetitive_agreement.

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
| company |
| --- |
| Stichting Certificatie Kraanverhuurbedrijf |
| Federatie van Nederlandse Kraanverhuurbedrijven |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders issued by the Commission to terminate the infringement; the decision involved withdrawing immunity from fines rather than prescribing specific structural or behavioral changes.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country            | jurisdiction   |
|:--------------------------|:-------------------|:---------------|
| Utrecht District Court    | Netherlands        | Netherlands    |
| Amsterdam Court of Appeal | Netherlands        | Netherlands    |
| District Court            | Netherlands        | Netherlands    |
| COMMISSION                | European Community | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision in 1994 withdrawing immunity from fines, but did not issue specific remedies or orders to terminate the infringement.


*(reported: 2026-11-11 11:43:58)*

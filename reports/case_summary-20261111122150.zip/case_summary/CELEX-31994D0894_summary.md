# 'IV/32.490', 'Eurotunnel'

**CELEX ID:** CELEX-31994D0894  
**Industry:** railway  
**Cartel Period:** 1987-07-29 : 2019-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0894 | IV/32490  |

### Case Title
Eurotunnel

### Overview
The case involves anticompetitive agreements and abuse of dominance by railway undertakings in the context of international rail transport, particularly concerning the Channel Tunnel. The European Commission investigated the conduct of British Railways Board, Société nationale des chemins de fer français, Channel Tunnel Group Limited, and France Manche SA.

### Industry
railway

### Oecd Nace
OECD sector: transport
NACE group code: 49.1: Passenger rail transport, interurban
NACE class code: 49.10: Passenger rail transport, interurban

### Companies Undertakings
| companies                                     | country   |
|:----------------------------------------------|:----------|
| British Railways Board                        | GB        |
| Société nationale des chemins de fer français | FR        |
| Channel Tunnel Group Limited                  | GB        |
| France Manche SA                              | FR        |

### Market
Relevant market includes the United Kingdom and France, with an oligopolistic structure. There is no indication of market turbulence.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-07-29 | British Railways Board and Société nationale des chemins de fer français | concluded contract |
| 1987-07-29 | CTG, FM, BR, and SNCF | concluded usage contract |
| 1987-07-29 | BR, SNCF and Eurotunnel | entered into usage contract |
| 1987-11-02 | Channel Tunnel Group Limited and France Manche SA | notified contract |
| 1991-11-15 | European Commission | decided not to express serious doubts, thereby exempting the contract |
| 1991-11-16 | unknown | exemption commenced |
| 1994-12-13 | unknown | decision adopted and addressed to relevant parties |
| 1995-01-01 | unknown | annual reporting obligations commence |
| 2006-12-31 | unknown | conditions apply until end of period |

### Legal Framework
Legal framework: Article 85, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption was sought and granted for the contract between Channel Tunnel Group Limited and France Manche SA.

### Leniency
No leniency applications were made or granted in this case.

### Fines
NA

### Remedies
BR and SNCF must not withhold their agreement to the sale by the managers of the infrastructure to other railway undertakings of the hourly paths necessary to operate international passenger and freight services; BR and SNCF must reserve 75% of the hourly capacity in each direction for international trains up to 31 December 2006, while others have at least 25%; annual reporting to the Commission of numbers of hourly paths used and applications not met; re-evaluation of capacity allocations before 31 December 2006.

### Company Recidivism
| companies                                                                                                         | recidivism   |
|:------------------------------------------------------------------------------------------------------------------|:-------------|
| Channel Tunnel Group Ltd, France Manche SA, British Railways Board, Société nationale des chemins de fer français | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
Courts were involved in the case, although specific rulings are not detailed in the provided facts.

### Book Reference
NA

### Outcome
The European Commission decided not to express serious doubts about the contract, thereby exempting it. Remedies were imposed to ensure fair access to infrastructure capacity and reporting obligations.


*(reported: 2026-10-16 20:28:27)*

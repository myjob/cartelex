# 'IV/79s', 'Kali und Salz/Kali Chemie'

**CELEX ID:** CELEX-31974D0017  
**Industry:** NA  
**Cartel Period:** 1970 : 1971  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31974D0017 | IV/795    |

### Case Title
IV/79s – Kali und Salz/Kali Chemie

### Overview
The European Commission found that Kali und Salz AG and Kali Chemie AG engaged in an anticompetitive agreement under Article 85 of the EEC Treaty, specifically involving exclusive dealing that foreclosed markets. The infringement occurred between 1970 and 1971.

### Industry
Straight potash fertilizer, compound fertilizer, magnesium kainite, non-granulated potash, RHE-KA-PHOS-fertilizer

### Oecd Nace
OECD sector: mining; NACE group code: 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; NACE class code: 20.15: Manufacture of fertilisers and nitrogen compounds

### Companies Undertakings
| companies        |
|:-----------------|
| Kali und Salz AG |
| Kali Chemie AG   |

### Market
Germany, Belgium, Luxembourg, Denmark, Netherlands, Italy; oligopoly market; outside EU: false

### Cartel Period
1970 : 1971

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-07-06 | Kali und Salz AG and Kali Chemic AG | concluded agreement infringing Article 85(1) |
| 1971-01-01 | Kali und Salz and Kali Chemie | implemented the agreement |
| 1972-11-17 | Commission | instituted proceedings under Article 3 of Regulation No 17 |
| 1973-05-08 | redacted | agreement notified to Commission |
| 1973-11-21 | Advisory Committee on Restrictive Practices and Monopolies | delivered opinion in accordance with Article 10 of Regulation No 17 |
| 1973-12-21 | European Commission | issued decision refusing exemption and ordering end of infringement |
| 1973-12-21 | Commission | issued Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85 (operative); Article 85 (all relevant)

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
True

| company |
| --- |
| Kali und Salz AG |
| Kali Chemie AG |

### Leniency
False

### Fines
NA

### Remedies
The undertakings named in Article I are required to bring the stated infringement to an end.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
François-Xavier Ortoli

### Courts
NA

### Book Reference
IV/795

### Outcome
The European Commission refused exemption and ordered an end to the infringement, concluding that the agreement was anticompetitive under Article 85 of the EEC Treaty.


*(reported: 2026-11-11 10:05:08)*

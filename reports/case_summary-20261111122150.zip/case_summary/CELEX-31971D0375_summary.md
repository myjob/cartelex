# 'IV/26909', 'S.I.A.E.'

**CELEX ID:** CELEX-31971D0375  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31971D0375 | IV/26909  |

### Case Title
S.I.A.E.

### Overview
The European Commission investigated S.I.A.E. for cartel behavior, leading to a decision and information requests.

### Industry
NA

### Oecd Nace
OECD: communication
NACE group code: 59.1
NACE class code: 59.11

### Companies Undertakings
Società Italiana degli Autori ed Editori (S.I.A.E.)
Country: IT

### Market
Italy

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-06-02 | Commission | issued decision against GEMA |
| 1971-06-10 | European Commission | sent information request to S.I.A.E. |
| 1971-08-05 | European Commission | sent reminder to S.I.A.E. regarding incomplete response |
| 1971-11-09 | redacted | issued decision |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Società Italiana degli Autori ed Editori (S.I.A.E.) is obliged to provide information within three weeks of the announcement of this decision, including the full wording of all regulations of the S.I.A.E. that govern its relationship with authors and publishers, membership application forms, contracts between authors/publishers and S.I.A.E., and contracts between S.I.A.E. and R.A.I. and record manufacturers.

### Company Recidivism
S.I.A.E.: NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                         | country    | jurisdiction   |
|:------------------------------|:-----------|:---------------|
| Court of European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The case resulted in a decision by the European Commission, with S.I.A.E. required to provide information within three weeks.


*(reported: 2026-11-11 09:54:17)*

# 'IV/30.517', 'Amersham Buchler'

**CELEX ID:** CELEX-31982D0742  
**Industry:** | industry                                     |
|:---------------------------------------------|
| Radiochemical industry                       |
| Radiation protection equipment manufacturing |
| Irradiation device manufacturing             |  
**Cartel Period:** 1971-10-13 : 1982-10-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0742 | IV/30517  |

### Case Title
Amersham Buchler

### Overview
This case involved a joint venture in the radiochemical industry, where companies Amersham International Ltd, The Radiochemical Centre GmbH, Buchler GmbH, Amersham Buchler GmbH, and Amersham Buchler GmbH & Co. KG were investigated for anticompetitive agreements under Article 85 of the EC Treaty.

### Industry
Radiochemical industry
Radiation protection equipment manufacturing
Irradiation device manufacturing

### Oecd Nace
manufacturing
21.1:Manufacture of basic pharmaceutical products
21.10: Manufacture of basic pharmaceutical products

### Companies Undertakings
| companies                      |
|:-------------------------------|
| Amersham International Ltd     |
| The Radiochemical Centre GmbH  |
| Buchler GmbH                   |
| Amersham Buchler GmbH          |
| Amersham Buchler GmbH & Co. KG |

### Market
United Kingdom
Germany

### Cartel Period
1971-08-16 : 1981-12-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-08-16 | Amersham International Ltd | signed initial company contract with Buchler |
| 1971-10-13 | Amersham International Ltd | entered into contract with Buchler & Co. |
| 1971-12-20 | Amersham International Ltd | amended company contract with Buchler |
| 1972-12-18 | Amersham International Ltd | superseded company contract with Buchler |
| 1972-12-18 | Amersham Buchler GmbH | signed company contract |
| 1974-11-29 | Amersham International Ltd | signed new company contract superseding previous agreement |
| 1974-11-29 | Amersham Buchler GmbH & Co. KG | signed company contract |
| 1978-12-20 | Amersham International Ltd | entered into new contract with TRC Ltd, TRC GmbH, Buchler & Co. KG |
| 1978-12-20 | The Radiochemical Centre Ltd, The Radiochemical Centre GmbH, Buchler & Co. KG and Amersham Buchler GmbH & Co. KG | concluded agreement concerning know-how and expertise |
| 1978-12-20 | Radiochemical Centre Ltd and Amersham Buchler GmbH & Co. KG | signed exclusive distributorship agreement |
| 1981-12-21 | Amersham International Ltd | notified agreements to Commission for negative clearance or exemption |
| 1982-10-29 | Commission | issued decision addressed to undertakings |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
| company                    |
|:---------------------------|
| Amersham International Ltd |
| Buchler GmbH               |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued to terminate the infringement. The Commission granted an exemption under Article 85(3) for a period of 15 years with reporting obligations.

### Company Recidivism
| companies                                | recidivism   |
|:-----------------------------------------|:-------------|
| Amersham International Ltd, Buchler GmbH | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) for a period of 15 years with reporting obligations, without issuing specific remedies or orders to terminate the infringement.


*(reported: 2026-10-16 20:00:27)*

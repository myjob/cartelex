# 'IV/93', 'European Machine Tool Exhibitions'

**CELEX ID:** CELEX-31969D0090  
**Industry:** | industry              |
|:----------------------|
| Machine tool industry |
| Metalworking industry |
| Tool industry         |  
**Cartel Period:** 1969-03-13 : 1978-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31969D0090 | IV/93-1   |

### Case Title
IV/93 – European Machine Tool Exhibitions

### Overview
This case concerns cartel behavior in the machine tool industry, specifically related to the European Machine Tool Exhibitions. The European Economic Community issued Regulation No.17, and a decision was made regarding the infringement.

### Industry
Machine tool industry, Metalworking industry, Tool industry

### Oecd Nace
manufacturing
NACE group code: 28.4: Manufacture of metal forming machinery and machine tools
NACE class code: 28.49: Manufacture of other machine tools

### Companies Undertakings
| companies                                                                                | location   |
|:-----------------------------------------------------------------------------------------|:-----------|
| European Committee for the Cooperation of the Machine Tool Industries                    | NA         |
| Association of German Machine Tool Manufacturers                                         | NA         |
| Professional Association of the Machine, Steel and Iron Construction Industry of Austria | NA         |
| Belgian Union of Machine Tool Builders for Metalworking                                  | NA         |
| Association of Danish Machine Tool Manufacturers                                         | NA         |
| French Union of Machine Tool Builders                                                    | NA         |
| The Machine Tool Trades Association (Metalworking Machine Tool Manufacturers' Section)   | NA         |
| Italian Union of Machine Tool Builders                                                   | NA         |
| Association of Metal Industries (Tool Group)                                             | NA         |
| Swedish Association of Machine Tool Manufacturers                                        | NA         |
| Swiss Association of Machine Industry                                                    | NA         |
| Spanish Association of Machine Tool Manufacturers                                        | NA         |
| Center for Cooperation of Tool-Machine Industries                                        | NA         |

### Market
Germany, Austria, Belgium, Denmark, France, United Kingdom, Italy, Netherlands, Sweden, Switzerland, Spain, Portugal
Market outside EU: True

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1950-07-13 | EKZW | founded |
| 1962-02-06 | European Economic Community | issued Regulation No.17 |
| 1962-03-13 | redacted | decision became effective |
| 1962-09-20 | Mr. F. Wolff Cammaerts | submitted application for negative test certificate |
| 1968-11-14 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion pursuant to Article10 of Regulation No.17 |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
No specific remedies or orders are mentioned in the document.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
False

### Book Reference
NA

### Outcome
The European Commission took no action and issued a decision, but did not impose fines or remedies.


*(reported: 2026-10-16 22:07:56)*

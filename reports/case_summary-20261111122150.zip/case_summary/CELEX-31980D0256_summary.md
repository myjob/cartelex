# 'IV/29.595', 'Pioneer Hi-Fi Equipment'

**CELEX ID:** CELEX-31980D0256  
**Industry:** | industry                   |
|:---------------------------|
| hi-fi equipment            |
| audio market               |
| retail                     |
| household electrical goods |  
**Cartel Period:** 1966 : 1976-02-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0256 | IV/29595  |

### Case Title
Pioneer Hi-Fi Equipment

### Overview
The case involved a horizontal cartel in the hi-fi equipment market, where companies including Pioneer and Melchers engaged in exclusive distribution agreements and coordinated actions to prevent parallel imports. The European Commission found these practices to be anticompetitive under Article 85 of the EC Treaty, resulting in significant fines and orders to cease such practices.

### Industry
hi-fi equipment, audio market, retail, household electrical goods

### Oecd Nace
manufacturing, 26.4:Manufacture of consumer electronics, 26.40: Manufacture of consumer electronics

### Companies Undertakings
| company                        |
|:-------------------------------|
| Musique Diffusion Française    |
| Pioneer Electronic Europe NV   |
| C. Melchers & Co.              |
| Pioneer High Fidelity (GB) Ltd |

### Market
France, United Kingdom, Germany; oligopolistic market structure

### Cartel Period
1966 : 1976-02-18

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1966-01-01 | Pioneer | entered into exclusive distribution agreement with Melchers |
| 1966-12-19 | Melchers | notified exclusive dealing agreement with Pioneer |
| 1976-01-19 | Pioneer | organized meeting discussing prevention of parallel imports |
| 1976-01-19 | Mr. Setton | complained about deliveries from the United Kingdom and Germany to France |
| 1976-01-19 | Mr Setton | made representations to discourage UK customers from exporting goods |
| 1976-01-19 | Todd | tried to prevent major customers from exporting to France |
| 1976-01-20 | Pioneer | organized meeting discussing prevention of parallel imports |
| 1976-01-20 | Mr. Setton | stated bluntly that he was absolutely opposed to parallel imports |
| 1976-01-20 | Mr Setton | made representations to discourage UK customers from exporting goods |
| 1976-01-20 | Melchers | discussed parallel imports with European sole distributors |
| 1978-07-19 | Pioneer | initiated proceedings under Article 9 (3) |
| 1979-12-14 | Commission | issued Commission Decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
export cartels

### Infringement Gravity
high

### Exemption
C. Melchers & Co. applied for exemption

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Musique Diffusion Frangaise | 850 000 European units of account |
| Pioneer Electronic Europe NV | 4 350 000 European units of account |
| C. Melchers & Co. | 1 450 000 European units of account |
| Pioneer High Fidelity (GB) Ltd | 300 000 European units of account |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond Vouel

### Courts
| court                     | country        | jurisdiction   |
|:--------------------------|:---------------|:---------------|
| European Court of Justice | European Union | European Union |

### Book Reference
NA

### Outcome
Commission Decision issued on 1979-12-14 by Commissioner Raymond Vouel; companies ordered to end concerted practices that compartmentalize national markets in the EEC.


*(reported: 2026-11-11 10:31:15)*

# 'IV/AF 379', 'AM & S Europe Ltd, Bristol'

**CELEX ID:** CELEX-31979D0670  
**Industry:** zinc  
**Cartel Period:** 1964-07-09 : 1979-07-09  

## Summary

### Celex Case Id
CELEX-31979D0670

### Case Title
AM & S Europe Ltd, Bristol

### Overview
This case involved a cartel of zinc producers operating in the European Union from 1964 to 1978. The European Commission investigated anticompetitive agreements, specifically price fixing collusion, under Article 85 of the EC Treaty. The investigation included multiple companies from various EU countries, including AM & S Europe Ltd, Metallgesellschaft AG, and Preussag AG. The case resulted in a Commission decision ordering investigations and remedies.

### Industry
zinc

- Zinc metal
- Zinc concentrates

### Oecd Nace
OECD sector: mining

NACE group code: 07.2:Mining of non-ferrous metal ores

NACE class code: 07.29: Mining of other non-ferrous metal ores

### Companies Undertakings
| companies | country |
|:----------|:--------|
| AM & S Europe Ltd | GB |
| Société Générale des Minerais SA | FR |
| Compagnie Royale Asturienne des Mines SA | ES |
| Société des Mines et Fonderies de Zinc de la Vieille Montagne SA | FR |
| Société Minière et Métallurgique de Penarroya SA | ES |
| Metallgesellschaft AG | DE |
| Preussag AG | DE |
| Billiton International Metals BV | NL |
| Adena Metal SA | FR |

### Market
Market outside EU: true

Market oligopoly: True

### Cartel Period
1964-07-09 : 1978-02-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-21 | European Communities | published Council Regulation No 17 |
| 1964-07-09 | zinc producers | held first meeting to fix prices and control production |
| 1971-07-01 | Mr Gordon Holloway | sent letter to Metallgesellschaft AG |
| 1971-07-09 | Herr F. von Dallwitz | responded to Mr Holloway's letter |
| 1978-02-10 | Commission | ordered investigations into undertakings under Article 14 of Regulation No 17 |
| 1979-02-20 | AM & S Europe Ltd | underwent investigation at premises |
| 1979-02-21 | Commission officials | inspected business records during investigation |
| 1979-03-26 | AM & S Europe Ltd | submitted letter to Commission regarding legal privilege claims |
| 1979-03-26 | AM & S Europe Ltd | sent photocopies of business records in response to written request |
| 1979-04-05 | Mr G. D. Child | filed statutory declaration concerning deleted passages in documents |
| 1979-04-05 | Mr. G. D. Child, solicitor | sent statutory declaration describing deletions in documents |
| 1979-07-06 | Commission | issued Decision |

### Legal Framework
Article 85

anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
AM & S Europe Ltd is required to submit to an investigation at its premises and produce business records as instructed by Commission officials during the investigation.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
| court | country | jurisdiction |
|:------|:--------|:-----------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
Commission issued a decision following investigations into undertakings under Article 14 of Regulation No 17, requiring AM & S Europe Ltd to submit to an investigation at its premises and produce business records as instructed by Commission officials during the investigation.


*(reported: 2026-10-16 19:00:47)*

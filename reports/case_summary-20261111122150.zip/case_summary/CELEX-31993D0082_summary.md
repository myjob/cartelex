# 'IV/32.448 and IV/32.450', 'Cewal, Cowac and Ukwal'

**CELEX ID:** CELEX-31993D0082  
**Industry:** maritime shipping  
**Cartel Period:** 1985 : 1990  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31993D0082 | IV/32450-2 |

### Case Title
IV/32.448 and IV/32.450 – Cewal, Cowac and Ukwal

### Overview
This case involves a cartel in the maritime shipping industry, specifically focusing on horizontal restraints and abuse of dominance. The cartel operated between 1985 and 1990, involving companies from multiple countries including CI, BE, NL, DE, CD, and SE. The infringement was found to contravene Articles 85 and 86 of the EC Treaty.

### Industry
maritime shipping

### Oecd Nace
OECD sector: transport
NACE group code: 50.2: Sea and coastal freight water transport
NACE class code: 50.20: Sea and coastal freight water transport

### Companies Undertakings
| company                               |
|:--------------------------------------|
| Cewal                                 |
| Cowac                                 |
| Ukwal                                 |
| Compagnie maritime belge              |
| Dafra Line                            |
| Nedlloyd Lijnen BV                    |
| Deutsche Afrika Linien-Woermann Linie |
| Angonave                              |
| Portline                              |
| Compagnie maritime zairoise (CMZ)     |
| Scandinavian West Africa Lines (SWAL) |

### Market
Geographical market includes Zaire, Angola, Mauritania, Togo, Benin, Gabon, Congo, Niger, France, United Kingdom, Germany, Netherlands
Market is outside the EU
Market is oligopolistic
Market turbulence: NA

### Cartel Period
1985 : 1990

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-01-13 | Bank of Zaire | issued circular No. 139(IV) authorizing foreign currency issuance to shippers using exclusively Cewal conference services |
| 1985-07-03 | CMEAOC | agreed to establish a system of cargo reservation |
| 1985-09-04 | Ogefrem | replied to CMB regarding the cargo reservation system |
| 1987-07-10 | Danish Shipowners' Association | filed complaint pursuant to Article 10 of Regulation (EEC) No 4056/86 |
| 1987-07-20 | Danish Government | filed complaint in support of Danish Shipowners' Association pursuant to Article 10 of Regulation (EEC) No 4056/86 |
| 1987-09-07 | Aiwasi | filed complaint referring to restrictive practices in shipping trade with West Africa pursuant to Article 10 of Regulation (EEC) No 4056/86 |
| 1988-08-25 | Cewal | concluded a cooperation agreement with Ogefrem |
| 1988-08-25 | Compagnie Maritime Zairoise | required to appear clause 'Embarquement par navire Cewal' on foreign exchange documents |
| 1989-05-18 | Fighting Committee | discussed fighting actions and container rates |
| 1990-04-01 | CMB group | included Woermann Linie |
| 1992-04-01 | member shipping companies | found to contravene Article 85 and infringe Article 86, imposed fine totaling ECU 15.3 million |
| 1992-12-23 | redacted | decision adopted |

### Legal Framework
Operative articles: Article 85, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Compagnie maritime belge | 9600000 |
| Dafra Line | 200000 |
| Nedlloyd Lijnen BV | 100000 |
| Deutsche Afrika Linien-Woermann Linie | 200000 |

### Remedies
Require the shipping companies concerned to bring to an end the infringements referred to in Article 2; refrain in future from any agreement or concerted practice which may have the same or similar object or effect as the agreements and practices referred to in Article 1; recommend that members of Cewal amend the terms of their loyalty contracts so that they conform with Article 5(2) of Regulation (EEC) No 4056/86; require undertakings or associations of undertakings concerned to bring such infringements to an end pursuant to Article 11(1) of Regulation (EEC) No 4056/86; monitor compliance with the conditions to ensure effective competition is restored and reserve right to withdraw the benefit of the block exemption if conditions are not met.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Cewal | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
| court            | country        | jurisdiction                           |
|:-----------------|:---------------|:---------------------------------------|
| Court of Justice | European Union | Court of Justice of the European Union |

### Book Reference
NA

### Outcome
The Commission found that member shipping companies contravened Article 85 and infringed Article 86, imposing a total fine of ECU 15.3 million. Remedies were imposed to end the infringement and ensure effective competition is restored.


*(reported: 2026-11-11 11:39:18)*

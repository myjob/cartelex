# 'IV/24.470', 'PirelliS.p.A.—SocietàItalianaDunlopS.p.A.'

**CELEX ID:** CELEX-31969D0477  
**Industry:** | industry             |
|:---------------------|
| Tire Manufacturing   |
| Rubber Manufacturing |  
**Cartel Period:** 1959-02-27 : 1969-12-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31969D0477 | IV/24470  |

### Case Title
Pirelli S.p.A.—Società Italiana Dunlop S.p.A.

### Overview
The European Commission investigated cartel activities in the tire manufacturing industry involving Pirelli S.p.A., S.A. des Pneumatiques Dunlop, S.A. Pirelli France, and Societa Italiana Dunlop, S.p.A. The investigation covered a period from 1959 to 1969. No infringement of Article 85(1) of the EEC Treaty was found, and no specific remedies or orders were issued.

### Industry
Tire Manufacturing
Rubber Manufacturing

### Oecd Nace
OECD_sector: manufacturing
NACE_group_code: 22.1:Manufacture of rubber products
NACE_class_code: 22.11: Manufacture of rubber tyres and tubes; retreading and rebuilding of rubber tyres

### Companies Undertakings
| companies                       | location   |
|:--------------------------------|:-----------|
| Pirelli S.p.A.                  | Milan      |
| S.A. des Pneumatiques Dunlop    | Paris      |
| S.A. Pirelli France             | Paris      |
| Societa Italiana Dunlop, S.p.A. | Milan      |

### Market
Geographical: Italy, France
Oligopoly: False
Turbulence: NA

### Cartel Period
1959-02-27 : 1969-05-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-02-27 | S.A. Pneumatiques Dunlop | concluded agreement with S.A. Pirelli France |
| 1959-11-09 | S.p.A. Pirelli | concluded agreement with S.p.A. Societa Italiana Dunlop |
| 1962-02-06 | Commission of the European Communities | issued Regulation No.17 |
| 1962-03-13 | redacted | regulation entered into force |
| 1962-10-30 | redacted | agreements notified |
| 1965-09-06 | redacted | agreements last amended and Commission decision not to intervene |
| 1969-02-12 | redacted | sent letter requesting negative certificate for Pirelli and PirelliFrance |
| 1969-02-14 | redacted | sent letter requesting negative certificate for Dunlop and DunlopItaliana |
| 1969-05-30 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion |
| 1969-12-05 | redacted | issued decision under Article 85 of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
Exemption sought or granted: True
Applicants:
| company                             |
|:------------------------------------|
| S.p.A. Pirelli, Milan               |
| S.A. des Pneumatiques Dunlop, Paris |

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
No specific remedies or orders were issued because the Commission found no infringement of Article 85(1) of the EEC Treaty.

### Company Recidivism
| companies                                                                | recidivism   |
|:-------------------------------------------------------------------------|:-------------|
| Pirelli, DunlopItaliana, Société des Pneumatiques Dunlop, Pirelli France | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Jean Rey

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 19:17:35)*

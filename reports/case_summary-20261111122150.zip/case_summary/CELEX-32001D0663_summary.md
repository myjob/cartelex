# 'COMP/34.950', 'Eco-Emballages'

**CELEX ID:** CELEX-32001D0663  
**Industry:** | industry         |
|:-----------------|
| Steel            |
| Aluminium        |
| Paper/paperboard |
| Plastic          |
| Glass            |  
**Cartel Period:** 1992-01-01 : 2004-12-31  

## Summary

### Celex Case Id
CELEX-32001D0663

### Case Title
COMP/34.950 – Eco-Emballages

### Overview
This case involved Eco-Emballages and several other companies in France, which were found to have engaged in anticompetitive agreements and abuse of dominance under Article 81 of the EC Treaty. The infringement concerned vertical restraints related to Exclusive Dealing/Market Foreclosure. The Commission took no action initially but later issued a decision requiring behavioral remedies to be implemented.

### Industry
Steel, Aluminium, Paper/paperboard, Plastic, Glass

### Oecd Nace
manufacturing (NACE: 24.10)

### Companies Undertakings
| company                                              |
|:-----------------------------------------------------|
| Eco-Emballages SA                                    |
| Pro Europe SPRL                                      |
| Adelphe SA                                           |
| Sollac SA                                            |
| France Aluminium Recyclage SA                        |
| Revipac                                              |
| Valorplast SA                                        |
| Chambre syndicale des verreries mécaniques de France |
| Compagnie pour le financement d'Eco-Emballages       |
| E. Leclerc                                           |
| Cyclamed                                             |
| Der Grüne Punkt-Duales System Deutschland AG         |

### Market
France

### Cartel Period
2000-01-18 : 2004-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-04-01 | redacted | adopted packaging waste decree |
| 1993-01-01 | Eco-Emballages | began operations under the agreement for managing packaging waste |
| 1993-12-17 | Eco-Emballages | submitted application and notification |
| 1994-07-08 | Eco-Emballages | concluded long-term programme contract |
| 1996-07-01 | Eco-Emballages | renewed approval for managing packaging waste |
| 1996-12-10 | Eco-Emballages | granted exclusive principal licence to use the Green Dot mark |
| 1998-12-04 | Eco-Emballages | concluded contract with Pro Europe |
| 1998-12-04 | Eco-Emballages | granted sublicences to regional systems dealing with specific materials |
| 2000-01-18 | Commission departments | informed Eco-Emballages of their view |
| 2000-02-28 | Eco-Emballages | offered to amend clauses and provided additional undertakings |
| 2000-06-21 | Eco-Emballages | new version of producer contract in force |
| 2001-06-15 | Commission of the European Communities | issued decision |

### Legal Framework
Article 81, Article 82, Article 86

### Infringement Category
anticompetitive_agreement, abuse_of_dominance, public_undertaking

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
NA

### Exemption
Exemption sought by Eco-Emballages

### Leniency
NA

### Fines
NA

### Remedies
The Commission issued behavioral remedies requiring Eco-Emballages to amend its contracts and practices. These include: (1) allowing producers to terminate contracts annually with six months' notice; (2) permitting producers and local authorities to enter into contracts for specific materials only; (3) granting sublicences to competing systems for the use of the Green Dot mark under the same territorial and material scope as its principal licence; (4) preventing either party in contracts with Adelphe from demanding the other’s list of members, while still allowing confirmation of membership status within one week; (5) clarifying interest on arrears for late payment of contributions, applicable from 31 December 1993 or from the date activity began if later; and (6) ensuring that Eco-Emballages does not receive amounts from producers beyond consideration for taking over their obligations under the Decree.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court      | country            | jurisdiction        |
|:-----------|:-------------------|:--------------------|
| COMMISSION | European Community | European Commission |

### Book Reference
NA

### Outcome
The Commission issued behavioral remedies requiring Eco-Emballages to amend its contracts and practices.


*(reported: 2026-10-16 22:13:27)*

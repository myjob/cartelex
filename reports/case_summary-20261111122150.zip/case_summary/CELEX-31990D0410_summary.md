# 'IV/32.009', 'Elopak/Metal Box— Odin'

**CELEX ID:** CELEX-31990D0410  
**Industry:** | industry          |
|:------------------|
| Packaging         |
| Central Heating   |
| Security Printing |  
**Cartel Period:** 1986-04-23 : 1990-07-13  

## Summary

### Celex Case Id
CELEX-31990D0410

### Case Title
Elopak/Metal Box— Odin

### Overview
The case involves Elopak A/S, Elopak Ltd, Metal Box plc, Odin Developments Ltd, CMB Packaging SA, CMB Packaging (UK) Ltd, and Odin Development Ltd. These companies were investigated for anticompetitive agreements under Article 85 of the EEC Treaty, specifically in relation to a joint venture. The cartel period was from 1986-04-23 to 1990-07-13. The Commission adopted a decision on the agreements establishing Odin Development Ltd and issued a Commission Decision relating to the proceeding under Article 85 of the EEC Treaty. No fines were imposed, and no remedies were ordered. The case was decided without any court involvement, and there was no leniency application. Exemption was sought by Elopak A/S, Elopak Ltd, and Metal Box plc.

### Industry
Packaging, Central Heating, Security Printing

### Oecd Nace
manufacturing, 10.8:Manufacture of other food products, 10.83: Processing of tea and coffee

### Companies Undertakings
| company                |
|:-----------------------|
| Elopak A/S             |
| Elopak Ltd             |
| Metal Box plc          |
| Odin Developments Ltd  |
| CMB Packaging SA       |
| CMB Packaging (UK) Ltd |
| Odin Development Ltd   |

### Market
United Kingdom, True, True

### Cartel Period
1986-04-23 : 1990-07-13

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-04-23 | Elopak and Metal Box | made agreements to establish joint venture company Odin |
| 1986-08-01 | Elopak, Elopak Ltd, Metal Box plc, and Odin Developments Ltd | submitted notification and application for negative clearance |
| 1990-07-13 | Commission | adopted decision on agreements establishing Odin Development Ltd |
| 1990-07-13 | Commission | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
joint venture

### Infringement Gravity
NA

### Exemption
| company       |
|:--------------|
| Elopak A/S    |
| Elopak Ltd    |
| Metal Box plc |

### Leniency
NA

### Fines
| name                   |
|:-----------------------|
| Odin Development Ltd   |
| Elopak A/S             |
| CMB Packaging SA       |
| CMB Packaging (UK) Ltd |
| Elopak Ltd             |

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 20:22:45)*

# '95/489/EC', 'concerning the conditions imposed on the second operator of GSM radiotelephony services in Italy'

**CELEX ID:** CELEX-31995D0489  
**Industry:** | industry                                        |
|:------------------------------------------------|
| voice telephony services                        |
| mobile radio telephony services                 |
| public telecommunications network operation     |
| cellular digital mobile radiotelephony services |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
NA

### Case Title
95/489/EC—concerning the conditions imposed on the second operator of GSM radiotelephony services in Italy

### Overview
The European Commission investigated the conditions imposed by the Italian government on the second operator of GSM radiotelephony services. The Commission expressed regret over the conditions and ultimately issued a decision to ensure equal treatment for operators.

### Industry
voice telephony services, mobile radio telephony services, public telecommunications network operation, cellular digital mobile radiotelephony services

### Oecd Nace
OECD sector: communication, NACE group code: 61.2:Wireless telecommunications activities, NACE class code: 61.20: Wireless telecommunications activities

### Companies Undertakings
| company                                     |
|:--------------------------------------------|
| Telecom Italia SpA                          |
| Omnitel Pronto Italia                       |
| STET                                        |
| IRI                                         |
| Società Italiana per l'Esercizio Telefonico |
| Telecom Italia Mobile                       |
| The Italian Republic                        |

### Market
Italy, oligopolistic market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-12-16 | Italian Government | published notice for second GSM concession |
| 1994-04-01 | European Commission | expressed regret over conditions imposed in the GSM tender |
| 1994-12-02 | Commission | licensed second GSM operator |
| 1995-01-03 | Commission | gave formal notice to the Italian government to annul the second operator's obligation to make an initial payment |
| 1995-02-28 | Italian authorities | replied to the Commission's formal notice |
| 1995-05-17 | Italian authorities | submitted further comments on the Commission's arguments |
| 1995-08-10 | Italian authorities | responded to the Commission's request for views |
| 1995-10-04 | Commission of the European Communities | issued decision concerning conditions for second GSM operator in Italy |
| 1995-10-04 | Commission | adopted decision on infringement |
| 1996-01-01 | Italy | took steps to eliminate distortion of competition |

### Legal Framework
Article 86, Article 90

### Infringement Category
abuse_of_dominance, public_undertaking

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Italian Government must either require Telecom Italia Mobile to make an identical payment (Lit 750 billion) or adopt corrective measures equivalent in economic terms to the payment made by Omnitel Pronto Italia, ensuring equal conditions for operators of GSM radiotelephony on the Italian market at the latest by 1 January 1996.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | Italy     | European Union |

### Book Reference
NA

### Outcome
The Commission took action to ensure equal treatment for operators in the GSM radiotelephony market, resulting in a decision that required corrective measures from the Italian government.


*(reported: 2026-11-10 19:23:27)*

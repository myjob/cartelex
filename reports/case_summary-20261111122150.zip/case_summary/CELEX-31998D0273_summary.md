# 'IV/35.733', 'VW'

**CELEX ID:** CELEX-31998D0273  
**Industry:** | industry                     |
|:-----------------------------|
| motor vehicle manufacturing  |
| vehicle parts and components |
| industrial motors            |
| financial services           |
| insurance operations         |  
**Cartel Period:** 1987-12-30 : 1994-06-13  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31998D0273 | IV/35733  |

### Case Title
IV/35.733 – VW

### Overview
The European Commission investigated Volkswagen AG, Audi AG, Autogerma SpA, and UCAV for anticompetitive agreements under Article 85 of the EC Treaty. The infringement involved vertical restraints related to territorial exclusivity and parallel trade bans in the motor vehicle manufacturing industry.

### Industry
motor vehicle manufacturing, vehicle parts and components, industrial motors, financial services, insurance operations

### Oecd Nace
manufacturing, 29.1:Manufacture of motor vehicles, 29.10: Manufacture of motor vehicles

### Companies Undertakings
| company       | country   |
|:--------------|:----------|
| Volkswagen AG | DE        |
| Audi AG       | DE        |
| Autogerma SpA | IT        |
| UCAV          | DE        |

### Market
Italy, Germany, Austria; oligopoly market

### Cartel Period
1987-12-30 : 1994-06-13

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-12-30 | Autogerma | signed dealership contract |
| 1987-12-30 | Autogerma | established infringement with certainty |
| 1987-12-31 | Volkswagen | introduced bonus scheme |
| 1993-08-30 | Volkswagen/Audi | discussed price harmonization |
| 1993-12-20 | Autogerma S.p.A. and Volkswagen AG | exercised influence by means of dealer audits, cautions, targeted allocation, bonus discounts, and terminations of contract |
| 1994-06-13 | Autogerma | terminated dealership contracts of dealers who sold vehicles for export |
| 1994-11-02 | Volkswagen AG | amended contracts with Italian dealers to abolish bonus payments based on sales within or outside the contract territory |
| 1995-02-24 | European Commission | sent letter to VW regarding infringement of competition rules |
| 1995-10-17 | Commission | ordered investigations under Article 14(3) of Regulation No 17 |
| 1995-10-23 | redacted | investigations carried out on premises of undertakings |
| 1996-10-24 | Commission | opened a proceeding in this case |
| 1998-01-28 | redacted | issued decision relating to proceeding under Article 85 of the EC Treaty

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
| company |
| --- |
| Volkswagen |
| Audi |
| Autogerma |

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Volkswagen AG | ECU 102 million |

### Remedies
Volkswagen AG must amend dealership contracts to stop linking bonus payments to territory of sale; inform dealers by circular that margin schemes introduced in 1994 have been abolished; inform dealers that restrictions on cross-deliveries to other Member States are removed; notify all authorised dealers in the European Community that such cross-deliveries are allowed and not penalized; instruct Audi AG and Autogerma SpA to send designated circulars to their respective dealers to implement these measures.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Volkswagen | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The European Commission found Volkswagen AG, Audi AG, Autogerma SpA, and UCAV guilty of anticompetitive agreements under Article 85. A fine of ECU 102 million was imposed on Volkswagen AG, and remedies were ordered to end the infringement.


*(reported: 2026-11-11 11:56:37)*

# 'IV/26844', 'Wild—Leitz'

**CELEX ID:** CELEX-31972D0128  
**Industry:** optical microscopes  
**Cartel Period:** 1970-07-15 : 1972-02-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0128 | IV/26844  |

### Case Title
Wild—Leitz

### Overview
The European Commission investigated two French companies, S.aR.L. Wild Paris and S.A.E. Leitz‑France, for involvement in a cartel related to the manufacture and sale of optical microscopes. The cartel period lasted from 1970-10-01 to 1972-02-23. The Commission concluded that the companies had infringed Article 85 of the EEC Treaty by concluding an agreement on technical cooperation and joint sales promotion.

### Industry
optical microscopes

### Oecd Nace
manufacturing
NACE group code: 26.7
NACE class code: 26.70

### Companies Undertakings
| companies           |
|:--------------------|
| S.aR.L. Wild Paris  |
| S.A.E. Leitz‑France |

### Market
France

### Cartel Period
1970-10-01 : 1972-02-23

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-07-15 | S.aR.L. Wild Paris and S.A. E. Leitz-France | concluded agreement on technical cooperation and joint sales promotion |
| 1970-10-01 | S.aR.L. Wild Paris and S.A. E. Leitz-France | agreement entered into force |
| 1971-10-09 | Commission of the European Communities | published essential content of application in Official Journal |
| 1972-02-23 | Commission of the European Communities | issued decision in procedure under Article85 of EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No remedies or orders were issued by the Commission.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the companies had infringed Article 85 of the EEC Treaty, but took no further action beyond issuing a decision.


*(reported: 2026-10-16 19:26:10)*

# 'IV/312-366', 'COBELPA/VNP'

**CELEX ID:** CELEX-31977D0592  
**Industry:** paper and printing  
**Cartel Period:** 1973 : 1976  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31977D0592 | IV/312    |

### Case Title
COBELPA/VNP

### Overview
This case involves a cartel among paper manufacturers in Belgium and the Netherlands, found to have engaged in anticompetitive practices under Article 85 of the EEC Treaty. The cartel operated from 1973 to 1976, focusing on price fixing collusion and exchange of information on prices and sales.

### Industry
paper and printing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 17.2:Manufacture of articles of paper and paperboard
NACE class code: 17.23: Manufacture of paper stationery

### Companies Undertakings
| companies                                                           | location   |
|:--------------------------------------------------------------------|:-----------|
| Association des Fabricants de Pates, Papiers et Cartons de Belgique | NA         |
| Vereeniging van Nederlandsche Papierfabrikanten                     | NA         |
| SA Papeteries de Belgique                                           | NA         |
| SA Intermills                                                       | NA         |
| SA Papeteries de Virginal                                           | NA         |
| Kon. Papierfabrieken Van Gelder Zonen NV                            | NA         |
| Gelderland-Tielens Papierfabrieken BV                               | NA         |
| NV Papierfabrieken Van Houtum & Palm                                | NA         |
| Papierfabriek Huiskamp & Sanders NV                                 | NA         |
| Kon. Nederlandsche Papierfabriek NV                                 | NA         |

### Market
Geographical: Belgium, Netherlands
Oligopoly: True
Turbulence: Economically slack periods, sharp fluctuations in market shares, keen competition from other common market manufacturers, foreign competitors, Scandinavian competition, need for large-scale reorganization, reduced product range

### Cartel Period
1973 : 1976

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-30 | Vereeniging van Nederlandsche Papierfabrikanten and Association des Fabricants de Pates, Papiers et Cartons de Belgique | filed notification under Article 5 of Regulation No 17 |
| 1973-01-14 | redacted | shared details of prices currently charged in Belgium |
| 1973-11-01 | redacted | mentioned an increase in price for a series by Bfrs 1.20 |
| 1973-11-29 | redacted | raised the price of varieties for bulk use by Bfrs 1.20 per kg |
| 1975-12-12 | VNP | informed Commission of abandoning price alignment practice |
| 1975-12-29 | COBELPA | informed Commission of abandoning price alignment practice |
| 1976-06-04 | Commission of the European Communities | initiated proceeding under Article 85 of the EEC Treaty |
| 1976-06-21 | Commission | issued statement of objections taking account of previous replies |
| 1976-06-30 | Belgian manufacturers and wholesalers | agreement terminated |
| 1977-09-08 | Commission of the European Communities | issued Commission Decision |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants:
| company |
| --- |
| Vereeniging van Nederlandsche Papierfabrikanten |
| Association des Fabricants de Pates, Papiers et Cartons de Belgique |

### Leniency
Leniency case: False
Leniency granted: NA

### Fines
NA

### Remedies
No specific decision remedies such as cease and desist orders, divestitures, or behavioral commitments are explicitly mentioned in the provided context.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| SA Papeteries de Belgique, Brussels, Belgium | NA |
| SA Intermills, La Hulpe, Belgium | NA |
| SA Papeteries de Virginal, Virginal, Belgium | NA |
| Kon. Papierfabrieken Van Gelder Zonen NV, Amsterdam, Netherlands | NA |
| Gelderland-Tielens Papierfabrieken BV, Nijmegen, Netherlands | NA |
| NV Papierfabrieken Van Houtum & Palm, Apeldoorn, Netherlands | NA |
| Papierfabriek Huiskamp & Sanders NV, Eerbeek, Netherlands | NA |
| Kon. Nederlandsche Papierfabriek NV, Maastricht, Netherlands | NA |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
IV/312

### Outcome
NA


*(reported: 2026-11-11 10:18:02)*

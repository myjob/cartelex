# 'IV/32.173', 'Continental/Michelin'

**CELEX ID:** CELEX-31988D0555  
**Industry:** | industry                 |
|:-------------------------|
| tyre manufacturing       |
| automotive tyre industry |  
**Cartel Period:** 1983-11-04 : 2008-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0555 | IV/32173  |

### Case Title
Continental/Michelin

### Overview
This case involves an anticompetitive agreement between Continental Gummi-Werke AG, Compagnie Générale des Etablissements Michelin, Michelin et Cie, and other undertakings in the tyre manufacturing industry. The agreement concerned cooperation in research and development, commercial development, and a common entity activity related to run-flat tyres and wheel systems.

### Industry
tyre manufacturing
automotive tyre industry

### Oecd Nace
manufacturing
22.1:Manufacture of rubber products
22.11: Manufacture of rubber tyres and tubes; retreading and rebuilding of rubber tyres

### Companies Undertakings
| companies                                                       | location         |
|:----------------------------------------------------------------|:-----------------|
| Continental Gummi-werke AG                                      | Hanover          |
| Compagnie Générale des Etablissements Michelin, Michelin et Cie | Clermont-Ferrand |
| Uniroyal Englebert                                              | Aachen           |
| Semperit Reifen AG                                              | Vienna           |
| General Tire Inc.                                               | Acron            |
| Kléber                                                          | NA               |

### Market
European Community
False
True
NA

### Cartel Period
1983-11-04 : 2008-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-11-04 | Continental and Michelin | concluded cooperation agreement for development of run-flat tyre/wheel system |
| 1984-07-23 | Commission | issued regulation on application of Article 85 (3) of the Treaty to certain categories of patent licensing agreements |
| 1986-10-27 | Continental and Michelin | filed application for negative clearance or exemption |
| 1986-10-27 | Continental and Michelin | notified agreement under Article 8(1) of Regulation No 17 |
| 1986-10-27 | Continental and Michelin | began cooperation in research and development, commercial development, and common entity activity |
| 1988-10-11 | Commission | issued Commission Decision |
| 1989-01-01 | Continental and Michelin | began cooperation in research and development |
| 1989-12-31 | Continental and Michelin | began reporting obligations to Commission every two years |
| 1990-12-31 | Continental and Michelin | ended cooperation in commercial development |
| 1998-12-31 | Continental and Michelin | ended cooperation in research and development |
| 2008-12-31 | Continental and Michelin | ended activity of common entity |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
True
| company                                       |
|:----------------------------------------------|
| Continental Gummi-Werke AG                    |
| Companie Générale des Etablissements Michelin |

### Leniency
False
NA
NA
NA

### Fines
NA

### Remedies
Without delay inform the Commission of any extension of the cooperation to other tyre categories and all instances of licences granted or refused to third parties; every two years, beginning on 31 December 1989, report on the evolution of the present cooperation.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption for the cooperation agreement under Article 85(3) of the Treaty, subject to reporting obligations and restrictions on licensing third parties.


*(reported: 2026-10-16 20:24:17)*

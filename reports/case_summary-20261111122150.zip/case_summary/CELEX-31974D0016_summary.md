# 'IV/223', 'Transocean Marine Paint Association'

**CELEX ID:** CELEX-31974D0016  
**Industry:** marine paints  
**Cartel Period:** 1959-01-01 : 1978-12-31  

## Summary

### Celex Case Id
CELEX-31974D0016

### Case Title
Transocean Marine Paint Association

### Overview
This case involves the Transocean Marine Paint Association, an international cartel of marine paint manufacturers that was found to have engaged in anticompetitive practices under Article 85 of the EC Treaty. The European Commission granted an initial exemption until 1972, which was later extended with conditions. The cartel period lasted from 1967 to 1978, and the Commission ultimately ordered the revocation of specific restrictive articles in the agreement along with annual reporting requirements.

### Industry
marine paints

### Oecd Nace
manufacturing, 20.3:Manufacture of paints, varnishes and similar coatings, printing ink and mastics, 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
| companies                                                   | location                          |
|:------------------------------------------------------------|:----------------------------------|
| Molijn & Co. NV                                             | Rotterdam, Netherlands            |
| J.C. de Coninck en Zonen NV                                 | Antwerp, Belgium                  |
| Astral, Société de Peintures, Vernis et Encres d'Imprimerie | Paris, France                     |
| Veneziani Zonca S.p.A.                                      | Trieste, Italy                    |
| Farbenfabriken Hansa-Hoeg                                   | Kiel, Federal Republic of Germany |
| Storry Smithson Group of Companies                          | Hull, England                     |
| Sadolin & Holmblad A/S                                      | Copenhagen, Denmark               |
| C. Ljungdahls, AB                                           | Goteborg, Sweden                  |
| Urruzola SA                                                 | Madrid, Spain                     |
| The National Lacquer and Paint Products Co. Ltd.            | Hongkong                          |
| Pacific Products Inc.                                       | Manila, Philippines               |
| Nippon Paint Co. Ltd.                                       | Osaka, Japan                      |
| Nippon Paint Ltd.                                           | Singapore                         |
| Nippon Paint, Malaysia                                      | NA                                |
| Nippon Paint Co. Ltd., Thailand                             | NA                                |
| Spartan Paints Pty. Ltd.                                    | Melbourne, Australia              |
| Patterson-Sargent                                           | New Brunswick, USA                |
| Galleon Paints Co. Ltd.                                     | Parow, South Africa               |
| Mauvilac & Co. Ltd.                                         | Pailles, Mauritius                |
| Antilian Paint Factory Ltd.                                 | Netherlands Antilles              |
| Transocean Marine Paint Association                         | NA                                |

### Market
Relevant market is described as oligopolistic and outside the EU. The geographical scope includes France, Belgium, Italy, Germany, England, Denmark, Sweden, Spain, Hong Kong, Philippines, Japan, Singapore, Malaysia, Thailand, Australia, USA, Netherlands Antilles, South Africa, Mauritius, and Netherlands.

### Cartel Period
1967-06-27 : 1978-12-31

### Key Timeline
1959-01-01: Transocean Marine Paint Association established agreement
1962-02-06: Commission of the European Communities established Council Regulation No 17
1967-06-27: Commission issued decision on agreement's compatibility with Article 85(1)
1967-06-27: European Commission issued decision concerning agreement
1967-06-27: redacted Commission Decision issued
1967-06-27: the Commission made decision considering provisions of the Agreement
1967-06-27: Commission of the European Communities granted exemption to Transocean Marine Paint Association until 31 December 1972
1972-10-27: Transocean Marine Paint Association lodged application for extension of exemption
1973-11-16: Commission of the European Communities published essential content of application in Official Journal
1973-12-05: Advisory Committee on Restrictive Practices and Dominant Positions delivered opinion on the application
1973-12-21: European Commission extended exemption and imposed conditions
1978-12-31: Commission concluded exemption period

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
Transocean Marine Paint Association, True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
True

### Book Reference
IV/223

### Outcome
The Commission ordered the revocation of Articles 5 and 8 of the Agreement, which restrict export and delivery practices. Additionally, members must submit annual reports to the Commission on activities and ensure informed compliance with changes related to membership, financial participation, and interlocking directorates.


*(reported: 2026-10-16 21:53:30)*

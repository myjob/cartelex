# 'IV/32.688', 'Konsortium ECR 900'

**CELEX ID:** CELEX-31990D0446  
**Industry:** | industry                                  |
|:------------------------------------------|
| Information and Communications Technology |
| Communications Systems                    |
| Telecommunications                        |
| Consumer Electronics                      |  
**Cartel Period:** 1988-04-07 : 1993-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0446 | IV/32688  |

### Case Title
Konsortium ECR 900

### Overview
The European Commission investigated an anticompetitive agreement among AEG Aktiengesellschaft, Alcatel NV, and Oy Nokia AB in the telecommunications sector. The companies were found to have engaged in horizontal cartel behavior under Article 85 of the EC Treaty, but no infringement was ultimately found, resulting in no remedies or fines being imposed.

### Industry
Information and Communications Technology, Communications Systems, Telecommunications, Consumer Electronics

### Oecd Nace
OECD sector: communication
NACE group code: 26.3: Manufacture of communication equipment
NACE class code: 26.30: Manufacture of communication equipment

### Companies Undertakings
| companies              | country   |
|:-----------------------|:----------|
| AEG Aktiengesellschaft | DE        |
| Alcatel NV             | BE        |
| Oy Nokia AB            | FI        |

### Market
Relevant market includes Germany, Netherlands, Finland, and France. The market is characterized as an oligopoly.

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-12-21 | AEG Aktiengesellschaft, Alcatel NV and Oy Nokia AB | concluded cooperation agreement |
| 1988-04-07 | AEG Aktiengesellschaft, Alcatel NV, Oy Nokia AB | notified cooperation agreement |
| 1989-06-30 | parties to the agreement | completed testing of the development system in the United Kingdom |
| 1990-07-27 | Commission | adopted decision on cooperation agreement |
| 1990-07-27 | Commission of the European Communities | issued decision |
| 1992-12-31 | parties | agreement ends automatically |
| 1993-12-31 | parties | agreement terminated

### Legal Framework
Legal framework: Article 85 (operative article), with the canonical concept being anticompetitive_agreement.

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
NA

### Exemption
False

### Leniency
NA

### Fines
No fines were imposed.

### Remedies
No remedies or orders were issued by the Commission because no infringement was found.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found no infringement, and therefore took no action.


*(reported: 2026-10-16 20:30:50)*

# 'COMP/E-1/36.212', 'Carbonless paper'

**CELEX ID:** CELEX-32004D0337  
**Industry:** NA  
**Cartel Period:** 1990-01-15 : 1994-10-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32004D0337 | IV/36212  |

### Case Title
COMP/E-1/36.212 – Carbonless paper

### Overview
This case involves a horizontal price-fixing cartel in the carbonless paper market, operating from 1990 to 1994. The cartel included companies from multiple EU countries and engaged in concerted practices that violated Article 81 of the EC Treaty.

### Industry
Carbonless paper reels, carbonless paper sheets, sanitary papers, household papers, diapers

### Oecd Nace
OECD sector: manufacturing
NACE group code: 17.2: Manufacture of articles of paper and paperboard
NACE class code: 17.22: Manufacture of household and sanitary goods and of toilet requisites

### Companies Undertakings
| companies                              | country   |
|:---------------------------------------|:----------|
| Arjo Wiggins Appleton Limited          | GB        |
| Bolloré SA                             | FR        |
| Carrs Paper Ltd                        | GB        |
| Distribuidora Vizcaína de Papeles S.L. | ES        |
| Mitsubishi HiTech Paper Bielefeld GmbH | DE        |
| Papelera Guipuzcoana de Zicuñaga SA    | ES        |
| Papeteries Mougeot SA                  | FR        |
| Papierfabrik August Koehler AG         | DE        |
| Sappi Limited                          | ZA        |
| Torraspapel SA                         | ES        |
| Zanders Feinpapiere AG                 | DE        |

### Market
Market geography includes France, Spain, United Kingdom, Ireland, Portugal, Italy, Austria, Germany, Belgium, Netherlands, Luxembourg, Finland, Sweden, Norway, Iceland. Market is outside the EU and is oligopolistic.

### Cartel Period
1990-01-15 : 1994-10-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-01-15 | Sappi | held pricing committee meeting in Zurich to increase price of carbonless reels |
| 1990-09-24 | Sappi | issued memorandum discussing club agreements among UK market participants in Zurich to increase price of carbonless reels |
| 1992-01-01 | cartel members | initiated concerted price increases |
| 1992-01-23 | AWA, Binda, Copigraph, Koehler, Torras-papel, Zanders | attended meeting |
| 1992-02-17 | AWA | discussed price increase |
| 1992-03-05 | Sappi | discussed price increase |
| 1992-03-27 | AWA, Binda, Koehler, Sappi, Stora, Torras-papel, Zanders | attended meeting |
| 1993-02-09 | AWA employee | was elected as chairman of the AEMCP, triggering cartel restructuring |
| 1993-09-30 | Sappi | agreed on price percentage increase and quotas for 1993 |
| 1994-01-01 | AWA | implemented 10% price increase for reels in France |
| 1994-10-01 | Sappi | price increase period ends |
| 2000-07-26 | Commission | initiated proceedings against undertakings |

### Legal Framework
Article 81 (operative), Article 81 (all relevant)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
| company | amount |
| --- | --- |
| Sappi Limited | 100% |
| Mougeot | 50% |
| AWA | 35% |
| Bolloré SA | 20% |

Rejected applicants:
| company |
| --- |
| Copigraph |
| MHTP |

### Fines
| company | amount |
| --- | --- |
| Arjo Wiggins Appleton Limited | EUR 184,27 million |
| Bolloré SA | EUR 22,68 million |
| Carrs Paper Ltd | EUR 1,57 million |
| Distribuidora Vizcaína de Papeles S.L | EUR 1,75 million |
| Mitsubishi HiTech Paper Bielefeld GmbH | EUR 21,24 million |
| Papelera Guipuzcoana de Zicunaga SA | EUR 1,54 million |
| Papeteries Mougeot SA | EUR 3,64 million |
| Papierfabrik August Koehler AG | EUR 33,07 million |
| Sappi Limited | EUR 0 |
| Torraspapel SA | EUR 14,17 million |
| Zanders Feinpapiere AG | EUR 29,76 million |

### Remedies
Undertakings must forthwith bring the infringement to an end and refrain from any agreements or concerted practices that may have the same or similar object or effect as the infringement. This is a cease and desist order issued per company.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court      | country     | jurisdiction   |
|:-----------|:------------|:---------------|
| COMMISSION |             |                |
| Zurich     | Switzerland | International  |
| Frankfurt  | Germany     | International  |
| Brussels   | Belgium     | International  |
| Paris      | France      | International  |
| Nice       | France      | International  |

### Book Reference
COMP/E

### Outcome
The European Commission found the companies guilty of participating in a horizontal price-fixing cartel. Fines were imposed, leniency was granted to some applicants, and cease and desist orders were issued.


*(reported: 2026-11-10 19:57:52)*

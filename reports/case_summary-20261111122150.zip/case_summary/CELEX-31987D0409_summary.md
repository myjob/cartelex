# 'IV/31.741', 'Sandoz'

**CELEX ID:** CELEX-31987D0409  
**Industry:** NA  
**Cartel Period:** 1983-12-31 : 1985-01-22  

## Summary

### Celex Case Id
CELEX-31987D0409

### Case Title
Sandoz

### Overview
The case involved Sandoz Prodotti Farmaceutici SpA and Sandoz Group, companies found to have engaged in anticompetitive agreements under Article 85 of the EC Treaty. The infringement related to territorial exclusivity and parallel trade bans, specifically involving export restrictions on pharmaceutical products such as Methergin, Visken, Calcium Forte, and Sandomigran. The cartel period was from December 31, 1983, to January 22, 1985. The Commission initiated proceedings in April 1986 and issued a decision in July 1987, imposing a fine of 8,000,000 ECU and ordering the companies to refrain from similar practices.

### Industry
manufacturing

### Oecd Nace
manufacturing, 21.2:Manufacture of pharmaceutical preparations

### Companies Undertakings
| company                          |
|:---------------------------------|
| Sandoz Prodotti Farmaceutici SpA |
| Sandoz Group                     |

### Market
NA

### Cartel Period
1983-12-31 : 1985-01-22

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-12-31 | Sandoz PF | used old invoice format with 'export prohibited' |
| 1984-01-01 | Sandoz PF | began using new invoice format with 'export prohibited' centered at bottom |
| 1984-11-26 | Sandoz PF | received request for information pursuant to Article 11 of Regulation No 17 |
| 1985-01-22 | Sandoz PF | replied to Article 11 letter and committed to removing 'export prohibited' phrase |
| 1986-04-15 | Commission | initiated proceedings in the Sandoz case |
| 1987-07-13 | Commission | issued decision in the Sandoz case and imposed fine

### Legal Framework
Article 85

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
| company | amount |
| --- | --- |
| Sandoz PF | 8000000 ECU |

### Remedies
NA

### Company Recidivism
| company | recidivism |
| --- | --- |
| Sandoz Prodotti Farmaceutici SpA | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
IV/31.741

### Outcome
A fine of 8,000,000 ECU and an order requiring Sandoz PF to refrain from any agreement or concerted practice which may have the same or similar object or effect relating to the sales of its products, in respect of export restrictions


*(reported: 2026-11-11 11:08:08)*

# 'IV/30937', 'Pronuptia'

**CELEX ID:** CELEX-31987D0017  
**Industry:** bridal fashions  
**Cartel Period:** 1986-12-17 : 1991-04-21  

## Summary

### Celex Case Id
CELEX-31987D0017

### Case Title
Pronuptia

### Overview
The case involves Pronuptia de Paris SA and Pronuptia GmbH, companies in the bridal fashions industry, investigated for anticompetitive agreements under Article 85 of the EEC Treaty. The infringement involved vertical restraints, specifically territorial exclusivity and parallel trade bans. The Commission adopted a decision on 1986-12-17, and Pronuptia de Paris SA received the decision. The case also includes an exemption request by Pronuptia de Paris SA.

### Industry
bridal fashions

### Oecd Nace
OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 14.1:Manufacture of wearing apparel, except fur apparel
NACE class code: 14.19: Manufacture of other wearing apparel and accessories

### Companies Undertakings
| companies             |
|:----------------------|
| Pronuptia de Paris SA |
| Pronuptia GmbH        |

### Market
Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

Geography: France, Germany, Belgium, Spain, Greece, Ireland, Luxembourg, United Kingdom
Outside EU: True

### Cartel Period
1986-12-17 : 1991-04-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-04-22 | Pronuptia de Paris SA | filed application for negative clearance or exemption |
| 1983-07-01 | European Commission | introduced new block exemption regulation for exclusive distribution agreements |
| 1986-01-28 | Court of Justice of the European Communities | gave judgment on franchise contract dispute |
| 1986-12-17 | Commission | decision is adopted |
| 1986-12-17 | Pronuptia de Paris SA | received Commission Decision in proceedings under Article 85 of the EEC Treaty |
| 1991-04-21 | Commission | end of exemption period |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
NA

### Exemption
Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

Pronuptia de Paris SA applied for exemption.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                        | country    | jurisdiction   |
|:---------------------------------------------|:-----------|:---------------|
| Court of Justice of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 20:07:28)*

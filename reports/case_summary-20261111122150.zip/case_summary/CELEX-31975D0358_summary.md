# 'IV/712', 'Stoves and Heaters'

**CELEX ID:** CELEX-31975D0358  
**Industry:** heating appliances  
**Cartel Period:** 1952 : 1973  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0358 | IV/71     |
| CELEX-31975D0358 | IV/712    |

### Case Title
Stoves and Heaters

### Overview
This case involves an anticompetitive agreement in the Netherlands concerning heating appliances, specifically stoves and heaters. The agreement was found to violate Article 85 of the EC Treaty, which prohibits agreements that prevent competition. The infringement category is vertical, specifically 'Territorial Exclusivity / Parallel Trade Bans'.

### Industry
heating appliances

### Oecd Nace
trade (wholesaling and retailing) and hotels
27.5:Manufacture of domestic appliances
27.52: Manufacture of non-electric domestic appliances

### Companies Undertakings
| company                  |
|:-------------------------|
| R. S. Stokvis & Zonen BV |
| Haarden- en Kachelbureau |

### Market
Netherlands
true

### Cartel Period
1952 : 1973

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1952-01-01 | redacted | agreement made |
| 1962-10-26 | redacted | agreement notified to commission |
| 1962-10-26 | Mr J. M. O'Breen | submitted notification under Article 5 of Regulation No 17 |
| 1969-10-30 | redacted | initiated investigation into Mr Kriek's affairs |
| 1970-01-09 | Committee of Arbitration | informed Mr Kriek of imposed fine |
| 1970-02-16 | Committee of Arbitration | suspended Mr Kriek as member of Agreement |
| 1971-11-03 | redacted | informed Stokvis of fines |
| 1971-12-06 | Appeal Committee | ruled on the case and upheld fine for infringement of Article 75(1) |
| 1973-01-01 | the bureau | terminated Agreement ceasing to have effect |
| 1973-01-05 | Mr O'Breen | summoned Stokvis before Arrondissementsrechtbank to enforce payment of fine |
| 1973-01-12 | the bureau | informed Commission that Agreement had been terminated |
| 1975-06-03 | Commission of the European Communities | issued Decision in case

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
The association of undertakings concerned must forthwith bring the infringement to an end by stopping the application of the disputed provisions of the Agreement and refraining from attempting to recover fines imposed for alleged breaches of the Agreement while it was in force.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
François-Xavier ORTOLI

### Courts
| court                    | country     | jurisdiction   |
|:-------------------------|:------------|:---------------|
| Beoordelingscommissie    | Netherlands | Netherlands    |
| Arrondissementsrechtbank | Netherlands | Haarlem        |
| Arrondissementsrechtbank | Netherlands | Rotterdam      |

### Book Reference
IV/71
IV/712
Bid-rigging and tender fixing

### Outcome
The Commission found that the agreement violated Article 85 of the EC Treaty, which prohibits agreements that prevent competition. The case resulted in a decision by the Commission, with remedies requiring the cessation of the infringing practices.


*(reported: 2026-11-11 10:09:31)*

# 'IV/28.824', "Breeders' rights — maize seed"

**CELEX ID:** CELEX-31978D0823  
**Industry:** Agricultural  
**Cartel Period:** 1960 : 1973  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0823 | IV/28824  |

### Case Title
Breeders’ rights — maize seed

### Overview
This case concerns anticompetitive agreements in the agricultural sector, specifically involving the licensing and distribution of maize seeds. The European Commission found infringements under Article 85 of the Treaty on the Functioning of the European Union (TFEU), relating to restrictive practices in the marketing of agricultural products.

### Industry
Agricultural

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.1: Growing of non-perennial crops
NACE class code: 01.11: Growing of cereals (except rice), leguminous crops and oil seeds

### Companies Undertakings
| companies                                                |
|:---------------------------------------------------------|
| Institut national de la recherche agronomique (INRA)     |
| Société anonyme Française des Semences de Mais (FRASEMA) |
| Mr Kurt Eisele                                           |
| L. C. Nungesser KG                                       |
| Louis David KG                                           |

### Market
Market geographical: France, Germany
Market outside EU: false
Market oligopoly: True
Market turbulence: NA

### Cartel Period
1960 : 1973

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1965-10-05 | INRA | granted licence to Mr. Eisele under exclusivity clause |
| 1965-10-05 | Kurt Eisele | entered into licensing contract with INRA |
| 1965-10-05 | INRA | signed exclusive propagation and sales contract with Mr. Kurt Eisele |
| 1965-10-05 | Mr. Kurt Eisele | signed contract granting exclusive right to organize sales of INRA varieties in Germany |
| 1973-06-18 | FRASEMA | formed with objectives to plan production of INRA seed varieties and allocate production among shareholders |
| 1973-08-13 | INRA | granted exclusive licence for commercial exploitation of maize varieties |
| 1973-11-14 | Mr. Kurt Eisele and Louis David KG | reached settlement to prevent unauthorized imports and sales of INRA seeds in Germany |
| 1973-11-14 | Louis David KG | refrained from selling or marketing seed of INRA 258/INRAKORN variety without authorization |
| 1974-02-19 | Mr. Eisele | published notice against importing INRA seeds without authorization |
| 1974-02-21 | FRASEMA | sent telex to dissuade Mr Bomberault from exporting |
| 1978-09-21 | Commission of the European Communities | issued Commission Decision rejecting exemption application and imposing obligations on parties to cease infringing activities |

### Legal Framework
Law article operative: Article 85
Law article all relevant:
| law_article   |
|:--------------|
| Article 85    |
| Article 90    |
Infringement concept: anticompetitive_agreement, public_undertaking

### Infringement Category
license

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
The parties concerned shall forthwith bring to an end the infringements found in Article 1. In particular they shall immediately refrain from taking any legal or other steps having the object or effect of preventing or impeding imports or exports between the Member States of seed that has been officially certified.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
| court                     | country   | jurisdiction   |
|:--------------------------|:----------|:---------------|
| Bad Kreuznach Landgericht | Germany   | 2.0 174/73     |

### Book Reference
NA

### Outcome
The Commission issued a decision rejecting the exemption application and imposed obligations on the parties to cease infringing activities. The case was found to involve anticompetitive agreements under Article 85 of the TFEU.


*(reported: 2026-11-11 10:25:48)*

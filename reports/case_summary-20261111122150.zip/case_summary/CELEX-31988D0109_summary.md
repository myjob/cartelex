# 'IV/31.735', 'New potatoes'

**CELEX ID:** CELEX-31988D0109  
**Industry:** NA  
**Cartel Period:** 1962-04-01 : 1987-12-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0109 | IV/31735  |

### Case Title
New potatoes

### Overview
The case concerns anticompetitive agreements in the French potato market, involving multiple producer organizations (CEAFLs and CERAFEL) that were found to have violated Article 85 of the EEC Treaty. The European Commission declared certain provisions inapplicable under Article 85(1) of the EEC Treaty.

### Industry
agriculture

### Oecd Nace
OECD sector: agriculture
NACE group code: 01.1: Growing of non-perennial crops
NACE class code: 01.13: Growing of vegetables and melons, roots and tubers

### Companies Undertakings
| companies                                                                   |
|:----------------------------------------------------------------------------|
| Comité Economique Agricole Régional Fruits et Légumes de Bretagne (CERAFEL) |
| CEAFL Aquitaine                                                             |
| CEAFL Basse-Normandie                                                       |
| CEAFL Val de Loire                                                          |
| CEAFL Languedoc-Roussillon                                                  |
| CEAFL Nord de la France                                                     |
| CEAFL Provence                                                              |

### Market
France

### Cartel Period
1962-04-04 : 1987-12-18

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-04-04 | redacted | adopted Council Regulation No 26 on competition rules for agricultural products |
| 1962-08-08 | French Ministry for Agriculture | authorized producer organizations under Law of 8 August 1962 |
| 1962-11-22 | French Government | issued decree laying down procedures for recognizing producer groups and authorizing economic committees |
| 1962-11-22 | seven authorized economic committees | formed a federation |
| 1963-08-02 | redacted | adopted decrees allowing contributions and imposing fines |
| 1965-07-06 | French Ministry for Agriculture | authorized Comité Economique Agricole Fruits et Légumes d'Aquitaine |
| 1966-07-27 | French Ministry for Agriculture | authorized Cerafel (Comité Economique Agricole Régional Fruits et Legumes de Bretagne) |
| 1966-12-30 | French Ministry for Agriculture | authorized CEAFL Languedoc-Roussillon |
| 1967-01-04 | French Ministry for Agriculture | authorized CEAFL Nord de la France and CEAFL Provence |
| 1967-01-10 | French Ministry for Agriculture | authorized CEAFL Val de Loire |
| 1971-07-06 | Afcofel | submitted statutes |
| 1974-12-10 | Court of Justice | delivered judgment in Case 48/74 (Charmasson v. Minister for Economic Affairs and Finance) |
| 1985-10-17 | French authorities | submitted request to the Commission for application of Article 2 of Regulation No 26 |
| 1987-12-18 | Commission | declared inapplicable the provisions of Article 85(1) of the EEC Treaty to agreements and decisions concerning potato market organization |
| 1987-12-18 | Commission of the European Communities | issued decision relating to proceeding under Article 85 of the EEC Treaty

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
NA

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific decision remedies or enforcement orders (e.g., cease and desist orders, divestitures) were identified in the provided context.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission declared inapplicable the provisions of Article 85(1) of the EEC Treaty to agreements and decisions concerning potato market organization.


*(reported: 2026-10-16 20:19:20)*

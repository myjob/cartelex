# '89/467/EEC', 'relating to a proceeding pursuant to Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31989D0467  
**Industry:** cinema  
**Cartel Period:** 1981-11-01 : 1991-10-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0467 | IV/30566  |

### Case Title
89/467/EEC – relating to a proceeding pursuant to Article 85 of the EEC Treaty

### Overview
The European Commission investigated an anticompetitive joint venture agreement among major film companies in the cinema industry, involving exclusive distribution rights and cooperation agreements that restricted competition within the European market.

### Industry
cinema

### Oecd Nace
OECD sector: communication
NACE group code: 59.1:Motion picture, video and television programme activities
NACE class code: 59.14: Motion picture projection activities

### Companies Undertakings
| companies                        | country   |
|:---------------------------------|:----------|
| United International Pictures BV | NL        |
| Paramount Pictures Corporation   | US        |
| MCA Inc.                         | US        |
| MGM/UA Communications Co.        | US        |

### Market
Relevant market includes Belgium, Denmark, France, Germany, Italy, United Kingdom, Ireland, Netherlands (geographical scope), with market outside the EU and oligopolistic structure.

### Cartel Period
1981-10-05 : 1993-07-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-10-05 | redacted | signed basic agreement |
| 1981-10-05 | parent companies | signed joint venture agreement and conditional effectiveness agreement |
| 1981-11-01 | Paramount, MCA, and MGM | formed corporation |
| 1981-11-01 | parent companies | signed franchise agreements, guaranties, and agency agreements |
| 1981-11-01 | parent companies | granted exclusive licence to distribute films |
| 1982-02-11 | redacted | notified agreements |
| 1982-02-11 | United International Pictures BV on behalf of Paramount Pictures Corporation, MCA Int., and Metro-Goldwyn-Mayer Film Co. | submitted application for negative clearance and notification for exemption |
| 1985-05-21 | Commission | opened proceedings |
| 1985-06-20 | Commission | sent statement of objections to applicants |
| 1986-01-29 | Commission | held oral hearing |
| 1989-07-12 | Commission of the European Communities | issued Commission Decision |
| 1991-10-31 | parent companies | ended exclusivity period |

### Legal Framework
Legal framework: Article 85 (operative article), with canonical concept of anticompetitive agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
medium

### Exemption
Exemption sought by all applicants: United International Pictures BV, Paramount Pictures Corporation, MCA Inc., MGM/UA Communications Co.

### Leniency
NA

### Fines
NA

### Remedies
The Commission required the undertakings to inform it forthwith of any amendment or addition to the agreements referred to in Article 1, and of any change in the scope, nature or extent of the cooperation between them; and to notify the Commission all awards by arbitration tribunals settling disputes regarding film allocation and access to screenspace between UIP and exhibitors in the Community.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court               | country             | jurisdiction                |
|:--------------------|:--------------------|:----------------------------|
| Court of Appeals    | exhibitor's country | commercial matters          |
| European Commission | European Union      | European Economic Community |

### Book Reference
NA

### Outcome
The case resulted in a Commission Decision issued on 1989-07-12, with the Commission requiring undertakings to notify it of any amendments or additions to agreements and all arbitration tribunal awards related to film allocation and screen space access.


*(reported: 2026-10-16 20:00:48)*

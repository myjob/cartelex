# 'IV/29.895', 'Telos'

**CELEX ID:** CELEX-31982D0124  
**Industry:** photographic equipment  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0124 | IV/29895  |

### Case Title
Telos

### Overview
This case involves a decision by the European Commission regarding an anticompetitive agreement in the photographic equipment industry. The infringement occurred through vertical restraints, specifically territorial exclusivity and parallel trade bans. The Commission found that Telos SA intentionally supplied incorrect information during its investigation.

### Industry
photographic equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.7: Manufacture of optical instruments and photographic equipment
NACE class code: 26.70: Manufacture of optical instruments and photographic equipment

### Companies Undertakings
| companies            |
|:---------------------|
| Telos SA             |
| Victor Hasselblad AB |
| Hasselblad (GB) Ltd  |
| Camera Care Ltd      |

### Market
Relevant market includes France and the United Kingdom. No information is available regarding oligopoly or market turbulence.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1974-06-18 | Victor Hasselblad | sent letter complaining about pirate imports |
| 1974-07-08 | Telos | promised to monitor pirate imports |
| 1978-07-05 | Hasselblad (GB) | initiated telephone conversation |
| 1978-07-05 | Hasselblad (GB) | informed Telos about Camera Care selling lens on UK market |
| 1978-07-06 | Camera Care | submitted complaint against Victor Hasselblad and Hasselblad (GB) |
| 1978-09-06 | Hasselblad (GB) | asked Telos for information on lens exported to Camera Care |
| 1978-09-11 | Telos | wrote letter to Camera Care regarding sale of lens |
| 1978-09-11 | Telos | wrote letter to Camera Care confirming contractual obligation |
| 1978-11-24 | Victor Hasselblad | contacted Telos about exports to the United Kingdom |
| 1980-06-30 | redacted | investigation conducted at premises of Telos and Hasselblad (GB) |
| 1980-11-18 | Commission | initiated proceedings |
| 1981-11-25 | Commission | issued decision relating to proceeding under Article 15 |

### Legal Framework
Legal framework: Article 85 (operative article), infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Telos SA | 5000 ECU |

### Remedies
A fine of 5000 ECU was imposed on Telos SA for intentionally supplying incorrect information in response to a Commission request.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Telos SA | False |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found that Telos SA engaged in an anticompetitive agreement under Article 85. A fine of 5000 ECU was imposed for intentionally supplying incorrect information during the investigation.


*(reported: 2026-11-11 10:37:29)*

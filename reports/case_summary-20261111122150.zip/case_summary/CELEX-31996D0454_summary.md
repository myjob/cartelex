# 'NA', 'NA'

**CELEX ID:** CELEX-31996D0454  
**Industry:** | industry                     |
|:-----------------------------|
| retail banking services      |
| wholesale banking services   |
| financial markets activities |
| insurance services           |  
**Cartel Period:** 1993-01-27 : 2005-01-22  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31996D0454 | IV/34607  |

### Case Title
NA

### Overview
The case involves two major European banks, Banque Nationale de Paris SA and Dresdner Bank AG, which were investigated for an anticompetitive agreement related to cooperation in the banking sector. The cooperation agreement was notified to the Commission and led to a decision granting an exemption from Articles 85(1) and 53(1) of the EC Treaty and EEA Agreement for the period 23 January 1995 to 22 January 2005, allowing cooperation between BNP and DB under the terms of their notified agreement. The infringement gravity was assessed as high.

### Industry
retail banking services
wholesale banking services
financial markets activities
insurance services

### Oecd Nace
OECD & NACE classifications, from the 'OECD_sector', 'NACE_group_code' and 'NACE_class_code' facts

OECD_sector: banking and insurance (including real estate)

NACE_group_code: 64.1:Monetary intermediation

NACE_class_code: 64.11: Central banking

### Companies Undertakings
| company                      |
|:-----------------------------|
| Banque Nationale de Paris SA |
| Dresdner Bank AG             |

### Market
Relevant market: geography ('market_geographical', 'market_outside_eu'), structure ('market_oligopoly') and turbulence ('market_turbulence')

| country    |
|:-----------|
| France     |
| Germany    |
| Luxembourg |

market_outside_eu: False

market_oligopoly: NA

market_turbulence: NA

### Cartel Period
1995-01-23 : 2005-01-22

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-01-27 | Banque Nationale de Paris SA and Dresdner Bank AG | notified cooperation agreement to Commission |
| 1995-01-23 | banks | notified annex to cooperation agreement to Commission |
| 1995-01-23 | BNP and DB | confirmed willingness to amend veto clause for cooperation with home competitors |
| 1996-01-31 | Commission | published Regulation (EC) No 240/96 on technology transfer agreements |
| 1996-06-24 | Commission | issued decision on cooperation agreement |
| 2005-01-22 | redacted | exemption period ended |

### Legal Framework
Article 85

infringement_concept: anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
True

| company                      |
|:-----------------------------|
| Banque Nationale de Paris SA |
| Dresdner Bank AG             |

### Leniency
False

NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
False

### Book Reference
NA

### Outcome
Exemption from the application of Articles 85(1) and 53(1) of the EC Treaty and EEA Agreement for the period 23 January 1995 to 22 January 2005, allowing cooperation between BNP and DB under the terms of their notified agreement.


*(reported: 2026-10-16 20:47:57)*

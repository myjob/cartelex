# 'NA', 'NA'

**CELEX ID:** CELEX-32000D0475  
**Industry:** domestic washing machines  
**Cartel Period:** 1995-01-01 : 2001-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0475 | IV/36718  |

### Case Title
NA

### Overview
This case involves a cartel of companies in the domestic washing machines industry, found to have engaged in anticompetitive agreements under Article 81 of the EC Treaty and Article 53 of the EEA Agreement. The cartel operated from 1997 to 2001, involving production and import restrictions in specific energy categories.

### Industry
domestic washing machines

### Oecd Nace
OECD sector: manufacturing
NACE group code: 27.5: Manufacture of domestic appliances
NACE class code: 27.52: Manufacture of non-electric domestic appliances

### Companies Undertakings
| companies                                                   |
|:------------------------------------------------------------|
| Conseil Européen de la Construction d'Appareils Domestiques |
| Atag Kitchen Group BV                                       |
| Bosch Siemens Hausgeräte GmbH                               |
| Brandt SA                                                   |
| Candy Elettrodomestici Srl                                  |
| Electrolux Holdings Ltd                                     |
| Merloni Elettrodomestici Spa                                |
| Miele & Cie GmbH&Co                                         |
| Whirlpool Europe Srl                                        |
| Antonio Merloni Spa                                         |
| Dolmar SA                                                   |
| Fagor Electrodomésticos S.Coop.                             |
| Smeg SpA                                                    |
| AMDEA (United Kingdom)                                      |
| ANFEL (Spain)                                               |
| FAPE (Spain)                                                |
| ANIE (Italy)                                                |
| EHA (Sweden)                                                |
| Fabrimetal (Belgium)                                        |
| FEEI (Austria)                                              |
| FEHA (Denmark)                                              |
| GIFAM (France)                                              |
| Vlehan (Netherlands)                                        |
| ZVEI (Germany)                                              |
| BESD (Turkey)                                               |
| FEA (Switzerland)                                           |
| NEL (Norway)                                                |
| Arçelik (Turkey)                                            |
| Iar Siltal Srl (Italy)                                      |

### Market
Relevant market: EEA, with production and imports outside the EU. Market is oligopolistic.

### Cartel Period
1997-09-24 : 2001-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1997-09-24 | Conseil Européen de la Construction d'Appareils Domestiques | entered into agreement regarding production and imports of domestic washing machines |
| 1997-10-22 | Conseil Européen de la Construction d'Appareils Domestiques (CECED) | submitted notification for negative clearance or exemption |
| 1997-10-22 | Commission | issued decision declaring provisions inapplicable |
| 1997-12-31 | The parties | ceased producing and/or importing machines in categories E, F, and G |
| 1999-01-24 | Commission of the European Communities | issued decision relating to proceeding under Article 81 of the EC Treaty and Article 53 of the EEA Agreement |
| 1999-01-24 | Mario Monti | issued decision addressed to CECED |
| 1999-12-31 | The parties | ceased producing and/or importing machines in category D |
| 2000-12-31 | Each party | contributed to reaching a weighted average efficiency of 0.24 kWh/kg |
| 2001-12-31 | redacted | exemption period ended |

### Legal Framework
Legal framework: Article 81 (EC Treaty) and Article 53 (EEA Agreement). Infringement concept: anticompetitive_agreement.

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
The Commission granted an exemption from the application of Articles 81(1) and 53(1) of the EC Treaty and EEA Agreement, respectively, for a specific period (22 October 1997 to 31 December 2001), allowing the parties to implement certain behavioral commitments while restricting production and imports of washing machines in energy categories D to G.

### Leniency
NA

### Fines
NA

### Remedies
The Commission granted an exemption from the application of Articles 81(1) and 53(1) of the EC Treaty and EEA Agreement, respectively, for a specific period (22 October 1997 to 31 December 2001), allowing the parties to implement certain behavioral commitments while restricting production and imports of washing machines in energy categories D to G.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption from the application of Articles 81(1) and 53(1) of the EC Treaty and EEA Agreement, respectively, for a specific period (22 October 1997 to 31 December 2001), allowing the parties to implement certain behavioral commitments while restricting production and imports of washing machines in energy categories D to G.


*(reported: 2026-10-16 22:21:30)*

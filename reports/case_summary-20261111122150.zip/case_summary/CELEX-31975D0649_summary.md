# 'IV/223', 'Transocean Marine Paint Association'

**CELEX ID:** CELEX-31975D0649  
**Industry:** marine paint  
**Cartel Period:** 1975-10-01 : 1978-12-31  

## Summary

### Celex Case Id
CELEX-31975D0649

### Case Title
Transocean Marine Paint Association

### Overview
The case involves the Transocean Marine Paint Association, which was investigated for anticompetitive agreements under Article 85 of the EEC Treaty. The cartel period lasted from 1973-12-21 to 1978-12-31. The Commission granted an exemption until 1978, which was later annulled by the European Court of Justice. A subsequent Commission decision addressed to members of the association was adopted in 1975. No specific remedies were issued to terminate the infringement.

### Industry
marine paint

### Oecd Nace
manufacturing, 20.3:Manufacture of paints, varnishes and similar coatings, printing ink and mastics, 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics

### Companies Undertakings
Transocean Marine Paint Association

### Market
NA

### Cartel Period
1973-12-21 : 1978-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-12-21 | Commission | granted exemption to Transocean Marine Paint Association until 31 December 1978 |
| 1974-10-23 | European Court of Justice | annulled Article 3(1)(d) of the Commission's Decision |
| 1975-10-23 | Commission | adopted decision addressed to members of transocean marine paint association |
| 1978-12-31 | unknown | exemption expired |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
Market sharing, quota cartels, and specialization agreements

### Infringement Gravity
NA

### Exemption
Transocean Marine Paint Association

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
A. BORSCHETTE

### Courts
| court                     | country            | jurisdiction   |
|:--------------------------|:-------------------|:---------------|
| European Court of Justice | European Community | EEC            |

### Book Reference
IV/223

### Outcome
No specific remedies or orders were issued by the Commission to terminate the infringement.


*(reported: 2026-10-16 21:53:45)*

# 'IV/26.917', 'Henkel/Colgate'

**CELEX ID:** CELEX-31972D0041  
**Industry:** washing and cleaning agents  
**Cartel Period:** 1971-12-23 : 1971-12-23  

## Summary

### Celex Case Id
CELEX-31972D0041 / IV/26.917

### Case Title
Henkel/Colgate

### Overview
The European Commission investigated an anticompetitive agreement between Henkel & Cie GmbH and Colgate-Palmolive Company concerning a joint venture in the manufacturing of washing and cleaning agents, specifically textile cleaning products.

### Industry
washing and cleaning agents

### Oecd Nace
manufacturing (OECD sector), NACE group code 20.4, NACE class code 20.41

### Companies Undertakings
- Henkel & Cie GmbH (DE)
- Colgate-Palmolive Company (US)

### Market
The market is oligopolistic; no geographical or turbulence details provided.

### Cartel Period
NA

### Key Timeline
| Date       | Event                                                                 |
|------------|-----------------------------------------------------------------------|
| 1971-05-21 | Henkel&CieGmbH concluded contract with Colgate-Palmolive Company      |
| 1971-05-26 | Henkel&CieGmbH filed application for negative test certificate        |
| 1971-11-10 | Advisory Committee for Cartel and Monopoly Issues submitted opinion   |
| 1971-12-23 | Commission of the European Communities issued decision                |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought by Henkel & Cie GmbH and Colgate-Palmolive Company.

### Leniency
No leniency applications were made in this case.

### Fines
NA

### Remedies
The Commission imposed conditions such as notifying patent and know-how license agreements, submitting annual reports on their application in the common market, informing about arbitral awards, and reporting on personnel interconnections and acquisitions of interest between companies.

### Company Recidivism
Henkel & Colgate-Palmolive: NA

### Case Commission Info Request
NA

### Case Commission No Action
true

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
NA

### Book Reference
IV/26.917, R&D joint ventures

### Outcome
NA


*(reported: 2026-10-16 19:28:29)*

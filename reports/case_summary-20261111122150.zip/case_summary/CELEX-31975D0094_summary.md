# 'IV/23.013', 'Goodyear Italiana-Euram'

**CELEX ID:** CELEX-31975D0094  
**Industry:** | industry             |
|:---------------------|
| tyres                |
| foodstuffs packaging |  
**Cartel Period:** 1963-05-01 : 1973-08-07  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31975D0094 | IV/23013  |

### Case Title
Goodyear Italiana-Euram

### Overview
The European Commission investigated an anticompetitive agreement between Goodyear Italiana SpA and Euram Italia SpA in the tyre and foodstuffs packaging industry. The companies entered into an exclusive sales agreement in 1963, which was found to violate Article 85 of the EEC Treaty. The cartel period lasted from 1963 to 1973.

### Industry
tyres, foodstuffs packaging

### Oecd Nace
manufacturing; 22.2:Manufacture of plastics products; 22.22: Manufacture of plastic packing goods

### Companies Undertakings
| companies             |
|:----------------------|
| Goodyear Italiana SpA |
| Euram Italia SpA      |

### Market
Italy

### Cartel Period
1963-05-01 : 1973-08-07

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-05-01 | Goodyear Italiana SpA | concluded exclusive sales agreement with Euram |
| 1963-05-01 | Goodyear Italiana SpA | filed notification under Article 4 of Regulation No 17 |
| 1973-08-07 | Goodyear Italiana and Euram | amended contract by deleting clauses on competing products and trademark challenge |
| 1974-12-19 | Commission of the European Communities | issued decision under Article 85 of EEC Treaty |
| 1982-12-31 | redacted | exclusive sales agreement ends |

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
medium

### Exemption
False

### Leniency
NA

### Fines
NA

### Remedies
No cease and desist orders or structural or behavioral remedies were issued to terminate the infringement. Instead, the Commission declared the provisions of Article 85(1) inapplicable under Article 85(3), allowing the agreement to proceed with specified conditions.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
François-Xavier Ortoli

### Courts
NA

### Book Reference
NA

### Outcome
The Commission declared the provisions of Article 85(1) inapplicable under Article 85(3), allowing the agreement to proceed with specified conditions, rather than imposing remedies.


*(reported: 2026-10-16 19:16:11)*

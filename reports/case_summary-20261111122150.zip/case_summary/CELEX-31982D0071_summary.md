# 'IV/29.972', 'Langenscheidt/Hachette'

**CELEX ID:** CELEX-31982D0071  
**Industry:** publishing  
**Cartel Period:** 1977-03-31 : 1984-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0071 | IV/29972  |

### Case Title
Langenscheidt/Hachette

### Overview
The European Commission investigated anticompetitive agreements between Librairie Hachette SA (France) and Langenscheidt KG (Germany), involving a joint venture in publishing French-language courses and dictionaries. The agreements were concluded in 1977, entered into force in 1978, and notified to the Commission in 1979. The Commission issued a decision under Article 85 of the EEC Treaty in 1981.

### Industry
publishing

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 58.1:Publishing of books, periodicals and other publishing activities
NACE class code: 58.14: Publishing of journals and periodicals

### Companies Undertakings
| companies                   |
|:----------------------------|
| Librairie Hachette SA       |
| Langenscheidt KG            |
| Langenscheidt-Hachette GmbH |

Countries:
- Librairie Hachette SA: FR
- Langenscheidt KG: DE
- Langenscheidt-Hachette GmbH: DE

### Market
Germany

### Cartel Period
1978-01-01 : 1984-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-03-31 | Hachette SA and Langenscheidt KG | concluded agreements for publishing and distribution of French-language courses |
| 1978-01-01 | redacted | agreement entered into force |
| 1979-11-06 | redacted | notified to Commission |
| 1981-11-17 | Commission of the European Communities | issued Commission Decision under Article 85 of EEC Treaty |
| 1984-12-31 | redacted | agreements expire on this date |

### Legal Framework
Article 85 (operative)
Article 85 (all relevant)

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
True
Applicants:
| company                     |
|:----------------------------|
| Librairie Hachette SA       |
| Langenscheidt KG            |
| Langenscheidt-Hachette GmbH |

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders issued by the Commission to terminate infringement are explicitly mentioned in the text.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85 of the EEC Treaty in 1981, finding anticompetitive agreements in a joint venture between Hachette and Langenscheidt. The case involved publishing French-language courses and dictionaries in Germany.


*(reported: 2026-10-16 19:52:20)*

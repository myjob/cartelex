# 'IV/32.450', 'COMMISSION DECISION of 19 December 1990 imposing a fine pursuant to Article 19 of Council Regulation (EEC) No 4056/86'

**CELEX ID:** CELEX-31991D0055  
**Industry:** NA  
**Cartel Period:** 1981 : 1990  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31991D0055 | IV/32450-1 |

### Case Title
IV/32.450 – COMMISSION DECISION of 19 December 1990 imposing a fine pursuant to Article 19 of Council Regulation (EEC) No 4056/86

### Overview
The European Commission imposed a fine on Secrétama for participating in a cartel between 1981 and 1990, violating Article 10 of Council Regulation (EEC) No 4056/86. The infringement was classified as having high gravity.

### Industry
Transport

### Oecd Nace
OECD sector: transport
NACE group code: 64.2: Activities of holding companies
NACE class code: 64.20: Activities of holding companies

### Companies Undertakings
Secrétama

### Market
Geographical market includes France and Senegal. The market is outside the EU.

### Cartel Period
1981 : 1990

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-06-30 | French lines | refer to imminent signing of Decree |
| 1981-07-08 | redacted | Decree was adopted |
| 1981-09-16 | Secrétama | decided to disseminate document |
| 1981-09-17 | Secrétama | sent circular letter to lines |
| 1984-02-25 | French shipping company | requested application of penalties |
| 1986-11-18 | Secrétasen | reminded director of mandatory nature of Decree |
| 1987-06-15 | Commission | sent request for information to Secrétama |
| 1987-07-03 | Association of Danish Shipowners | lodged complaint based on Article 10 of Regulation (EEC) No 4056/86 |
| 1987-07-22 | Danish Government | lodged complaint based on Article 10 of Regulation (EEC) No 4056/86 |
| 1988-12-22 | Secrétama | informed in a statement of objections |
| 1989-06-20 | Commission | hearing took place |
| 1990-12-19 | Secrétama | imposed fine of ECU 5,000

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Secrétama | ECU 5.000 |

### Remedies
A fine of ECU 5,000 was imposed on Secrétama.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Secrétama | NA |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed a fine of ECU 5,000 on Secrétama for its involvement in a cartel between 1981 and 1990.


*(reported: 2026-11-11 11:25:50)*

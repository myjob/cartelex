# 'IV/30.988', 'Agreements and concerted practices in the flat-glass sector in the Benelux countries'

**CELEX ID:** CELEX-31984D0388  
**Industry:** NA  
**Cartel Period:** 1978-01-01 : 1980-07-07  

## Summary

### Celex Case Id
CELEX-31984D0388

### Case Title
IV/30.988 – Agreements and concerted practices in the flat-glass sector in the Benelux countries

### Overview
This case involves a cartel in the flat-glass sector in the Benelux countries, where companies engaged in price-fixing collusion and market sharing agreements. The infringement period lasted from 1978 to 1980, and the European Commission adopted its decision in 1984. Several companies were fined for their involvement in anticompetitive practices.

### Industry
raw glass products, floatglass, sheet glass, cast glass, insulating-glass, toughened glass, laminated glass, silvered glass, reflecting-glass, worked glass

### Oecd Nace
OECD sector: manufacturing

NACE group code: 23.1:Manufacture of glass and glass products

NACE class code: 23.11: Manufacture of flat glass

### Companies Undertakings
| companies                    | country   |
|:-----------------------------|:----------|
| BSN SA                       | NL        |
| Glaverbel SA                 | BE        |
| Maasglas BV                  | NL        |
| Glaverned BV                 | NL        |
| Compagnie de Saint-Gobain SA | FR        |
| Glaceries de Saint-Roch SA   | FR        |
| Glasfabriek Sas van Gent BV  | BE        |
| Alglas BV                    | NL        |
| Asahi Glass                  | JP        |

### Market
Geographical market: Belgium, Luxembourg, Netherlands

Oligopoly: True

Outside EU: False

Turbulence: NA

### Cartel Period
1978-01-01 : 1980-07-07

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-06-07 | Glaverbel and Saint-Roch | held coordination meeting to agree prices in Benelux countries |
| 1977-06-09 | Saint-Roch | summarized agreed prices and discounts for window glass |
| 1978-01-01 | redacted | infringements of Article 85(1) of the EEC Treaty commenced |
| 1978-02-07 | Glaverbel and Saint-Roch | held meeting discussing relative positions in Belgium and Netherlands |
| 1978-03-20 | Saint-Gobain | outlined country-by-country targets for 1979 compared with 1977 sales |
| 1978-04-17 | Glaverbel and Saint-Roch executives | looked for ways of carrying out a parallel price increase |
| 1980-01-14 | Saint-Roch | reported $10% price increase on insulating-glass in Netherlands |
| 1980-03-05 | Saint-Roch | agreed or colluded on Belgian price-list for sealed triple-glazing units |
| 1980-03-21 | Saint-Roch | drafted Dutch price-list for float in consultation with Glaverbel |
| 1980-03-27 | Glaverbel | prepared Dutch price-list jointly with Saint-Roch under Alglas leadership |
| 1980-07-07 | Saint-Roch | introduced new Belgian price-list for cast glass in consultation with Glaverbel |
| 1984-07-23 | Commission | adopted Commission Decision relating to proceedings under Article 85 |

### Legal Framework
Article 85 (operative article), Article 85 (all relevant articles)

Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal restraints

### Infringement Sub Category
price fixing collusion; market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
Exemption sought: True

Applicants: NA

### Leniency
Leniency case: False

Applicants: NA

Granted: NA

Rejected: NA

### Fines
| company | amount |
| --- | --- |
| BSN SA | 935 000 ECU |

Decision remedies:
BSN SA: a fine of 935 000 ECU; Glaverbel SA: a fine of 850 000 ECU; Compagnie de Saint-Gobain SA: a fine of 1 450 000 ECU; Glaceries de Saint-Roch SA: a fine of 765 000 ECU

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Saint-Gobain | True |
| BSN | True |

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission imposed fines on several companies involved in the cartel, including BSN SA, Glaverbel SA, Compagnie de Saint-Gobain SA, and Glaceries de Saint-Roch SA. The case was found to involve high gravity infringement under Article 85 of the EEC Treaty.


*(reported: 2026-11-11 10:52:33)*

# 'IV/32031', 'Auditel'

**CELEX ID:** CELEX-31993D0668  
**Industry:** Television Broadcasting  
**Cartel Period:** 1991-11-01 : 1996-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0668 | IV/32031  |

### Case Title
Auditel

### Overview
The case involves a horizontal cartel in the television broadcasting industry in Italy, where Auditel Srl and its partners engaged in anti-competitive practices under Article 85 of the EC Treaty. The European Commission initiated proceedings and found an infringement related to Article 11 of the agreement.

### Industry
Television Broadcasting

### Oecd Nace
OECD sector: communication
NACE group code: 46.3:Wholesale of food, beverages and tobacco
NACE class code: 46.39: Non-specialised wholesale of food, beverages and tobacco

### Companies Undertakings
| companies                        |
|:---------------------------------|
| Auditel Srl                      |
| A. C. Nielsen Italia SpA         |
| Marketing TV Services Srl (MTvs) |

### Market
Italy
NA
NA

### Cartel Period
1991-11-01 : 1996-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-10-07 | European Commission | initiated proceedings in this case |
| 1991-10-25 | Auditel Srl and AGB | signed new agreement |
| 1991-11-01 | Auditel Srl and AGB | agreement entered into force |
| 1992-07-08 | Auditel | signed agreement containing Article 11 |
| 1992-07-08 | Auditel partners | amended article 11 to clarify exclusive use of Auditel's audience rating measurements |
| 1992-07-08 | Commission | amended agreement between members of Auditel |
| 1993-06-11 | Auditel's lawyers | gave notice of a modification to Article 11 |
| 1993-06-23 | Auditel's lawyers | indicated that Article 11 was being withdrawn |
| 1993-07-24 | Auditel | withdrew Article 11 |
| 1993-07-24 | Commission | deleted Article 11 of the agreement |
| 1993-07-24 | Administrative Council of Auditel | adopted the decision to withdraw Article 11 |
| 1993-11-24 | European Commission | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |
| 1993-11-24 | Commission | adopted decision on Auditel Srl |
| 1996-12-31 | Auditel Srl and AGB | agreement expired |

### Legal Framework
Article 85
Article 86
abuse_of_dominance, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
structural crisis cartels

### Infringement Gravity
high

### Exemption
Auditel Srl sought exemption under Article 85(3), which was rejected.

### Leniency
NA

### Fines
NA

### Remedies
The Commission declared that Article 11 of the agreement between the members of Auditel constituted an infringement of Article 85(1) of the EC Treaty, and rejected the request for exemption under Article 85(3). Additionally, the Commission ordered the formal withdrawal of Article 11 on 24 July 1993 to terminate the anti-competitive effects.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Auditel Srl | False |

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission found an infringement under Article 85(1) of the EC Treaty, rejected the exemption request, and ordered the formal withdrawal of Article 11 to terminate the anti-competitive effects.


*(reported: 2026-11-11 11:42:15)*

# 'IV/32.202-APB', 'relating to a proceeding under Article 85 of the EEC Treaty'

**CELEX ID:** CELEX-31990D0033  
**Industry:** | industry            |
|:--------------------|
| cosmetics           |
| dietary supplements |
| special foods       |  
**Cartel Period:** 1986-12-01 : 1989-12-14  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0033 | IV/32202  |

### Case Title
IV/32.202-APB – relating to a proceeding under Article 85 of the EEC Treaty

### Overview
The European Commission investigated an anticompetitive agreement involving the Association Pharmaceutique Belge (APB) in Belgium, related to vertical restraints under Article 85 of the EEC Treaty. The case concerned exclusive dealing practices that restricted competition in the pharmaceutical and cosmetic sectors.

### Industry
cosmetics

dietary supplements

special foods

### Oecd Nace
OECD sector: manufacturing

NACE group code: 21.1: Manufacture of basic pharmaceutical products

NACE class code: 21.10: Manufacture of basic pharmaceutical products

### Companies Undertakings
Association Pharmaceutique Belge (BE)

### Market
Belgium

NA

NA

### Cartel Period
1986-12-01 : 1989-12-14

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1986-12-01 | Association Pharmaceutique Belge | notified standard agreement of indefinite duration |
| 1986-12-01 | APB | notified contract |
| 1988-10-26 | APB | issued statement of objections |
| 1989-12-14 | Commission | issued decision |

### Legal Framework
Article 85

anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
medium

### Exemption
True

Association Pharmaceutique Belge

### Leniency
False

NA

NA

NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission decided not to take action in this case.


*(reported: 2026-10-16 20:24:54)*

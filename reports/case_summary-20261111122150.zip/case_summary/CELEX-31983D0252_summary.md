# 'IV/181', 'Cematex'

**CELEX ID:** CELEX-31983D0252  
**Industry:** Textile and Clothing Machinery  
**Cartel Period:** 1971-09-24 : 1982-11-30  

## Summary

### Celex Case Id
CELEX-31983D0252

### Case Title
Cematex

### Overview
This case involves the European Commission's decision regarding Cematex, an association of textile machinery constructors. The Commission granted an exemption under Article 85(3) for a period from 1971 to 1982, allowing certain anticompetitive agreements related to market sharing, quota cartels, and specialization agreements. The case is landmark in the book reference IV/181 and pertains to trade associations.

### Industry
Textile and Clothing Machinery

### Oecd Nace
OECD sector: manufacturing
NACE group code: 28.4:Manufacturing of metal forming machinery and machine tools

### Companies Undertakings
| company                                                                                                                                 |
|:----------------------------------------------------------------------------------------------------------------------------------------|
| Comité européen des Constructeurs de Matériel textile (Cematex)                                                                         |
| Fachgemeinschaft Textilmaschinen im Verein Deutscher Maschinenbau — Anstalten EV (VDMA)                                                 |
| Syndicat des Constructeurs belges de Machines textiles (Symatex)                                                                        |
| Union des Constructeurs de Matériel textile de France (UCMTF)                                                                           |
| British Textile Machinery Association (BTMA)                                                                                            |
| Associazione Costruttori Italiani di Macchinario per I'Industria Tessile (ACIMIT)                                                       |
| Groep Textielmachines (GTM) van de Vereniging voor de Metaal- en de Elektrotechnische Industrie FME Bredewater 20 NL-2715 CA Zoetermeer |
| Société Suisse des Constructeurs de Machines (VSM) Groupe 'Machines textiles'                                                           |

| companies_investigated                                                                                                                  | country   |
|:----------------------------------------------------------------------------------------------------------------------------------------|:----------|
| Comité européen des Constructeurs de Matériel textile (Cematex)                                                                         | EU        |
| Fachgemeinschaft Textilmaschinen im Verein Deutscher Maschinenbau — Anstalten EV (VDMA)                                                 | DE        |
| Syndicat des Constructeurs belges de Machines textiles (Symatex)                                                                        | BE        |
| Union des Constructeurs de Matériel textile de France (UCMTF)                                                                           | FR        |
| British Textile Machinery Association (BTMA)                                                                                            | GB        |
| Associazione Costruttori Italiani di Macchinario per I'Industria Tessile (ACIMIT)                                                       | IT        |
| Groep Textielmachines (GTM) van de Vereniging voor de Metaal- en de Elektrotechnische Industrie FME Bredewater 20 NL-2715 CA Zoetermeer | NL        |
| Société suisse des Constructeurs de Machines (VSM) Groupe Machines textiles' 4, Kirchenweg CH-8032 Zurich                               | CH        |

### Market
Relevant market:
- Geography: Switzerland, Germany, Belgium, France, United Kingdom, Italy, Netherlands
- Outside EU: True
- Oligopoly: NA
- Turbulence: NA

### Cartel Period
1971-09-24 : 1982-11-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-25 | Cematex | made notification for organizing ITMA exhibition |
| 1971-09-24 | European Commission | granted exemption under Article 85(3) |
| 1981-11-19 | Cematex | submitted application for renewal of exemption |
| 1982-11-30 | redacted | exemption expired |
| 1983-05-24 | redacted | issued Commission decision |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
NA

### Exemption
True

Exemption applicants:
- Cematex

### Leniency
False

Leniency applicants: NA
Leniency granted: NA
Leniency rejected: NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court      | country   | jurisdiction   |
|:-----------|:----------|:---------------|
| COMMISSION |           |                |

### Book Reference
IV/181

### Outcome
The Commission renewed the exemption under Article 85(3) with conditions including notification of refusals and compliance with undertakings, but no enforcement actions for terminating an infringement are referenced.


*(reported: 2026-10-16 21:52:43)*

# 'IV/29.598', "SABA's EEC distribution system"

**CELEX ID:** CELEX-31983D0672  
**Industry:** consumer electronics  
**Cartel Period:** 1980-07-21 : 1988-07-21  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0672 | IV/29598  |

### Case Title
SABA's EEC distribution system

### Overview
The European Commission investigated SABA GmbH's selective distribution system in the consumer electronics industry, finding an anticompetitive agreement under Article 85 of the EEC Treaty. The case involved a vertical selective distribution system with medium gravity infringement.

### Industry
consumer electronics

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.4:Manufacture of consumer electronics
NACE class code: 26.40: Manufacture of consumer electronics

### Companies Undertakings
SABA GmbH (DE)

### Market
Market geography:
| country                     |
|:----------------------------|
| Federal Republic of Germany |
| Italy                       |

Market outside EU: false
Market oligopoly: False
Market turbulence: NA

### Cartel Period
1980-07-21 : 1988-07-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | European Commission | implemented Council Regulation No 17 |
| 1977-10-25 | Court of Justice | issued judgment in Case 26/76 Metro on selective distribution systems and competition law |
| 1979-07-02 | SABA GmbH | requested extension of Commission Decision |
| 1979-07-02 | SABA | applied for exemption of distribution system |
| 1979-07-02 | SABA | requested extension of exemption from Article 85(1) of the EEC Treaty |
| 1980-07-10 | Court of Justice | delivered judgment in Perfumes cases, establishing exemption criteria for selective distribution systems |
| 1980-07-21 | European Commission | Decision on SABA's distribution system expired |
| 1980-07-22 | SABA | set date for Article 85 (3) declaration to take effect |
| 1983-12-21 | European Commission | adopted decision concerning EEC distribution system |
| 1983-12-21 | Commission | issued Decision on SABA's distribution system |
| 1984-12-31 | SABA | submitted first annual report to Commission |
| 1988-07-21 | redacted | end date of validity period for Decision |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
medium

### Exemption
Exemption sought: True
Exemption applicants: SABA

### Leniency
Leniency case: False
Leniency applicants: NA
Leniency granted: NA
Leniency rejected: NA

### Fines
NA

### Remedies
SABA must submit annual reports to the Commission beginning by 31 December 1984, detailing cases involving refusal or withdrawal of dealership, or cutting off supplies. SABA must also conduct inspections of dealer records under certain conditions related to serial numbers.

### Company Recidivism
| companies   | recidivism   |
|:------------|:-------------|
| SABA GmbH   | True         |

### Case Commission Info Request
False

### Case Commission No Action
true

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
Is court involved: True
Court list: NA

### Book Reference
NA

### Outcome
The European Commission adopted a decision concerning SABA's EEC distribution system, granting an exemption for the selective distribution system while imposing remedies including annual reporting and dealer record inspections.


*(reported: 2026-10-16 19:48:15)*

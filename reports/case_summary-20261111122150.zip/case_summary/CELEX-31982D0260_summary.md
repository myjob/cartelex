# 'IV/AF 512', 'SA National Panasonic (Belgium) NV'

**CELEX ID:** CELEX-31982D0260  
**Industry:** consumer electronics  
**Cartel Period:** 1972 : 1979  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0260 | IV/512    |

### Case Title
IV/AF 512 – SA National Panasonic (Belgium) NV

### Overview
The European Commission investigated SA National Panasonic (Belgium) NV for participation in a horizontal price fixing collusion in the consumer electronics sector in Belgium. The cartel period spanned from 1972 to 1979, with the Commission initiating proceedings in 1981 and issuing a decision imposing a fine of 5,000 ECU.

### Industry
consumer electronics

### Oecd Nace
trade (wholesaling and retailing) and hotels; OECD sector: trade (wholesaling and retailing) and hotels; NACE group code: 26.4: Manufacture of consumer electronics; NACE class code: 26.40: Manufacture of consumer electronics

### Companies Undertakings
SA National Panasonic (Belgium) NV (BE)

### Market
Belgium

### Cartel Period
1972 : 1979

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-09-29 | NPB | signed programme agreement concerning selling prices of household electrical apparatus |
| 1979-06-27 | Commission | carried out investigation pursuant to Article 14 (3) of Regulation No 17 |
| 1979-07-17 | NPB | implemented new pricing regulations for household electrical and consumer electronics equipment |
| 1981-08-04 | Commission | initiated proceeding in case |
| 1981-11-24 | Advisory Committee | delivered opinion on restrictive practices |
| 1981-12-11 | Commission | issued decision imposing fine

### Legal Framework
Article 85; infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| SA National Panasonic (Belgium) NV | 5000 ECU |

### Remedies
A fine of 5,000 ECU (European Currency Units) was imposed on SA National Panasonic (Belgium) NV.

### Company Recidivism
| company | recidivism |
| --- | --- |
| SA National Panasonic (Belgium) NV | NA |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court                                        | country   | jurisdiction         |
|:---------------------------------------------|:----------|:---------------------|
| Court of Justice of the European Communities | Belgium   | European Communities |

### Book Reference
NA

### Outcome
The Commission imposed a fine of 5,000 ECU on SA National Panasonic (Belgium) NV for participating in an anticompetitive horizontal price fixing collusion in the consumer electronics sector in Belgium.


*(reported: 2026-11-11 10:38:42)*

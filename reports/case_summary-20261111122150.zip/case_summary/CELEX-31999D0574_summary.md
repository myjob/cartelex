# 'IV/36.581', 'Télécom Développement'

**CELEX ID:** CELEX-31999D0574  
**Industry:** telecommunications  
**Cartel Period:** 1997-04-11 : 1998-02-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0574 | IV/36581  |

### Case Title
Télécom Développement

### Overview
The case concerns an anticompetitive agreement under Article 81 of the EC Treaty, involving companies from France. The European Commission investigated agreements between Cégétel SA and SNCF through their jointly-owned subsidiary Télécom Développement. The agreements were found not to fall under Article 81(1) of the EC Treaty or Article 53(1) of the EEA Agreement, hence no remedies or fines were imposed.

### Industry
telecommunications

### Oecd Nace
OECD sector: communication
NACE group code: 61.9: Other telecommunications activities
NACE class code: 61.90: Other telecommunications activities

### Companies Undertakings
| companies_investigated                        | country   |
|:----------------------------------------------|:----------|
| Société nationale des chemins de fer français | FR        |
| Cégétel SA                                    | FR        |
| Télécom Développement                         | FR        |

### Market
France
NA
NA

### Cartel Period
1996-11-22 : 1998-07-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | European Community | implemented First Regulation under Articles 85 and 86 of the EC Treaty |
| 1997-04-11 | Cégetel SA and SNCF | concluded agreements to cooperate through jointly-owned subsidiary Télécom Développement |
| 1998-01-01 | French telecommunications market | was fully liberalised |
| 1998-02-01 | TD and Cégetel | entered long-distance voice-telephony market |
| 1998-02-01 | Cégetel | began offering full range of telecommunications services |
| 1998-02-01 | Cégetel | began offering long-distance services |
| 1998-03-18 | Commission | informed parties that clause on priority use of railway premises fell under Article 81(1) of the EC Treaty |
| 1998-04-20 | parties | proposed amending clause to clarify scope and application of TD's priority access |
| 1998-07-31 | Télécom Développement | introduced amendments to exclusive use of SNCF network capacity and priority use of railway land |
| 1998-07-31 | parties | introduced amendment to original agreements providing for equal treatment and access to other operators without interfering with TD's network development |
| 1999-05-20 | European Commission | declared agreements setting up Cégetel do not give grounds for objection under Article 81(1) of the EC Treaty |
| 1999-07-27 | European Commission | issued decision in Case IV/36.581 relating to Télécom Développement |

### Legal Framework
Article 81
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
NA

### Exemption
True
NA

### Leniency
False
NA
NA
NA

### Fines
NA

### Remedies
No decision remedies found; the Commission determined that the agreements do not fall under Article 81(1) of the EC Treaty or Article 53(1) of the EEA Agreement and thus no orders or remedies were issued.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
False

### Book Reference
NA

### Outcome
The European Commission determined that the agreements between Cégétel SA and SNCF through Télécom Développement did not fall under Article 81(1) of the EC Treaty or Article 53(1) of the EEA Agreement, and thus no remedies or fines were imposed.


*(reported: 2026-10-16 22:20:25)*

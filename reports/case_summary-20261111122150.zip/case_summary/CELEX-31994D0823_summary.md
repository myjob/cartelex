# 'IV/34.891', 'Fujitsu AMD Semiconductor'

**CELEX ID:** CELEX-31994D0823  
**Industry:** NA  
**Cartel Period:** 1993-10-21 : 1994-12-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0823 | IV/34891  |

### Case Title
Fujitsu AMD Semiconductor

### Overview
The case involves a joint venture between Fujitsu Limited and Advanced Micro Devices, Inc. in the semiconductor industry, specifically related to Eproms, flash memories, and other memory devices. The companies entered into a Joint Development Agreement, Investment Agreements, and Technology Cross-Licence Agreement on 1993-03-26.

### Industry
manufacturing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 26.1:Manufacture of electronic components and boards
NACE class code: 26.11: Manufacture of electronic components

### Companies Undertakings
| companies                    | location   |
|:-----------------------------|:-----------|
| Fujitsu Limited              | JAPAN      |
| Advanced Micro Devices, Inc. | USA        |

### Market
worldwide
market_turbulence: rapid growth and dynamic nature of the flash memory market, explosive demand, market shifts from Eproms to flash memory, high competition from numerous JVs forming to increase production capacity, short life cycle of semiconductor products, substantial investment risks

### Cartel Period
1993-03-26 : 2003-10-20

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-03-26 | Fujitsu and AMD | entered into Joint Development Agreement, Investment Agreements, and Technology Cross-Licence Agreement |
| 1993-10-21 | Fujitsu Limited | notified joint venture agreement and five related agreements with Advanced Micro Devices, Inc. |
| 1994-02-11 | Fujitsu Limited and Advanced Micro Devices, Inc. | requested Commission to extend notification to cover Article 53 of the EEA Agreement |
| 1994-12-12 | Commission of the European Communities | issued Commission Decision relating to proceeding under Articles 85 and 53 |

### Legal Framework
Article 85
infringement_concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
Exemption sought or granted:
An individual exemption was granted for 10 years under Articles 85(3) and 53(3) of the EC Treaty and EEA Agreement, respectively.

### Leniency
NA

### Fines
NA

### Remedies
An individual exemption was granted for 10 years under Articles 85(3) and 53(3) of the EC Treaty and EEA Agreement, respectively.

### Company Recidivism
| companies                                     | recidivism   |
|:----------------------------------------------|:-------------|
| Fujitsu Limited, Advanced Micro Devices, Inc. | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action but granted an individual exemption for 10 years under Articles 85(3) and 53(3) of the EC Treaty and EEA Agreement, respectively.


*(reported: 2026-10-16 20:50:05)*

# 'IV/36.237', 'TPS'

**CELEX ID:** CELEX-31999D0242  
**Industry:** | industry                                     |
|:---------------------------------------------|
| programme production and rights distribution |
| pay-TV market                                |
| technical services for pay-TV                |
| film broadcasting rights                     |
| sporting events broadcasting                 |
| cable market                                 |
| satellite platforms                          |
| digital television                           |  
**Cartel Period:** 1996-04-18 : 1999-12-15  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0242 | IV/36237  |

### Case Title
TPS

### Overview
The European Commission investigated an anticompetitive agreement among several French companies in the pay-TV market, involving horizontal restraints such as market sharing and quota cartels. The cartel period lasted from April 11, 1996, to March 3, 1999. The Commission found no grounds for action under Article 85(1) of the EC Treaty and did not issue any remedies or orders.

### Industry
programme production and rights distribution, pay-TV market, technical services for pay-TV, film broadcasting rights, sporting events broadcasting, cable market, satellite platforms, digital television

### Oecd Nace
OECD sector: communication
NACE group code: 59.1:Motion picture, video and television programme activities
NACE class code: 59.13: Motion picture, video and television programme distribution activities

### Companies Undertakings
| companies                                  |
|:-------------------------------------------|
| Télévision Française 1                     |
| France Télévision Entreprises              |
| France Télécom                             |
| Métropole Télévision                       |
| Compagnie Luxembourgeoise de Télédiffusion |
| Suez Lyonnaise des Eaux                    |
| TPS                                        |
| TPSG                                       |

### Market
France, oligopoly market, no turbulence

### Cartel Period
1996-04-11 : 1999-03-03

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted Regulation No 17 implementing Articles 85 and 86 of the Treaty |
| 1996-04-11 | redacted | signed initial agreement |
| 1996-04-18 | parties | finalized agreement concerning coordination with cable service |
| 1996-10-18 | parties | notified operation to Commission requesting negative clearance and/or exemption |
| 1998-04-02 | parties to the TPS agreements | deleted cable clause in TPS agreements |
| 1998-07-27 | parties | notified Commission of amendment deleting clause on coordinating programmes and services |
| 1998-09-17 | Commission | requested clarification of non-competition clause scope and deleted provision on exclusive broadcasting of Arte and La Cinquieme channels |
| 1999-03-03 | Commission | declared provisions inapplicable |
| 1999-12-15 | redacted | exemption period ended for TPS services |

### Legal Framework
Article 85 (operative article), Article 85 (all relevant articles)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
Exemption sought by Télévision Française 1, France Télévision Entreprises, France Télécom, Métropole Télévision, Suez Lyonnaise des Eaux; exemption period ended for TPS services.

### Leniency
NA

### Fines
NA

### Remedies
No orders or remedies were issued to terminate an infringement because the Commission found no grounds for action under Article 85(1) of the EC Treaty.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 22:18:44)*

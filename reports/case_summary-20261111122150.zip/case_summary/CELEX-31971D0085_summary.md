# 'IV/26792', 'C.I.C.G.—ZVEI/ZPU'

**CELEX ID:** CELEX-31971D0085  
**Industry:** | industry                                                          |
|:------------------------------------------------------------------|
| Electrical industry                                               |
| Tape recorder and video recorder manufacturing/importing industry |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31971D0085 | IV/26792  |

### Case Title
C.I.C.G.—ZVEI/ZPU

### Overview
The European Commission investigated cartel behavior in the electrical industry, specifically involving tape recorder and video recorder manufacturers in Germany. The case involved a request for information by the Commission, which led to a decision finding violations of Article 85(1) of the EEC Treaty.

### Industry
Electrical industry
Tape recorder and video recorder manufacturing/importing industry

### Oecd Nace
manufacturing
26.4:Manufacture of consumer electronics
26.40: Manufacture of consumer electronics

### Companies Undertakings
| companies                                                        | location   |
|:-----------------------------------------------------------------|:-----------|
| Central Office for Private Transfer Rights                       | NA         |
| Central Association of the Electrical Engineering Industry, e.V. | NA         |

### Market
Germany
outside the EU

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-03-12 | Commission | addressed request for information to ZPU |
| 1970-09-07 | ZpU | requested to provide information concerning manufacturers and importers not belonging to the Central Association |
| 1971-02-01 | Central Office for Private Transfer Rights (ZPU) | issued decision requiring information on agreements and calculations |
| 1971-02-01 | Commission of the European Communities | determined that agreements violated Article 85(1) of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission imposed compulsory fines ranging from fifty to one thousand accounting units for each day of delay under Article 16, and from one hundred to five thousand accounting units under Article 15, on companies or business associations that intentionally or negligently fail to provide information requested under Articles 11(3), (5), or 12 within the set deadline. These fines are intended to compel compliance with the information requests and halt the infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Franco M. MALFATTI

### Courts
| court                             | country    | jurisdiction   |
|:----------------------------------|:-----------|:---------------|
| Court of the European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission determined that agreements violated Article 85(1) of the EEC Treaty and imposed compulsory fines to compel compliance with information requests.


*(reported: 2026-11-11 09:52:16)*

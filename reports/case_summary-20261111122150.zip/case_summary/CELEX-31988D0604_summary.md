# 'IV/32.358', 'ServiceMaster'

**CELEX ID:** CELEX-31988D0604  
**Industry:** housekeeping, cleaning and maintenance services  
**Cartel Period:** 1962-02-01 : 1962-02-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0604 | IV/32358  |

### Case Title
ServiceMaster

### Overview
The European Commission investigated ServiceMaster Ltd for an anticompetitive agreement under Article 85. The company notified the Commission about the agreement and submitted an application for negative clearance. An amended agreement was communicated, and the Commission granted exemption.

### Industry
housekeeping, cleaning and maintenance services

### Oecd Nace
OECD sector: public service
NACE group code: 81.2: Cleaning activities
NACE class code: 81.21: General cleaning of buildings

### Companies Undertakings
ServiceMaster Ltd (GB)

### Market
NA

### Cartel Period
1987-06-03 : 1998-05-09

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-06-03 | ServiceMaster | notified Commission about agreement |
| 1987-06-03 | ServiceMaster Limited | submitted application for negative clearance |
| 1988-05-10 | ServiceMaster | communicated amended agreement to Commission |
| 1988-11-14 | Commission | adopted decision granting exemption |
| 1988-11-14 | Commission | issued decision on proceeding under Article 85 |
| 1998-05-09 | redacted | exemption period ended |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
license

### Infringement Sub Category
horizontal_restraints

### Infringement Gravity
low

### Exemption
True
Applicants: ServiceMaster Limited

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
False

### Book Reference
NA

### Outcome
The Commission granted exemption for the agreement under Article 85, and no further action was taken.


*(reported: 2026-10-16 20:26:12)*

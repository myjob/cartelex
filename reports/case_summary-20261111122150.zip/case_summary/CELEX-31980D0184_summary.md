# 'IV/223', 'Transocean Marine Paint Association'

**CELEX ID:** CELEX-31980D0184  
**Industry:** marine paint  
**Cartel Period:** 1959-01-01 : 1978-12-31  

## Summary

### Celex Case Id
CELEX-31980D0184

### Case Title
Transocean Marine Paint Association

### Overview
The case concerns the Transocean Marine Paint Association, a cartel in the marine paint industry operating from 1959 to 1986. The European Commission investigated the association for anticompetitive agreements under Article 85 of the EC Treaty. Exemptions were granted under Article 85(3) but eventually expired, leading to the termination of the exemption from competition law in 1986.

### Industry
marine paint

### Oecd Nace
OECD & NACE classifications: manufacturing (NACE group code 20.3: Manufacture of paints, varnishes and similar coatings, printing ink and mastics; NACE class code 20.30: Manufacture of paints, varnishes and similar coatings, printing ink and Mastics)

### Companies Undertakings
| companies                                    | location       |
|:---------------------------------------------|:---------------|
| Transocean Marine Paint Association          | US             |
| Glasurit SA                                  | CH             |
| Astral SA                                    | FR             |
| F. A. C. van der Linden & Co.                | NL             |
| Pacific Products, Inc.                       | US             |
| Spartan Paints Pty Ltd                       | AU             |
| Croda Paints Ltd                             | GB             |
| Veneziani Zonca Vermici SpA                  | IT             |
| North Brunswick Coatings & Chemicals         | US             |
| Nippon Paint (Singapore) Co. Pte Ltd         | SG             |
| Sadolin Industri A/S                         | DK             |
| Durmus Yasar & Sons                          | TR             |
| P. T. United Transocean Marine Paint Co. Ltd | ID             |
| Pars Sadolin Chemical Co.                    | IR             |
| Merethe Ring Company                         | NO             |
| Galleon Paints (SA) Pty Ltd                  | ZA             |
| Copalin SA                                   | FR             |
| Toa Paint Co. Ltd                            | JP             |
| Sikkens B.V.                                 | NL             |
| Consolidated Chemicals Ltd                   | ZA             |

### Market
Relevant market: geography (South Africa, Greece, Japan, New Zealand, Netherlands, France, Germany, England, Italy, Denmark, Spain, Philippines, Australia, Singapore, USA, Turkey, Indonesia, Iran, Norway), structure (oligopoly), turbulence (NA)

### Cartel Period
1959-01-01 : 1986-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1959-01-01 | Commission | established Agreement |
| 1962-02-06 | Council | adopted Regulation No 17 |
| 1967-06-27 | Commission | issued decision concerning Agreement |
| 1967-06-27 | Commission | granted exemption under Article 85(3) |
| 1972-12-31 | Commission | exemption expired |
| 1973-12-21 | Commission | issued decision concerning Agreement |
| 1973-12-21 | Commission | issued decision describing main provisions of Transocean Charter and By-laws |
| 1973-12-21 | Commission | issued decision on economic links with Transocean members |
| 1973-12-21 | Commission | issued Decision extending exemption |
| 1975-10-23 | Commission | amended Articles 5 and 8 of the Agreement as required by earlier Decision |
| 1975-10-23 | Commission | amended Decision extending exemption |
| 1978-12-07 | Transocean Marine Paint Association | applied for further extension of exemption |
| 1978-12-31 | Commission | exemption expired |
| 1979-12-12 | Commission | issued final decision on exemption extension |
| 1986-12-31 | Commission | ended exemption from competition law |
| 1986-12-31 | Commission | extended exemption for eight years with obligations from previous Decisions reaffirmed |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
No specific cease and desist orders, structural remedies (e.g., divestitures), or behavioral remedies per company are mentioned in the document.

### Company Recidivism
| companies                           | recidivism   |
|:------------------------------------|:-------------|
| Transocean Marine Paint Association | True         |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/223

### Outcome
NA


*(reported: 2026-10-16 21:54:07)*

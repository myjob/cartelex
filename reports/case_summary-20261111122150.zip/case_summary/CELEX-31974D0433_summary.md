# 'IV/26.602', 'FRUBO'

**CELEX ID:** CELEX-31974D0433  
**Industry:** NA  
**Cartel Period:** 1961 : 1974  

## Summary

### Celex Case Id
CELEX-31974D0433 / IV/26602

### Case Title
FRUBO

### Overview
The European Commission investigated a cartel involving Dutch fruit importers, specifically focusing on vertical restraints related to exclusive dealing and market foreclosure. The infringement occurred between 1961 and 1974.

### Industry
Trade in citrus fruits, apples, and pears

### Oecd Nace
trade (wholesaling and retailing) and hotels; NACE group code 01.2: Growing of perennial crops; NACE class code 01.24: Growing of pome fruits and stone fruits

### Companies Undertakings
Nederlandse Vereniging voor de Fruit- en Groentenimporthandel or The Hague (NL)
Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit 'FRUBO' (NL)
Govers en Zonen or Amsterdam (NL)
22 Dutch undertakings belonging to Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit 'FRUBO' (NL)

### Market
Netherlands, Spain, Italy, Belgium, Germany

### Cartel Period
1961 : 1974

### Key Timeline
| Event | Actor | Predicate Object |
| --- | --- | --- |
| 1961-02-01 | Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | revised agreement |
| 1961-02-01 | redacted | agreement was amended |
| 1965-02-15 | Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | revised agreement |
| 1965-02-15 | redacted | agreement was amended |
| 1968-08-01 | Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | revised agreement |
| 1968-08-01 | redacted | agreement was amended |
| 1972-03-15 | Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | revised agreement |
| 1972-03-15 | Importers' Association and Wholesalers' Association | amended clauses of agreement |
| 1972-04-21 | Nederlandse Vereniging voor de Fruiten Groentenimporthandel and Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | submitted notification |
| 1972-04-21 | Importers' Association and Wholesalers' Association | notified amended agreement to commission |
| 1973-10-05 | 22 Dutch undertakings belonging to Nederlandse Bond van Grossiers in Zuidvruchten en ander geimporteerd fruit FRUBO | submitted application |
| 1974-07-25 | Commission of the European Communities | issued decision |

### Legal Framework
Article 85 (operative); Article 85 (all relevant)

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The associations of undertakings and the undertakings listed in the Annex shall forthwith bring the said infringements to an end.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that the agreements constituted an infringement of Article 85 of the EC Treaty. Remedies were ordered to end the infringements immediately.


*(reported: 2026-11-11 10:06:46)*

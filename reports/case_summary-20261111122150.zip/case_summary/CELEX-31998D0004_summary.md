# 'IV/36.069', 'Wirtschaftsvereinigung Stahl'

**CELEX ID:** CELEX-31998D0004  
**Industry:** steel industry  
**Cartel Period:** NA  

## Summary

### Celex Case Id
NA

### Case Title
IV/36.069 – Wirtschaftsvereinigung Stahl

### Overview
The European Commission investigated an anticompetitive agreement in the German steel industry involving the Wirtschaftsvereinigung Stahl and several steel companies. The cartel involved exchange of information on prices and sales, which is a horizontal restraint under Article 85. The infringement was deemed to have high gravity.

### Industry
steel industry

### Oecd Nace
manufacturing (OECD), 24.1:Manufacture of basic iron and steel and of ferro-alloys (NACE)

### Companies Undertakings
| companies                    |
|:-----------------------------|
| Wirtschaftsvereinigung Stahl |
| AG der Dillinger Hüttenwerk  |
| EKO Stahl GmbH               |
| Krupp Hoesch Stahl AG        |
| Krupp Thyssen Nirosta GmbH   |
| Preussag Stahl AG            |
| Stahlwerke Bremen GmbH       |
| Thyssen Stahl AG             |

### Market
Germany, oligopolistic market

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1996-05-28 | Wirtschaftsvereinigung Stahl | notified information exchange system |
| 1996-07-08 | Commission | sent warning letter to association |
| 1996-07-08 | Commission | sent warning letter to parties |
| 1996-07-31 | Commission | held meeting with parties |
| 1996-09-24 | parties | transmitted information to Commission |
| 1997-03-04 | Commission | sent statement of objections to parties |
| 1997-11-26 | Commission | issued decision

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the Wirtschaftsvereinigung Stahl and the 16 notifying undertakings to refrain from implementing the notified information exchange, which constitutes a behavioral remedy in the form of a cease-and-desist order.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                   | country                           | jurisdiction                      |
|:------------------------|:----------------------------------|:----------------------------------|
| Court of First Instance | United Kingdom                    | EU                                |
| COMMISSION              | European Coal and Steel Community | European Coal and Steel Community

### Book Reference
NA

### Outcome
The Commission took action against the cartel, ordering a cease-and-desist from implementing the information exchange system. No fines were imposed.


*(reported: 2026-11-10 19:30:56)*

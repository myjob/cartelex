# 'IV/32.792', 'IATA cargo agency programme'

**CELEX ID:** CELEX-31991D0481  
**Industry:** aviation  
**Cartel Period:** 1988-07-07 : 1998-07-06  

## Summary

### Celex Case Id
CELEX-31991D0481 / IV/32792

### Case Title
IATA cargo agency programme

### Overview
The case concerns the International Air Transport Association (IATA) and its cargo agency programme, which was found to involve anticompetitive agreements under Article 85 of the EEC Treaty. The programme included market sharing, quota cartels, and specialization agreements, leading to a medium gravity infringement. The Commission took a decision regarding this programme.

### Industry
aviation

### Oecd Nace
OECD sector: transport; NACE group code: 51.2: Freight air transport and space transport; NACE class code: 51.21: Freight air transport

### Companies Undertakings
International Air Transport Association (International)
Adria Airways (SI)
Aer Lingus plc (IE)
Aeroflot Soviet Airlines (RU)
Aerolineas Argentinas (AR)
Aerolineas Nicaraguenses SA (AERON) (NI)
Aerovias de Mexico SA de CV (AEROMEXICO) (MX)
Aerovias Nacionales de Colombia SA (AVIANCA) (CO)
Affretair (PVT) Ltd (LK)
Air Afrique (Ivory Coast)
Air Algerie (DZ)
Air Botswana (BW)
Air Bremen GmbH & Co. (DE)
Air Bridge Carriers Ltd (RU)
Air Canada (CA)
Air Europe Ltd (IT)
Air France (FR)
Air Gabon (GA)
Air Guinee (GN)
Air Jamaica Ltd (JM)
Air Littoral (Ivory Coast)
Air Madagascar (MG)
Air Malawi Ltd (MW)
Air Malta Company Ltd (MT)
Air Martinique (MQ)
Air Mauritius (MU)
Air New Zealand Ltd (NZ)
Air Niugini (PG)
Air Pacific Ltd (FJ)
Air Seychelles Ltd (SC)
Air Tanzania Corporation (TZ)
Air Tungaru Corporation (KI)
Air UK (GB)
Air Zaire (Democratic Republic of the Congo)
Air Zimbabwe Corporation (ZW)
Air India (IN)
Airline of the Marshall Islands (MH)
Alaska Airlines Inc. (US)
Alisarda SpA (IT)
Alitalia — Linee Aeree Italiane SpA (IT)
All Nippon Airways Co., Ltd (JP)
American Airlines Inc. (US)
America West Airlines, Inc. (US)
Ariana Afghan Airlines Co. Ltd (AF)
Austrian Airlines (AT)
Balkan Bulgarian Airlines (BG)
Berlin European UK Ltd (GB)
Birmingham European Airways plc (GB)
Braathens SAFE (NO)
British Airways plc (GB)
British Midland Airways Ltd (GB)
Brymon Airways (GB)
Cameroon Airlines (CM)
Canadian Airlines International Ltd (CA)
Caribbean Air Cargo Company Ltd (BB)
Ceskoslovenske Aerolinie (CSA) (Czechoslovakia)
Compañia Mexicana de Aviación SA de CV (MEXICANA) (MX)
Continental Airlines Inc. (US)
Cook Islands International Airlines Ltd (CK)
Crossair (CH)
Cruzeiro do Sul SA — Servicos Aereos (BR)
Cyprus Airways Ltd (CY)
Dan-Air Services Ltd (GB)
Delta Air Regionalflugverkehr GmbH (DE)
Democratic Yemen Airlines (ALYEMOA) (YE)
Deutsche Lufthansa AG (LUFTHANSA) (DE)
Eastern Air Lines Inc. (US)
Egyptair (EG)
El Al Israel Airlines Ltd (IL)
Emirates (AE)
Empresa Consolidada Cubana de Aviación (CUBANA) (CU)
Empresa de Transporte Aereo del Perú (AEROPERU) (PE)
Empresa Ecuatoriana de Aviación SA (ECUATORIANA) (EC)
Ethiopian Airlines Corporation (ET)
Federal Express Corporation (US)
Finnair Oy (FI)
Friendly Islands Airways Ltd (TV)
Gambia Air Shuttle Ltd (GM)
Garuda Indonesia (ID)
German Wings Luffahrtunternehmen GmbH (DE)
Ghana Airways Corporation (GH)
Gulf Air Company GSC (BH)
Hong Kong Dragon Airlines Ltd (DRAGONAIR) (HK)
IBERIA, Lineas Aereas de España SA (ES)
Icelandair (IS)
Indian Airlines (IN)
Iran Air, The Airline of the Islamic Republic of Iran (IR)
Iraqi Airways (IQ)
Jamahiriya Libyan Arab Airlines (LY)
Japan Airlines Co. Ltd (JP)
Japan Air System Co. Ltd (JP)
Jugoslovenski Aerotransport (JAT) (Yugoslavia)
Kenya Airways Ltd (KE)
KLM Royal Dutch Airlines (NL)
Korean Air (KR)
Kuwait Airways Corporation (KW)
LAM — Linhas Aereas de Moçambique (MZ)
Lauda Air (AT)
Luftfahrt AG (DE)
Lesotho Airways Corporation (LS)
Linea Aerea del Cobre SA (LADECO) (CL)
Linea Aerea Nacional — Chile SA (LAN-CHILE) (CL)
Lineas Aereas Costarricenses SA (LACSA) (CR)
Lineas Aereas Paraguayas — LAP (PY)
Lloyd Aereo Boliviano SA (LAB) (BO)
Loganair Ltd (GB)
London City Airways (GB)
MALEV — Hungarian Airlines (HU)
Manx Airlines Ltd (IM)
Midle East Airlines Airliban (MEA) (LB)
Nationair Canada (CA)
NFD Luftverkehrs AG (DE)
Nigeria Airways Ltd (NG)
Nippon Cargo Airlines (NCA) (JP)
Olympic Airways, SA (GR)
Pakistan International Airlines Corp. (PIA) (PK)
Pan American World Airways, Inc. (US)
Philippine Airlines Inc. (PH)
PLUNA — Primeras Lineas Uruguayas de Navegación Aerea (UY)
Polskie Linie Lotnicze (LOT) (PL)
Polynesian Airlines Ltd (Tahiti)
Qantas Airways Ltd (AU)
Royal Air Maroc (MA)
Royal Jordanian (ALIA — The Royal Jordanian Airline) (JO)
Royal Swazi National Airways Corp. Ltd (Swaziland)
Ryanair Ltd (IE)
SABENA (Sociéte anonyme belge d'exploitation de la navigation aerienne) (BE)
Saudi Arabian Airlines Corp. (SAUDIA) (SA)
Scandinavian Airlines System (SAS) (SE)
Scottish European Airways (GB)
Solomon Airlines (SB)
Somali Airlines (SO)
South African Airways (SAA) (ZA)
Sudan Airways Company Ltd (SD)
Swedair AB (SE)
Swiss Air Transport Co. Ltd (SWissAIR) (CH)
Syrian Arab Airlines (SY)
TAGG — Linhas Aereas de Angola (ANGOLA AIRLINES) (AO)
TAP — Air Portugal (PT)
Tempelhof Airways USA Inc. (US)
Tower Air Inc. (US)
Trans-Mediterranean Airways SAL (TMA) (LB)
Transavia Holland BV d/b/a Transavia Airlines (NL)
Trans World Airlines Inc. (TWA) (US)
Trinidad & Tobago (BWIA International) Airwavs CorD. (TT)
Tunis Air (TN)
Turk Hava Yollari AD (TURKISH AIRLINES) (Turkey)
United Airlines (US)
USAir, Inc. (US)
UTA (Union de Transports Aeriens) (FR)
VARIG SA (Viaçao Aerea Rio-Grandense) (BR)
Venezolana Internacional de Aviación SA (VIASA) (VE)
Virgin Atlantic Airways (GB)
YEMENIA Yemen Airways (YE)
Zambia Airways Corporation Ltd (ZM)
ZAS Airline of Egypt (EG)

### Market
European Community, not outside EU

### Cartel Period
1988-07-07 : 1998-07-06

### Key Timeline
1962-02-06: Commission of the European Communities adopted Council Regulation No 17
1988-07-07: IATA notified several resolutions concerning the IATA cargo agency programme
1989-10-02: IATA adopted new resolution 803 series replacing resolution 801 series
1990-04-17: IATA notified resolution 805 series substituting resolution 803 as the basic applicable regime in the European Community
1991-07-30: Commission of the European Communities issued decision on IATA cargo agency programme
1991-07-30: Commission issued Decision addressed to IATA and undertakings
1998-07-06: Exemption from Article 85(1) EEC Treaty ends

### Legal Framework
Article 85 (anticompetitive agreement)

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
medium

### Exemption
Exemption sought or granted for certain companies involved in the IATA cargo agency programme.

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took a decision regarding the IATA cargo agency programme, finding it to be in breach of Article 85 EEC Treaty due to anticompetitive agreements. Exemptions were granted for certain companies.


*(reported: 2026-10-16 20:32:58)*

# 'IV/32.879', 'Viho/Toshiba'

**CELEX ID:** CELEX-31991D0532  
**Industry:** photocopiers  
**Cartel Period:** 1975-01-01 : 1988-09-06  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31991D0532 | IV/32879  |

### Case Title
Viho/Toshiba

### Overview
This case involves an export cartel in the photocopiers industry, where companies entered into infringing agreements under Article 85 of the EEC Treaty. The cartel operated from 1975 to 1988, with TEG being found guilty of recidivism.

### Industry
photocopiers

### Oecd Nace
manufacturing

NACE group code: 26.2:Manufacture of computers and peripheral equipment

NACE class code: 26.20: Manufacture of computers and peripheral equipment

### Companies Undertakings
| companies                      |
|:-------------------------------|
| Toshiba Corporation of Japan   |
| Toshiba Europa (IE) GmbH (TEG) |
| Viho Europe BV                 |

### Market
Belgium, Ireland, Netherlands, Portugal, Denmark, Italy, United Kingdom

### Cartel Period
1975-01-01 : 1988-09-06

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-01-01 | Handelsondernehming Reprotechniek BV | entered into agreement |
| 1975-01-01 | TEG | entered into infringing agreement with Reprotechniek |
| 1975-07-28 | International Office Products Ltd | entered into agreement |
| 1976-05-01 | Eres NV | entered into agreement |
| 1977-03-01 | Tiber SpA. | entered into agreement |
| 1980-02-04 | Moller & Landschulz Aktieselskab | entered into agreement |
| 1980-05-27 | Magnus Office Equipment Ltd | entered into agreement |
| 1981-02-01 | Hoechst Portuguesa SARL | entered into agreement |
| 1984-07-18 | International Office Products Ltd | terminated agreement |
| 1986-12-18 | Moller & Landschulz Aktieselskab | terminated agreement |
| 1987-04-30 | Tiber SpA. | terminated agreement |
| 1991-06-05 | Commission | issued Commission Decision relating to the infringement case |

### Legal Framework
Article 85

infringement_concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
export cartels

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Toshiba Europa (IE) GmbH | ECU 2 million |

### Remedies
TEG was required to modify its distribution agreements with its exclusive distributors to remove the export prohibition clauses that infringed Article 85(1) of the EEC Treaty. This included writing to and receiving acknowledgments from the Belgian, Dutch, Portuguese, and Irish distributors to implement these changes.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Toshiba Europa (IE) GmbH | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country            | jurisdiction   |
|:--------------------------|:-------------------|:---------------|
| European Court of Justice | European Community | European Union |

### Book Reference
NA

### Outcome
The European Commission issued a decision fining Toshiba Europa (IE) GmbH 2 million ECU. Remedies required TEG to modify its distribution agreements by removing export prohibition clauses.


*(reported: 2026-11-11 11:31:51)*

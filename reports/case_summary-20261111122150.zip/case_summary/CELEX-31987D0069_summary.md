# 'IV/31.458', 'X/Open Group'

**CELEX ID:** CELEX-31987D0069  
**Industry:** information technology  
**Cartel Period:** 1985-09-01 : 1990-11-30  

## Summary

### Celex Case Id
CELEX-31987D0069

### Case Title
X/Open Group

### Overview
The case involves a cartel among companies in the information technology sector, specifically agreements on standards made between 1984-11-30 and 1985-09-27. The European Commission investigated these anticompetitive agreements under Article 85 of the EEC Treaty. No fines were imposed, but an exemption was granted from 19 August 1985 to 30 November 1990. The companies involved included Bull, DEC, Ericsson, ICL, Nixdorf, Olivetti, Philips, Siemens, Unisys, and AT&T.

### Industry
information technology

### Oecd Nace
OECD sector: manufacturing, NACE group code: 26.2, NACE class code: 26.20

### Companies Undertakings
| companies                                            | country   |
|:-----------------------------------------------------|:----------|
| Compagnie des Machines Bull                          | FR        |
| Digital Equipment Corporation International (Europe) | US        |
| Telefonaktiebolaget L.M. Ericsson                    | SE        |
| International Computers Limited                      | GB        |
| Nixdorf Computer AG                                  | DE        |
| Ing. C. Olivetti & C. SpA                            | IT        |
| Philips International BV                             | NL        |
| Siemens Aktiengesellschaft                           | DE        |
| Unisys Corporation                                   | US        |
| AT&T Information Systems                             | US        |

### Market
Relevant market: geography ('France', 'United Kingdom', 'Germany', 'Italy', 'Netherlands', 'Sweden'), structure ('oligopoly'), turbulence ('NA')

### Cartel Period
1984-11-30 : 1985-09-27

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-11-30 | redacted | agreements made with retroactive effect |
| 1985-06-26 | redacted | agreements executed |
| 1985-08-19 | redacted | notified agreements including X/Open Group Agreement |
| 1985-09-27 | AT&T Information Systems Inc. | entered into information exchange agreement |
| 1985-11-27 | redacted | copy of agreement sent to Commission |
| 1986-12-15 | redacted | issued Commission Decision on proceeding under Article 85 |
| 1990-11-30 | redacted | exemption period ended |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
horizontal

### Infringement Sub Category
agreements on standards

### Infringement Gravity
medium

### Exemption
True

| company                                              |
|:-----------------------------------------------------|
| Compagnie des Machines Bull                          |
| Digital Equipment Corporation International (Europe) |
| Telefonaktiebolaget L.M. Ericsson                    |
| International Computers Limited                      |
| Nixdorf Computer AG                                  |
| Ing. C. Olivetti & C., SpA                           |
| Philips International BV                             |
| Siemens Aktiengesellschaft                           |
| Unisys Corporation                                   |

### Leniency
False

NA

### Fines
NA

### Remedies
NA

### Company Recidivism
| companies                                            | recidivism   |
|:-----------------------------------------------------|:-------------|
| Compagnie des Machines Bull                          | NA           |
| Digital Equipment Corporation International (Europe) | NA           |
| Telefonaktiebolaget L.M. Ericsson                    | NA           |
| International Computers Limited                      | NA           |
| Nixdorf Computer AG                                  | NA           |
| Ing. C. Olivetti & C., SpA                           | NA           |
| Philips International BV                             | NA           |
| Siemens Aktiengesellschaft                           | NA           |
| Unisys Corporation                                   | NA           |
| AT&T Information Systems                             | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission issued an exemption from 19 August 1985 to 30 November 1990 under Article 85(3) of the EEC Treaty. The members are required to submit annual reports on cases where applications for membership have been refused and to inform the Commission immediately of any changes in membership.


*(reported: 2026-10-16 20:15:00)*

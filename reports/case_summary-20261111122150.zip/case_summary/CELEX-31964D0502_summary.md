# 'IV|A‑00095', 'CARTELS AND MONOPOLIES'

**CELEX ID:** CELEX-31964D0502  
**Industry:** hair cosmetics  
**Cartel Period:** 1962-07-11 : 1969-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31964D0502 | IV/95     |

### Case Title
CARTELS AND MONOPOLIES

### Overview
The case involves a cartel in the hair cosmetics industry, where Société Anonyme Nicholas Frères and Vitapro (U.K.) Ltd. engaged in anti-competitive practices. The European Commission investigated these activities and issued a negative test according to Article 2 of Council Regulation No. 17.

### Industry
hair cosmetics

### Oecd Nace
manufacturing (OECD sector: manufacturing; NACE group code: 20.4: Manufacture of soap and detergents, cleaning and polishing preparations, perfumes and toilet preparations; NACE class code: 20.41: Manufacture of soap and detergents, cleaning and polishing preparations)

### Companies Undertakings
| companies                       | location                                              |
|:--------------------------------|:------------------------------------------------------|
| Société Anonyme Nicholas Frères | Chatou (Seine-et-Oise), Frankreich                    |
| Vitapro (U.K.) Ltd.             | London, Regina House, Marylebone Road, GroBbritannien |

### Market
United Kingdom; outside the EU

### Cartel Period
1962-07-11 : 1964-07-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1961-01-12 | Nicholas Frères | acquired assets of Vitapointe |
| 1962-02-06 | Société Anonyme Nicholas Frères | submitted application for negative certificate |
| 1962-07-11 | Nicholas Frères | concluded contract with Vitapro (U.K.) Ltd. |
| 1962-07-11 | redacted | concluded contract with Vitapro |
| 1963-07-04 | redacted | published essential content of negative certificate request in Official Journal |
| 1964-07-30 | the Commission | issued a negative test according to Article 2 of Council Regulation No. 17 |
| 1964-07-30 | Commission | issued decision addressing Nicholas

### Legal Framework
NA

### Infringement Category
Market sharing, quota cartels, and specialization agreements

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Walter Hallstein

### Courts
NA

### Book Reference
IV/95

### Outcome
The Commission issued a negative test and a decision addressing Nicholas Frères, indicating no action was taken in this specific case.


*(reported: 2026-10-16 18:55:31)*

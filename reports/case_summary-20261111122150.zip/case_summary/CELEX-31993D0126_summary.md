# 'IV/33.151 — Jahrhundertvertrag', 'NA'

**CELEX ID:** CELEX-31993D0126  
**Industry:** | industry                        |
|:--------------------------------|
| Coal Industry                   |
| Electricity Supply Industry     |
| Electricity Generation Industry |
| Coalmining Industry             |  
**Cartel Period:** 1977-05-10 : 1995-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0126 | IV/33151  |

### Case Title
IV/33.151 — Jahrhundertvertrag

### Overview
The case involves anticompetitive agreements in the German coal and electricity industries, where companies colluded to control the sale of coal and electricity, violating EU competition law under Article 85.

### Industry
Coal Industry
Electricity Supply Industry
Electricity Generation Industry
Coalmining Industry

### Oecd Nace
OECD_sector: mining
NACE_group_code: 05.1:Mining of hard coal
NACE_class_code: 05.10: Mining of hard coal

### Companies Undertakings
| companies                                       |
|:------------------------------------------------|
| Gesamtverband des deutschen Steinkohlenbergbaus |
| Vereinigung Deutscher Elektrizitatswerke e.V.   |
| Vereinigung Industrielle Kraftwirtschaft e.V.   |

### Market
Germany
market_oligopoly: True
market_outside_eu: False

### Cartel Period
1977-05-10 : 1995-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-05-10 | GVSt and VDEW | concluded agreement on sale of German coal |
| 1977-08-22 | GVSt and VIK | concluded agreement on sale of German coal |
| 1977-08-23 | GVSt and VIK | concluded agreement on sale of German coal |
| 1980-04-20 | Gesamtverband des deutschen Steinkohlenbergbaus and Vereinigung Deutscher Elektrizitatswerke e.V. | concluded supplementary agreement on sale of German coal |
| 1980-04-23 | GVSt and VDEW | signed supplementary agreement replacing earlier agreement |
| 1981-01-01 | GVSt and VDEW | began arrangements for German coal-purchasing by electricity supply companies |
| 1986-06-30 | Commission | issued decision establishing Community rules for State aid to the coal industry |
| 1986-07-01 | Commission | commenced application of Community rules for State aid to the coal industry |
| 1989-06-01 | Gesamtverband des deutschen Steinkohlenbergbaus | notified agreement to Commission |
| 1991-07-02 | Gesamtverband des deutschen Steinkohlenbergbaus and Vereinigung Industrielle Kraftwirtschaft e.V. | authorized supplementary agreement for coal purchasing commitments |
| 1992-12-22 | Commission of the European Communities | issued Commission Decision |
| 1995-12-31 | GVSt and VIK | supplementary agreements meet exemption conditions under Article 85(3) up until this date |

### Legal Framework
Article 85
Article 90
infringement_concept: anticompetitive_agreement, public_undertaking

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
| company                                         |
|:------------------------------------------------|
| Gesamtverband des deutschen Steinkohlenbergbaus |
| Vereinigung Deutscher Elektrizitatswerke e.V.   |
| Vereinigung Industrielle Kraftwirtschaft e.V.   |

### Leniency
NA

### Fines
NA

### Remedies
No explicit cease and desist orders or structural or behavioral remedies were issued by the Commission to terminate any infringement in the provided context.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Leon Brittan

### Courts
| court                                        | country        | jurisdiction   |
|:---------------------------------------------|:---------------|:---------------|
| Court of Justice of the European Communities | European Union | European       |

### Book Reference
NA

### Outcome
The Commission established Community rules for state aid to the coal industry and applied these rules in 1986. The agreements were found to be anticompetitive under Article 85, but no explicit remedies were issued.


*(reported: 2026-10-16 20:37:35)*

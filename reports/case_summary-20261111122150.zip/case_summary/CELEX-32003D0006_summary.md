# 'COMP/33.133-C', 'Soda ash  Solvay'

**CELEX ID:** CELEX-32003D0006  
**Industry:** | industry      |
|:--------------|
| glass         |
| chemical      |
| metallurgical |
| soda ash      |  
**Cartel Period:** 1978-02-07 : 1990-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32003D0006 | IV/39004  |

### Case Title
COMP/33.133-C – Soda ash Solvay

### Overview
This case involves the European Commission's investigation into Solvay SA for abuse of dominance and anticompetitive agreements in the soda ash market, leading to a finding of infringement under Articles 82 and 86 of the EC Treaty.

### Industry
glass, chemical, metallurgical, soda ash

### Oecd Nace
manufacturing; 20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
Solvay SA (BE)

### Market
The market is oligopolistic within EU countries including Austria, Belgium, France, Germany, Italy, Spain, Portugal, and Switzerland.

### Cartel Period
1978-02-07 : 1990-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1978-02-07 | redacted | signed agreements with Solvay |
| 1981-02-19 | Solvay | sent letter containing formal instructions to DN |
| 1981-06-18 | Solvay | concluded evergreen supply contract with BSN for soda ash |
| 1983-01-01 | Saint-Gobain | signed agreement establishing most-favored-nation status |
| 1983-01-01 | redacted | contract established with revision clause |
| 1983-01-01 | redacted | concluded new agreements with Solvay |
| 1983-12-30 | Solvay | amended BSN supply agreement to require customer to advise of competing offers |
| 1988-02-01 | Deutsche Solvay Werke | communicated pricing policy emphasizing protection against competition through cheque subsidies |
| 1990-02-19 | Commission | opened a proceeding on its own initiative |
| 1990-12-19 | Commission | adopted Decision 91/299/EEC finding infringement |
| 1990-12-31 | redacted | infringement ceased |
| 2000-04-06 | Court of Justice | dismissed Commission's appeal against Solvay II judgment |

### Legal Framework
| law_article |
| --- |
| Article 82 |
| Article 86 |

Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought by Ansac

### Leniency
No leniency applicants

### Fines
| company | amount |
| --- | --- |
| Solvay SA | EUR 20 million |

### Remedies
A fine of EUR 20 million is imposed on Solvay in respect of the infringement specified in Article 1(b) and (c).

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Solvay | True |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                   | country        | jurisdiction   |
|:------------------------|:---------------|:---------------|
| Court of First Instance | European Union | European Court |
| Court of Justice        | European Union | European Court |
| European Commission     | European Union | EC Treaty      |

### Book Reference
NA

### Outcome
The Commission found infringement and imposed a fine of EUR 20 million on Solvay. The Court of Justice dismissed the Commission's appeal in 2000.


*(reported: 2026-11-11 12:14:53)*

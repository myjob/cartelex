# 'IV/32.318', 'London European — Sabena'

**CELEX ID:** CELEX-31988D0589  
**Industry:** NA  
**Cartel Period:** 1987-03-05 : 1987-04-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0589 | IV/32318  |

### Case Title
IV/32.318 – London European — Sabena

### Overview
The case involved allegations of abuse of dominance and anticompetitive agreements by Sabena, a Belgian airline, in relation to its control over the Saphir reservation system. London European Airways PLC sought access to this system, which was denied by Sabena, leading to a complaint and subsequent investigation by the European Commission.

### Industry
Air transport services, computerized reservation services, ground handling services

### Oecd Nace
OECD sector: transport
NACE group code: 79.9 Other reservation service and related activities
NACE class code: 79.90 Other reservation service and related activities

### Companies Undertakings
| companies                      | location        |
|:-------------------------------|:----------------|
| Sabena, Belgian World Airlines | B-1000 Brussels |
| London European Airways PLC    | United Kingdom  |

### Market
Belgium

### Cartel Period
1987-03-05 : 1987-04-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1987-03-06 | Mr. Verdonck | informed London European representatives about conditions for collaboration and access to reservation system |
| 1987-03-20 | Mr Verdonck | informed London European representatives about necessity of handling contract for Saphir listing |
| 1987-04-01 | Mr Colleman (Sabena-Brussels) | decided to refuse LEA access to Saphir system |
| 1987-04-01 | redacted | refused access to Saphir system |
| 1987-04-09 | Sabena | legal department acknowledged potential penalties under Article 86 |
| 1987-04-22 | London European Airways PLC | filed complaint against Sabena |
| 1987-04-30 | redacted | investigation carried out pursuant to Article 14(3) of Regulation No 17 |
| 1987-05-06 | Commission | initiated proceedings in the case |
| 1988-11-04 | redacted | decision issued by European Commission

### Legal Framework
Law articles: Article 85, Article 86
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Sabena, Belgian World Airlines | 100 000 ECU |

### Remedies
The Commission ordered Sabena to grant London European access to the Saphir system, thereby ceasing the infringement. In addition, a fine of 100,000 ECU was imposed on Sabena as a behavioral remedy.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Sabena | False |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | Belgium   | EC Treaty      |

### Book Reference
NA

### Outcome
The European Commission found Sabena guilty of abuse of dominance and anticompetitive agreements. Sabena was ordered to grant London European access to the Saphir system and was fined 100,000 ECU.


*(reported: 2026-11-11 11:15:07)*

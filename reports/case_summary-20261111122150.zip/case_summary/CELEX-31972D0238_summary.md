# 'NA', 'NA'

**CELEX ID:** CELEX-31972D0238  
**Industry:** | industry                                       |
|:-----------------------------------------------|
| Automotive Industry                            |
| Fastening Devices / Plastic Fasteners Industry |  
**Cartel Period:** No cartel period found.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0238 | IV/26813  |

### Case Title
NA

### Overview
This case involves A. Raymond and Nagoya Rubber Co. Ltd., investigated for cartel behavior in the automotive industry, specifically related to brake pads, vehicle tires, upholstery bodies for motor vehicles, and plastic fasteners. The companies are located in Japan, Korea, China, Taiwan, and the Philippines, with the market being outside the EU.

### Industry
Automotive Industry
Fastening Devices / Plastic Fasteners Industry

### Oecd Nace
manufacturing
29.1:Manufacture of motor vehicles
29.10: Manufacture of motor vehicles

### Companies Undertakings
| companies              |
|:-----------------------|
| A. Raymond             |
| Nagoya Rubber Co. Ltd. |

### Market
Japan
Korea
China
Taiwan
Philippines
market outside EU: true

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1968-12-30 | A.Raymond and Nagoya Rubber Co., Ltd. | concluded license agreement |
| 1970-03-12 | A. Raymond branch office | submitted application for negative test certificate |
| 1970-12-05 | redacted | publication of essential content of application in Official Journal |
| 1972-01-21 | Advisory Committee on Cartel and Monopoly Issues | submitted opinion pursuant to Article 10 of Regulation No. 17 |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
NA

### Exemption
False
Applicant: A. Raymond

### Leniency
False
No applicants, no grants or rejections

### Fines
NA

### Remedies
No remedies or orders were issued by the Commission.

### Company Recidivism
| companies              | recidivism   |
|:-----------------------|:-------------|
| Nagoya Rubber Co. Ltd. | NA           |
| A. Raymond             | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
False

### Book Reference
NA

### Outcome
No remedies or orders were issued by the Commission. No action was taken by the Commission.


*(reported: 2026-10-16 19:25:36)*

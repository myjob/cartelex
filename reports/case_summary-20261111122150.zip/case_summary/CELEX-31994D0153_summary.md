# 'IV/30.525', 'International Energy Agency'

**CELEX ID:** CELEX-31994D0153  
**Industry:** oil  
**Cartel Period:** 1993-12-31 : 2003-12-31  

## Summary

### Celex Case Id
CELEX-31994D0153 / IV/30.525

### Case Title
International Energy Agency

### Overview
The case involves the International Energy Agency (IEA), a cartel of oil companies that engaged in anticompetitive practices, specifically exchanging information on prices and sales. The cartel period was from January 1, 1994 to February 21, 1994. The Commission requested information and took a decision but did not take any action regarding leniency or remedies. Companies involved have prior infringement history. The case is related to structural crises cartels.

### Industry
oil

### Oecd Nace
mining / 06.1: Extraction of crude petroleum

### Companies Undertakings
| Amerada Hess Corporation | New York, NY-10036 | US |
| Amoco Corporation | Chicago, IL-60601 | US |
| Anonima Petroli Italiana (API) | Rome, Italy | IT |
| Ashland Oil, Inc. | Russell, KY-41169 | US |
| Atlantic Richfield Company | Dallas, TX-75228 | US |
| BP Oil International Limited | London, EC2M 7BA | GB |
| Caltex Petroleum Corporation | Irving, TX-75062-2794 | US |
| Chevron Corporation | San Francisco, CA-94104-4289 | US |
| Compañia Española de Petróleos, SA (Cepsa) | Madrid 2, Spain | ES |
| Conoco Inc. | Houston, TX-77079 | US |
| Cosmo Oil Co. Ltd | Tokyo, 105, Japan | JP |
| DEA Mineralol AG | Hamburg, 22297 | DE |
| Ente Nazionale Idrocarburi (ENI) Agip Petroli SpA | Rome, Italy | IT |
| Exxon Corporation | Florham Park, NJ-07932 | US |
| Idemitsu Kosan Co., Ltd | Tokyo 100, Japan | JP |
| Japan Energy Corporation | Tokyo 105, Japan | JP |
| Mabanaft GmbH | Hamburg, 20459 | DE |
| Mitsubishi Oil Co., Ltd | Tokyo 105, Japan | JP |
| Mobil Oil Corporation | Fairfax, VA-22037 | US |
| Neste Oy | Espo, Finland | FI |
| Norsk Hydro as | Stabekk, Norway | NO |
| OK Petroleum AB | Stockholm, Sweden | SE |
| OMV AG | Vienna, Austria | AT |
| Petro-Canada Products Ltd | Calgary, Alberta, T2P 3E3 | CA |
| Petrofina SA | Brussels, Belgium | BE |
| Petrogal, SA | Lisbon, Portugal | PT |
| Petróleos del Norte, SA (Petronor) | Madrid, Spain | ES |
| Petroleum Association of Japan (PAJ) | Tokyo 100, Japan | JP |
| Praoil | Assago, Milan, Italy | IT |
| Phillips Petroleum Company | Bartlesville, OK 74004 | US |
| Repsol, SA | Madrid, Spain | ES |
| Shell International Petroleum Co., Ltd | London, SE1 7NA | GB |
| Shell Oil Company | Houston, TX 77002 | US |
| Société nationale Elf Aquitaine | Paris-La Défense, France | FR |
| Statoil | Stavanger, Norway | NO |
| Sun Oil Company, Inc. | Philadelphia, PA-19103-1699 | US |
| Texaco Inc. | White Plains, NY-10650 | US |
| Total SA | Paris-La Défense, France | FR |
| Türkiye Petrol Rafinerili AS (TUPRAS) | Izmit, Turkey | TR |
| VEBA ÖI AG | Gelsenkirchen, Germany | DE |
| Wintershall AG | Kassel, Germany | DE |

### Market
| USA |
| France |
| Germany |
| Finland |
| Norway |
| Sweden |
| Austria |
| Canada |
| Belgium |
| Portugal |
| Spain |
| Japan |
| Italy |
| Turkey |

### Cartel Period
1994-01-01 : 1994-02-21

### Key Timeline
| 1974-11-18 | redacted | agreement signed establishing IEP |
| 1993-10-12 | Chairman of the Industry Advisory Board of the IEA | submitted application for renewal of exemption |
| 1993-12-31 | redacted | exemption ended |
| 1994-01-01 | redacted | decision begins to apply |
| 1994-02-21 | Commission | issued Decision on renewal of exemption |
| 2003-12-31 | redacted | exemption ends |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
medium

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
NA

### Company Recidivism
oil companies

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/30.525

### Outcome
NA


*(reported: 2026-10-16 22:01:17)*

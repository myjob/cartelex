# 'IV/30.717-A', 'Eurocheque: Helsinki Agreement'

**CELEX ID:** CELEX-31992D0212  
**Industry:** NA  
**Cartel Period:** 1980 : 1991  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31992D0212 | IV/30717-2 |

### Case Title
Eurocheque: Helsinki Agreement

### Overview
The Eurocheque case involved anticompetitive agreements in the payment card industry, specifically price fixing collusion. The cartel period spanned from 1980 to 1991, with key events including the conclusion of package deals and the Helsinki Agreement. The European Commission initiated proceedings in 1990 and issued a decision in 1992 under Article 85 of the EEC Treaty.

### Industry
Trade (wholesaling and retailing) and hotels; monetary intermediation

### Oecd Nace
OECD sector: trade (wholesaling and retailing) and hotels
NACE group code: 64.1: Monetary intermediation
NACE class code: 64.19: Other monetary intermediation

### Companies Undertakings
| companies                          |
|:-----------------------------------|
| Groupement des cartes bancaires CB |
| Eurocheque International sc        |
| Association frangaise des banques  |

### Market
France, Germany, Belgium, Spain, Italy, Netherlands, Denmark, Switzerland, Austria, Luxembourg, Portugal, Greece, Ireland, United Kingdom
Market outside EU: True

### Cartel Period
1980 : 1991

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1980-10-31 | Eurocheque community | concluded package deal Agreement |
| 1981-05-01 | redacted | package deal Agreement came into effect |
| 1982-07-07 | Eurocheque International | notified package deal Agreement covering opening-up of non-banking sector |
| 1982-07-07 | national banking groups | notified Commission of package deal Agreement |
| 1983-05-19 | Eurocheque Assembly and French financial institutions | concluded agreement in Helsinki on conditions for accepting foreign Eurocheques |
| 1983-12-01 | French financial institutions | began accepting foreign Eurocheques |
| 1984-07-31 | Groupement | signed protocol including clause on Eurocheque guarantee of payment |
| 1986-04-24 | Eurocheque Assembly | decided to increase maximum interbank commission rate from 1.25% to 1.60% |
| 1986-04-30 | Commission | exemption ended for package deal Agreement |
| 1988-01-01 | redacted | new package deal Agreement came into force |
| 1990-07-19 | Commission of the European Communities | initiated proceedings in this case |
| 1990-07-31 | Commission | issued Statements of Objections concerning the Helsinki Agreement |
| 1991-05-09 | Eurocheque General Assembly | terminated Helsinki Agreements |
| 1991-05-22 | Groupement | informed Commission about abolition of Helsinki Agreement |
| 1992-03-25 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought or granted:
- Groupement des Cartes Bancaires 'CB'
- Eurocheque International sc

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Groupement des cartes bancaires 'CB' | ECU 5 000 000 |
| Eurocheque International sc | ECU 1 000 000 |

### Remedies
The Commission imposed fines on Groupement des cartes bancaires 'CB' (ECU 5,000,000) and Eurocheque International sc (ECU 1,000,000). The Agreement was terminated by the Eurocheque General Assembly on 27 May 1991.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                     | country            | jurisdiction                |
|:--------------------------|:-------------------|:----------------------------|
| Eurocheque Assembly       | France             | European Economic Community |
| Commission                | European Community | EEC                         |
| Conseil de la concurrence | France             | French                      |

### Book Reference
NA

### Outcome
The European Commission imposed significant fines on Groupement des cartes bancaires 'CB' and Eurocheque International sc for anticompetitive agreements. The cartel was terminated by the Eurocheque General Assembly in 1991.


*(reported: 2026-11-11 11:35:03)*

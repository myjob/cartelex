# 'IV/33.440', 'Warner-Lambert/Gillette and Others'

**CELEX ID:** CELEX-31993D0252  
**Industry:** wetshaving products  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0252 | IV/33.440 |
| CELEX-31993D0252 | IV/33486  |

### Case Title
Warner-Lambert/Gillette and Others

### Overview
The European Commission investigated anticompetitive behavior in the wetshaving products market involving several companies, including The Gillette Company, Eemland Holdings NV, Warner-Lambert Company, La Société Bic SA, and Stora Kopparbergs Bergslags AB. The infringement was categorized as horizontal restraints under Article 85 of the EEC Treaty, specifically market sharing, quota cartels, and specialization agreements.

### Industry
wetshaving products

### Oecd Nace
manufacturing; 25.7:Manufacture of cutlery, tools and general hardware; 25.71: Manufacture of cutlery

### Companies Undertakings
| company                        |
|:-------------------------------|
| The Gillette Company           |
| Eemland Holdings NV            |
| Warner-Lambert Company         |
| La Société Bic SA              |
| Stora Kopparbergs Bergslags AB |

### Market
The market is oligopolistic and outside the EU, with significant geographical coverage across multiple European countries including Netherlands, Sweden, Italy, Germany, United Kingdom, France, Denmark, Spain, Greece, Belgium, Luxembourg, Portugal, and Ireland.

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-01-02 | Eemland | signed intellectual property agreement with Gillette |
| 1992-01-01 | Eemland | agreement expired |
| 1992-11-10 | Commission | issued decision to end infringement of Article 85 EEC Treaty |

### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |

The operative articles are Article 85 and Article 86, with the canonical concept being abuse_of_dominance, anticompetitive_agreement.

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption was sought by The Gillette Company.

### Leniency
NA

### Fines
NA

### Remedies
Gillette must dispose of its equity interest and creditor interest in Eemland; if not done within a set period, an independent third party will be appointed to carry out these disposals. Additionally, Gillette must re-assign to Eemland the Wilkinson Sword businesses including trademarks in the former German Democratic Republic, Czechoslovakia, Hungary, Poland, Turkey, former Yugoslavia, and EFTA countries.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Leon Brittan

### Courts
| court      | country            | jurisdiction   |
|:-----------|:-------------------|:---------------|
| COMMISSION | European Community | EEC Treaty     |
| US Court   | United States      | Federal        |

### Book Reference
IV/33.440

### Outcome
The Commission issued a decision to end the infringement of Article 85 EEC Treaty, imposing remedies on Gillette including disposal of equity and creditor interests in Eemland and re-assignment of Wilkinson Sword businesses.


*(reported: 2026-11-11 11:40:12)*

# 'IV/31.017', 'Fisher-Price/Quaker Oats Ltd  Toyco'

**CELEX ID:** CELEX-31988D0086  
**Industry:** toys  
**Cartel Period:** 1981-04-28 : 1985-08-05  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31988D0086 | IV/31017  |

### Case Title
Fisher-Price/Quaker Oats Ltd – Toyco

### Overview
This case involved anticompetitive agreements between Fisher-Price and Toyco Ltd, related to vertical restraints in the toys industry. The European Commission found that these agreements violated Article 85 of the EEC Treaty.

### Industry
toys

### Oecd Nace
OECD sector: manufacturing
NACE group code: 32.4: Manufacture of games and toys
NACE class code: 32.40: Manufacture of games and toys

### Companies Undertakings
| companies       |
|:----------------|
| Quaker Oats Ltd |
| Toyco Ltd       |

### Market
Relevant market: United Kingdom, Ireland
Market outside EU: False
Market oligopoly: NA
Market turbulence: NA

### Cartel Period
1981-04-28 : 1985-08-05

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-04-28 | Fisher-Price UK territory manager for Northern Ireland | communicated conditions of agreements with buying groups requiring direct delivery |
| 1982-11-23 | FisherPrice | sent letter to Toyco regarding group account |
| 1982-11-23 | Fisher-Price UK general sales manager | warned Toyco that it would close the Toyco buying group account unless Toyco provided assurance against supplying Irish members |
| 1982-11-25 | Toymaster Ltd | assured Fisher-Price UK that pressure was applied to Toyco and received unqualified assurance from Toyco director |
| 1985-08-05 | Fisher-Price Europe | informed Toyco that it will never again refuse to supply customers wishing to supply retailers or wholesalers in Southern Ireland or other EEC countries |
| 1985-08-19 | Fisher-Price Europe | sent memo explaining commercial policy |
| 1986-07-11 | Commission | initiated proceedings in the case |
| 1987-12-18 | Commission | issued Decision relating to a proceeding under Article 85 of the EEC Treaty |
| 1987-12-18 | Quaker Oats Ltd | imposed fine of 300 000 ECU |

### Legal Framework
Legal framework: Article 85 (operative article)
Canonical concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
| company | amount |
| --- | --- |
| Quaker Oats Ltd | 300 000 ECU |

### Remedies
A fine of 300,000 ECU was imposed on Quaker Oats Ltd as a behavioural remedy to terminate the infringement. No specific cease and desist order or structural remedy was issued.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
| court      | country   | jurisdiction                |
|:-----------|:----------|:----------------------------|
| Commission | EEC       | European Economic Community |

### Book Reference
NA

### Outcome
The European Commission found that Quaker Oats Ltd engaged in anticompetitive agreements under Article 85 of the EEC Treaty. A fine of 300,000 ECU was imposed on Quaker Oats Ltd as a behavioural remedy to terminate the infringement.


*(reported: 2026-11-11 11:09:10)*

# 'NA', 'NA'

**CELEX ID:** CELEX-31999D0474  
**Industry:** NA  
**Cartel Period:** 1985-01-01 : 1998-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0474 | IV/35992  |

### Case Title
NA

### Overview
The European Commission investigated anticompetitive agreements in the beer industry, focusing on exclusive dealing practices by Scottish and Newcastle plc. The case involved companies from multiple countries including the UK, Germany, and Finland. The cartel period spanned from February 6, 1962, to December 31, 2002. The infringement was categorized as vertical restraints under Article 81 of the EC Treaty, with a high gravity of infringement.

### Industry
beer

### Oecd Nace
trade (wholesaling and retailing) and hotels

NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.03: Manufacture of cider and other fruit wines

### Companies Undertakings
| company                               |
|:--------------------------------------|
| Scottish and Newcastle plc            |
| Scottish Licensed Trade Consultants   |
| Bavarian Lager Company                |
| trade associations                    |
| Finnish Petrol Retailers Organisation |

Countries:
- Scottish and Newcastle plc (GB)
- Scottish Licensed Trade Consultants (GB)
- Bavarian Lager Company (DE)
- Finnish Petrol Retailers Organisation (FI)

### Market
United Kingdom

Market outside EU: True

Market oligopoly: True

### Cartel Period
1962-02-06 : 2002-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1995-05-16 | Office of Fair Trading | issued press release on brewers' wholesale pricing policy |
| 1996-04-25 | Scottish and Newcastle plc | submitted application for negative clearance and exemption |
| 1996-04-25 | S&N | notified eight standard forms of leases |
| 1997-04-30 | S&N | reported worldwide turnover of GBP 3 349 million and retail division turnover of GBP 779 million |
| 1998-04-22 | S&N | informed Commission about releasing free-of-tie pubs and achieving rent increase |
| 1998-05-03 | S&N | recorded sales of 152 000 barrels of beer from 432 leased pubs |
| 1998-10-02 | S&N | confirmed in a letter that it will not use leases to exclude or unduly impede advertising for products of other undertakings |
| 1998-11-16 | S&N | was released from undertaking by UK competition authorities, allowing tying of 2 739 public houses |
| 2002-12-31 | redacted | exemption period ends on this date |
| 2002-12-31 | redacted | ceased to be applicable |

### Legal Framework
Article 81

Relevant articles:
- Article 81
- Article 85

Canonical concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure

### Infringement Gravity
high

### Exemption
Exemption sought and granted for Scottish and Newcastle plc.

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders issued by the Commission to terminate the infringement are mentioned in the provided text.

### Company Recidivism
| company                    | recidivism   |
|:---------------------------|:-------------|
| Scottish and Newcastle plc | False        |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
| court                   | country   | jurisdiction        |
|:------------------------|:----------|:--------------------|
| Court of First Instance |           |                     |
| Justices' Courts        | UK        | local courts of law |

### Book Reference
NA

### Outcome
The Commission took a decision, requested information, and granted an exemption to Scottish and Newcastle plc. No specific remedies were issued.


*(reported: 2026-10-16 22:16:48)*

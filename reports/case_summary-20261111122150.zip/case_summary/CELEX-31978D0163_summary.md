# 'IV/28.282', 'The Distillers Company Limited, Conditions of Sale and Price Terms'

**CELEX ID:** CELEX-31978D0163  
**Industry:** | industry           |
|:-------------------|
| alcoholic beverage |
| yeast              |
| chemical           |
| food product       |  
**Cartel Period:** 1973-01-01 : 1975-06-24  

## Summary

### Celex Case Id
CELEX-31978D0163

### Case Title
The Distillers Company Limited, Conditions of Sale and Price Terms

### Overview
The European Commission investigated The Distillers Company Limited (DCL) and several related companies for implementing anticompetitive practices in the sale of alcoholic beverages, specifically focusing on export restrictions and price terms that restricted trade within the EEC. The infringement was categorized as vertical under 'Territorial Exclusivity / Parallel Trade Bans' with high gravity. DCL was found to have recidivism, and leniency was granted to DCL with no fine imposed. The case is a landmark in the book reference IV/28.282.

### Industry
alcoholic beverage, yeast, chemical, food product

### Oecd Nace
manufacturing, 11.0:Manufacture of beverages, 11.01: Distilling, rectifying and blending of spirits

### Companies Undertakings
| The Distillers Company Limited          | NA         |
| John Dewar & Sons Ltd.                  | NA         |
| John Walker & Sons Ltd.                 | NA         |
| James Buchanan & Co. Ltd.               | NA         |
| Buchanan-Booth's Agencies Ltd.          | NA         |
| White Horse Distillers Ltd.             | NA         |
| Wm. Sanderson & Son Ltd.                | NA         |
| John Haig & Co. Ltd.                    | NA         |
| Distillers Agency Ltd.                  | NA         |
| A. & A. Crawford Ltd.                   | NA         |
| J. & G. Stewart Ltd.                    | NA         |
| Macdonald Greenlees Ltd.                | NA         |
| Slater Rodger & Co. Ltd.                | NA         |
| James Watson & Co. Ltd.                 | NA         |
| W. P. Lowrie & Co. Ltd.                 | NA         |
| Ainslie & Heilbron (Distillers) Ltd.    | NA         |
| John Gillon & Co. Ltd.                  | NA         |
| John Begg Ltd.                          | NA         |
| Bermore Distilleries Ltd.               | NA         |
| Peter Dawson Ltd.                       | NA         |
| Maclay Duff (Distillers) Ltd.           | NA         |
| Mitchell Bros. Ltd.                     | NA         |
| Bulloch Lade & Co. Ltd.                 | NA         |
| J. & R. Harvey & Co. Ltd.               | NA         |
| Daniel Crawford & Son Ltd.              | NA         |
| John Hopkins & Co. Ltd.                 | NA         |
| Baird-Taylor Ltd.                       | NA         |
| Donald Fisher Ltd.                      | NA         |
| D. & J. McCallum Ltd.                   | NA         |
| Low Robertson & Co. Ltd.                | NA         |
| John Robertson & Co. Ltd.               | NA         |
| J. & W. Hardie Ltd.                     | NA         |
| John Crabbie & Co. Ltd.                 | NA         |
| Tanqueray Gordon & Co. Ltd.             | NA         |
| Booth's Distilleries Ltd.               | NA         |
| Charles Tanqueray & Co. Ltd.            | NA         |
| Boord & Son Ltd.                        | NA         |
| J. & J. Vickers & Co. Ltd.              | NA         |
| Pimm's Ltd.                             | NA         |
| A. Bulloch & Co. of Eaglesham           | NA         |
| A. Bulloch (Agencies) Ltd of Catrine    | NA         |
| John Grant (Blenders) Ltd of Larkhall   | NA         |
| Inland Fisheries Ltd of Eaglesham       | NA         |
| Classic Wines Ltd of Glasgow            | NA         |
| Madison Benson and Carter Ltd of London | NA         |

### Market
NA

### Cartel Period
1973-01-01 : 1975-06-24

### Key Timeline
| 1973-01-01 | DCL | began implementing prohibited export and resale restrictions |
| 1973-06-30 | DCL | notified conditions of sale to Commission |
| 1975-06-24 | DCL | implemented price terms |
| 1975-07-04 | Commission | made request for information |
| 1975-07-08 | DCL | responded to Commission request by sending conditions of sale |
| 1975-07-11 | DCL | submitted text of circular letter and annexes to Commission |
| 1975-08-15 | Commission | sent letter requesting information under Article 11 of Regulation No 17 |
| 1977-03-31 | Commission | initiated proceedings in the case |
| 1977-04-22 | Commission | issued statement of objections to DCL |
| 1977-06-23 | DCL | attended hearing on Commission's objections |
| 1977-12-20 | Commission | issued final decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
| A. Bulloch & Co. of Eaglesham |
| A. Bulloch (Agencies) Ltd of Catrine, Ayrshire |
| John Grant (Blenders) Ltd of Larkhall |
| Inland Fisheries Ltd of Eaglesham |
| Classic Wines Ltd of Glasgow |
| Madison Benson and Carter Ltd of London |

### Leniency
| The Distillers Company Limited | No fine imposed |

### Fines
NA

### Remedies
The Commission ordered The Distillers Company Limited to ensure that the infringement referred to in Article 3 is brought to an end without delay. It required DCL and its subsidiary companies to refrain from all further action by means of their price terms calculated to restrict exportation from the United Kingdom into other EEC countries.

### Company Recidivism
| The Distillers Company Limited | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/28.282

### Outcome
The Commission ordered The Distillers Company Limited to ensure that the infringement referred to in Article 3 is brought to an end without delay. It required DCL and its subsidiary companies to refrain from all further action by means of their price terms calculated to restrict exportation from the United Kingdom into other EEC countries.


*(reported: 2026-11-11 10:21:46)*

# 'IV/26.992', 'WEA-Filipacchi Music S.A.'

**CELEX ID:** CELEX-31972D0480  
**Industry:** Music Industry  
**Cartel Period:** 1972-02-07 : 1972-02-24  

## Summary

### Celex Case Id
CELEX-31972D0480

### Case Title
WEA-Filipacchi Music S.A.

### Overview
This case involves a cartel in the French music industry, where WEA-Filipacchi Music S.A. and several other companies engaged in anti-competitive behavior by issuing circulars to set terms for agreements and reprimanding traders who refused to sign. The Commission uncovered the breach and initiated proceedings, resulting in a monetary penalty.

### Industry
Music Industry

### Oecd Nace
trade (wholesaling and retailing) and hotels

NACE_group_code: 59.2:Sound recording and music publishing activities

NACE_class_code: 59.20: Sound recording and music publishing activities

### Companies Undertakings
| companies                                                               | location         |
|:------------------------------------------------------------------------|:-----------------|
| WEA-Filipacchi Music S.A.                                               | Paris            |
| COGEDEP                                                                 | Paris            |
| S.A. Operating Company of the Gavelle and Co. Establishments, Discobole | Paris            |
| F.N.A.C. S.A.                                                           | Paris            |
| At the Good Store                                                       | Paris            |
| At the Spring                                                           | Paris            |
| Magenta Music                                                           | Paris            |
| Codimusic S.A.                                                          | Avignon          |
| S. Wolf                                                                 | Strasbourg       |
| C.M.N., Musical Counter of Normandy                                     | Rouen            |
| Establishments Discoparade                                              | Somain           |
| Disco-Centre A. Tessanne                                                | Clermont-Ferrand |
| Claude Ridel Instruments                                                | Caen             |
| Desforges and Co. S.A.                                                  | Le Havre         |
| Central Distribution Company, Radio-Television Equipment                | Clermont-Ferrand |
| Establishments ERBEL                                                    | Bordeaux         |
| D.E.M. Wholesale Records                                                | Nice             |
| Establishments Teleglobe                                                | Lyon             |
| Raphael House                                                           | Marseille        |

### Market
| country   |
|:----------|
| France    |
| Germany   |

market_outside_eu: true

### Cartel Period
1972-02-07 : 1972-02-24

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1972-02-07 | WEA-Filipacchi Music S.A. | issued circular initiating violation |
| 1972-02-07 | WEA-Filipacchi Music S.A. | issued circular setting terms for agreement |
| 1972-02-24 | WEA-Filipacchi Music S.A. | sent reminder circular to customers |
| 1972-02-24 | WEA-Filipacchi Music S.A. | reprimanded traders who refused to sign the agreement |
| 1972-06-28 | Commission | uncovered breach through verification |
| 1972-07-20 | Commission | initiated exofficio proceedings against WEA-Filipacchi Music S.A. |
| 1972-12-04 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion on the case |
| 1972-12-22 | Commission | issued decision concerning procedure under Article85 |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| WEA‑Filipacchi Music S.A. | 60000 accounting units |

### Remedies
monetary penalty

### Company Recidivism
| company | recidivism |
| --- | --- |
| WEA-Filipacchi Music S.A. | False |

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Commission of the European Communities | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision concerning procedure under Article 85, imposing a monetary penalty on WEA-Filipacchi Music S.A.


*(reported: 2026-11-11 10:02:25)*

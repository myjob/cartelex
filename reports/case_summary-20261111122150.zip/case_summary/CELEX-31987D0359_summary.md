# '87/359/CEE', 'reductions in air and sea transport fares available only to Spanish nationals resident in the Canary Islands and the Balearic Islands'

**CELEX ID:** CELEX-31987D0359  
**Industry:** transport  
**Cartel Period:** 1962 : 1986  

## Summary

### Celex Case Id
87/359/CEE

### Case Title
reductions in air and sea transport fares available only to Spanish nationals resident in the Canary Islands and the Balearic Islands

### Overview
The European Commission found that Spain's preferential transport fare arrangements for air and sea services, which were limited to Spanish nationals resident in the Canary Islands and the Balearic Islands, were incompatible with the EEC Treaty. The arrangements were introduced through various decrees and laws between 1962 and 1986, and the Commission made representations to Spain regarding their incompatibility. The Commission ultimately declared these provisions incompatible with the Treaty.

### Industry
transport

### Oecd Nace
OECD: transport; NACE: 51.10 Passenger air transport

### Companies Undertakings
| companies         |
|:------------------|
| Iberia            |
| Transmediterranea |

Companies are based in Spain (ES).

### Market
Spain

### Cartel Period
1962 : 1986

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-06-14 | Spain | introduced Decree-Law No 22/62 establishing preferential transport fare arrangements |
| 1962-06-14 | Spanish State | introduced State subsidies for air transport to the Canary Islands |
| 1981-12-29 | Spain | enacted Law No 46/81 defining special transport fare arrangements |
| 1981-12-29 | Spanish State | extended State subsidies for air and sea transport to the Balearic Islands |
| 1982-11-12 | Spanish State | clarified eligibility criteria for transport subsidies for Spanish nationals resident in the Balearic Islands, Las Palmas, and Santa Cruz de Tenerife |
| 1986-01-01 | Spain | maintained in force preferential transport fare arrangements beyond transition period |
| 1986-12-23 | Commission | made representations to Spanish Government regarding incompatibility with Treaty |
| 1987-02-05 | Commission | reiterated position on incompatibility of arrangements with Treaty |
| 1987-03-04 | Commission | reaffirmed position after receiving comments from Spanish authorities |
| 1987-06-22 | Commission | declared provisions incompatible with EEC Treaty and addressed to Kingdom of Spain |
| 1987-06-22 | Commission of the European Communities | issued decision concerning fare reductions

### Legal Framework
Article 90 (operative); infringement concept: public_undertaking

### Infringement Category
member states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Spain must inform the Commission within two months of notification of this Decision about the measures it has taken to comply with it.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission declared the Spanish preferential transport fare arrangements incompatible with the EEC Treaty and issued a decision addressing Spain.


*(reported: 2026-11-10 18:35:51)*

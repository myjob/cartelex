# 'IV/29.672', 'Floral'

**CELEX ID:** CELEX-31980D0182  
**Industry:** NA  
**Cartel Period:** 1968-05-10 : 1978-07-10  

## Summary

### Celex Case Id
CELEX-31980D0182

### Case Title
Floral

### Overview
This case involves a cartel among French fertilizer manufacturers and a German individual, operating through a joint venture company named Floral. The cartel operated from 1968 to 1978, engaging in anti-competitive cooperation that infringed Article 85(1) of the EEC Treaty. The European Commission investigated the practices, imposed fines on the companies involved, and ordered the termination of the infringement with the transfer of ownership of Floral to Mr Franz Schiffer.

### Industry
The products in question are compound fertilizers being exported to Germany by three French manufacturers.

### Oecd Nace
manufacturing (OECD), 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms (NACE group), 20.15: Manufacture of fertilisers and nitrogen compounds (NACE class)

### Companies Undertakings
| Compagnie Frangaise de I'Azote SA | FR |
| Genérale des Engrais SA | FR |
| CdF Chimie, Société Chimique des Charbonnages SA | FR |
| Mr Franz Schiffer | DE |
| Floral Düngemittelverkaufsgesellschaft mbH | DE |

### Market
Germany, oligopolistic market

### Cartel Period
1968-05-10 : 1978-07-10

### Key Timeline
| 1968-05-10 | Genérale des Engrais SA, Compagnie Frangaise de I'Azote SA, Société Chimique des Charbonnages SA, Mr Franz Schiffer | formed and managed company in joint venture |
| 1968-05-10 | companies concerned | began anti-competitive cooperation |
| 1968-05-10 | French manufacturers | began infringing Article 85(1) |
| 1968-05-10 | redacted | began cooperative arrangement restricting competition |
| 1968-05-10 | Genérale des Engrais SA, Compagnie Frangaise de IAzote SA, Société Chimique des Charbonnages SA, and Franz Schiffer | began cooperation through Floral Düngemittelverkaufsgesellschaft mbH |
| 1968-05-10 | Alfa GmbH | formed by Sociéeté des Produits Chimiques d'Auby, Société Chimique des Charbonnages, Société Produits Chimiques Péchiney-Saint Gobain, Société Genérale d'Engrais et de Produits Chimiques, and Mr. F. Schiffer |
| 1968-11-06 | Commission | gave negative clearance pursuant to Article 2 of Regulation No 17 |
| 1978-07-10 | companies concerned | ended anti-competitive cooperation |
| 1978-07-10 | Commission | commenced investigations on concerted practices |
| 1978-07-10 | redacted | infringement period ended due to notification |
| 1978-07-10 | redacted | notified cooperation to Commission |
| 1979-11-28 | Commission | issued Decision relating to cooperation through Floral |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
high

### Exemption
True

Applicants:
- Compagnie Frangaise de I'Azote SA
- Genérale des Engrais SA
- Société Chimique des Charbonnages SA

### Leniency
NA

### Fines
| Genérale des Engrais SA | 85 000 EUA |
| Compagnie Frangaise de I'Azote SA | 85 000 EUA |
| Société Chimique des Charbonnages SA | 85 000 EUA |

### Remedies
NA

### Company Recidivism
| Genérale des Engrais SA | True |
| Compagnie Frangaise de I'Azote SA | True |
| Société Chimique des Charbonnages SA | True |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| Court of Justice | European Union | European Economic Community |

### Book Reference
IV/29.672

### Outcome
Termination of the infringement and transfer of ownership of Floral to Mr Franz Schiffer


*(reported: 2026-11-11 10:29:04)*

# 'IV/33.640', 'Exxon/Shell'

**CELEX ID:** CELEX-31994D0322  
**Industry:** | industry      |
|:--------------|
| polyethylene  |
| polypropylene |  
**Cartel Period:** 1989-01-26 : 1993-12-31  

## Summary

### Celex Case Id
CELEX-31994D0322

### Case Title
Exxon/Shell

### Overview
The European Commission investigated a joint venture between Exxon and Shell in the polyethylene market, finding anticompetitive agreements under Article 85. The case involved companies from multiple countries including the US, UK, and France. The cartel period was from 1989 to 1993, with key events including submissions for exemptions and modifications of agreements. Remedies were imposed to ensure that competition is not restricted beyond what is indispensable for the smooth running of the plant.

### Industry
polyethylene, polypropylene

### Oecd Nace
manufacturing (20.1: Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms; 20.16: Manufacture of plastics in primary forms)

### Companies Undertakings
| Exxon Chemical International Inc. (US) |
| Shell International Chemical Company Limited (GB) |
| Exxon Chemical Polymers SNC (FR) |
| Shell Chimie SA (FR) |
| Société Francaise Exxon Chemical (FR) |
| Shell Nederland Chemie BV (NL) |
| Exxon Chemical Belgium (BE) |
| Exxon Corporation (US) |
| Union Carbide Corporation (US) |
| ECP (FR) |
| Compagnie Industrielle des Polyéthylènes de Normandie (FR) |

### Market
France, oligopolistic

### Cartel Period
1989-01-26 : 1993-12-31

### Key Timeline
| 1989-01-26 | Exxon | discussed pre-payment agreement with Shell |
| 1989-02-01 | Shell | outlined form of cooperation for Cape Project |
| 1991-11-21 | Exxon Chemical International Inc. | submitted application for negative clearance |
| 1991-12-02 | Shell International Petroleum Company Limited | submitted notification for exemption |
| 1992-04-03 | the parties | modified and notified the agreements |
| 1992-06-10 | Shell International Petroleum Company Limited | submitted notification for exemption |
| 1993-01-01 | Exxon | submitted first annual report on production and sale of LDPE, LLDPE and HDPE |
| 1993-01-01 | redacted | commencement of reporting obligations under exemption |
| 1993-12-31 | Shell | submitted first annual report on production and sale of LDPE, LLDPE and HDPE |
| 1994-05-18 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 |
| 1994-05-18 | Commission | issued decision addressed to Exxon Group and Seil Group |
| 1994-05-18 | redacted | issued decision |

### Legal Framework
Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
medium

### Exemption
True

Applicants:
| company |
| --- |
| Exxon Chemical International Inc. |
| Shell International Petroleum Company Limited |

### Leniency
False

### Fines
NA

### Remedies
The Commission required Exxon and Shell to modify their agreements such that: 1) Each party may make separate investments within the GIE without needing consent from the other if it does not impair the technical capabilities of the plant; 2) The Operating Committee was replaced by an Advisory Committee convened at the director’s discretion, limiting interference in day-to-day operations; 3) Parties can take over non-utilized production rights from the other party without prior consent. These behavioral remedies were necessary to ensure that competition is not restricted beyond what is indispensable for the smooth running of the plant.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| European Commission (European Union) |
| EC |

### Book Reference
IV/33.640

### Outcome
The Commission required Exxon and Shell to modify their agreements such that: 1) Each party may make separate investments within the GIE without needing consent from the other if it does not impair the technical capabilities of the plant; 2) The Operating Committee was replaced by an Advisory Committee convened at the director’s discretion, limiting interference in day-to-day operations; 3) Parties can take over non-utilized production rights from the other party without prior consent. These behavioral remedies were necessary to ensure that competition is not restricted beyond what is indispensable for the smooth running of the plant.


*(reported: 2026-11-11 11:44:44)*

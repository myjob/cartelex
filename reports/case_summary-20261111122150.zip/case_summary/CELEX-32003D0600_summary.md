# 'COMP/C.38.279/F3', 'French beef'

**CELEX ID:** CELEX-32003D0600  
**Industry:** | industry                      |
|:------------------------------|
| beef industry                 |
| meat wholesaling              |
| cattle farming                |
| pig farming                   |
| sheep farming                 |
| slaughter and meat-processing |  
**Cartel Period:** 2001-10-16 : 2001-11-30  

## Summary

### Celex Case Id
CELEX-32003D0600

### Case Title
French beef

### Overview
Six French agricultural federations were found to have entered into an agreement setting minimum purchase prices for cattle in October 2001, which was deemed an anticompetitive practice under Article 81 of the EC Treaty. The Commission intervened with information requests and formal notices, leading to a statement of objections in June 2002. Fines were imposed on several companies involved, and leniency was granted to some applicants. Remedies included ceasing and desisting from restrictive practices.

### Industry
beef industry, meat wholesaling, cattle farming, pig farming, sheep farming, slaughter and meat-processing

### Oecd Nace
agriculture, 10.1:Processing and preserving of meat, 10.11: Processing and preserving of meat

### Companies Undertakings
| companies                                                                |
|:-------------------------------------------------------------------------|
| Fédération nationale des syndicats d'exploitants agricoles               |
| Fédération nationale bovine                                              |
| Fédération nationale des producteurs de lait                             |
| Jeunes agriculteurs                                                      |
| Fédération nationale de l'industrie et des commerces en gros des viandes |
| Fédération nationale de la coopération bétail et viande                  |

### Market
France, Germany, Netherlands, Belgium, Britain, Spain; unprecedented crisis in the beef sector beginning October 2000, massive imbalance between supply and demand, considerable drop in prices, hard years for farmers, deep-seated malaise in the sector

### Cartel Period
2001-10-16 : 2001-11-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 2001-10-24 | six French federations | signed written agreement setting minimum purchase price for cattle |
| 2001-10-24 | French Minister for Agriculture | intervened in parliament and issued press release |
| 2001-10-24 | farmers' federations | used violence to compel slaughterers' federations to accept agreement |
| 2001-10-24 | FNB and FNPL | signed an agreement |
| 2001-10-24 | Ministry of Agriculture | welcomed agreement signed |
| 2001-10-24 | FNB | implemented agreement with import control measures |
| 2001-10-24 | farmers | began protests destroying imported meat |
| 2001-11-09 | Commission | wrote to five federations requesting information pursuant to Article 11 of Regulation No 17 |
| 2001-11-26 | Commission | sent letter of formal notice to federations |
| 2001-11-30 | federations | replied that agreement would end |
| 2002-06-24 | Commission | adopted statement of objections |
| 2002-06-30 | unknown | intervention price period ended |

### Legal Framework
Article 81, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM); Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
True

### Leniency
| company   | amount   |
|:----------|:---------|
| FNPL      | 30 %     |
| FNICGV    | 30 %     |
| FNCBV     | 30 %     |

### Fines
| company | amount |
| --- | --- |
| FNSEA | EUR 12 million |
| FNB | EUR 1,44 million |
| JA | EUR 600 000 |
| FNPL | EUR 1,44 million |
| FNICGV | EUR 720 000 |
| FNCBV | EUR 480 000 |

### Remedies
Cease and desist from any restrictive practice that has the same or an equivalent object or effect; bring the infringement to an end immediately if it has not already been done so; refrain from any future similar conduct.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario MONTI

### Courts
| court                                        | country   | jurisdiction   |
|:---------------------------------------------|:----------|:---------------|
| Court of Justice of the European Communities | France    | European Union |

### Book Reference
COMP/C

### Outcome
Statement of objections adopted by Commission; fines imposed; remedies ordered to cease and desist from restrictive practices.


*(reported: 2026-11-11 12:18:10)*

# 'IV/33.863 — Asahi/Saint-Gobain', 'Extra alloy'

**CELEX ID:** CELEX-31994D0896  
**Industry:** | industry                    |
|:----------------------------|
| automotive industry         |
| safety glass industry       |
| chemical industry           |
| automotive glazing industry |  
**Cartel Period:** 1990-03-30 : 2005-12-07  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0896 | IV/33863  |

### Case Title
IV/33.863 — Asahi/Saint-Gobain

### Overview
This case involves an anticompetitive agreement between Saint-Gobain Vitrage International and Asahi Glass Company Ltd in the automotive glazing industry, concerning bi-layer safety glass products. The agreement was found to be in breach of Article 85 of the EC Treaty, with a high gravity infringement. The Commission granted an exemption under Article 85(3) for a period of five years from the start of commercial production or until 7 December 2005, whichever was sooner.

### Industry
automotive industry
safety glass industry
chemical industry
automotive glazing industry

### Oecd Nace
manufacturing
23.1:Manufacture of glass and glass products
23.11: Manufacture of flat glass

### Companies Undertakings
| companies                          |
|:-----------------------------------|
| Saint-Gobain Vitrage International |
| Asahi Glass Company Ltd            |

### Market
The car market is constantly evolving in terms of design trends, customer preference, environmental considerations and government regulation. It is not easy to predict the eventual development of the market, nor can it be said whether bi-layer glass will replace conventional safety glass. The evolution of the market for safety glass is directly related to the evolution in the production of motor vehicles. Substantial research and development still has to be done, and commercial viability is still uncertain. Competition from other large chemical and glass companies is expected.

Geographical scope: France, Japan, Germany, United Kingdom, Italy
Outside EU: True

### Cartel Period
1990-03-30 : 2005-12-07

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-03-30 | Saint-Gobain Vitrage International and Asahi Glass Company Ltd | concluded Licence and Technical Assistance Agreement and Licence Agreement |
| 1991-01-03 | Saint-Gobain Vitrage International and Asahi Glass Company Ltd | made notification of agreements |
| 1992-12-07 | Commission | declared provisions of Article 85(3) inapplicable to agreements |
| 1992-12-07 | Saint-Gobain Vitrage International and Asahi Glass Company Ltd | amended Joint Venture Agreement |
| 1994-12-16 | Commission of the European Communities | issued Commission Decision |
| 2005-12-07 | parties | dissolved JVC and took measures for technology access and IP rights |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
True
Applicants:
| company                            |
|:-----------------------------------|
| Saint-Gobain Vitrage International |
| Asahi Glass Company Ltd            |

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an exemption under Article 85(3) for a period of five years from the start of commercial production or until 7 December 2005, whichever was sooner, with conditions that the parties must dissolve the JVC and take necessary measures to continue using bi-layer technology developed in common. No specific remedies or orders for termination of infringement were issued.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel Van Miert

### Courts
NA

### Book Reference
NA

### Outcome
The Commission granted an exemption under Article 85(3) for a period of five years from the start of commercial production or until 7 December 2005, whichever was sooner, with conditions that the parties must dissolve the JVC and take necessary measures to continue using bi-layer technology developed in common. No specific remedies or orders for termination of infringement were issued.


*(reported: 2026-10-16 20:42:20)*

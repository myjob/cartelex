# 'IV/AF 528', 'Extra alloy'

**CELEX ID:** CELEX-31982D0756  
**Industry:** footwear and leather industry  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0756 | IV/528    |

### Case Title
IV/AF 528 – Extra alloy

### Overview
The European Commission investigated an anticompetitive agreement within the French footwear and leather industry, specifically involving Fédération nationale de l'industrie de la chaussure de France (FNICF). The agreement was found to be in violation of Article 85 of the EC Treaty, which prohibits agreements that prevent, restrict or distort competition within the common market.

### Industry
footwear and leather industry

### Oecd Nace
OECD sector: manufacturing
NACE group code: 15.2: Manufacture of footwear
NACE class code: 15.20: Manufacture of footwear

### Companies Undertakings
Fédération nationale de l'industrie de la chaussure de France (FR)

### Market
France

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1981-11-25 | FNICF management bodies | reached gentlemen's agreement on footwear market measures |
| 1982-03-09 | Commission | initiated investigation |
| 1982-03-09 | Commission's officials | carried out investigation at FNICF head office |
| 1982-03-10 | Commission | continued investigation |
| 1982-03-10 | Commission's officials | carried out investigation at FNICF head office |
| 1982-03-10 | Secretary-General of FNICF | recorded written statement confirming verbal account of agreement |
| 1982-03-10 | Secretary-General of the FNICF | responded to inspector's request for documents |
| 1982-04-14 | Commission | communicated objections to Fédération |
| 1982-05-14 | Fédération nationale de l'industrie de la chaussure de France | expressed view on objections |
| 1982-05-14 | FNICF | agreed to submit to investigation under Articles 14 and 15 of Regulation No 17 |
| 1982-10-27 | Commission | imposed fine on Fédération |
| 1982-10-27 | Commission | imposed fine on FNICF |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
trade associations

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Fédération nationale de l'industrie de la chaussure de France | $5 0 0 0 units of account or FF 33 252.85 |

### Remedies
A fine of $5,000 units of account or FF 33,252.85 was imposed on Fédération nationale de l'industrie de la chaussure de France (FNICF) to terminate the infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission imposed a fine on Fédération nationale de l'industrie de la chaussure de France (FNICF) for its involvement in an anticompetitive agreement, thereby terminating the infringement.


*(reported: 2026-11-11 10:42:11)*

# 'IV/31.340', 'Mitchell Cotts/Sofiltra'

**CELEX ID:** CELEX-31987D0100  
**Industry:** air filtration equipment  
**Cartel Period:** 1984-07-01 : 1994-07-04  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0100 | IV/31340  |

### Case Title
Mitchell Cotts/Sofiltra

### Overview
This case involves the European Commission's decision regarding anticompetitive agreements in the air filtration equipment industry. The companies involved were Mitchell Cotts & Co. (Engineering) Limited, Sofiltra Poelman SA, and Mitchell Cotts Air Filtration Limited. The cartel period lasted from 1982 to 1986.

### Industry
air filtration equipment

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.1: Manufacture of glass and glass products
NACE class code: 23.14: Manufacture of glass fibres

### Companies Undertakings
| companies                                  |
|:-------------------------------------------|
| Mitchell Cotts & Co. (Engineering) Limited |
| Sofiltra Poelman SA                        |
| Mitchell Cotts Air Filtration Limited      |

### Market
Relevant market includes the United Kingdom and Ireland. No indication of oligopoly or turbulence.

### Cartel Period
1982-07-01 : 1986-12-17

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1984-06-28 | Mitchell Cotts Air Filtration Ltd | acquired business of air filtration equipment |
| 1984-07-01 | Joint Venture | entered into licence agreement effective |
| 1984-07-05 | Mitchell Cotts & Co. (Engineering) Limited and Sofiltra Poelman SA | concluded agreements |
| 1984-07-05 | Commission | granted exemption under Article 8(1) of Regulation No 17 |
| 1984-07-05 | M.C. Engineering and Sofiltra | made effective Agreements for creation of joint venture company |
| 1984-09-20 | M.C. Engineering and Sofiltra | submitted application for negative clearance |
| 1984-09-20 | Commission | notified agreement to Commission with application for negative clearance |
| 1986-12-17 | Commission | adopted decision |
| 1986-12-17 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 of the EEC Treaty |
| 1994-07-04 | Commission | exemption period ended, allowing Joint Venture to establish itself |

### Legal Framework
Legal framework applying to the case: the operative article is 'Article 85' and the canonical concept is 'anticompetitive_agreement'

### Infringement Category
license

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
Exemption was granted under Article 8(1) of Regulation No 17 for the following applicants:
| company                                    |
|:-------------------------------------------|
| Mitchell Cotts & Co. (Engineering) Limited |
| Sofiltra Poelman SA                        |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement as per the provided document.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission adopted a decision under Article 85 of the EEC Treaty, granting an exemption under Article 8(1) of Regulation No 17 for the joint venture company formed by Mitchell Cotts & Co. (Engineering) Limited and Sofiltra Poelman SA.


*(reported: 2026-10-16 20:12:48)*

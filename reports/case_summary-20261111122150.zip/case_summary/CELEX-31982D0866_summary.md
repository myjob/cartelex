# 'IV/29.629', 'Rolled zinc products and zinc alloys'

**CELEX ID:** CELEX-31982D0866  
**Industry:** zinc  
**Cartel Period:** 1971-05-04 : 1976-10-29  

## Summary

### Celex Case Id
CELEX-31982D0866

### Case Title
Rolled zinc products and zinc alloys

### Overview
This case involved a horizontal cartel in the zinc industry, specifically concerning rolled products of pure zinc, titanium zinc in strip or sheet form, and zinc alloys. The cartel activities occurred between 1971 and 1976, with various agreements and concerted practices concluded among several European zinc companies. The European Commission initiated proceedings in 1981 and issued a decision in December 1982, imposing fines on two of the companies involved and ordering them to cease the infringing practices.

### Industry
zinc

### Oecd Nace
manufacturing, 24.4:Manufacture of basic precious and other non-ferrous metals, 24.43: Lead, zinc and tin production

### Companies Undertakings
| company                                                       |
|:--------------------------------------------------------------|
| Compagnie Royale Asturienne des Mines                         |
| Rheinisches Zinkwalzwerk GmbH & Co. KG                        |
| Société des Mines et Fonderies de zinc de la Vieille-Montagne |
| Société Minière et Métallurgique de Penarroya                 |
| Société anonyme de Prayon                                     |
| Société Générale de Paris                                     |
| SAL Oppenheim                                                 |
| Penarroya SA                                                  |
| Société de Prayon SA                                          |

### Market
| country   |
|:----------|
| France    |
| Germany   |
| Belgium   |
| Italy     |
| Greece    |

### Cartel Period
1971-05-04 : 1976-10-29

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission | implemented Articles 85 and 86 of the Treaty |
| 1971-05-04 | CRAM and PYA | signed contract infringing Article 85 |
| 1974-08-05 | CRAM, RZ and VM | concluded contract concerning reciprocal provision of emergency supplies |
| 1976-10-21 | CRAM and RZ | began concerted practice |
| 1976-10-29 | CRAM and RZ | ended concerted practice |
| 1977-10-01 | CRAM and Prayon | concluded rationalization contract |
| 1979-01-01 | CRAM and Prayon | agreement took effect in full |
| 1979-02-08 | Commission Frangaise de la Concurrence | interpreted the agreement and acknowledged its restrictive effects on competition |
| 1981-06-09 | Commission | initiated proceedings |
| 1981-06-17 | Commission | complained to CRAM and Prayon about commitment under agreement of 1 October 1977 |
| 1982-09-23 | Advisory Committee | delivered opinion on restrictive practices |
| 1982-12-14 | the Commission of the European Communities | issued Commission Decision IV/29.629 relating to rolled zinc products and zinc alloys |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
Exemption sought but no applicants listed

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| CRAM | 400 000 ECU |
| Rheinische Zinkwalzwerk GmbH & Co. | 500 000 ECU |

### Remedies
The parties are ordered to bring to an end forthwith the infringements established and to refrain in future from any contractual provision or concerted practice having the same effect.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans ANDRIESSEN

### Courts
| court            | country   | jurisdiction   |
|:-----------------|:----------|:---------------|
| Court of Justice | Germany   | European Union |

### Book Reference
NA

### Outcome
Commission Decision IV/29.629 issued, fines imposed, remedies ordered


*(reported: 2026-11-11 10:43:31)*

# 'IV AF 356', 'NA'

**CELEX ID:** CELEX-31978D0024  
**Industry:** forging  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0024 | IV/356    |

### Case Title
IV AF 356

### Overview
The European Commission investigated an anticompetitive agreement involving the exchange of information on prices and sales among companies in the forging industry. The case centered on the Vereinigung deutscher Freiformschmieden, a German company involved in heavy forgings weighing over four tonnes.

### Industry
forging

### Oecd Nace
manufacturing (OECD), 28.4:Manufacture of metal forming machinery and machine tools (NACE group), 28.41: Manufacture of metal forming machinery (NACE class)

### Companies Undertakings
Vereinigung deutscher Freiformschmieden (DE)

### Market
Germany

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-01-18 | Vereinigung deutscher Freiformschmieden | refused to submit to investigation unless authorized by Commission Decision |
| 1977-12-08 | Commission | issued decision imposing obligations on Vereinigung deutscher Freiformschmieden |
| 1977-12-13 | Commission | began investigation in business premises of Vereinigung deutscher Freiformschmieden |

### Legal Framework
Article 85 (operative), Article 85 (all relevant)

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
fines of from 100 to 5000 units of account and periodic penalty payments of from 50 to 1000 units of account per day

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court                                        | country    | jurisdiction                |
|:---------------------------------------------|:-----------|:----------------------------|
| Court of Justice of the European Communities | Luxembourg | European Communities        |
| Federal Cartel Office                        | Germany    | European Economic Community |

### Book Reference
NA

### Outcome
The Commission issued a decision imposing obligations on Vereinigung deutscher Freiformschmieden, including fines and periodic penalty payments.


*(reported: 2026-11-11 10:18:56)*

# 'IV/D-2/34.780', 'Virgin/British Airways'

**CELEX ID:** CELEX-32000D0074  
**Industry:** air transport  
**Cartel Period:** 1993-04-01 : 1999-03-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32000D0074 | IV/34780  |

### Case Title
Virgin/British Airways

### Overview
The European Commission investigated British Airways plc and Virgin Atlantic Airways Limited for alleged anticompetitive practices under Articles 81, 82, 85, and 86 of the EC Treaty. The investigation focused on abuse of dominance, specifically involving vertical restraints such as discounts and rebates.

### Industry
air transport

### Oecd Nace
OECD sector: transport
NACE group code: 79.1: Travel agency and tour operator activities
NACE class code: 79.11: Travel agency activities

### Companies Undertakings
| company                         |
|:--------------------------------|
| British Airways plc             |
| Virgin Atlantic Airways Limited |

### Market
United Kingdom
Market outside EU: True

### Cartel Period
1993-04-01 : 1999-03-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-04-01 | British Airways | allocated marketing and training support fund for joint activities |
| 1993-07-09 | Virgin Atlantic Airways Limited | lodged complaint alleging infringements of Articles 81 and 82 of the Treaty |
| 1996-12-20 | Commission | issued initial Statement of Objections criticizing BA's arrangements with travel agents |
| 1997-03-27 | BA | submitted written response to Commission's Statement of Objections |
| 1997-11-12 | BA | made oral presentations at oral hearing and presented paper by Professor Pindyck |
| 1997-11-17 | BA | wrote to travel agents announcing revised approach to commission payments |
| 1997-12-01 | BA | implemented Performance Reward Scheme (PRS) |
| 1998-01-01 | British Airways plc | began extending abusive behavior to all UK travel agents |
| 1998-01-09 | BA | lodged supplementary complaint against BA's Performance Reward scheme |
| 1999-02-08 | BA | announced that the scheme would not be renewed for the year 1999/2000 |
| 1999-03-31 | British Airways plc | ended extended abusive behavior to all UK travel agents |
| 1999-07-14 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 82 of the EC Treaty

### Legal Framework
Law articles: 
- Article 81
- Article 82
- Article 85
- Article 86
Infringement concept: abuse_of_dominance, anticompetitive_agreement, public_undertaking

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
Discounts and Rebates

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| British Airways plc | EUR 6,8 million |

### Remedies
British Airways plc shall immediately bring to an end the infringements referred to in Article 1 and shall refrain from repeating any act or conduct described in Article 1, and from adopting any measure having equivalent effect.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                  | country        | jurisdiction   |
|:---------------------------------------|:---------------|:---------------|
| Court of Justice of the European Union | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission found British Airways guilty of abuse of dominance and imposed a fine of EUR 6.8 million. The case was decided by the Court of Justice of the European Union.


*(reported: 2026-11-11 12:03:25)*

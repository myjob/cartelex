# '80/334/EEC', 'imposing a fine on Fabbrica Pisana, Pisa, pursuant to Article 15 of Regulation No17'

**CELEX ID:** CELEX-31980D0334  
**Industry:** glass  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31980D0334 | IV/400-2  |

### Case Title
80/334/EEC - imposing a fine on Fabbrica Pisana, Pisa, pursuant to Article 15 of Regulation No17

### Overview
The case involves the European Commission's imposition of a fine on Fabbrica Pisana SpA for participating in an anticompetitive agreement under Article 85 of Regulation No 17. The infringement was related to horizontal restraints, specifically market sharing, quota cartels, and specialization agreements.

### Industry
glass

### Oecd Nace
manufacturing
23.1:Manufacture of glass and glass products
23.11: Manufacture of flat glass

### Companies Undertakings
Fabbrica Pisana SpA (IT)

### Market
Italy

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-02-06 | Commission of the European Communities | adopted Council Regulation No 17 |
| 1976-03-30 | Fabbrica Pisana | signed memorandum of agreement with Saint-Gobain, SIV-Società Italiana Vetro SpA, and Fabbrica Lastre di Vetro P. Sciarra SpA |
| 1976-03-30 | Fides | confirmed authority to collect information and perform checks |
| 1978-05-03 | Fabbrica Pisana | began investigation under Article 14 of Regulation No 17 |
| 1978-05-03 | Commission | initiated investigation under Article 14 of Regulation No 17 |
| 1978-07-10 | Fabbrica Pisana | concluded investigation under Article 14 of Regulation No 17 |
| 1978-07-10 | Commission's inspectors | examined correspondence files |
| 1979-01-30 | Fabbrica Pisana | was decided to be investigated by Commission |
| 1979-02-07 | Commission's inspectors | conducted investigation at Milan offices of Fides and took copies of documents |
| 1979-10-12 | Fabbrica Pisana | was heard pursuant to Article 19(1) of Regulation No 17 |
| 1979-11-30 | Advisory Committee on Restrictive Practices and Monopolies | delivered opinion pursuant to Article 10 of Regulation No 17 |
| 1979-12-20 | Commission of the European Communities | imposed a fine on Fabbrica Pisana

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Fabbrica Pisana SpA | 5 000 units of account or Lit 5 795 050 |

### Remedies
A fine of 5,000 units of account or Lit 5,795,050 was imposed on Fabbrica Pisana SpA.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed a fine of 5,000 units of account or Lit 5,795,050 on Fabbrica Pisana SpA for its involvement in an anticompetitive agreement under Article 85 of Regulation No 17.


*(reported: 2026-11-11 10:31:41)*

# 'IV/32.265', 'Concordato Incendio'

**CELEX ID:** CELEX-31990D0025  
**Industry:** industrial fire insurance  
**Cartel Period:** 1988-01-01 : 2010-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0025 | IV/32265  |

### Case Title
Concordato Incendio

### Overview
The European Commission investigated an anticompetitive agreement among companies in the Italian industrial fire insurance market. The agreement, entered into force in 1988, was found to constitute a horizontal price-fixing collusion under Article 85 of the EC Treaty.

### Industry
industrial fire insurance

### Oecd Nace
banking and insurance (including real estate) (NACE 65.11)

### Companies Undertakings
Concordato Italiano Incendio Rischi Industriali (IT)

### Market
Italy, oligopolistic market

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-01-01 | Concordato | entered into force |
| 1988-05-02 | Concordato Italiano Incendio Rischi Industriali | amended agreement approved by general meeting |
| 1989-12-20 | Commission | adopted decision |

### Legal Framework
Article 85 (anticompetitive_agreement)

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate the infringement.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action, and the infringement was not terminated by specific remedies.


*(reported: 2026-10-16 20:25:07)*

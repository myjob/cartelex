# 'IV/30.849', 'IBM personal computer'

**CELEX ID:** CELEX-31984D0233  
**Industry:** information-handling systems, equipment, and services  
**Cartel Period:** 1984-04-18 : 1984-04-18  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31984D0233 | IV/30849  |

### Case Title
IBM personal computer

### Overview
The European Commission investigated IBM's selective distribution system for personal computers and related products, determining that the system did not constitute an anticompetitive agreement under Article 85 of the EEC Treaty.

### Industry
information-handling systems, equipment, and services

### Oecd Nace
trade (wholesaling and retailing) and hotels

NACE group code: 26.2: Manufacture of computers and peripheral equipment

NACE class code: 26.20: Manufacture of computers and peripheral equipment

### Companies Undertakings
| companies                                    |
|:---------------------------------------------|
| IBM Europe SA                                |
| IBM UK International Products Ltd            |
| IBM Belgium Distribution Company SA          |
| IBM Danmark Produkt Distribution Selskab A/S |
| IBM Deutschland Produktvertrieb GmbH         |
| IBM EMEA Product Distribution Corporation    |
| IBM France Diffusion SA                      |
| IBM Ireland Product Distribution Ltd         |
| IBM Italia Distribuzione Prodotti Srl        |
| IBM Nederland Distributie BV                 |
| IBM UK Product Sales Ltd                     |

### Market
| country        |
|:---------------|
| United Kingdom |
| Belgium        |
| Denmark        |
| Germany        |
| Greece         |
| France         |
| Ireland        |
| Italy          |
| Netherlands    |
| Luxembourg     |

Market outside EU: False

### Cartel Period
2030-12-31 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-01-18 | IBM Europe SA | made application for negative clearance and notification concerning selective distribution system for IBM personal computer |
| 1983-10-25 | Court of Justice of the European Communities | handed down judgment in AEG-Telefunken case |
| 1984-04-18 | European Commission | adopted decision on selective distribution system and issued decision in proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85

Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Selective Distribution

### Infringement Gravity
low

### Exemption
False

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Frans Andriesen

### Courts
| court                                        | country        | jurisdiction   |
|:---------------------------------------------|:---------------|:---------------|
| Court of Justice of the European Communities | European Union | European Union |

### Book Reference
NA

### Outcome
The Commission took no action, concluding that IBM's selective distribution system did not violate Article 85 of the EEC Treaty.


*(reported: 2026-10-16 20:06:28)*

# 'IV/30.698– ECS/AKZO', 'relating to a proceeding under Article 86 of the EEC Treaty'

**CELEX ID:** CELEX-31985D0609  
**Industry:** | industry                 |
|:-------------------------|
| Polymer industry         |
| Flour additives industry |  
**Cartel Period:** 1979-01-01 : 1979-12-11  

## Summary

### Celex Case Id
CELEX-31985D0609

### Case Title
IV/30.698– ECS/AKZO

### Overview
AKZO Chemie BV was found guilty of abuse of dominance under Article 86 of the EEC Treaty for engaging in predatory pricing practices in the flour additives market. The company increased prices by 10% multiple times, threatened retaliation, and attempted to discipline competitors like ECS. A decision was adopted on December 14, 1985, imposing a fine of 10 million ECU and ordering specific remedies to cease discriminatory pricing and comply with price conditions.

### Industry
Polymer industry, Flour additives industry

### Oecd Nace
manufacturing (OECD), 20.5:Manufacture of other chemical products (NACE group), 20.59: Manufacture of other chemical products n.e.c. (NACE class)

### Companies Undertakings
AKZO Chemie BV (NL)

### Market
United Kingdom, Ireland, Netherlands, Belgium, Germany; oligopoly market

### Cartel Period
1979-01-01 : 1979-12-11

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1979-01-01 | AKZO UK | increased prices by 10% |
| 1979-06-20 | AKZO UK | discussed price increase for RHM and Spillers |
| 1979-07-02 | AKZO UK | increased prices by 10% |
| 1979-11-14 | AKZO UK | requested urgent meeting with ECS |
| 1979-11-16 | AKZO UK | made threats of retaliation in first meeting with ECS |
| 1979-12-02 | AKZO | failed to disclose crucial meeting memorandum to High Court |
| 1979-12-03 | AKZO | held discussions with ECS regarding cooperation on milling products |
| 1979-12-07 | AKZO | prepared confidential memorandum outlining plan to discipline ECS |
| 1979-12-07 | AKZO | issued memorandum to discipline ECS in flour additives business |
| 1979-12-11 | AKZO | planned aggressive commercial action against ECS if no response was received by midday |
| 1985-12-14 | Commission | adopted decision terminating operation of Decision 83/462/EEC |
| 1986-01-01 | AKZO Chemie BV | began five-year compliance period for flour additive pricing |

### Legal Framework
Article 86, abuse_of_dominance, anticompetitive_agreement

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| AKZO Chemie BV | 10 million ECU |

### Remedies
AKZO Chemie BV must cease offering discriminatory prices for flour additives in the EEC, refrain from aligning prices below those acceptable before the decision date, and comply with specific price conditions. Additionally, a fine of 10 million ECU was imposed.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court            | country        | jurisdiction   |
|:-----------------|:---------------|:---------------|
| Court of Justice | European Union | European Union |
| High Court       | United Kingdom | London         |
| Commission       | Netherlands    | European Union |

### Book Reference
IV/30.698

### Outcome
Commission adopted decision terminating operation of Decision 83/462/EEC; AKZO Chemie BV fined 10 million ECU and ordered to cease discriminatory pricing, refrain from aligning prices below acceptable levels, and comply with specific price conditions.


*(reported: 2026-11-11 11:00:23)*

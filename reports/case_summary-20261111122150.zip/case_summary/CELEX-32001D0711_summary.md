# 'COMP/F-2/36.693', 'Volkswagen'

**CELEX ID:** CELEX-32001D0711  
**Industry:** | industry                        |
|:--------------------------------|
| automotive manufacturing        |
| automotive parts and components |
| industrial motors               |
| spare parts                     |
| financial services              |
| insurance                       |  
**Cartel Period:** 1996-09-26 : 1999-09-06  

## Summary

### Celex Case Id
CELEX-32001D0711

### Case Title
Volkswagen

### Overview
The case involved Volkswagen AG and its dealers in an antitrust infringement related to resale price maintenance (RPM) in the automotive industry. The Commission found that Volkswagen AG engaged in anti-competitive practices by issuing circulars to maintain price discipline within its distribution network, which violated Article 81 of the EC Treaty. The infringement was classified as high gravity and resulted in a fine of EUR 30.96 million.

### Industry
automotive manufacturing
automotive parts and components
industrial motors
spare parts
financial services
insurance

### Oecd Nace
manufacturing
29.1:Manufacture of motor vehicles
29.10: Manufacture of motor vehicles

### Companies Undertakings
| company                                |
|:---------------------------------------|
| Volkswagen AG                          |
| Volkswagen and Audi dealer association |
| Volkswagen dealer council              |

### Market
Relevant market: Germany, Belgium, France, Netherlands, Spain, Italy, Sweden, Denmark, United Kingdom
Market structure: oligopoly
Market turbulence: NA

### Cartel Period
1996-09-26 : 1999-09-06

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1996-09-26 | Volkswagen AG | issued circular concerning price of new VW Passat |
| 1996-09-26 | Volkswagen AG | urging members of the distribution network to maintain price discipline |
| 1996-09-26 | Marketing Director for Germany | called on German Volkswagen dealers and garages to report breaches of price discipline |
| 1996-10-02 | Bernard Rütz | received written warning from Volkswagen AG |
| 1997-04-17 | Marketing Director for Germany | issued circular addressing dealers advertising Passat below RRP and called for warnings |
| 1997-04-17 | Volkswagen AG | distributed second circular confirming price restrictions |
| 1997-06-26 | Marketing Director for Germany | issued follow-up circular reiterating concerns about non-compliance with price discipline |
| 1997-06-26 | V Volkswag en AG | distributed third circular confirming price restrictions |
| 1998-01-01 | Volkswagen AG | implemented new dealer agreement terms |
| 1999-06-22 | Volkswagen AG | received statement of objections from Commission |
| 1999-09-06 | Volkswagen AG | sent circular annuling previous price restrictions |
| 2001-06-29 | Mario Monti | adopted decision imposing fine on Volkswagen AG for antitrust infringement |

### Legal Framework
Article 81
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Resale Price Maintenance (RPM)

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Volkswagen AG | EUR 30,96 million |

### Remedies
Volkswagen AG was required to end its anti-competitive pricing practices by 6 September 1999, and a fine of EUR 30.96 million was imposed.

### Company Recidivism
| company | recidivism |
| --- | --- |
| Volkswagen AG | NA |

### Case Commission Info Request
False

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                                  | country   | jurisdiction   |
|:---------------------------------------|:----------|:---------------|
| Court of Justice of the European Union | Belgium   | European Union |

### Book Reference
COMP/F-2/36.693

### Outcome
Volkswagen AG was required to end its anti-competitive pricing practices by 6 September 1999, and a fine of EUR 30.96 million was imposed.


*(reported: 2026-11-11 12:09:26)*

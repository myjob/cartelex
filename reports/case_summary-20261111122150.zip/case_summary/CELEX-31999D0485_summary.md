# 'IV/34.250', 'Europe Asia Trades Agreement'

**CELEX ID:** CELEX-31999D0485  
**Industry:** NA  
**Cartel Period:** 1991-03-05 : 1997-09-16  

## Summary

### Celex Case Id
CELEX-31999D0485

### Case Title
Europe Asia Trades Agreement

### Overview
This case involves a horizontal cartel in the shipping industry, specifically focusing on anticompetitive agreements among major shipping lines for Europe/Far East trade. The agreement was found to be in violation of EU competition law under Articles 85 and 86, leading to a Commission decision prohibiting the agreement.

### Industry
transport

### Oecd Nace
OECD & NACE classifications: transport; 32.9:Manufacturing n.e.c.; 32.99: Other manufacturing n.e.c.

### Companies Undertakings
| companies                                        |
|:-------------------------------------------------|
| CGM SA                                           |
| Hapag-Lloyd Container Linie GmbH                 |
| Kawasaki Kisen Kaisha Ltd                        |
| A.P. Moller — Maersk Line                        |
| Malaysian International Shipping Corporation Bhd |
| Mitsui O.S.K. Lines Ltd                          |
| Neptune Orient Lines Ltd                         |
| Nippon Yusen Kaisha                              |
| Oriental Overseas Container Line                 |
| P&O Nedlloyd Container Line Limited              |
| Cho Yang Shipping Co. Ltd                        |
| DSR-Senator Linie GmbH                           |
| Evergreen Marine Corp. (Taiwan) Ltd              |
| Hanjin Shipping Co. Ltd                          |
| Hyundai Merchant Marine Co. Ltd                  |
| Yangming Marine Transport Corp.                  |

### Market
Relevant market: geography (Belgium, Denmark, Finland, France, Germany, Iceland, Ireland, Netherlands, Norway, Sweden, United Kingdom, Hong Kong, Japan, Korea, North, Korea, South, Malaysia, Philippines, Singapore, Taiwan); structure (oligopoly); turbulence (NA)

### Cartel Period
1991-03-05 : 1997-09-16

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1991-03-05 | shipping lines including FEFC members and non-conference lines | signed FETTSCA agreement setting charges and surcharges for Europe/Far East trade |
| 1992-09-02 | Commission | was notified of an requested to exempt under Article 85(3) of the Treaty |
| 1992-11-26 | parties | agreed to limit capacity for supply |
| 1993-03-12 | parties | agreed to further limit capacity for supply |
| 1993-04-01 | EATA parties | increased freight rates |
| 1993-04-01 | parties | agreed to limit capacity for supply |
| 1993-06-14 | Commission | informed the former EATA parties that it had serious doubts as to whether any of the four conditions of Article 85(3) were satisfied |
| 1993-06-30 | parties | agreed to limit capacity for supply |
| 1993-07-01 | EATA parties | increased freight rates |
| 1994-10-19 | Commission | adopted decision prohibiting Trans-Atlantic Agreement |
| 1997-09-16 | EATA parties | terminated the agreement with effect from this date |
| 1999-04-30 | Commission | adopted decision concerning EATA infringement |

### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

### Leniency
False

### Fines
NA

### Remedies
Each undertaking referred to in Article 1 is hereby required to abstain from any similar agreement or practice in the future.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                               | country        | jurisdiction   |
|:------------------------------------|:---------------|:---------------|
| Court of Justice                    | European Union | European Union |
| General Court of the European Union | European Union | European Union |

### Book Reference
IV/M.190

### Outcome
Commission decision prohibiting the Trans-Atlantic Agreement


*(reported: 2026-11-11 12:01:06)*

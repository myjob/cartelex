# 'IV/30.570', 'Sole distribution agreements for whisky and gin'

**CELEX ID:** CELEX-31985D0562  
**Industry:** spirit  
**Cartel Period:** 1985-12-13 : 1986-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0562 | IV/30570  |

### Case Title
IV/30.570 – Sole distribution agreements for whisky and gin

### Overview
The European Commission investigated sole distribution agreements for whisky and gin, which were found to constitute anticompetitive agreements under Article 85 of the Treaty. The case involved numerous companies from various countries in the spirits industry.

### Industry
spirit

### Oecd Nace
OECD sector: manufacturing
NACE group code: 11.0: Manufacture of beverages
NACE class code: 11.04: Manufacture of other non-distilled fermented beverages

### Companies Undertakings
| companies                                             | location   |
|:------------------------------------------------------|:-----------|
| The Distillers Company plc                            | Edinburgh  |
| James Buchanan & Company Limited                      | NA         |
| Bulloch Lade & Company Limited                        | NA         |
| John Dewar & Sons Limited                             | NA         |
| John Haig & Company Limited                           | NA         |
| W.P. Lowrie & Company Limited                         | NA         |
| Wm. Sanderson & Son Limited                           | NA         |
| White Horse Distillers Ltd                            | NA         |
| J. & W. Hardie Limited                                | NA         |
| Tanqueray, Gordon & Company Limited                   | NA         |
| Booth's Distilleries Limited                          | NA         |
| The Distillers Agency Limited                         | NA         |
| Frans Verbunt & Co. BV                                | NA         |
| Henkell & Co.                                         | NA         |
| Sarma Penney Limited                                  | NA         |
| BV Im- en Export- maatschappij v/h Wilmerink & Muller | NA         |
| SA Cinzano et Co.                                     | NA         |
| De Danske Sprit-fabrikker                             | NA         |
| Pierre Riviere SA                                     | NA         |
| J. A. Verbunt BV                                      | NA         |
| Ets. Fourcroy SA                                      | NA         |
| Sohnlein Rheingold KG                                 | NA         |
| Hans Just                                             | NA         |
| Taittinger SA                                         | NA         |
| Fratelli Averna SpA                                   | NA         |
| Fratelli Rinaldi SpA                                  | NA         |
| Gio Buton & Co. SpA                                   | NA         |
| Martini & Rossi AG                                    | NA         |
| Corima SA                                             | NA         |
| Gilbeys of Ireland                                    | NA         |

### Market
Relevant market: Germany, Netherlands, France, Ireland

### Cartel Period
1970-03-03 : 1986-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1970-03-03 | White Horse Distillers Ltd and Corima SA | entered into agreement for 'White Horse' and Logan whiskies |
| 1983-07-01 | Commission of the European Communities | implemented new regulations with effect from 1 July 1983, initiating transition period until 31 December 1986 |
| 1985-12-13 | Commission of the European Communities | issued Commission decision relating to sole distribution agreements for whisky and gin |
| 1986-12-31 | Commission | ended transition period for application of Article 85 (1) of the Treaty to agreements in force on 1 July 1983 |
| 1987-01-01 | redacted | individual exemptions came into force |
| 1996-12-31 | redacted | exemption period ended |

### Legal Framework
Legal framework applying to the case: Article 85 (operative article), infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure; Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
NA

### Exemption
Exemption sought or granted: True
Applicants:
| company                         |
|:--------------------------------|
| Booth's Distileries Ltd         |
| Tanqueray, Gordon & Company Ltd |
| White Horse Distilers Ltd       |
| Martini & Rossi AG              |
| Frans Verbunt & Co. BV          |
| Corima SA                       |
| Gilbeys of Ireland              |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders for terminating infringement are mentioned in the document.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
NA

### Book Reference
NA

### Outcome
The Commission found that sole distribution agreements for whisky and gin were anticompetitive under Article 85 of the Treaty. Exemptions were granted to certain companies, but no specific remedies or orders for terminating the infringement were mentioned.


*(reported: 2026-10-16 20:01:11)*

# 'IV/34.689', 'Sea Containers v. Stena Sealink — Interim measures'

**CELEX ID:** CELEX-31994D0019  
**Industry:** NA  
**Cartel Period:** 1993-05-01 : 1993-07-16  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31994D0019 | IV/34689  |

### Case Title
Sea Containers v. Stena Sealink — Interim measures

### Overview
This case involved allegations of abuse of dominance by Stena Sealink Line in the ferry services market between the United Kingdom and Ireland. The Commission investigated the conduct of Sea Containers Ltd and Stena Sealink Line, among others, regarding their proposed ferry service and the use of existing facilities at Holyhead. The Commission concluded that there was a prima-facie case of abuse of dominance, leading to the adoption of interim measures.

### Industry
- marine cargo containers
- passenger, car and freight ferry services
- port facilities for car and passenger ferry operations

### Oecd Nace
OECD & NACE classifications: transport, 50.1:Sea and coastal passenger water transport, 50.10: Sea and coastal passenger water transport

### Companies Undertakings
| companies           |
|:--------------------|
| Sea Containers Ltd  |
| Stena Sealink Line  |
| Stena Sealink Ports |
| B&I Line plc        |

### Market
Relevant market: geography ('United Kingdom', 'Ireland'), structure ('oligopoly'), turbulence ('NA')

### Cartel Period
1993-07-16 : 1993-12-21

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-08-17 | SC and Sealink | held meeting discussing proposed ferry service and technical requirements |
| 1992-09-01 | SC and Sealink | met and discussed options for launching service |
| 1992-11-11 | parties | held meeting discussing use of existing facilities |
| 1992-11-17 | SC | announced publicly that it would commence a service from Holyhead in spring 1993 |
| 1993-04-15 | SC | lodged its complaint with the Commission |
| 1993-05-28 | SSP | approved application and timetable for 1993 and 1994 |
| 1993-06-21 | Sealink | wrote to Commission outlining terms for using existing facilities at Holyhead |
| 1993-07-16 | Sealink | began operating fast ferry service from Admiralty Pier Berth |
| 1993-10-01 | Sealink | made offer to SC of slot on west side between 13.20 and 14.00 |
| 1993-10-01 | Commission | concluded interim measures orderable due to prima-facie case of abuse |
| 1993-11-08 | SC | accepted offer despite reservations |
| 1993-12-21 | Commission | adopted this decision |

### Legal Framework
Article 86

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate an infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
True

### Book Reference
NA

### Outcome
The Commission concluded that interim measures were orderable due to a prima-facie case of abuse of dominance, but no specific remedies or orders were issued to terminate the infringement.


*(reported: 2026-10-16 20:48:37)*

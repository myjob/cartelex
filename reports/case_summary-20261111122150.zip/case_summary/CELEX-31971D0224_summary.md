# 'IV/26.760', 'GEMA'

**CELEX ID:** CELEX-31971D0224  
**Industry:** music industry  
**Cartel Period:** NA  

## Summary

### Celex Case Id
CELEX-31971D0224

### Case Title
GEMA

### Overview
The case involves GEMA, a German organization operating in the music industry. It was investigated by the European Commission for violations related to excessive pricing, discriminatory sales conditions, and prohibition to resale. The investigation followed a series of legal developments in Germany, including the establishment of laws on mediation of music-performance rights, management of copyrights, and the transfer of music copyrights to GEMA. The Commission initiated ex officio proceedings against GEMA in 1970, leading to a judgment by the Federal Court of Justice in 1971.

### Industry
music industry

### Oecd Nace
OECD sector: communication; NACE group code: 59.2; NACE class code: 59.20

### Companies Undertakings
GEMA (DE)

### Market
Germany, outside EU

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1933-07-04 | redacted | established law on mediation of music-performance rights |
| 1962-02-06 | Commission of the European Communities | issued Regulation No. 17 |
| 1965-09-09 | redacted | established law on management of copyrights and related rights |
| 1968-06-20 | authorized party | transferred music copyrights to GEMA |
| 1970-01-01 | redacted | implemented changes to rating procedure bylaws |
| 1970-06-03 | Commission of the European Communities | initiated ex officio proceedings against GEMA |
| 1970-06-09 | redacted | distribution plan established |
| 1970-06-10 | redacted | issued regulations for valuation procedure |
| 1970-06-10 | redacted | distribution plan established |
| 1971-03-03 | Federal Court of Justice | delivered judgment in case KZR5/70 |
| 1971-04-27 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion on the case |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
GEMA: False

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Franco M. Malfatti

### Courts
| court                                  | country   | jurisdiction         |
|:---------------------------------------|:----------|:---------------------|
| Commission of the European Communities | Germany   | European Communities |

### Book Reference
Excessive pricing, discriminatory sales conditions, and prohibition to resale

### Outcome
Cease and desist order to immediately stop the violations identified in Article 1 and Article 2; order to amend or repeal certain provisions in the statutes, rules of procedure for the rating process, licensing agreements, and statutes of the social fund within six months after the announcement of the decision


*(reported: 2026-11-11 09:52:48)*

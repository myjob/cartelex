# 'IV/30.099', 'Schlegel/CPIO'

**CELEX ID:** CELEX-31983D0622  
**Industry:** | industry                         |
|:---------------------------------|
| automotive                       |
| rubber and plastic manufacturing |  
**Cartel Period:** 1979-12-10 : 1985-03-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31983D0622 | IV/30099  |

### Case Title
Schlegel/CPIO

### Overview
The European Commission investigated an anticompetitive agreement between Schlegel Corporation (Canada) and Compagnie des produits industriels de l'ouest SA (France) in the automotive industry. The agreement involved the exchange of know-how for the production of weatherseals and wire carriers for motor vehicles.

### Industry
automotive, rubber and plastic manufacturing

### Oecd Nace
manufacturing, 29.3:Manufacture of parts and accessories for motor vehicles, 29.31: Manufacture of electrical and electronic equipment for motor vehicles

### Companies Undertakings
| companies                                        |
|:-------------------------------------------------|
| Schlegel Corporation                             |
| Compagnie des produits industriels de I'ouest SA |

### Market
The relevant market includes France, England, Germany, Spain, Ireland with presence outside the EU. The market is not described as oligopolistic or turbulent.

### Cartel Period
1980-04-01 : 1985-03-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1979-12-10 | Schlegel Corporation and Compagnie des produits industriels de l'ouest SA | concluded Know-How Communication Agreement |
| 1980-04-01 | CPIO | commenced obligation to use and purchase exclusively Schlegel wire carrier |
| 1980-05-20 | Schlegel Corporation and Compagnie des produits industriels de l'ouest SA | notified Commission of agreement |
| 1983-02-16 | Schlegel Corporation and Compagnie des produits industriels de l'ouest SA | submitted application for negative clearance |
| 1983-04-05 | Schlegel Corporation and Compagnie des produits industriels de l'ouest SA | amended the agreement |
| 1983-07-28 | Commission of the European Communities | decided to open proceeding |
| 1983-12-06 | Commission of the European Communities | issued Commission Decision |
| 1985-03-31 | redacted | period of inapplicability ends |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
medium

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
No remedies or orders were issued by the Commission to terminate the infringement; instead, the agreement was declared inapplicable under Article 85(3).

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission decided to open proceedings and issued a decision declaring the agreement inapplicable under Article 85(3). No remedies or fines were imposed.


*(reported: 2026-10-16 19:55:49)*

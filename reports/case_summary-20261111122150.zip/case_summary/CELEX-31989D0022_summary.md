# 'IV/31.900', 'BPB Industries plc'

**CELEX ID:** CELEX-31989D0022  
**Industry:** | industry           |
|:-------------------|
| gypsum products    |
| building materials |
| paper and board    |  
**Cartel Period:** 1984-08-31 : 1987-04-13  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31989D0022 | IV/31900  |

### Case Title
BPB Industries plc

### Overview
This case involved anticompetitive practices in the gypsum products market, specifically focusing on abuse of dominance and anticompetitive agreements. The European Commission investigated companies including BPB Industries plc, British Gypsum Ltd, and others for their involvement in a cartel that manipulated pricing and sourcing strategies.

### Industry
gypsum products, building materials, paper and board

### Oecd Nace
manufacturing, 23.6:Manufacture of articles of concrete, cement and plaster, 23.62: Manufacture of plaster products for construction purposes

### Companies Undertakings
| company                    |
|:---------------------------|
| BPB Industries plc         |
| British Gypsum Ltd         |
| Iberian Trading UK Limited |
| Epysa                      |
| Lafarge                    |
| GIL                        |
| Gypsum Industries plc      |
| Iberian Trading            |

### Market
Great Britain, Ireland

### Cartel Period
1984-08-31 : 1987-04-13

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Commission of the European Communities | adopted Council Regulation No 17 implementing Articles 85 and 86 |
| 1963-07-25 | Commission of the European Communities | issued Commission Regulation No 99/63/EEC on hearings under Article 19(1) and (2) |
| 1984-08-31 | redacted | discussed not buying imported plasterboard and continuing to source from BG |
| 1984-10-24 | chairman | reported on Super Schedule A pricing scheme at sales meeting |
| 1984-10-25 | chairman | continued reporting on Super Schedule A pricing scheme at sales meeting |
| 1985-01-16 | managing director of BG | requested marketing director to consider rewarding merchant loyalty |
| 1985-02-14 | managing director | stated that Super Schedule A scheme achieved desired result |
| 1985-03-01 | marketing director of BG | considered cost of payments under proposed loyalty scheme |
| 1986-01-01 | BG | applied and extended scheme of payments tying merchants |
| 1987-04-13 | BG | implemented a scheme of Super Schedule A prices in the whole of the United Kingdom |
| 1987-12-03 | Commission of the European Communities | initiated proceedings in case against BPB Industries plc |
| 1988-12-05 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 86 |
| 1988-12-05 | British Gypsum Ltd | imposed fine of ECU 3 million |
| 1988-12-05 | BPB Industries plc | imposed fine of ECU 150 000 |

### Legal Framework
Article 86, Article 85, Article 86

### Infringement Category
abuse_of_dominance, anticompetitive_agreement

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| British Gypsum Ltd | ECU 3 million |
| BPB Industries plc | ECU 150 000 |

### Remedies
Payment of fines into designated Commission accounts within three months, with automatic interest at ECU-based rate plus 3.5% if delayed.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| BPB Industries plc | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
| court            | country        | jurisdiction                |
|:-----------------|:---------------|:----------------------------|
| Court of Justice | United Kingdom | European Economic Community |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 86, imposing fines on British Gypsum Ltd and BPB Industries plc for their involvement in anticompetitive practices. The case was part of broader proceedings initiated by the Commission.


*(reported: 2026-11-11 11:15:57)*

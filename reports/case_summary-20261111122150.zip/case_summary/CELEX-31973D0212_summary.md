# NA

**CELEX ID:** CELEX-31973D0212  
**Industry:** potassium salts  
**Cartel Period:** NA  

## Summary

### Celex Case Id
CELEX-31973D0212

### Case Title
IV/791

### Overview
This case involves a cartel in the potassium salts industry, where companies from France, Germany, Netherlands, Italy, and Belgium engaged in horizontal restraints including market sharing, quota cartels, and exchange of information on prices and sales. The European Commission found infringements under Article 85 and ordered specific remedies to terminate the cooperation agreement and cease certain distribution practices.

### Industry
potassium salts

### Oecd Nace
OECD sector: mining; NACE group code: 08.9:Mining and quarrying n.e.c.; NACE class code: 08.91: Mining of chemical and fertiliser minerals

### Companies Undertakings
| companies                                                | location   |
|:---------------------------------------------------------|:-----------|
| Société Commerciale des Potasses et de I'Azote, S.a.r.l. | Paris      |
| Verkaufsgemeinschaft Deutscher Kaliwerke GmbH            | Hannover   |
| Kali und Salz AG                                         | Kassel     |
| Nederlandsche Kali-Import Maatschappij                   | Amsterdam  |
| Comptoir général des sels et engrais potassiques S.A.    | Brussels   |
| Compagnie belge des engrais potassiques S.A.             | Brussels   |
| Sali Potassici                                           | Milan      |
| Henri Vallette                                           | Hanover    |
| Kali-Chemie AG                                           | Hanover    |
| Kali-Union Verwaltungsgesellschaft                       | NA         |

### Market
Relevant market: geography (France, Germany, Netherlands, Italy, Belgium, Luxembourg); structure (oligopoly); turbulence (NA)

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-10-22 | GmbH Verkaufsgemeinschaft Deutscher Kaliwerke (VDK) and S.ar.l. Société Commerciale des Potasses d'Alsace (SCPA) | submitted notification IV/791 |
| 1962-10-22 | VDK | agreement notified with SCPA |
| 1970-12-31 | Kali und Salz AG | wound up |
| 1971-01-01 | Kali und Salz | succeeded VDK as party to SCPA agreement |
| 1971-01-15 | Kali und Salz | informed Commission about succeeding VDK |
| 1971-07-13 | SCPA and Kali und Salz | heard by regulatory authority |
| 1972-03-22 | Advisory Committee on Restrictive Practices and Monopolies | delivered opinion on restrictive practices |
| 1973-05-11 | redacted | European Commission issued decision finding infringements and ordering corrective actions |

### Legal Framework
Article 85; anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements; exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
True

Applicants:
- Société Commerciale des Potasses et de I'Azote, S.a.r.l., Paris
- Kali und Salz, A.G., Kassel

### Leniency
False

### Fines
NA

### Remedies
terminate the cooperation agreement and cease exchange of information in respect of distribution and production; cease selling in the Netherlands and Italy through a joint distributor; cease distributing its products in the Federal Republic of Germany through the agency of the Henri Vallette company or any other undertaking directly or indirectly controlled by Kali und Salz

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Société Commerciale des Potasses et de l'Azote, Kali und Salz | NA |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
IV/791

### Outcome
European Commission issued decision finding infringements and ordering corrective actions


*(reported: 2026-11-11 10:03:29)*

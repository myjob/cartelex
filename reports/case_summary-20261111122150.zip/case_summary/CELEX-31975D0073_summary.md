# 'IV/14.650', 'Bayerische Motoren Werke AG'

**CELEX ID:** CELEX-31975D0073  
**Industry:** automotive  
**Cartel Period:** 1973-11-16 : 1977-12-01  

## Summary

### Celex Case Id
CELEX-31975D0073

### Case Title
Bayerische Motoren Werke AG

### Overview
The European Commission investigated Bayerische Motoren Werke Aktiengesellschaft (BMW) for anticompetitive practices in the automotive industry. The case involved violations of Article 85 of the EC Treaty related to selective distribution systems. The infringement occurred between 1963 and 1973, with BMW using exclusive dealing, territorial exclusivity, and selective distribution arrangements that restricted competition. The Commission took action, resulting in a decision in December 1974. BMW was required to submit annual reports starting from 31 December 1975 detailing cases of refusal to conclude distribution agreements, termination or modification of such agreements, and instances where BMW dealers are refused permission to sell competing products.

### Industry
automotive

### Oecd Nace
manufacturing (29.32)

### Companies Undertakings
Bayerische Motoren Werke Aktiengesellschaft (DE)

### Market
Germany

### Cartel Period
1963-02-01 : 1973-01-01

### Key Timeline
1963-03-13: Bayerische Motoren Werke Aktiengesellschaft began using earlier agreements
1972-03-03: European Commission sent statement of objections to BMW regarding export prohibition
1973-01-01: Bayerische Motoren Werke Aktiengesellschaft began using new standard forms of agreement
1973-01-01: Bayerische Motoren Werke Aktiengesellschaft introduced standard form of agreement for main dealers and required them to use a new standard form when appointing retail dealers
1973-11-16: European Commission published essential content of BMW's notification
1974-09-26: Advisory Committee on Restrictive Practices and Dominant Positions delivered opinion on restrictive practices
1974-12-13: Bayerische Motoren Werke Aktiengesellschaft received decision from Commission
1977-12-31: Bayerische Motoren Werke Aktiengesellschaft exemption period ended

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Exclusive Dealing / Market Foreclosure;Territorial Exclusivity / Parallel Trade Bans;Selective Distribution

### Infringement Gravity
high

### Exemption
Bayerische Motoren Werke Aktiengesellschaft

### Leniency
NA

### Fines
NA

### Remedies
BMW is required to submit annual reports to the Commission starting from 31 December 1975, detailing cases of refusal to conclude distribution agreements, termination or modification of such agreements, and instances where BMW dealers are refused permission to sell competing products.

### Company Recidivism
False

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Francois-Xavier ORTOLI

### Courts
NA

### Book Reference
IV/14.650

### Outcome
Commission took action; BMW required to submit annual reports detailing cases of refusal to conclude distribution agreements, termination or modification of such agreements, and instances where BMW dealers are refused permission to sell competing products.


*(reported: 2026-10-16 19:15:06)*

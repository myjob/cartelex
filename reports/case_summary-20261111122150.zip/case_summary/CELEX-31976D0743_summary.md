# 'IV/28.996', 'Reuter/ BASF'

**CELEX ID:** CELEX-31976D0743  
**Industry:** | industry                        |
|:--------------------------------|
| motor industry                  |
| building industry               |
| furniture industry              |
| footwear industry               |
| electrical engineering industry |
| varnish industry                |
| glue industry                   |
| shipbuilding industry           |
| mechanical engineering industry |  
**Cartel Period:** 1971-06-25 : 1971-12-31  

## Summary

### Celex Case Id
CELEX-31976D0743

### Case Title
Reuter–BASF

### Overview
The case involves anticompetitive agreements in the chemical industry, specifically vertical restraints such as exclusive dealing and market foreclosure. The Commission found that BASF Aktiengesellschaft, Dr. Gottfried Reuter, and Gottfried-Reuter-Holding-GmbH engaged in practices infringing Article 85(1) of the EEC Treaty between June 25, 1971, and December 31, 1971. The Commission issued a decision to end the infringement.

### Industry
motor industry, building industry, furniture industry, footwear industry, electrical engineering industry, varnish industry, glue industry, shipbuilding industry, mechanical engineering industry

### Oecd Nace
manufacturing, 20.5:Manufacture of other chemical products, 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| companies                     |
|:------------------------------|
| BASF Aktiengesellschaft       |
| Dr Gottfried Reuter           |
| Gottfried-Reuter-Holding-GmbH |

*Country: DE*

### Market
Germany, market outside EU, oligopolistic market

### Cartel Period
1971-06-25 : 1971-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-06-25 | BASF Aktiengesellschaft | signed contract infringing Article 85(1) of the EEC Treaty |
| 1971-06-25 | Dr. Reuter | signed agreement with non-competition clause in Clause IX |
| 1971-06-26 | Dr. Reuter | signed licensing agreement with Elastogran GmbH and CAF |
| 1971-12-31 | Dr. Reuter | concluded contracts in relevant field |
| 1972-01-02 | BASF | granted irrevocable option to purchase remaining shares |
| 1975-01-27 | Dr. Reuter | lodged a complaint with the Commission |
| 1975-01-27 | Dr. Reuter | filed written application concerning BASF AG |
| 1976-06-15 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion pursuant to Article 10 of Regulation No 17 |
| 1976-07-26 | Commission | issued decision addressed to entities |
| 1976-07-26 | Commission of the European Communities | issued Commission Decision relating to proceeding under Article 85 |
| 1976-12-31 | Dr Reuter | performed business activities in relevant field

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought

### Leniency
NA

### Fines
NA

### Remedies
The undertakings shall forthwith bring to an end the infringement referred to in Article 1.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
G. M. Thomson

### Courts
NA

### Book Reference
IV/28.996

### Outcome
Commission Decision issued to end the infringement


*(reported: 2026-11-11 10:15:24)*

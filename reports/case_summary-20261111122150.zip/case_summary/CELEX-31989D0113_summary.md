# 'IV/30.979 and 31.394', 'Decca Navigator System'

**CELEX ID:** CELEX-31989D0113  
**Industry:** | industry                           |
|:-----------------------------------|
| maritime navigation systems        |
| navigation equipment manufacturing |
| radio navigation services          |  
**Cartel Period:** 1982 : 1987-01-01  

## Summary

### Celex Case Id
CELEX-31989D0113

### Case Title
Decca Navigator System

### Overview
This case involved anticompetitive agreements in the maritime navigation systems industry. Companies including Racal Decca, Racal Electronics plc, AP Radiotelefon A/S, NV Philips Gloeilampenfabrieken, and others were investigated for engaging in cartels related to marine user receivers and navigation equipment. The infringement period was from 1982 to 1987, with key events including licence agreements, notifications to the Commission, and eventual termination of agreements. The Commission took a decision under Articles 85 and 86 of the EEC Treaty, resulting in remedies that included the termination of agreements.

### Industry
maritime navigation systems, navigation equipment manufacturing, radio navigation services

### Oecd Nace
manufacturing (OECD), 26.5:Manufacture of instruments and appliances for measuring, testing and navigation; watches and clocks (NACE group), 26.51: Manufacture of instruments and appliances for measuring, testing and navigation (NACE class)

### Companies Undertakings
| companies                                 |
|:------------------------------------------|
| Racal Decca                               |
| Racal Electronics plc                     |
| AP Radiotelefon A/S                       |
| NV Philips Gloeilampenfabrieken           |
| Polytechnic Marine plc                    |
| Navstar SA                                |
| Philips                                   |
| Racal Group Services Limited              |
| Landesfischereiverband Schleswig-Holstein |
| Dansk Fiskeriforening                     |
| RS                                        |
| Racal Decca Marine Navigation Limited     |
| Polytechnic Electronics plc               |

### Market
United Kingdom, Denmark, Ireland, Netherlands, Germany, Norway, France, Finland, Sweden, Spain

### Cartel Period
1982 : 1987-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1983-01-01 | Racal Electronics plc | entered into licence agreement with AP Radiotelefon A/S |
| 1983-05-20 | Racal Group Services | made notification under Article 4 of Regulation No 17 |
| 1983-05-20 | Racal Group Services | notified Commission about licence agreement with AP |
| 1983-05-25 | Racal Decca and AP | held meeting to form steering committee |
| 1983-05-26 | Rauff & Sorensen | made application to Commission pursuant to Article 3 of Regulation No 17 |
| 1984-12-06 | Racal Decca | Commission issued announcement of decision under Article 15(6) of Regulation No 17 |
| 1987-01-01 | Racal Decca and AP | terminated all agreements |
| 1987-09-30 | Commission | initiated proceedings in this case by Decision |
| 1987-10-19 | Commission | issued statement of objections |
| 1987-11-05 | Racal Decca | signed a settlement agreement providing for discontinuance of legal action |
| 1987-12-04 | RS | signed a settlement agreement providing for discontinuance of legal action |
| 1988-12-21 | Commission | issued Commission Decision relating to proceeding under Articles 85 and 86 of the EEC Treaty

### Legal Framework
| law_article |
| --- |
| Article 85 |
| Article 86 |

Canonical concept: abuse_of_dominance, anticompetitive_agreement, public_undertaking

### Infringement Category
abuse_of_dominance, anticompetitive_agreement, public_undertaking

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
Exemption sought

### Leniency
NA

### Fines
NA

### Remedies
Termination of agreements with AP and PE-Navstar as of 1 January 1987.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                           | country     | jurisdiction   |
|:--------------------------------|:------------|:---------------|
| Vestre Landsret                 | Denmark     | Denmark        |
| Hanseatisches Oberlandesgericht | Germany     | Bremen         |
| Hoge Raad                       | Netherlands | Netherlands    |

### Book Reference
IV/30.979 and IV/30979

### Outcome
Termination of agreements with AP and PE-Navstar as of 1 January 1987.


*(reported: 2026-11-11 11:18:07)*

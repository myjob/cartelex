# '87/14/EEC', 'COMMISSION DECISION'

**CELEX ID:** CELEX-31987D0014  
**Industry:** | industry        |
|:----------------|
| cosmetics       |
| beauty products |
| perfumes        |
| hair-care       |
| toiletries      |  
**Cartel Period:** 1970-01-01 : 1993-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31987D0014 | IV/31428  |

### Case Title
87/14/EEC

### Overview
Commission Decision on anticompetitive agreements in the cosmetics industry, involving SECTA and Yves Rocher.

### Industry
cosmetics
beauty products
perfumes
hair-care
toiletries

### Oecd Nace
trade (wholesaling and retailing) and hotels
20.4:Manufacture of soap and detergents, cleaning and polishing preparations, perfumes and toilet preparations
20.42: Manufacture of perfumes and toilet preparations

### Companies Undertakings
Société d'études de chimie et de thérapie appliquées (SECTA) FR
Laboratoires de Cosmétologie Yves Rocher FR

### Market
France
Germany
Belgium
Luxembourg
Netherlands
United Kingdom
Spain

market outside EU: True
oligopoly: False
market turbulence: NA

### Cartel Period
1986-12-01 : 1992-01-14

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1985-01-15 | Yves Rocher | submitted notification and application for negative clearance |
| 1985-01-15 | Yves Rocher | notified contracts fulfilling exemption conditions |
| 1986-12-01 | Commission | amended franchise contracts removing resale-price-maintenance clauses |
| 1986-12-01 | Yves Rocher | deleted resale price maintenance provisions |
| 1986-12-01 | Yves Rocher | authorized cross supplies between franchisees |
| 1986-12-17 | Commission | Decision signed at Brussels |
| 1992-01-14 | Yves Rocher group | Decision expired on this date |
| 1992-01-14 | Commission | limited validity of Decision to this date |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans; Exclusive Dealing / Market Foreclosure; Franchising

### Infringement Gravity
medium

### Exemption
True
Société d'études de chimie et de thérapie appliquées (SECTA) Laboratoires de Cosmétologie Yves Rocher

### Leniency
False
NA
NA
NA

### Fines
NA

### Remedies
No specific orders or remedies for termination of infringement are mentioned in the provided context.

### Company Recidivism
NA

### Case Commission Info Request
False

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Peter Sutherland

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action, and the case was decided under an exemption framework.


*(reported: 2026-10-16 20:14:39)*

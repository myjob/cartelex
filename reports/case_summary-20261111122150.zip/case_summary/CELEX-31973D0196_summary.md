# NA

**CELEX ID:** CELEX-31973D0196  
**Industry:** | industry                           |
|:-----------------------------------|
| photographic products              |
| photochemical products             |
| photographic films                 |
| photographic paper                 |
| photographic equipment             |
| sensitive products for radiography |
| accessories                        |  
**Cartel Period:** 1963-01-31 : 1971-02-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31973D0196 | IV/14111  |

### Case Title
NA

### Overview
This case involves the European Commission's investigation into anticompetitive agreements among German companies in the photographic products industry. The companies were found to have engaged in vertical restraints, specifically territorial exclusivity and parallel trade bans, which violated Article 85 of the EC Treaty.

### Industry
photographic products, photochemical products, photographic films, photographic paper, photographic equipment, sensitive products for radiography, accessories

### Oecd Nace
manufacturing, 20.1:Manufacture of basic chemicals, fertilisers and nitrogen compounds, plastics and synthetic rubber in primary forms, 20.13: Manufacture of other inorganic basic chemicals

### Companies Undertakings
| companies                              |
|:---------------------------------------|
| Adox Fotowerke Dr. C. Schleussner GmbH |
| Du Pont Fotowerke Adox GmbH            |
| Du Pont de Nemours (Deutschland) GmbH  |

### Market
Germany, false

### Cartel Period
1962-03-13 : 1973-06-14

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-03-13 | Adox Fotowerke Dr. C. Schleussner GmbH | entered into force of Regulation No 17 |
| 1963-01-31 | Adox Fotowerke Dr. C. Schleussner GmbH | submitted notification as precaution under Regulation No 17 |
| 1971-02-01 | Du Pont Fotowerke Adox GmbH | eliminated restrictive clauses from standard contracts |
| 1972-11-24 | Commission of the European Communities | published summary of notification in Official Journal |
| 1973-03-27 | Advisory Committee on Restrictive Practices and Monopolies | delivered Opinion pursuant to Article 10 of Regulation No 17 |
| 1973-06-14 | redacted | issued formal decision |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
low

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
No specific orders or remedies were issued by the Commission to terminate the infringement. The decision was based on voluntary elimination of restrictive clauses by the company.

### Company Recidivism
| companies                                                           | recidivism   |
|:--------------------------------------------------------------------|:-------------|
| Adox Fotowerke Dr. C. Schleussner GmbH, Du Pont Fotowerke Adox GmbH | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
False

### Book Reference
NA

### Outcome
The Commission found that the companies had engaged in anticompetitive agreements, but no specific remedies were ordered as the companies voluntarily eliminated restrictive clauses before the final decision was issued.


*(reported: 2026-10-16 19:14:50)*

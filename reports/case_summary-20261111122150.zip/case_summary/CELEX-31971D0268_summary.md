# 'IV/AF 239', 'NA'

**CELEX ID:** CELEX-31971D0268  
**Industry:** roofing  
**Cartel Period:** No infringement period can be determined from the provided timeline. The events described are related to procedural steps under Regulation No 17 and the EEC Treaty, but do not specify a period of collusive conduct or competition rule violations. Dates related to the actual infringement are not present in the table.  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31971D0268 | IV/239    |

### Case Title
IV/AF 239

### Overview
This case involves the European Commission's decision regarding an infringement of Article 85 of the EEC Treaty, related to cartel behavior in the roofing industry. The investigation focused on Asphaltoid-Keller S.A., a company based in Huningue, France.

### Industry
roofing

### Oecd Nace
OECD sector: manufacturing
NACE group code: 23.9:Manufacture of abrasive products and non-metallic mineral products n.e.c.
NACE class code: 23.99: Manufacture of other non-metallic mineral products n.e.c.

### Companies Undertakings
| companies              | location   |
|:-----------------------|:-----------|
| Asphaltoid-Keller S.A. | Huningue   |

### Market
Geographical market includes France and Germany.

### Cartel Period
2030-12-31 : 1900-01-01

### Key Timeline
| event         | actor      | predicate object                        |
|---------------|------------|-----------------------------------------|
| 1971-07-02    | redacted   | issued decision under Article 85 of the EEC Treaty |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
The Commission may impose fines of one hundred to five thousand accounting units for intentionally or negligently providing incorrect information or failing to provide required information within the deadline set in a decision. Additionally, coercive fines of fifty to one thousand billing units may be imposed for each day of delay to compel compliance with the request.

### Remedies
The Commission may impose fines of one hundred to five thousand accounting units for intentionally or negligently providing incorrect information or failing to provide required information within the deadline set in a decision. Additionally, coercive fines of fifty to one thousand billing units may be imposed for each day of delay to compel compliance with the request.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Franco M. MALFATTI

### Courts
| court                                  | country    | jurisdiction   |
|:---------------------------------------|:-----------|:---------------|
| Court of Justice of the European Union | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision under Article 85 of the EEC Treaty, imposing fines for non-compliance with information requests.


*(reported: 2026-10-16 18:57:42)*

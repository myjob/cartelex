# 'IV/30.525', 'International Energy Agency'

**CELEX ID:** CELEX-31983D0671  
**Industry:** NA  
**Cartel Period:** 1982-01-05 : 1993-12-31  

## Summary

### Celex Case Id
CELEX-31983D0671

### Case Title
International Energy Agency

### Overview
This case involves a cartel in the oil industry, where companies coordinated on exchange of information on prices and sales through the International Energy Agency. The European Commission found infringement under Article 85, but exemptions were granted to some applicants.

### Industry
crude oil, all petroleum products, all refinery feedstock, all finished products produced in association with natural gas and crude oil, possibly synthetic fuels

### Oecd Nace
OECD sector: mining, NACE group code: 06.1: Extraction of crude petroleum, NACE class code: 06.10: Extraction of crude petroleum

### Companies Undertakings
| companies                                  | location   |
|:-------------------------------------------|:-----------|
| Atlantic Richfield Company                 | NA         |
| Arco Petroleum Products Company            | NA         |
| The British National Oil Corporation       | NA         |
| British Petroleum Company PLC              | NA         |
| Cities Service Company                     | NA         |
| Conoco Inc.                                | NA         |
| Daikyo Oil Co., Ltd                        | NA         |
| Exxon Corporation                          | NA         |
| Gulf Oil Corporation                       | NA         |
| Gulf Trading & Transportation Co.          | NA         |
| Hispanica de Petroleos, SA (Hispanoil)     | NA         |
| Idemitsu Kosan Co., Ltd                    | NA         |
| Mabanaft GmbH                              | NA         |
| Maruzen Oil Co., Ltd                       | NA         |
| Mobil Oil Corporation                      | NA         |
| Murphy Oil Company                         | NA         |
| Nippon Mining Co., Ltd                     | NA         |
| Occidental Petroleum Corp.                 | NA         |
| Petrofina SA                               | NA         |
| Petroleos de Portugal, EP (Petrogal)       | NA         |
| Phillips Petroleum                         | NA         |
| Saarbergwerke AG                           | NA         |
| Shell International Petroleum Co., Ltd     | NA         |
| Standard Oil Company of California         | NA         |
| Standard Oil Company (Indiana)             | NA         |
| Standard Oil Company of Ohio               | NA         |
| Sohio Supply Company                       | NA         |
| Statoil                                    | NA         |
| Sun Company                                | NA         |
| Svenska Petroleum AB                       | NA         |
| Texaco Inc.                                | NA         |
| Union Rheinische Braunkohlen Kraftstoff AG | NA         |
| Union Oil Company of California            | NA         |
| Veba Öl AG                                 | NA         |
| Wintershall AG                             | NA         |

### Market
Relevant market: geography (United States, United Kingdom, Germany, Belgium, France, Spain, Japan, Norway, Sweden), structure (oligopoly), turbulence (NA)

### Cartel Period
1900-01-01 : 2030-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1974-11-18 | redacted | signed agreement on international energy program |
| 1982-01-05 | Chairman of the Industry Advisory Board of the International Energy Agency | submitted notification and application for negative clearance |
| 1983-12-12 | Commission of the European Communities | issued decision relating to proceeding under Article 85 |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
medium

### Exemption
| company                                |
|:---------------------------------------|
| Atlantic Richfield Company             |
| British National Oil Corporation       |
| British Petroleum Company PLC          |
| Cities Service Company                 |
| Conoco Inc.                            |
| Daikyo Oil Co., Ltd                    |
| Exxon Corporation                      |
| Gulf Oil Corporation                   |
| Hispanica de Petroleos, SA (Hispanoil) |
| Idemitsu Kosan Co., Ltd                |
| Mabanaft GmbH                          |
| Maruzen Oil Co., Ltd                   |
| Mobil Oil Corporation                  |
| Murphy Oil Company                     |
| Nippon Mining Co., Ltd                 |
| Occidental Petroleum Corp.             |
| Petrofina SA                           |

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders for terminating infringement are mentioned in the document.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriessen

### Courts
NA

### Book Reference
IV/30.525

### Outcome
The case involved an anticompetitive agreement under Article 85, with an exemption granted to several applicants.


*(reported: 2026-10-16 22:00:52)*

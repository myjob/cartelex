# 'IV/36.592', 'C. 27/97'

**CELEX ID:** CELEX-31999D0573  
**Industry:** telecommunications  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31999D0573 | IV/34.857 |
| CELEX-31999D0573 | IV/36592  |

### Case Title
C. 27/97

### Overview
The case concerns anticompetitive agreements in the telecommunications sector involving joint ventures among companies such as Vivendi SA, British Telecommunications plc, Mannesmann AG, and SBCI Inc. The agreements were deemed pro-competitive and exempted under Article 81(3) of the EC Treaty and Article 53(3) of the EEA Agreement for a period of 10 years from 18 July 1997.

### Industry
telecommunications

### Oecd Nace
OECD sector: communication
NACE group code: 61.9:Other telecommunications activities
NACE class code: 61.90: Other telecommunications activities

### Companies Undertakings
| companies                      |
|:-------------------------------|
| Vivendi SA                     |
| British Telecommunications plc |
| Mannesmann AG                  |
| SBCI Inc.                      |

### Market
France
Market is oligopolistic
No information on market turbulence

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1997-05-14 | unknown | established agreements concerning the operation |
| 1998-01-01 | France Télécom | began full liberalisation of telecommunications market |
| 1999-05-20 | Commission | made decision addressed to named entities |

### Legal Framework
Article 81 (operative)
All relevant articles: Article 81
Infringement concept: anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
True
Applicants:
| company |
| --- |
| Vivendi SA |
| British Telecommunications plc |
| Mannesmann AG |
| SBCI Inc |

### Leniency
False
No applicants, no grants or rejections

### Fines
NA

### Remedies
No orders or remedies were issued by the Commission to terminate an infringement because the agreements were deemed pro-competitive and exempted under Article 81(3) of the EC Treaty and Article 53(3) of the EEA Agreement for a period of 10 years from 18 July 1997. No cease-and-desist orders, structural, or behavioral remedies were imposed.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
IV/34.857
Strategic and technological alliances

### Outcome
NA


*(reported: 2026-11-11 12:01:22)*

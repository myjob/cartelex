# 'COMP/38.369', 'T-Mobile Deutschland/O2 Germany: Network Sharing Rahmenvertrag'

**CELEX ID:** CELEX-32004D0207  
**Industry:** | industry                                             |
|:-----------------------------------------------------|
| Digital mobile radiocommunications equipment         |
| Wholesale access to national roaming for 3G services |
| Retail mobile services (voice and data)              |
| Mobile network operations and service provision      |  
**Cartel Period:** 2002-01-01 : 2008-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32004D0207 | IV/38369  |

### Case Title
T-Mobile Deutschland/O2 Germany: Network Sharing Rahmenvertrag

### Overview
The European Commission investigated a network sharing agreement between T-Mobile Deutschland and O2 Germany, which was found to constitute an anticompetitive agreement under Article 81 EC. The agreement involved cooperation in providing roaming services and was granted an exemption under Articles 81(3) EC/53(3) EEA with specific conditions.

### Industry
Digital mobile radiocommunications equipment, Wholesale access to national roaming for 3G services, Retail mobile services (voice and data), Mobile network operations and service provision

### Oecd Nace
OECD sector: communication
NACE group code: 61.2:Wireless telecommunications activities
NACE class code: 61.20: Wireless telecommunications activities

### Companies Undertakings
| companies                      |
|:-------------------------------|
| T-Mobile Deutschland GmbH      |
| O2 Germany & Co OHG            |
| Deutsche Telekom AG            |
| T-Mobile International AG      |
| mmO2 plc                       |
| British Telecommunications plc |
| RegTP                          |
| BKartA                         |
| D2 Vodafone                    |
| E-Plus                         |

### Market
Germany, oligopoly market, no turbulence information available

### Cartel Period
2001-09-20 : 2008-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 2001-07-09 | unknown | concluded general agreement |
| 2002-02-06 | T-Mobile Deutschland and O2 Germany | began applying provisions of EC Treaty and EEA Agreement |
| 2002-02-06 | the Parties | notified Commission of agreement |
| 2002-02-06 | Commission | exemption took effect |
| 2003-01-01 | O2 Germany | began roaming on TMobile's network |
| 2003-01-22 | Parties | amended notified Agreement to reinforce terms of wholesale national roaming rights |
| 2003-05-21 | Parties | amended agreement to reflect phased-out roaming areas |
| 2003-07-16 | European Commission | issued Commission Decision relating to network sharing agreement |
| 2005-12-31 | O2 Germany | became active as competitor offering nationwide 3G coverage |
| 2008-12-31 | Parties | ended national roaming agreement |
| 2008-12-31 | T-Mobile Deutschland and O2 Germany | ended applicability of EC Treaty and EEA Agreement provisions |
| 2008-12-31 | Commission | exemption expired |

### Legal Framework
Law articles: Article 81, Article 82
Canonical concept: abuse_of_dominance, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
horizontal

### Infringement Gravity
high

### Exemption
True
Applicants:
| company              |
|:---------------------|
| T-Mobile Deutschland |
| O2 Germany & Co OHG  |

### Leniency
False

### Fines
NA

### Remedies
The Commission granted an exemption under Articles 81(3) EC/53(3) EEA for cooperation between T-Mobile and O2 Germany, with conditions including time-limited access to roaming, geographic coverage limitations, requirements for independent network planning, and restrictions on resale of roaming rights.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 22:30:15)*

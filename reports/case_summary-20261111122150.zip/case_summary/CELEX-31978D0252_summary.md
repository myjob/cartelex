# 'IV/29.176', 'Vegetable parchment'

**CELEX ID:** CELEX-31978D0252  
**Industry:** NA  
**Cartel Period:** 1973-01-01 : 1975-02-12  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31978D0252 | IV/29176  |

### Case Title
Vegetable parchment

### Overview
This case involves a cartel of companies engaged in the production and supply of vegetable parchment, found to have violated Article 85 of the EEC Treaty through horizontal restraints. The cartel was active from 1973 to 1975, engaging in concerted practices including exchange of information on prices and sales, and implementing price increases and surcharges.

### Industry
processing and preserving of fruit and vegetables

### Oecd Nace
OECD sector: manufacturing
NACE group code: 10.3:Processing and preserving of fruit and vegetables
NACE class code: 10.39: Other processing and preserving of fruit and vegetables

### Companies Undertakings
| companies                                     |
|:----------------------------------------------|
| Papeteries Alamigeon & Lacroix SA             |
| Papeteries Dalle & Lecomte SA                 |
| Cartiere Burgo SpA                            |
| Feldmühle AG                                  |
| 4 P Nicolaus Kempten GmbH                     |
| 4 P Rube Göttingen GmbH                       |
| Schleipen & Erkens AG                         |
| G. A. Serlachius OY                           |
| Wiggins Teape Limited                         |
| Genuine Vegetable Parchment Association       |
| Syndicat des Fabricants de Papiers Sulfurisés |
| Vereinigung Echt Pergament                    |

### Market
Relevant market: Germany, France, Italy, Netherlands, United Kingdom, Ireland, Denmark; oligopolistic structure; no turbulence

### Cartel Period
1973-01-01 : 1975-02-12

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-01-01 | Alamigeon, Dalle & Lecomte, Feldmühle, Nicolaus, Schleipen & Erkens and Wiggins Teape | engaging in a concerted practice to supply vegetable parchment on the British market to the exclusion of all others |
| 1973-01-01 | redacted | began restricting competition within the common market |
| 1973-06-19 | GVPA members | agreed percentage increases for export prices to Community markets |
| 1973-07-02 | GVPA members | applied price increases to export prices for Community markets |
| 1973-09-20 | GVPA | decided on 10% price increase effective from 1 January 1974 |
| 1973-09-20 | GVPA members | decided to increase dollar export prices by 10% with immediate effect |
| 1974-01-01 | GVPA | implemented 10% price increase effective from this date |
| 1974-01-01 | GVPA members | increased all export prices by 10% from 1 January 1974 |
| 1974-01-31 | GVPA delegates | decided to apply surcharge of $79 per tonne and recommended restricting supplies |
| 1974-04-01 | GVPA | implemented surcharge and price increases |
| 1974-05-16 | GVPA members | decided to raise export prices by 15% plus additional increase averaging between 7 and 8% |
| 1977-12-23 | Commission | issued Decision relating to proceeding under Article 85 of the EEC Treaty |

### Legal Framework
Article 85 (operative article), Article 85 (all relevant articles)
Infringement concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Dalle & Lecomte | 25,000 units of account or 138,855 French francs |
| Feldmühle | 15,000 units of account or 54,900 German marks |
| Nicolaus | 25,000 units of account or 91,500 German marks |
| Rube | 10,000 units of account or 36,600 German marks |
| Schleipen & Erkens | 25,000 units of account or 91,500 German marks |
| Serlachius | 15,000 units of account or 63,000 Finnish marks |

### Remedies
Imposition of monetary fines as specified in Article 2 of the Decision, with no structural or behavioral commitments imposed.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Dalle & Lecomte | False |
| Feldmühle | False |
| Nicolaus | False |
| Rube | False |
| Schleipen & Erkens | False |
| Serlachius | False |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Raymond VOUéL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission imposed monetary fines on the participating companies, with no structural or behavioral commitments. The case was decided under Article 85 of the EEC Treaty.


*(reported: 2026-11-11 10:23:25)*

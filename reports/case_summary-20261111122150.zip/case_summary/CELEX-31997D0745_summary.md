# '97/745/EC', 'relating to a proceeding pursuant to Article 90 (3) of the EC Treaty regarding the tariffs for piloting in the Port of Genoa'

**CELEX ID:** CELEX-31997D0745  
**Industry:** NA  
**Cartel Period:** 1994 : 1996-09-09  

## Summary

### Celex Case Id
97/745/EC

### Case Title
relating to a proceeding pursuant to Article 90 (3) of the EC Treaty regarding the tariffs for piloting in the Port of Genoa

### Overview
This case concerns the infringement of Article 90 (1) of the EC Treaty by the Italian authorities regarding piloting services in the Port of Genoa. The European Commission found that the compulsory nature of piloting services and the tariff setting mechanism constituted an abuse of dominance by a public undertaking, leading to a high gravity infringement.

### Industry
Transport sector

### Oecd Nace
OECD: transport; NACE: 52.22 Service activities incidental to water transportation

### Companies Undertakings
| companies                                  |
|:-------------------------------------------|
| Tourship Italia                            |
| Tirrenia di Navigazione                    |
| Viamare di Navigazione                     |
| Navarma                                    |
| Corporation of Pilots of the Port of Genoa |
| Italia di Navigazione                      |

### Market
Italy

### Cartel Period
1994 : 1996-09-09

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-12-30 | Corpo dei Piloti del Porto di Genova | made piloting compulsory in port of Genoa |
| 1994-06-21 | Tourship | lodged complaint concerning piloting tariffs |
| 1994-06-21 | Tourship | complained to the Commission concerning the system of reductions in piloting tariffs |
| 1994-10-05 | Ministry for the Merchant Navy | published new tariff in Circular No 5203904 |
| 1994-10-12 | maritime authority | issued decree implementing the new piloting tariffs |
| 1995-11-06 | Italian authorities | conducted study on piloting service economies of scale |
| 1996-02-22 | Italian authorities | provided second method of calculation demonstrating economies of scale in planning |
| 1996-02-22 | Italian authorities | communicated study on piloting service costs |
| 1996-09-02 | Corpo dei Piloti del Porto di Genova | reaffirmed compulsory piloting services in port of Genoa |
| 1996-09-02 | Minister for Transport and Shipping | adopted decree confirming compulsory nature of piloting service |
| 1996-09-04 | Ministry of Transport and Shipping | introduced reductions in piloting tariffs |
| 1996-09-09 | maritime authority | implemented new tariff in port of Genoa |
| 1996-09-09 | Genoa Board of Navigation | implemented tariffs for piloting services |
| 1997-07-08 | Tourship | withdrew complaint |
| 1997-10-21 | Commission | adopted decision on infringement of Article 90 (1) of the EC Treaty

### Legal Framework
Legal framework applying to the case: the operative articles are Article 86 and Article 90, and the canonical concept is abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance, member_states

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
Exemption sought or granted: True

### Leniency
NA

### Fines
NA

### Remedies
The Italian Government shall put an end to the infringement referred to in Article 1 of this Decision and shall inform the Commission of the measures it has taken to that end within two months of the notification of this Decision.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                  | country   | jurisdiction   |
|:---------------------------------------|:----------|:---------------|
| Court of Justice of the European Union | Italy     | European Union |
| Court of Genoa                         | Italy     | Italy          |

### Book Reference
NA

### Outcome
The Commission adopted a decision finding an infringement of Article 90 (1) of the EC Treaty, concluding that the compulsory piloting services and tariff setting mechanism constituted an abuse of dominance by a public undertaking. Remedies were ordered to end the infringement.


*(reported: 2026-11-10 19:29:54)*

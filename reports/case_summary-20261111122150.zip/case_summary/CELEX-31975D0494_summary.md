# 'NA', 'NA'

**CELEX ID:** CELEX-31975D0494  
**Industry:** | industry                            |
|:------------------------------------|
| motor industry                      |
| electrical industry                 |
| extinguisher-manufacturing industry |
| mechanical-engineering industry     |  
**Cartel Period:** 1962-01-16 : 1977-12-31  

## Summary

### Celex Case Id
CELEX-31975D0494

### Case Title
NA

### Overview
This case involved two companies, Kabel- und Metallwerke Gutehoffnungshütte AG (Germany) and Ets Luchaire SA (Switzerland), who entered into licensing agreements related to patents and know-how. These agreements were found to be in violation of Article 85 of the Treaty, which prohibits certain agreements that prevent competition. The Commission issued a decision on 1975-07-18, signed by François-Xavier ORTOLI, declaring the agreement inapplicable under Article 85(3), allowing it to continue subject to modifications made on 13 March 1974.

### Industry
motor industry
electrical industry
extinguisher-manufacturing industry
mechanical-engineering industry

### Oecd Nace
manufacturing
25.9:Manufacture of other fabricated metal products
25.94: Manufacture of fasteners and screw machine products

### Companies Undertakings
| companies                                    |
|:---------------------------------------------|
| Kabel- und Metallwerke Gutehoffnungshütte AG |
| Ets Luchaire SA                              |

### Market
France
true

### Cartel Period
1958-06-19 : 1977-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1958-06-19 | Kabelmetal and Luchaire | concluded patent and know-how licensing agreement |
| 1960-03-04 | Kabelmetal | amended licensing and technical assistance agreement |
| 1960-11-10 | Kabelmetal | amended licensing and technical assistance agreement |
| 1962-01-16 | Kabelmetal | amended licensing and technical assistance agreement |
| 1962-02-06 | Commission of the European Communities | adopted Regulation No 17 |
| 1963-02-02 | Kabelmetal | notified licensing agreement |
| 1974-03-13 | Kabelmetal | amended licensing and technical assistance agreement |
| 1974-03-13 | Kabelmetal and Luchaire | deleted restrictive obligations from licensing agreement |
| 1974-12-14 | Commission of the European Communities | published summary of notification |
| 1975-04-24 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered Opinion |
| 1975-07-18 | Commission of the European Communities | issued Commission Decision |
| 1977-12-31 | redacted | end date of decision's effect |

### Legal Framework
Article 85

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
license

### Infringement Gravity
high

### Exemption
| company    |
|:-----------|
| Kabelmetal |
| Luchaire   |

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
François-Xavier ORTOLI

### Courts
NA

### Book Reference
IV/21.353

### Outcome
The agreement was declared inapplicable under Article 85(3) of the Treaty, allowing it to continue subject to modifications made on 13 March 1974.


*(reported: 2026-10-16 19:15:26)*

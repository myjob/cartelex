# 'IV/35.518', 'Iridium'

**CELEX ID:** CELEX-31997D0039  
**Industry:** | industry             |
|:---------------------|
| Telecommunications   |
| Aerospace            |
| Defense Electronics  |
| Satellite Operations |  
**Cartel Period:** 2003-07-31 : 2003-07-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31997D0039 | IV/35518  |

### Case Title
Iridium

### Overview
The Iridium case involved a satellite-based personal communications system, with companies from multiple countries participating in the development and operation of the S-PCS system. The European Commission investigated potential anticompetitive agreements related to territorial exclusivity and parallel trade bans under Article 85 of the EC Treaty.

### Industry
Telecommunications, Aerospace, Defense Electronics, Satellite Operations

### Oecd Nace
OECD sector: communication
NACE group code: 26.3: Manufacture of communication equipment
NACE class code: 26.30: Manufacture of communication equipment

### Companies Undertakings
| companies                                             | location   |
|:------------------------------------------------------|:-----------|
| Motorola Inc.                                         | NA         |
| Iridium LLC                                           | NA         |
| Iridium China (Hong Kong) Ltd                         | Hong Kong  |
| Iridium Africa Co.                                    | NA         |
| Iridium Canada, Inc.                                  | NA         |
| Iridium India Telecom Private Ltd.                    | NA         |
| Iridium Middle East Co.                               | NA         |
| Khrunichev State Research and Production Space Center | NA         |
| Iridium Sudamérica                                    | NA         |
| Korea Mobile Telecommunications                       | NA         |
| Lockheed Martin                                       | NA         |
| Nippon Iridium Co.                                    | NA         |
| Pacific Electric Wire & Cable Co.                     | NA         |
| Raytheon Co.                                          | NA         |
| Sprint                                                | NA         |
| Thai Satellite Telecommunications Co. Ltd             | NA         |
| Stet                                                  | NA         |
| Vebacom                                               | NA         |
| China Great Wall Industry Corporation                 | NA         |
| Mawarid Overseas Company                              | NA         |
| BCE, Inc.                                             | NA         |
| Sunkyong Business Group                               | NA         |
| DDI Co.                                               | NA         |
| Kyocena Co.                                           | NA         |
| Alcatel                                               | NA         |
| Aerospatiale                                          | NA         |
| Alenia                                                | NA         |
| Deutsche Aerospace                                    | NA         |
| Tesam                                                 | NA         |
| Loral Corporation                                     | NA         |
| TR W                                                  | NA         |
| Teleglobe Inc.                                        | NA         |
| Inmarsat-P/ICO                                        | NA         |
| Globalstar                                            | NA         |
| Odyssey S-PCS system                                  | NA         |

### Market
Geographical market includes Canada, Italy, Germany, Hong Kong, India, Saudi Arabia, Russia, Venezuela, Brazil, South Korea, Japan, Taiwan, Thailand, Mexico, and Central America. The market is outside the EU.

### Cartel Period
1998-10-01 : 2003-07-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted First Regulation implementing Articles 85 and 86 of the Treaty |
| 1995-08-11 | unknown | submitted application for negative clearance and notification for exemption |
| 1996-12-18 | Commission | issued Commission Decision relating to Iridium proceeding |
| 1996-12-18 | Iridium LLC | adopted decision finding no grounds for action under Articles 85(1) and 53(1) |
| 1998-10-01 | unknown | expected commercial operation of Iridium system |
| 2003-07-31 | Motorola Inc. | ended contractual restriction on producing similar satellite-based systems |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
NA

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
No specific remedies or orders were issued by the Commission to terminate any infringement. The Commission concluded that the arrangements do not fall within the scope of Articles 85(1) of the EC Treaty and Article 53(1) of the EEA Agreement, thus no interventions or sanctions were imposed.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
NA

### Outcome
The Commission concluded that the arrangements do not fall within the scope of Articles 85(1) of the EC Treaty and Article 53(1) of the EEA Agreement, thus no interventions or sanctions were imposed.


*(reported: 2026-10-16 20:51:53)*

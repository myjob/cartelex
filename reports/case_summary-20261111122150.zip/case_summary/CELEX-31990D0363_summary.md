# 'IV/32.846', 'Metaleurop SA'

**CELEX ID:** CELEX-31990D0363  
**Industry:** non-ferrous metals  
**Cartel Period:** 1990-06-01 : 1990-06-26  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31990D0363 | IV/32846  |

### Case Title
Metaleurop SA

### Overview
This case involved the European Commission's investigation into potential abuse of dominance by companies in the non-ferrous metals industry, specifically focusing on Metaleurop SA and its affiliates Preussag Aktiengesellschaft and Société Minière et Métallurgique de Peñarroya SA. The investigation centered around industrial cooperation and merger activities within the lead and zinc markets in Germany and France.

### Industry
non-ferrous metals

### Oecd Nace
OECD sector: mining
NACE group code: 07.2:Mining of non-ferrous metal ores
NACE class code: 07.29: Mining of other non-ferrous metal ores

### Companies Undertakings
| company                                          |
|:-------------------------------------------------|
| Preussag Aktiengesellschaft                      |
| Société Minière et Métallurgique de Peñarroya SA |
| Metaleurop SA                                    |

### Market
Relevant market: Germany, France

### Cartel Period
1990-06-26 : 1990-06-26

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-04-22 | Preussag Aktiengesellschaft and Metaleurop SA | entered into transaction regarding industrial cooperation |
| 1988-04-22 | Peñarroya and Preussag | merged non-ferrous metals activities |
| 1988-06-27 | Preussag | proceeded with capital increase of FF 441 million by issuing shares |
| 1988-08-29 | Société Minière et Métallurgique de Peñarroya SA and Preussag Aktiengesellschaft | submitted application for negative clearance or exemption |
| 1990-06-26 | Leon BRITTAN | signed and issued official decision on antitrust case |
| 1990-06-26 | Commission of the European Communities | issued decision on Metaleurop SA merger |
| 1990-11-07 | Imetal | presented second capital increase of FF 170 million to general meetings |

### Legal Framework
Legal framework applying to the case: Article 86 (operative article), abuse_of_dominance (canonical concept)

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
| company                                          |
|:-------------------------------------------------|
| Société Minière et Métallurgique de Peñarroya SA |
| Preussag Aktiengesellschaft                      |

### Leniency
NA

### Fines
NA

### Remedies
None

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Leon BRITTAN

### Courts
True

### Book Reference
NA

### Outcome
The European Commission took no action in this case, indicating that the alleged infringement was not pursued further.


*(reported: 2026-10-16 20:33:32)*

# 'IV/29877', 'British Telecommunications'

**CELEX ID:** CELEX-31982D0861  
**Industry:** telecommunications  
**Cartel Period:** 1976 : 1982-12-10  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31982D0861 | IV/29877  |

### Case Title
British Telecommunications

### Overview
The European Commission found British Telecommunications (BT) guilty of abuse of dominance under Article 86 of the Treaty on the Functioning of the European Union (TFEU). BT was investigated for its conduct in the telecommunications sector, specifically related to telex, telecommunication, facsimile, visual display unit, and data form messages. The infringement occurred between 1976 and December 10, 1982.

### Industry
telecommunications

### Oecd Nace
OECD sector: communication
NACE group code: 61.9: Other telecommunications activities
NACE class code: 61.90: Other telecommunications activities

### Companies Undertakings
British Telecommunications (GB)

### Market
United Kingdom, outside the EU

### Cartel Period
1976 : 1982-12-10

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1976-06-01 | redacted | scheme came into operation |
| 1982-10-22 | BT | withdrew the particular restrictions at issue and amended the Telecommunication Scheme |
| 1982-12-10 | Commission | issued decision relating to proceeding under Article 86 |
| 1982-12-10 | British Telecommunications | ended infringements

### Legal Framework
Article 86, Article 90
Infringement concept: abuse_of_dominance, public_undertaking

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
| company                    | amount          |
|:---------------------------|:----------------|
| British Telecommunications | no fine imposed |

### Fines
NA

### Remedies
British Telecommunications shall within two months of the date of notification of this Decision bring the infringements found in Article 1 to an end in so far as those infringements have not already been brought to an end.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| British Telecommunications | True |

### Case Commission Info Request
True

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Frans Andriesen

### Courts
NA

### Book Reference
NA

### Outcome
British Telecommunications was found guilty of abuse of dominance under Article 86. No fine was imposed due to leniency, but remedies required BT to end the infringements within two months of notification.


*(reported: 2026-11-11 10:43:07)*

# 'IV/128-1968', 'Julien/Van Katwijk'

**CELEX ID:** CELEX-31970D0487  
**Industry:** textile industry  
**Cartel Period:** 1952-02-15 : 1957-12-30  

## Summary

### Celex Case Id
CELEX-31970D0487

### Case Title
Julien/Van Katwijk

### Overview
This case involves a cartel agreement between Van Katwijk's Industries N.V. and S.A. Tuberies Louis Julien in the textile industry, specifically in the manufacture of steel tubes and pipes. The agreement was concluded in 1952 and terminated in 1957. The companies were found to have violated Article 85 of the Treaty establishing the European Economic Community. The case is notable for its high infringement gravity and recidivism of the companies involved.

### Industry
textile industry

### Oecd Nace
manufacturing

### Companies Undertakings
| Van Katwijk's Industries N.V. |
| S.A. Tuberies Louis Julien    |

### Market
The development of new technologies and international competition, especially with the entry of Van Katwijk N.V. into an international group (SONOCO Products Co.), resulted in changes to traditional trade flows and questioned previously acquired market positions, thereby creating market turbulence and uncertainty.

### Cartel Period
1952-02-15 : 1957-12-30

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1952-02-15 | Van Katwijk's Industries N.V. and S.A. Tuberies Louis Julien | concluded agreement violating Article85 of the Treaty establishing the European Economic Community |
| 1957-12-30 | Van Katwijk N.V. | informed S.A. Julien of intention to unilaterally terminate agreement |
| 1961-06-28 | Van Katwijk N.V. | was legally prevented from unilaterally terminating agreement and imposed penalty |
| 1962-10-23 | Van Katwijk's Industrien N.V. | registered agreement under Article 85(1) |
| 1963-01-26 | S.A. Tuberies Louis Julien | applied for exemption under Article 85(3) |
| 1970-09-22 | Advisory Committee for Cartel and Monopoly Issues | submitted opinion on application of Regulation No.17 |
| 1970-10-28 | redacted | issued decision

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
S.A. Tuberies Louis Julien applied for exemption under Article 85(3)

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
Van Katwijk's Industries N.V. and S.A. Tuberies Louis Julien

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Franco M. Malfa

### Courts
| court                  | country     | jurisdiction   |
|:-----------------------|:------------|:---------------|
| Arnhem Court of Appeal | Netherlands | Netherlands    |

### Book Reference
IV/128

### Outcome
The companies are required to immediately lift the restrictions listed in Article 1, which include prohibitions on Van Katwijk N.V. selling in Belgium and S.A. Julien supplying more than a specified quantity in the Netherlands.


*(reported: 2026-11-11 09:50:55)*

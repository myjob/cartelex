# 'IV/35.703', 'Portuguese airports'

**CELEX ID:** CELEX-31999D0199  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-3199D0199 | IV/35703  |

### Case Title
Portuguese airports

### Overview
The case concerns the abuse of dominance by companies in the airport infrastructure services sector in Portugal, specifically involving ANA, TAP Air Portugal, and Portugalia. The infringement relates to public undertaking practices and was investigated under Articles 86 and 90 of the EC Treaty.

### Industry
airport infrastructure services

### Oecd Nace
OECD sector: transport
NACE group code: 52.2: Support activities for transportation
NACE class code: 52.23: Service activities incidental to air transportation

### Companies Undertakings
| companies        |
|:-----------------|
| ANA              |
| TAP Air Portugal |
| Portugalia       |

### Market
Portugal

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1990-03-21 | Portuguese authorities | enacted decree-law establishing framework for aeronautical charges |
| 1998-07-01 | redacted | liberalisation of air traffic to and from the Azores archipelago came into effect under Article 1(4) of Council Regulation (EEC) No 2408/92 |
| 1999-02-10 | redacted | formal decision issued by Commission to Portugal |

### Legal Framework
Article 86, Article 90

### Infringement Category
abuse_of_dominance, public_undertaking

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Portugal shall bring to an end the infringement referred to in Article 1 and shall inform the Commission within two months of the date of notification of the measures it has taken to that end.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court                                  | country        | jurisdiction       |
|:---------------------------------------|:---------------|:-------------------|
| Court of Justice of the European Union | European Union | European Community |

### Book Reference
NA

### Outcome
The Commission found that Portugal had infringed EU law by allowing companies to engage in abusive practices. The case resulted in a formal decision issued by the Commission, requiring Portugal to take corrective measures.


*(reported: 2026-11-11 11:58:14)*

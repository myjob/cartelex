# 'IV/29.428', 'GEC-Weir Sodium Circulators'

**CELEX ID:** CELEX-31977D0781  
**Industry:** | industry                                |
|:----------------------------------------|
| power engineering                       |
| liquid metal technology                 |
| nuclear reactor equipment manufacturing |
| sodium circulator technology            |
| pump manufacturing                      |
| foundry processes                       |
| high-precision steel casting            |  
**Cartel Period:** 1977-03-21 : 1989-01-01  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31977D0781 | IV/29428  |

### Case Title
GEC-Weir Sodium Circulators

### Overview
This case involved a joint venture between The General Electric Company Ltd (US) and The Weir Group Ltd (GB) in the power engineering and nuclear reactor equipment manufacturing sectors. The venture, which included Weir Pumps Ltd and The English Electric Company Ltd, was established to produce sodium circulators and related products. The Commission initiated proceedings under Article 85 of the EC Treaty for an anticompetitive agreement.

### Industry
power engineering
liquid metal technology
nuclear reactor equipment manufacturing
sodium circulator technology
pump manufacturing
foundry processes
high-precision steel casting

### Oecd Nace
manufacturing
25.1:Manufacture of structural metal products
25.11: Manufacture of metal structures and parts of structures

### Companies Undertakings
| companies                        |
|:---------------------------------|
| The Weir Group Ltd               |
| The General Electric Company Ltd |
| Weir Pumps Ltd                   |
| The English Electric Company Ltd |

### Market
Relevant market is an oligopoly in the following countries:

- United Kingdom
- France
- Italy
- Netherlands
- Federal Republic of Germany
- United States
- Japan
- USSR

Market outside EU: false

### Cartel Period
1977-03-21 : 1989-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1977-03-21 | The General Electric Company Limited and The Weir Group Limited | entered into joint venture agreement |
| 1977-04-14 | parties | notified Commission |
| 1977-04-14 | joint venture | authorized under Article 85(3) |
| 1977-07-18 | Commission of the European Communities | initiated proceedings in case |
| 1977-09-30 | The General Electric Company Limited and The Weir Group Limited | amended joint venture agreement |
| 1977-10-20 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on agreement |
| 1977-11-23 | Commission of the European Communities | issued Commission Decision |
| 1989-12-31 | redacted | agreement period ends |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
joint venture

### Infringement Sub Category
horizontal restraints

### Infringement Gravity
high

### Exemption
| company                          |
|:---------------------------------|
| The Weir Group Ltd               |
| The General Electric Company Ltd |

### Leniency
NA

### Fines
NA

### Remedies
No specific cease and desist orders, structural remedies (such as divestitures), or behavioral remedies were issued by the Commission to terminate the infringement.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
true

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
NA

### Outcome
The Commission initiated proceedings but took no action (no specific remedies were issued). The case was an exemption case where both GE and Weir applied for exemption, but the Commission requested information and ultimately took no action.


*(reported: 2026-10-16 19:45:45)*

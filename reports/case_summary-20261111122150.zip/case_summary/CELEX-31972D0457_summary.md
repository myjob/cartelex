# 'IV/26.911', 'Zoja/CSC‑ICI'

**CELEX ID:** CELEX-31972D0457  
**Industry:** | industry            |
|:--------------------|
| Pharmaceutical      |
| Chemical            |
| Raw Material Supply |  
**Cartel Period:** 1969-03-11 : 1971-10-26  

## Summary

### Celex Case Id
CELEX-31972D0457

### Case Title
Zoja/CSC‑ICI

### Overview
This case involved two companies, Commercial Solvents Corporation (US) and Istituto Chemioterapico Italiano (IT), investigated for cartel behavior in the pharmaceutical and chemical sectors. The infringement involved refusal to deal and essential facilities doctrine, with a high gravity level.

### Industry
Pharmaceutical, Chemical, Raw Material Supply

### Oecd Nace
manufacturing, 21.1:Manufacture of basic pharmaceutical products, 21.10: Manufacture of basic pharmaceutical products

### Companies Undertakings
- Commercial Solvents Corporation (US)
- Istituto Chemioterapico Italiano (IT)

### Market
The market was in Italy, France, Germany, and third countries. The termination of deliveries by CSC-ICI caused severe restriction of effective competition in the ethambutol market, leading to market instability and uncertainty regarding future supply. The abrupt and unexpected nature of the supply cutoff created an unpredictable competitive environment for Zoja and other producers.

### Cartel Period
1969-03-11 : 1971-10-26

### Key Timeline
| Event | Date |
| --- | --- |
| Council Regulation No.17 adopted | 1962-02-06 |
| Zoja placed annual order with ICI | 1970-11-18 |
| Zoja ordered delivery of aminobutanol from ICI | 1970-11-18 |
| Zoja applied to Commission to initiate proceedings | 1971-04-08 |
| Commission informed of complaint concerning non-supply of nitropropane | 1971-07-09 |
| Zoja placed order for aminobutanol and nitropropane | 1971-10-11 |
| ICI replied to order with no available stocks | 1971-10-26 |
| ICI stated prohibition on reselling nitropropane for pharmaceutical use aimed at preventing access to ethambutol markets in developing countries | 1972-05-15 |
| Commission issued decision on procedure | 1972-12-14 |

### Legal Framework
NA

### Infringement Category
Refusal to deal and essential facilities doctrine

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Commercial Solvents Corporation | 200000 accounting units |
| Istituto Chemioterapico Italiano | 200000 accounting units |

### Remedies
The Commission ordered the companies to cease the violation, deliver 60,000 kg nitropropane or 30,000 kg aminobutanol immediately, submit proposals to the Commission within two months, and pay a fine of 200,000 accounting units (125,000,000 lire) jointly and severally. Additionally, they are liable for daily penalties of 1000 billing units (625,000 lire) for each day of delay in delivery or submission of proposals after the announcement of this decision.

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
NA

### Case Commission Decision
True

### Commissioner
S. L. MANSHOLT

### Courts
NA

### Book Reference
IV/26.911

### Outcome
The Commission ordered the companies to cease the violation, deliver 60,000 kg nitropropane or 30,000 kg aminobutanol immediately, submit proposals to the Commission within two months, and pay a fine of 200,000 accounting units (125,000,000 lire) jointly and severally. Additionally, they are liable for daily penalties of 1000 billing units (625,000 lire) for each day of delay in delivery or submission of proposals after the announcement of this decision.


*(reported: 2026-11-11 10:00:18)*

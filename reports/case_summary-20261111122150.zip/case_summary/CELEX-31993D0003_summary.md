# 'IV/32.797 and 32.798', "Lloyd's Underwriters' Association and The Institute of London Underwriters"

**CELEX ID:** CELEX-31993D0003  
**Industry:** marine insurance  
**Cartel Period:** 1989-02-09 : 1991-04-25  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0003 | IV/32797  |

### Case Title
IV/32.797 and 32.798 – Lloyd's Underwriters' Association and The Institute of London Underwriters

### Overview
The European Commission investigated anticompetitive agreements between Lloyd's Underwriters' Association and The Institute of London Underwriters in the marine insurance industry. The case involved price fixing collusion under Article 85 of the EC Treaty, with a cartel period from 1989-02-09 to 1991-04-25.

### Industry
marine insurance

### Oecd Nace
OECD sector: banking and insurance (including real estate)
NACE group code: 65.1: Insurance
NACE class code: 65.12: Non-life insurance

### Companies Undertakings
| companies                            |
|:-------------------------------------|
| Lloyd's Underwriters' Association    |
| The Institute of London Underwriters |

Countries:
- Lloyd's Underwriters' Association: GB
- The Institute of London Underwriters: GB

### Market
Relevant market includes the United Kingdom, USA, France, and Norway. The market is described as oligopolistic and outside the EU.

### Cartel Period
1989-02-09 : 1991-04-25

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1988-07-07 | ILU and LUA | submitted Agreements (JHU and RLA) informally |
| 1989-02-09 | members of the two Associations | ceased to be obliged to respect rates indicated in the graph |
| 1989-06-07 | ILU and LUA | formally notified Agreements (JHU and RLA) to the Commission |
| 1990-10-01 | Commission of the European Communities | initiated proceedings in case |
| 1991-04-25 | ILU and LUA | abandoned agreement |
| 1991-04-25 | ILU and LUA | deleted clauses and abandoned Respect of Lead Agreement |
| 1991-04-25 | parties | ended period of obligation to report deviations from the graph |
| 1992-12-04 | Commission of the European Communities | issued Commission Decision |

### Legal Framework
Article 85 (operative article)
All relevant articles: Article 85
Canonical concept: anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
price fixing collusion

### Infringement Gravity
high

### Exemption
Exemption sought or granted: NA

### Leniency
Not a leniency case

### Fines
NA

### Remedies
Cease applying the infringing clauses and implement behavioral remedies to prevent future infringement

### Company Recidivism
| companies   | recidivism   |
|:------------|:-------------|
| ILU and LUA | NA           |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
NA

### Courts
NA

### Book Reference
NA

### Outcome
The Commission took no action initially but later issued a decision. The outcome includes remedies to cease applying infringing clauses and implement behavioral measures.


*(reported: 2026-10-16 20:33:16)*

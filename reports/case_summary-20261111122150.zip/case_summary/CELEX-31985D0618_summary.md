# 'IV/30.739', 'Siemens/Fanuc'

**CELEX ID:** CELEX-31985D0618  
**Industry:** | industry                        |
|:--------------------------------|
| machine-tool industry           |
| numerical control (NC) industry |  
**Cartel Period:** 1975-06 : 1982-10-06  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31985D0618 | IV/30739  |

### Case Title
Siemens/Fanuc

### Overview
The case involves horizontal restraints in the machine-tool industry, with Siemens AG and Fanuc Ltd found to have entered into anticompetitive agreements. The infringement occurred between 1975 and 1982, and the Commission imposed fines of one million ECU each on both companies.

### Industry
machine-tool industry
numerical control (NC) industry

### Oecd Nace
manufacturing
28.4:Manufacture of metal forming machinery and machine tools
28.49: Manufacture of other machine tools

### Companies Undertakings
| companies   |
|:------------|
| Fanuc Ltd   |
| Siemens AG  |
| Fujitsu Ltd |

| companies_investigated   | country   |
|:-------------------------|:----------|
| Fanuc Ltd                | JP        |
| Siemens AG               | DE        |
| Fujitsu Ltd              | JP        |

### Market
Germany

### Cartel Period
1975-06 : 1982-10-06

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-06-11 | Siemens and Fanuc | concluded basic agreement |
| 1982-12-10 | redacted | initiated proceedings in the case |
| 1983-04-19 | Siemens and Fanuc | concluded new agreements and abrogated basic agreement |
| 1983-07-01 | Siemens and Fanuc | notified new agreements to Commission |
| 1985-12-18 | redacted | issued Commission Decision relating to Siemens/Fanuc proceeding |
| 1985-12-18 | Commission of the European Communities | adopted decision imposing fines and enforcing ruling |

### Legal Framework
Article 85
anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
high

### Exemption
NA

### Leniency
NA

### Fines
| company | amount |
| --- | --- |
| Fanuc Ltd | one million ECU |
| Siemens AG | one million ECU |

### Remedies
NA

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Fanuc Ltd, Siemens AG | False |

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Peter SUTHERLAND

### Courts
| court                                  | country   | jurisdiction       |
|:---------------------------------------|:----------|:-------------------|
| Commission of the European Communities | Belgium   | European Community |

### Book Reference
NA

### Outcome
Imposition of fines of one million ECU each on Fanuc Ltd and Siemens AG; declaration that the agreements constituted infringements under Article 85(1) of the EEC Treaty; abrogation of the 1975 agreements.


*(reported: 2026-11-11 11:01:35)*

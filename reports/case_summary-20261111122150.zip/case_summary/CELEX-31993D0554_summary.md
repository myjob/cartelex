# 'IV/31.550 — Zera/Montedison and IV/31.898 — Hinkens/Stähler', 'relating to a proceeding pursuant to Article 85 of the EEC Treaty in Cases'

**CELEX ID:** CELEX-31993D0554  
**Industry:** plant protection products  
**Cartel Period:** 1977 : 1985  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31993D0554 | IV/31550  |

### Case Title
IV/31.550 — Zera/Montedison and IV/31.898 — Hinkens/Stähler

### Overview
This case involves a proceeding pursuant to Article 85 of the EEC Treaty concerning anticompetitive agreements in the plant protection products industry. The European Commission investigated vertical agreements involving territorial exclusivity and parallel trade bans between companies operating in Germany, France, Italy, Spain, and the United Kingdom.

### Industry
plant protection products

### Oecd Nace
OECD sector: manufacturing
NACE group code: 21.2: Manufacture of pharmaceutical preparations
NACE class code: 21.20: Manufacture of pharmaceutical preparations

### Companies Undertakings
| company                         |
|:--------------------------------|
| Farmoplant SpA                  |
| Agrimont SpA                    |
| Montedison Deutschland GmbH     |
| Stahler Agrochemie GmbH & Co KG |
| EniChem Agricoltura SpA         |
| EniChem Deutschland AG          |

### Market
Geographical: Germany, France, Italy, Spain, United Kingdom
Outside EU: False
Oligopoly: NA
Turbulence: NA

### Cartel Period
1977 : 1985

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1975-11-05 | Agrimont | filed application for registration in Italy |
| 1976-11-19 | MED | estimated individual test costs and registration costs |
| 1976-11-19 | MED | commented on the patent situation |
| 1977-06-22 | Stahler | negotiated regarding registration and pricing |
| 1977-12-12 | Stahler | negotiated regarding registration and pricing |
| 1978-01-30 | Agrimont | obtained registration in Germany |
| 1978-10-03 | MED | asked Farmoplant to assent to conclusion of distribution agreement with Stahler |
| 1978-10-13 | MED and Stahler | confirmed mutual intention of transferring sole distribution to Stahler |
| 1978-10-13 | Stahler | negotiated regarding registration and pricing |
| 1979-08-24 | Stahler | began marketing Digermin on the day the patent expired |
| 1980-09-09 | MED and Stahler | signed written distribution agreement |
| 1980-09-09 | MED and Stahler Agrochemie GmbH & Co KG | concluded agreement for exclusive distribution of Digermin |
| 1980-09-09 | MED and Farmoplant | entered into exclusive distribution agreement with Stahler |
| 1980-11-25 | MED and Stahler | amended agreement to extend minimum purchase quantities |
| 1981-01-12 | MED | discussed formulation differences with Dr Stahler |
| 1981-01-14 | MED | issued memo regarding nitrosamine content of Digermin |
| 1981-01-14 | Stahler | became aware of Digermin's basic composition |
| 1981-05-13 | MED and Stahler | held meetings coordinating jointly financed advertising for Digermin |
| 1985-01-01 | MED and Stahler | agreement extended by one year at a time with three-month notice period |
| 1988-12-31 | MED and Stahler | annulment of distribution agreement |
| 1993-06-22 | redacted | issued Commission Decision |

### Legal Framework
Law article operative: Article 85
Law article all relevant: Article 85
Infringement concept: anticompetitive_agreement

### Infringement Category
vertical

### Infringement Sub Category
Territorial Exclusivity / Parallel Trade Bans

### Infringement Gravity
high

### Exemption
Exemption sought: True
Applicants: NA

### Leniency
Leniency case: False
Applicants: NA
Granted: NA
Rejected: NA

### Fines
NA

### Remedies
No specific orders or remedies are mentioned in the context

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
| court            | country        | jurisdiction                 |
|:-----------------|:---------------|:-----------------------------|
| Court of Justice | European Union | Case 7/82, GVL v. Commission |

### Book Reference
NA

### Outcome
NA


*(reported: 2026-11-11 11:41:57)*

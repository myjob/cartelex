# 'IV/26.940/a', 'United Reprocessors GmbH'

**CELEX ID:** CELEX-31976D0248  
**Industry:** oxide fuels reprocessing  
**Cartel Period:** 1971-10-11 : 1986-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id    |
|:-----------------|:-----------|
| CELEX-31976D0248 | IV/26940-1 |

### Case Title
United Reprocessors GmbH

### Overview
The European Commission investigated an anticompetitive agreement in the nuclear reprocessing industry involving British Nuclear Fuels Ltd, Commissariat à l'Énergie Atomique, and Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH. The agreement was concluded in 1971 and amended in 1973, with the Commission issuing a decision in 1975.

### Industry
oxide fuels reprocessing

### Oecd Nace
OECD sector: electricity and gas
NACE group code: 08.9:Mining and quarrying n.e.c.
NACE class code: 08.91: Mining of chemical and fertiliser minerals

### Companies Undertakings
| companies                                          |
|:---------------------------------------------------|
| British Nuclear Fuels Ltd                          |
| Commissariat à l'Énergie Atomique                  |
| Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH |

Companies and undertakings investigated, from the 'companies_investigated' fact, with their country from the 'companies_country' fact. Preserve markdown lists if present.

### Market
European countries with free market economies
The market is subject to uncertainties due to technical unknown factors affecting plant commissioning timelines and delays in nuclear power station building programmes, which may affect reprocessing demand forecasts. The reprocessing industry also faces uncertainty related to political barriers influencing trade in irradiated fuels between East and West.
Market is oligopolistic

### Cartel Period
1971-10-12 : 1986-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1971-10-11 | Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH (KEWA) | made notification concerning agreement |
| 1971-10-12 | British Nuclear Fuels Ltd, Commissariat à l'Énergie Atomique, and Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH | concluded agreement |
| 1973-07-31 | British Nuclear Fuels Ltd, Commissariat à l'Énergie Atomique, and Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH | amended agreement |
| 1973-09-28 | Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH (KEWA) | supplemented notification concerning agreement |
| 1974-07-16 | European Commission | published summary of notification in Official Journal |
| 1975-02-27 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion on agreement |
| 1975-12-23 | European Commission | issued commission decision |
| 1975-12-23 | European Commission | decision was signed |
| 1986-12-31 | unknown | decision ceased to be in force |

### Legal Framework
Article 85
The operative articles ('law_article_operative', falling back to 'law_article_all_relevant') and the canonical concept ('infringement_concept')

### Infringement Category
horizontal

### Infringement Sub Category
market sharing, quota cartels, and specialization agreements

### Infringement Gravity
NA

### Exemption
| company                                            |
|:---------------------------------------------------|
| British Nuclear Fuels Ltd                          |
| Commissariat à l'Énergie Atomique                  |
| Kernbrennstoff-Wiederaufarbeitungsgesellschaft mbH |

Exemption sought or granted, from the 'exemption_case' and 'exemption_applicants' facts. Preserve markdown lists if present.

### Leniency
NA

### Fines
NA

### Remedies
The Commission ordered the parties to communicate standard contract conditions and any substantial amendments thereto; provide particulars of pricing policy including quantity or other discounts and substantial revisions; report on the principles of URG's marketing policy determined by its Board; submit annual balance sheets and profit/loss accounts; notify the Commission immediately upon conclusion of any reprocessing-related contracts; discuss with the Commission the terms and conditions of such contracts; inform the Commission of arrangements for exchange of research results, information, and know-how, and report on these arrangements every two years.

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
A. BORSCHETTE

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission issued a decision in 1975 finding an infringement of Article 85, ordering specific remedies to ensure compliance with EU competition law.


*(reported: 2026-10-16 21:56:04)*

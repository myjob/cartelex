# 'COMP/36.841', 'Unisource'

**CELEX ID:** CELEX-32001D0143  
**Industry:** telecommunications  
**Cartel Period:** 2000-12-31 : 2000-12-31  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32001D0143 | IV/36841  |

### Case Title
COMP/36.841 – Unisource

### Overview
The European Commission investigated anticompetitive agreements among Unisource NV, Koninklijke KPN NV, Swisscom AG, and Telia AB in the telecommunications sector. The case involved a joint venture that was found to be in breach of EU competition law.

### Industry
telecommunications

### Oecd Nace
OECD: communication
NACE group code: 61.9
NACE class code: 61.90

### Companies Undertakings
| companies          |
|:-------------------|
| Unisource NV       |
| Koninklijke KPN NV |
| Swisscom AG        |
| Telia AB           |

### Market
Relevant market includes the Netherlands, Sweden, and Switzerland.

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1962-02-06 | Council | adopted regulation implementing Articles 85 and 86 |
| 1997-10-29 | Commission | issued decision on Unisource agreements |
| 1999-05-29 | Unisource | acquired 100% of AUCS shares |
| 1999-07-08 | European Commission | declared transaction compatible with common market |
| 1999-12-23 | Unisource NV and its shareholders | filed application for review of conditions in decision |
| 2000-12-29 | Koninklijke KPN NV | adopted decision repealing Decision 97/780/EC |
| 2000-12-29 | Commission | issued decision relating to Unisource proceeding

### Legal Framework
Legal framework: Article 81 (operative), with relevant articles including Article 85.

### Infringement Category
joint venture

### Infringement Sub Category
NA

### Infringement Gravity
low

### Exemption
NA

### Leniency
NA

### Fines
NA

### Remedies
Decision 97/780/EC was repealed

### Company Recidivism
| companies                                 | recidivism   |
|:------------------------------------------|:-------------|
| Koninklijke KPN NV, Swisscom AG, Telia AB | True         |

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
NA

### Book Reference
NA

### Outcome
The European Commission took a decision to repeal Decision 97/780/EC, indicating that the anticompetitive agreements were addressed through this action.


*(reported: 2026-10-16 22:22:09)*

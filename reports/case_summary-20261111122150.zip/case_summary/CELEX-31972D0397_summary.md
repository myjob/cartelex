# 'IV/24171Misal', 'Extra alloy'

**CELEX ID:** CELEX-31972D0397  
**Industry:** NA  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-31972D0397 | IV/24171  |

### Case Title
IV/24171Misal – Extra alloy

### Overview
This case involves the European Commission's decision concerning a cartel agreement between Cummins Diesel International Ltd in Lausanne (Switzerland) and Misal s.a.s. Leto, Milan, along with other undertakings. The agreement concerned exclusive distribution arrangements for Cummins Diesel products and contract products.

### Industry
manufacturing

### Oecd Nace
OECD: manufacturing
NACE group code: 29.3: Manufacture of parts and accessories for motor vehicles
NACE class code: 29.31: Manufacture of electrical and electronic equipment for motor vehicles

### Companies Undertakings
| companies                                                       |
|:----------------------------------------------------------------|
| Cummins Diesel International Ltd in Lausanne (Switzerland)      |
| Misal s.a.s. Leto, Milan, Via L. Zuccoli 8                      |
| N.V. Nederlandsche Hasler Mij, Arnhem (N)                       |
| Gosselaar's Industrie en Handelsonderneming N.V.; Amsterdam (N) |

### Market
Italy
Switzerland

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1963-01-31 | Cummins Diesel International and Misal | filed exclusive distribution agreement |
| 1972-09-28 | Commission of the European Communities | issued decision concerning agreement with Cummins Diesel International Ltd |

### Legal Framework
NA

### Infringement Category
NA

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
False

### Leniency
False

### Fines
NA

### Remedies
The Commission may impose fines ranging from one hundred to five thousand accounting units if companies act intentionally or negligently in providing incorrect information or failing to provide required information within the deadline. Additionally, penalties of fifty to one thousand billing units per day of delay can be imposed to compel full and accurate responses.

### Company Recidivism
| companies | recidivism |
| --- | --- |
| Misal | NA |

### Case Commission Info Request
| company                                    |   info_request_date |   info_request_reminder_date | deadline_for_response              | requested_information                                                                                                                                                                                                                                                                                                                                                               |
|:-------------------------------------------|--------------------:|-----------------------------:|:-----------------------------------|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Misal s.a.s. Leto, Milan, Via L. Zuccoli 8 |                1969 |                         1971 | three weeks from 28 September 1972 | ['Is the registered agreement still in force?', 'Total turnover of the company for each of the years 1968, 1969, 1970 and 1971', 'Turnover of the company from contract products for each of the years 1968, 1969, 1970 and 1971', 'Approximate percentage in the contractual territory of the sales of contract products compared with total sales of competing similar products'] |

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
S.L. Mansholt

### Courts
| court                         | country    | jurisdiction   |
|:------------------------------|:-----------|:---------------|
| Court of European Communities | Luxembourg | European Union |

### Book Reference
NA

### Outcome
The Commission issued a decision concerning the cartel agreement, imposing potential fines and penalties for non-compliance with information requests.


*(reported: 2026-11-11 09:59:37)*

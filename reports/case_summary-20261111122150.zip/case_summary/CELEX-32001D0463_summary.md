# 'NA', 'NA'

**CELEX ID:** CELEX-32001D0463  
**Industry:** | industry                                                                                                                                         |
|:-------------------------------------------------------------------------------------------------------------------------------------------------|
| manufacturers and distributors of sales packaging                                                                                                |
| large enterprises and industrial installations                                                                                                   |
| printers and other paper-using enterprises                                                                                                       |
| restaurants, canteens, hospitals, government offices, educational establishments, barracks, offices of liberal professions and craft enterprises |
| transport packaging industry (paper/cardboard and plastic)                                                                                       |
| 12 industries with splitting agreements                                                                                                          |  
**Cartel Period:** NA  

## Summary

### Celex Case Id
| celex_id         | case_id   |
|:-----------------|:----------|
| CELEX-32001D0463 | IV/34493  |

### Case Title
NA

### Overview
The European Commission investigated the practices of Der Grüne Punkt Duales System Deutschland AG (DSD) regarding the use of the Green Dot trade mark, finding that DSD had abused its dominant position in the German packaging market by imposing discriminatory licensing fees and failing to comply with exemption rules.

### Industry
manufacturers and distributors of sales packaging, large enterprises and industrial installations, printers and other paper-using enterprises, restaurants, canteens, hospitals, government offices, educational establishments, barracks, offices of liberal professions and craft enterprises, transport packaging industry (paper/cardboard and plastic), 12 industries with splitting agreements

### Oecd Nace
public service, 20.5:Manufacture of other chemical products, 20.59: Manufacture of other chemical products n.e.c.

### Companies Undertakings
| company                                                 |
|:--------------------------------------------------------|
| Der Grüne Punkt Duales System Deutschland AG            |
| Duales System Deutschland AG                            |
| ProEurope (Packaging Recovery Organisation Europe SPRL) |
| L'Oréal                                                 |
| Wella                                                   |
| Goldwell                                                |
| Schwarzkopf                                             |
| Industrieverband Friseurbedarf                          |
| Vfw                                                     |
| Eco-Emballages SA (France)                              |
| Altstoff Recycling Austria AG (Austria)                 |
| asbl Fost plus vzw (Belgium)                            |
| Sociedade Ponto Verde SA (Portugal)                     |
| Ecoembalajes España (Spain)                             |
| Valorlux asbl (Luxembourg)                              |
| Repak Limited (Ireland)                                 |

### Market
Germany, False, NA

### Cartel Period
NA

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1992-09-02 | DSD | notified agreements for negative clearance or exemption |
| 1993-06-24 | DSD | issued formal prohibition order against extending collection activities to sales and transport packaging |
| 1995-01-01 | DSD | implemented new price list for licence fees |
| 1998-10-15 | DSD | submitted commitment to avoid double charging in exemption systems |
| 1998-10-15 | DSD | submitted commitment |
| 1999-11-03 | Commission | informed DSD that commitment was insufficient and needed extension to self-management solutions |
| 2000-03-13 | DSD | submitted further commitments by letter |
| 2000-10-09 | DSD | replied by letter indicating willingness to submit further commitment |
| 2000-11-21 | DSD | submitted newly worded commitment and requested hearing |
| 2000-11-28 | Hearing Officer | denied hearing request due to time elapsed |
| 2001-04-20 | Commission | issued decision |
| 2001-04-20 | DSD | notification of decision |

### Legal Framework
Article 82, abuse_of_dominance

### Infringement Category
abuse_of_dominance

### Infringement Sub Category
NA

### Infringement Gravity
high

### Exemption
True

### Leniency
NA

### Fines
NA

### Remedies
| value                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|:------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| DSD shall bring the infringement referred to in Article 1 to an end immediately. DSD shall refrain from continuing or repeating the conduct described in Article 1 or from taking measures having the same effect.                                                                                                                                                                                                                                                                                          |
| DSD shall undertake vis-à-vis all parties to the Trade Mark Agreement not to charge any licence fee for such partial quantities of sales packaging carrying the Green Dot trade mark as are put into circulation in Germany for which the exemption service referred to in Article 2 of the Trade Mark Agreement is not used and for which the Packaging Ordinance obligations have demonstrably been fulfilled in another way.                                                                             |
| DSD has undertaken to conclude with manufacturers and distributors of sales packaging whose registered office is in the European Community or the European Economic Area agreements on use of the Green Dot trade mark within the territory covered by the Packaging Ordinance. It undertakes to treat undertakings whose registered office is in one of the countries referred to in paragraph 1 no differently from those whose registered office is in the territory covered by the Packaging Ordinance. |
| DSD has undertaken to determine the amount of the licence fee and/or the basis of its assessment for the use of the Green Dot trade mark in such a way that costs are allocated in accordance with the polluter-pays principle to the specific groups of materials and to let this periodically be verified.                                                                                                                                                                                                |
| DSD may charge a licence fee in the European Community or the European Economic Area for use of the Green Dot trade mark only for packaging which has been put into circulation in the territory covered by the Packaging Ordinance.                                                                                                                                                                                                                                                                        |

### Company Recidivism
| company | recidivism |
| --- | --- |
| Der Grüne Punkt Duales System Deutschland AG | True |

### Case Commission Info Request
True

### Case Commission No Action
False

### Case Commission Decision
True

### Commissioner
Mario Monti

### Courts
| court                  | country   | jurisdiction   |
|:-----------------------|:----------|:---------------|
| Cologne Regional Court | Germany   | Germany        |

### Book Reference
NA

### Outcome
The Commission found that DSD had abused its dominant position in the German packaging market by imposing discriminatory licensing fees and failing to comply with exemption rules. The decision imposed remedies requiring DSD to end the infringement, refrain from repeating the conduct, and implement specific measures regarding licence fee allocation and use of the Green Dot trade mark.


*(reported: 2026-11-11 12:08:08)*

# 'IV/28.796', 'Beecham/Parke, Davis'

**CELEX ID:** CELEX-31979D0298  
**Industry:** pharmaceutical  
**Cartel Period:** 1974-01-28 : 1978-05-01  

## Summary

### Celex Case Id
CELEX-31979D0298

### Case Title
Beecham/Parke, Davis

### Overview
The case involved an anticompetitive agreement between Beecham Group Limited and Parke, Davis and Company in the pharmaceutical industry, relating to horizontal restraints on exchange of information on prices and sales. The companies sought exemption for their joint research and development agreement, which was granted with conditions.

### Industry
pharmaceutical

### Oecd Nace
manufacturing (OECD), 21.2:Manufacture of pharmaceutical preparations (NACE group), 21.20: Manufacture of pharmaceutical preparations (NACE class)

### Companies Undertakings
| companies                | location                             |
|:-------------------------|:-------------------------------------|
| Beecham Group Limited    | Brentford, Middlesex, United Kingdom |
| Parke, Davis and Company | Detroit, Michigan, United States     |

### Market
England, USA; oligopoly market

### Cartel Period
1973-05-04 : 1988-12-31

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1973-05-04 | Beecham Group Limited and Parke, Davis and Company | signed joint research and development agreement |
| 1974-01-28 | Beecham Group Limited | made notification requesting exemption |
| 1976-02-23 | Beecham Group Limited and Parke, Davis and Company | amended joint research and development agreement |
| 1978-10-19 | Commission | published summary of notification |
| 1978-11-22 | Advisory Committee on Restrictive Practices and Dominant Positions | delivered opinion |
| 1979-01-17 | Commission | declared inapplicable provisions of Treaty establishing the European Economic Community |
| 1979-01-17 | Commission of the European Communities | issued Commission Decision |
| 1988-12-31 | redacted | exemption period ended |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
horizontal

### Infringement Sub Category
exchange of information on prices and sales

### Infringement Gravity
medium

### Exemption
| company                  |
|:-------------------------|
| Beecham Group Limited    |
| Parke, Davis and Company |

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
NA

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Raymond VOUEL

### Courts
NA

### Book Reference
IV/28.796

### Outcome
The Commission required the parties to remove exclusions from licensing arrangements in France, delete profit-sharing clauses for France and Japan, eliminate royalties on licenses, and grant royalty-free sublicenses. Additionally, the parties were committed to furnishing information regarding patent applications, licenses, and sublicenses to assess the practical effects of the Agreement.


*(reported: 2026-10-16 19:35:23)*

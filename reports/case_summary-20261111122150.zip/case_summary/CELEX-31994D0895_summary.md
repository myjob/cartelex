# 'IV/34.768', 'International Private Satellite Partners'

**CELEX ID:** CELEX-31994D0895  
**Industry:** | industry           |
|:-------------------|
| aerospace          |
| telecommunications |  
**Cartel Period:** 1993-06-28 : 1994-12-15  

## Summary

### Celex Case Id
CELEX-31994D0895

### Case Title
International Private Satellite Partners

### Overview
The case involves a cartel formed by several international satellite telecommunications companies, including entities from the US, UK, Canada, and Italy. The European Commission investigated anticompetitive agreements related to joint ventures in the satellite telecommunications sector. The Commission issued a decision under Articles 85 and 53 of the EEA Agreement following notifications and requests for extension of notification.

### Industry
aerospace, telecommunications

### Oecd Nace
manufacturing, 61.3:Satellite telecommunications activities, 61.30: Satellite telecommunications activities

### Companies Undertakings
| companies                                         | location   |
|:--------------------------------------------------|:-----------|
| International Private Satellite Partners, L.P.    | NA         |
| Orion Satellite Corporation                       | NA         |
| British Aerospace Communications Inc.             | NA         |
| COM DEV Satellite Communications Ltd              | NA         |
| Kingston Communications International Limited     | NA         |
| MCN SAT U.S., Inc.                                | NA         |
| Orion Network Systems                             | NA         |
| STET Società Finanziaria Telefonica per Azioni    | NA         |
| Trans-Atlantic Satellite, Inc.                    | NA         |
| General Dynamics Commercial Launch Services, Inc. | NA         |

### Market
High barriers to entry, substantial investment requirements, regulatory changes affecting operations, technical coordination challenges with established players, and uncertainty due to deregulation processes

### Cartel Period
1900-01-01 : 1900-01-01

### Key Timeline
| event | actor | predicate object |
| --- | --- | --- |
| 1993-06-28 | parties concerned | notified agreements for creation of International Private Satellite Partners |
| 1994-02-14 | parties concerned | requested extension of notification to Article 53 of the EEA Agreement |
| 1994-12-15 | Commission of the European Communities | issued decision relating to proceeding under Articles 85 and 53 |

### Legal Framework
Article 85, anticompetitive_agreement

### Infringement Category
anticompetitive_agreement

### Infringement Sub Category
joint venture

### Infringement Gravity
NA

### Exemption
| company                                           |
|:--------------------------------------------------|
| International Private Satellite Partners, L.P.    |
| Orion Satellite Corporation                       |
| STET Società Finanziaria Telefonica per Azioni    |
| Kingston Communications International Limited     |
| COM DEV Satellite Communications Ltd              |
| Matra Aerospace Inc.                              |
| Orion Network Systems                             |
| Trans-Atlantic Satellite, Inc.                    |
| General Dynamics Commercial Launch Services, Inc. |

### Leniency
NA

### Fines
NA

### Remedies
NA

### Company Recidivism
NA

### Case Commission Info Request
True

### Case Commission No Action
True

### Case Commission Decision
True

### Commissioner
Karel VAN MIERT

### Courts
NA

### Book Reference
NA

### Outcome
NA


*(reported: 2026-10-16 20:48:52)*
